"""Collect stock CANN operators with an independent single-kernel identity check."""
import argparse
from collections import Counter
import csv
import hashlib
import json
import math
import os
from pathlib import Path
import subprocess
import sys
import traceback

from collect import compare, describe, digest, run, save, target_range

ROOT = Path(__file__).resolve().parent
MANIFEST = ROOT / "cases.json"


def tensor_metadata(torch_npu, device, host):
    result = describe(host, True)
    result.update(device_stride=list(device.stride()), address_mod_128=device.data_ptr() % 128)
    if hasattr(torch_npu, "get_npu_format"):
        result["npu_format"] = int(torch_npu.get_npu_format(device))
    return result


def application(case, stage, directory):
    import torch
    import torch_npu

    torch.set_num_threads(8)
    torch.npu.set_device(0)
    gen = torch.Generator(device="cpu").manual_seed(
        int.from_bytes(hashlib.sha256(case["id"].encode()).digest()[:8], "little"))
    dtype = getattr(torch, case["dtype"])
    op = case["op"]
    dims = case["shape"]
    if op in ("mm", "bmm"):
        prefix = tuple(dims[:-3])
        m, k, n = dims[-3:]
        shapes = [prefix + (m, k), prefix + (k, n)]
    elif op == "attention":
        b, h, q, k, d = dims
        shapes = [(b,h,q,d), (b,h,k,d), (b,h,k,d)]
    else:
        shapes = [tuple(dims)] * (2 if op == "add" else 1)
    host = [torch.randn(shape, generator=gen).to(dtype) for shape in shapes]
    device = [value.to("npu:0") for value in host]
    # Golden runs on CPU only, and all output validation follows the target.
    high = [value.double() for value in host]
    if op in ("mm", "bmm"):
        launch = lambda: getattr(torch, op)(*device)
        golden = high[0] @ high[1]
    elif op == "attention":
        scale = 1 / math.sqrt(d)
        launch = lambda: torch_npu.npu_fused_infer_attention_score(
            *device, num_heads=h, num_key_value_heads=h, input_layout="BNSD",
            scale=scale, sparse_mode=0, softmax_lse_flag=False)
        golden = torch.softmax((high[0] @ high[1].transpose(-1,-2)) * scale, dim=-1) @ high[2]
    elif op == "add":
        launch = lambda: torch.add(*device)
        golden = high[0] + high[1]
    else:
        assert op == "gelu"
        launch = lambda: torch.nn.functional.gelu(device[0], approximate="none")
        golden = torch.nn.functional.gelu(high[0], approximate="none")
    torch.npu.synchronize()
    answer = None

    def invoke():
        nonlocal answer
        answer = launch()

    if stage == "default":
        target_range(torch, invoke)
    else:
        invoke()
        torch.npu.synchronize()
    if isinstance(answer, tuple):
        out, *auxiliary = answer
    else:
        out, auxiliary = answer, []
    precision = compare(torch, (out,), (golden.to(dtype),), case["family"])
    info = {"status": "passed" if all(x["passed"] for x in precision) else "failed",
            "inputs": [tensor_metadata(torch_npu, d, h) for d,h in zip(device,host,strict=True)],
            "output": dict(describe(out), address_mod_128=out.data_ptr() % 128),
            "auxiliary_outputs": [describe(v) for v in auxiliary], "precision": precision}
    save(directory / f"{stage}.json", info)
    return info["status"] == "passed"


def csv_table(path):
    with path.open(encoding="utf-8-sig", newline="") as stream:
        reader = csv.DictReader(stream)
        return reader.fieldnames, list(reader)


def trace_targets(directory):
    targets = []
    files = sorted((directory/"trace").rglob("op_summary_*.csv"))
    assert files, "no ordinary op_summary"
    for path in files:
        _, rows = csv_table(path)
        for row in rows:
            task_type = row["Task Type"].upper()
            # Preserve all potentially computational tasks, including hidden
            # layout conversions, rather than selecting a convenient kernel.
            if task_type.startswith(("AI_", "AIC", "AIV", "MIX", "HCCL", "DSA", "SDMA")):
                targets.append({k:row.get(k) for k in ("Op Name", "Task Type", "Task ID", "Stream ID",
                                                        "Block Num", "Mix Block Num")})
    return targets, [str(p.relative_to(ROOT)) for p in files]


def capture_table(directory, target):
    files = list((directory/"capture").rglob("OpBasicInfo.csv"))
    assert len(files) == 1, "Default has missing/ambiguous target identity"
    basic, = files
    _, info_rows = csv_table(basic)
    info, = info_rows
    assert info["Op Name"] and info["Device Id"] == "0", info["Op Name"]
    assert info["Op Type"] in ("vector","cube","mix"), info["Op Type"]
    assert int(info["Block Dim"]) == int(target["Block Num"]), (info["Block Dim"], target)
    if info["Op Type"] == "mix":
        assert int(info["Mix Block Dim"]) == int(target["Mix Block Num"]), (info["Mix Block Dim"], target)
    tables = {}
    for path in sorted(basic.parent.glob("*.csv")):
        fields, rows = csv_table(path)
        item = {"path": path.relative_to(ROOT).as_posix(), "sha256": digest(path),
                "fields": fields, "rows": len(rows)}
        if "sub_block_id" in fields:
            keys = {(r["block_id"],r["sub_block_id"]) for r in rows}
            assert len(rows) == len(keys), f"duplicate keys in {path.name}"
            item["sub_block_counts"] = dict(Counter(r["sub_block_id"] for r in rows))
        tables[path.stem] = item
    required = {"OpBasicInfo","ArithmeticUtilization","Memory","MemoryL0","MemoryUB","L2Cache",
                "PipeUtilization","ResourceConflictRatio"}
    assert required <= tables.keys(), sorted(required - tables.keys())
    # Keep family holdouts blind except capture identity, field schema and accuracy.
    identity = {k:info[k] for k in ("Op Name","Op Type","Block Dim","Mix Block Dim","Device Id",
                                    "Pid","Current Freq","Rated Freq")}
    return {"identity":identity,"files":tables,"match":"one ordinary compute task and one cold MSTX capture; block dimensions match",
            "application_operator_name":target["Op Name"]}


def run_case(case):
    directory = ROOT/"cases"/case["id"]
    directory.mkdir(parents=True)
    command = [sys.executable,"-B",__file__,"app",case["id"]]
    rec = {k:case[k] for k in ("id","family","role","shape","dtype")}
    try:
        trace = ["msprof",f"--output={directory/'trace'}","--task-time=on",
                 "--runtime-api=on","--ascendcl=on","--msproftx=on"] + command + ["trace"]
        rec["trace_command"] = trace
        rec["trace_rc"] = run(trace,directory/"trace.log",240)
        assert rec["trace_rc"] == 0, "ordinary trace failed"
        app = json.loads((directory/"trace.json").read_text())
        assert app["status"] == "passed", "ordinary trace output failed accuracy"
        targets, paths = trace_targets(directory)
        rec.update(target_tasks=targets, trace_files=paths)
        if len(targets) != 1:
            rec.update(status="scope_excluded", reason=f"{len(targets)} computational tasks in the single-call trace")
        else:
            default = ["msprof","op",f"--output={directory/'capture'}","--aic-metrics=Default",
                       "--replay-mode=kernel","--mstx=true","--mstx-include=cold_call",
                       "--launch-count=1","--warm-up=5"] + command + ["default"]
            rec["default_command"] = default
            rec["default_rc"] = run(default,directory/"default.log",360)
            assert rec["default_rc"] == 0, "Default collection failed"
            current = json.loads((directory/"default.json").read_text())
            assert current["status"] == "passed", "Default post-replay precision failed"
            assert [v["sha256"] for v in current["inputs"]] == [v["sha256"] for v in app["inputs"]]
            rec["capture"] = capture_table(directory,targets[0])
            rec["status"] = "admitted"
    except Exception as e:
        rec.update(status="failed", reason=f"{type(e).__name__}: {e}")
    save(directory/"result.json",rec)
    return rec


def batch(manifest, phase):
    version = subprocess.check_output(["msprof","op","--version"],text=True)
    device = subprocess.check_output(["npu-smi","info"],text=True)
    assert manifest["profiler_build"] in version and manifest["device_bus"] in device
    assert "Ascend950PR" in device and os.environ["ASCEND_HOME_PATH"].endswith("/cann-9.2.1")
    packages = subprocess.check_output([sys.executable,"-c",
        'from importlib.metadata import version;print(version("torch"),version("torch-npu"))'],text=True).strip()
    assert packages == "2.13.0+cpu 2.13.0", packages
    save(ROOT/"environment.json",{"device":device,"profiler":version,"packages":packages,
        "cann":os.environ["ASCEND_HOME_PATH"],"manifest_sha256":digest(MANIFEST)})
    path = ROOT/"progress.json"
    if phase == "pilot":
        assert not path.exists()
        result = {"status":"running","cases":[]}
    else:
        result = json.loads(path.read_text())
        assert result["status"] == "pilot_finished"
        result["status"] = "running"
    eligible = {c["family"] for c in result["cases"] if c["status"] in ("admitted","scope_excluded")}
    save(path,result)
    for case in manifest["cases"]:
        if case["pilot"] != (phase == "pilot"):
            continue
        if phase == "remaining" and case["family"] not in eligible:
            rec = {k:case[k] for k in ("id","family","role","shape","dtype")}
            rec.update(status="skipped",reason="family pilot failed")
        else:
            rec = run_case(case)
        result["cases"].append(rec)
        save(path,result)
        print(case["id"],rec["status"],rec.get("reason",""),flush=True)
    result["status"] = "pilot_finished" if phase == "pilot" else "finished"
    save(path,result)


def main():
    manifest = json.loads(MANIFEST.read_text())
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="command",required=True)
    app = sub.add_parser("app")
    app.add_argument("case")
    app.add_argument("stage",choices=("trace","default"))
    runner = sub.add_parser("batch")
    runner.add_argument("phase",choices=("pilot","remaining"))
    args = parser.parse_args()
    if args.command == "batch":
        batch(manifest,args.phase)
        return
    case = next(x for x in manifest["cases"] if x["id"] == args.case)
    directory = ROOT/"cases"/args.case
    try:
        passed = application(case,args.stage,directory)
    except Exception:
        save(directory/f"{args.stage}.json",{"status":"failed","error":traceback.format_exc()})
        raise
    raise SystemExit(0 if passed else 2)


if __name__ == "__main__":
    main()

