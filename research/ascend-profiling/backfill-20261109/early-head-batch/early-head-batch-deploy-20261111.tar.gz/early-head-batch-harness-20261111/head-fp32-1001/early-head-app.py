"""Reproduce a frozen mHC head call and record source, inputs and result."""
import hashlib,json,os,sys,traceback
from pathlib import Path
import collect,library
root=Path(__file__).resolve().parent;out=Path(sys.argv[1]);pid=os.getpid();record=out/f'application-{pid}.json';state={'status':'running','pid':pid}
def save():record.write_text(json.dumps(state,indent=2)+'\n',encoding='utf8')
try:
 import torch,torch_npu
 from tile_kernels.config import get_num_vec_cores
 from tile_kernels.mhc import head_compute_mix_asc
 from tile_kernels.mhc.head_compute_mix_kernel import _get_ascend_token_block_size
 torch.set_num_threads(4);torch.npu.set_device(0);case=json.loads((root/'case.json').read_text());assert collect.digest(Path(head_compute_mix_asc.__file__))==case['expert_source_sha256']
 seed=int.from_bytes(hashlib.sha256(case['seed_key'].encode()).digest()[:8],'little');rng=torch.Generator(device='cpu').manual_seed(seed);dtype=getattr(torch,case['dtype'])
 host=[torch.randn(case['shape'],generator=rng).to(dtype)];host.extend([torch.randn(shape,generator=rng) for shape in ((1,),(4,))]);device=[v.to('npu:0') for v in host]
 expected=(torch.sigmoid(host[0].double()*host[1].double()+host[2].double())+0.01).to(dtype);output=torch.empty_like(expected,device='npu:0');assert get_num_vec_cores()==56
 kernel=head_compute_mix_asc.mhc_head_compute_mix_fwd_asc.compile(*device,output,0.01,token_block_size=_get_ascend_token_block_size(len(expected),4),num_vec_cores=56)
 source=kernel.get_kernel_source();sf=out/f'generated-kernel-{pid}.cpp';sf.write_text(source)
 state.update(runtime_kernel=str(kernel.prim_func.attrs['global_symbol'])+'_kernel',source_sha256=hashlib.sha256(source.encode()).hexdigest(),inputs=[library.tensor_metadata(torch_npu,d,h) for d,h in zip(device,host,strict=True)],output_address=hex(output.data_ptr()))
 collect.target_range(torch,lambda:kernel(*device,output));accuracy=collect.compare(torch,(output,),(expected,),case['family']);actual=output.cpu();bad=int((~torch.isclose(actual,expected,rtol=2**-13,atol=2e-5,equal_nan=False)).sum())
 state.update(output=dict(collect.describe(actual,True),address_mod_128=output.data_ptr()%128),precision=accuracy,post_reference_mismatch_elements=bad);assert all(x['passed'] for x in accuracy) and bad==0
 state['status']='passed';save()
except BaseException:
 state.update(status='failed',error=traceback.format_exc());save();raise
