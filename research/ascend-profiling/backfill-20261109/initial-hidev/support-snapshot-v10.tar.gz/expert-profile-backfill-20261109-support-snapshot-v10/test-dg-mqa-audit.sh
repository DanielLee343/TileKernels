#!/usr/bin/env bash
set -Eeuo pipefail
echo __DG_MQA_AUDIT_TEST_BEGIN__
root=/workspace/expert-profile-backfill-20261109-hidev
tmp=$(mktemp -d "$root/dg-mqa-audit-test.XXXXXXXX");trap 'rm -rf -- "$tmp"' EXIT
case_id=mqa-0-q16-k512-h8-random;base="deepgemm-runs/$case_id/hidev-npu0/attempt-002"
mkdir -p "$tmp/$(dirname "$base")";cp -a "$root/$base" "$tmp/$base";cp "$root/audit-reduce-family.py" "$tmp/";export BACKFILL_ROOT="$tmp"
run_audit(){ python3 -B "$root/audit-dg-mqa-candidate.py" "$case_id" attempt-002; }
run_audit
p="$tmp/$base";cp "$p/detail/profile.log" "$tmp/profile.log";cp "$p/profile-addresses.json" "$tmp/addresses.json";cp "$p/mqa-range-end.bin" "$tmp/end.bin"
python3 - "$p/detail/profile.log" <<'PY'
from pathlib import Path
import sys
p=Path(sys.argv[1]);lines=p.read_text().splitlines(keepends=True);i=next(i for i,s in enumerate(lines) if 'DBI record core:' in s and 'dst:(type:GM;' in s and 'src:(type:UB;' in s);del lines[i];p.write_text(''.join(lines))
PY
if run_audit > "$tmp/missing.out" 2>&1;then echo MISSING_STORE_UNDETECTED;exit 1;fi
cp "$tmp/profile.log" "$p/detail/profile.log"
mem=$(find "$p/detail/capture" -name Memory.csv -print -quit);cp "$mem" "$tmp/memory.csv"
python3 - "$mem" <<'PY'
from pathlib import Path
import csv,io,sys
p=Path(sys.argv[1]);r=csv.DictReader(io.StringIO(p.read_text(encoding='utf-8-sig')));rows=list(r)
row=next(x for x in rows if x['sub_block_id']=='vector1' and x['UB_to_GM_datas(KB)'] not in ('NA',''));row['UB_to_GM_datas(KB)']=str(float(row['UB_to_GM_datas(KB)'])+1)
with p.open('w',encoding='utf8',newline='') as f:w=csv.DictWriter(f,fieldnames=r.fieldnames);w.writeheader();w.writerows(rows)
PY
if run_audit > "$tmp/csv.out" 2>&1;then echo WRONG_CSV_UNDETECTED;exit 1;fi
cp "$tmp/memory.csv" "$mem"
python3 - "$p/mqa-range-end.bin" <<'PY'
from pathlib import Path
import sys
p=Path(sys.argv[1]);b=bytearray(p.read_bytes());b[0]^=1;p.write_bytes(b)
PY
if run_audit > "$tmp/range.out" 2>&1;then echo WRONG_RANGE_UNDETECTED;exit 1;fi
cp "$tmp/end.bin" "$p/mqa-range-end.bin"
python3 - "$p/profile-addresses.json" <<'PY'
from pathlib import Path
import json,sys
p=Path(sys.argv[1]);d=json.loads(p.read_text());d[0]['returned']['address']=d[0]['args'][0][0]['address'];p.write_text(json.dumps(d))
PY
if run_audit > "$tmp/alias.out" 2>&1;then echo INPUT_ALIAS_UNDETECTED;exit 1;fi
echo 'PASS rejects missing store, altered vector CSV, modified range input and input/output alias'
echo __DG_MQA_AUDIT_TEST_END__
