#!/usr/bin/env bash
set -Eeuo pipefail
root=/workspace/expert-profile-backfill-20261109-hidev
q="$root/deepgemm-mqa-queue-hidev-npu0";mkdir -p "$q"
trap 'rc=$?;printf "exit=%s at=%s\n" "$rc" "$(date -u +%FT%TZ)" > "$q/exit.txt"' EXIT
grep -q 'PASS rejects missing store, altered vector CSV, modified range input and input/output alias' "$root/dg-mqa-test.log"
previous="$root/extra-norm-accum-app-smoke-hidev-npu0";pid=$(cat "$previous/pid")
while ps -p "$pid" -o args= | grep -Fq "$root/orchestrate-norm-accum-app-smoke.sh";do sleep 10;done
python3 -B "$root/hidev-dg-mqa-queue.py"
