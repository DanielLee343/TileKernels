#!/usr/bin/env bash
set -Eeuo pipefail
root=/workspace/expert-profile-backfill-20261109-hidev;previous="$root/extra-norm-forward-queue-hidev-npu0"
q="$root/extra-swiglu-variants-smoke-hidev-npu0";mkdir -p "$q"
trap 'rc=$?; printf "exit=%s at=%s\n" "$rc" "$(date -u +%FT%TZ)" > "$q/exit.txt"' EXIT
pid=$(cat "$previous/pid")
while ps -p "$pid" -o args= | grep -Fq "$root/hidev-extra-norm-forward-queue.py";do sleep 10;done
for n in 02 07 08;do
 export TARGET_ID="unified-extra3/quant_swiglu_forward-$n" ATTEMPT=attempt-001
 bash "$root/run-hidev-extra-swiglu-forward-detail.sh"
 python3 -B "$root/inspect-extra-swiglu-forward.py" "$TARGET_ID" "$ATTEMPT"
 echo "$TARGET_ID identity smoke complete; address audit pending"
done
