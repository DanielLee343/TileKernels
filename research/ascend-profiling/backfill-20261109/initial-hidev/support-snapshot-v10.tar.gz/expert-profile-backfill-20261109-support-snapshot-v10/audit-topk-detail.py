"""Verify TopK output stores against source-derived per-token/block addresses."""
import csv,hashlib,json,os,re,subprocess,sys
from collections import Counter
from decimal import Decimal
from pathlib import Path
from importlib.machinery import SourceFileLoader
root=Path(os.environ.get('BACKFILL_ROOT',str(Path.home()/'expert-profile-backfill-20261109')))
R=SourceFileLoader('reduce_audit',str(root/'audit-reduce-family.py')).load_module().REGEX
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):
 with p.open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def main():
 case,device,attempt=sys.argv[1:];assert re.fullmatch(r'topk-(0[1-9]|1[0-9]|20)',case) and device=='0'
 p=root/'topk-runs'/case/'hidev-npu0'/attempt/'detail'
 app=json.loads((p/'metadata/application.json').read_text());hist=json.loads((root/'topk-history'/case/'default.json').read_text())
 mon=json.loads((p/'monitor-summary.json').read_text());assert app['status']=='passed' and app['visible_devices']==device and mon['status']=='passed' and mon['max_seconds_between_successful_queries']<=3
 for key in ('runtime_kernel','inputs','outputs'):assert app[key]==hist[key],key
 src=p/'metadata/default-kernel.cpp';assert sha(src)==app['source_sha256'];code=src.read_text()
 historical=root/'topk-history'/case/'default-kernel.cpp'
 assert sha(historical)==hist['source_sha256']
 old_code=historical.read_text()
 # Only the embedded diagnostic path changed when the same checkout moved.
 old_path=r'\/workspace\/tilekernels-env-20261101\/src\/TileKernels\/'
 new_path=r'\/workspace\/tilekernels-env-20261101\/src\/TileKernels-private\/'
 assert old_code.replace(old_path,new_path)==code, 'generated source differs beyond checkout path'
 caseobj=app['case'];n=caseobj['tokens'];k=caseobj['topk'];width=k*8
 assert caseobj['family']=='moe_topk_gate' and app['outputs'][0]['shape']==[n,k] and app['outputs'][0]['dtype']=='int64'
 assert code.count('asc_copy_ub2gm_align(')==1 and '((w * 56) + ((int32_t)block_idx)) < num_tokens' in code
 line=next(s for s in code.splitlines() if 'asc_copy_ub2gm_align(' in s)
 assert f'(int64_t){112*k}' in line and f'(int64_t){2*k}' in line and re.search(r',\s*1,\s*'+str(width)+r',\s*static_cast<asc_store_l2_cache_mode>',line)
 op,=list((p/'capture').rglob('OpBasicInfo.csv'));basic,=read(op)
 assert basic['Op Name']==app['runtime_kernel'] and basic['Op Type']=='vector' and basic['Block Dim']=='56' and basic['Device Id']==device
 binary=op.parent/'dump/aicore_binary.o';bsha=sha(binary)
 assert any(x.startswith(bsha+' ') and x.rstrip().endswith('/kernel.aibin') for x in (p/'cache-sha256.txt').read_text().splitlines())
 objdump=os.environ['BACKFILL_OBJDUMP'];isa=subprocess.check_output([objdump,'-d',str(binary)],text=True);(p/'device-kernel.isa').write_text(isa)
 raw=(p/'profile.log').read_text(errors='replace');stores=[x for x in raw.splitlines() if 'DBI record core:' in x and 'dst:(type:GM;' in x and 'src:(type:UB;' in x]
 rec=R.findall(raw);assert len(stores)==len(rec)==n,(len(stores),len(rec),n)
 base=int(app['device_output_addresses'][0],16);hits=Counter();blocks=Counter();rounded_blocks=Counter();pcs=set()
 for c,pc,addr,stride,l1s,l2s,srcaddr,srcstride,srcl1s,srcl2s,burst,length,dtype,l1,l2,left,right in rec:
  c=int(c);row,rem=divmod(int(addr,16)-base,width);assert 0<=row<n and rem==0
  assert (int(burst),int(length),int(l1),int(l2),int(left),int(right))==(1,width,1,1,0,0)
  block=row%56;assert (c//3,c%3)==divmod(block,2)
  hits[row]+=1;blocks[block]+=width;rounded_blocks[block]+=((width+31)//32)*32;pcs.add(int(pc,16))
 assert hits==Counter(range(n))
 for pc in pcs:assert any(re.match(r'^\s*'+format(pc,'x')+r':',line) and 'MOV_UB_TO_OUT' in line for line in isa.splitlines())
 mem=read(op.with_name('Memory.csv'));assert len(mem)==56
 for i,row in enumerate(mem):
  assert int(row['block_id'])==i and row['sub_block_id']=='vector0'
  value=row['UB_to_GM_datas(KB)'];expected=rounded_blocks[2*i]+rounded_blocks[2*i+1] if i<28 else None
  # For this TopK family each address record is one burst. Compare CSV with
  # the empirically observed per-burst 32-byte rounded total; keep requested
  # bytes separately. Do not generalize this to other instructions/kernels.
  # Memory.csv is printed to six fractional KiB digits.
  if i<28 and value not in ('NA',''):assert abs(Decimal(value)*1024-expected)<=Decimal('0.000512')
  elif i<28:assert expected==0
  else:assert value in ('NA','')
 result={'target':'second/'+case,'status':'passed','device':'hidev NPU 0','correctness':'passed',
  'historical_input_and_source_match':True,'source_comparison':'exact after substituting the diagnostic checkout path','runtime_kernel':basic['Op Name'],'dbi_requested_bytes':sum(blocks.values()),
  'output_logical_bytes':n*width,'per_vector_block_requested_bytes':{i:blocks[i] for i in range(56)},
  'capture_binary_sha256':bsha,'dbi_pc':[hex(x) for x in sorted(pcs)],'csv_pair_totals_match':True,
  'csv_comparison':'empirical per-burst 32-byte rounded totals for this TopK output store, not requested bytes',
  'csv_per_pair_rounded_bytes':{i:rounded_blocks[2*i]+rounded_blocks[2*i+1] for i in range(28)},
  'scope':'one MemoryDetail window; requested UB to GM bytes, not physical DRAM transactions',
  'max_seconds_between_successful_device_queries':mon['max_seconds_between_successful_queries']}
 (p/'audit-result.json').write_text(json.dumps(result,indent=2)+'\n');print('PASS',case,sum(blocks.values()))
if __name__=='__main__':main()
