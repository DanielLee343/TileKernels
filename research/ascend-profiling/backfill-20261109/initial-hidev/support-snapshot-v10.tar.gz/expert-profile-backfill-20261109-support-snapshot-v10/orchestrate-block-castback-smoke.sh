#!/usr/bin/env bash
set -Eeuo pipefail
root=/workspace/expert-profile-backfill-20261109-hidev;previous="$root/classic-castback-smoke-hidev-npu0"
q="$root/extra-block-castback-smoke-hidev-npu0";mkdir -p "$q"
trap 'rc=$?; printf "exit=%s at=%s\n" "$rc" "$(date -u +%FT%TZ)" > "$q/exit.txt"' EXIT
pid=$(cat "$previous/pid")
while ps -p "$pid" -o args= | grep -Fq "$root/orchestrate-classic-castback-smoke.sh";do sleep 10;done
export TARGET_ID=unified-extra2/quant_cast_back_block-01 ATTEMPT=attempt-001
bash "$root/run-hidev-extra-block-castback-detail.sh"
python3 -B "$root/inspect-extra-block-castback.py" "$TARGET_ID" "$ATTEMPT"
python3 -B "$root/audit-extra-block-castback.py" quant_cast_back_block-01 "$ATTEMPT"
echo 'candidate audit complete; negative tests and independent acceptance remain required'
