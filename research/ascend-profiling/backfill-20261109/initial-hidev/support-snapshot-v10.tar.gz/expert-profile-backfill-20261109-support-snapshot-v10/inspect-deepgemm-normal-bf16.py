"""Verify capture identity/correctness; report raw DBI events without assigning core roles."""
import hashlib,importlib.util,json,re,shutil,sys
from pathlib import Path
root=Path('/workspace/expert-profile-backfill-20261109-hidev');case=sys.argv[1];attempt=sys.argv[2]
out=root/'deepgemm-runs'/case/'hidev-npu0'/attempt
harness=root/'deepgemm-normal-bf16-harness';collector=harness/'campaign-13/collect.py'
spec=importlib.util.spec_from_file_location('deepgemm_capture',collector);mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
manifest=json.loads((harness/'campaign-13/cases.json').read_text());selected=[x for x in manifest['cases'] if x['id']==case];assert len(selected)==1
a=json.loads((out/'prepare.json').read_text());b=json.loads((out/'profile.json').read_text());old=json.loads((harness/'history'/case/'profile.json').read_text())
assert a['status']==b['status']==old['status']=='passed' and a['target_input']==b['target_input']
current=b['target_input'];previous=old['target_input'];output_prestate=None
if case=='gemm-fp4fp4-nn-mn-m64-n576-k7168':
 # The historical collector snapshots the zero-initialized output before the
 # five warmups; the present collector snapshots it after those warmups.
 # This non-accumulating GEMM overwrites argument 2. Its shape/layout still
 # must match, and all actual input data and kwargs must match exactly.
 assert len(current['args'])==len(previous['args'])==3
 assert current['args'][:2]==previous['args'][:2] and current['kwargs']==previous['kwargs']
 assert 'c' not in current['kwargs'] and 'accumulate' not in current['kwargs']
 now_out=dict(current['args'][2]);old_out=dict(previous['args'][2])
 now_hash=now_out.pop('sha256');old_hash=old_out.pop('sha256')
 assert now_out==old_out and old_out['shape']==[64,576] and old_out['dtype']=='torch.bfloat16'
 assert old_hash==hashlib.sha256(bytes(64*576*2)).hexdigest()
 output_prestate={'historical_sha256':old_hash,'current_sha256':now_hash,
                  'reason':'historical snapshot before warmups; current snapshot after warmups; output is overwritten, no accumulation'}
else:
 assert current==previous
capture=mod.inspect_profile(selected[0],out/'detail/capture',root/'deepgemm-cache'/case)
log=(out/'detail/profile.log').read_text(errors='replace');mod.validate_profiler_log(log)
addresses=json.loads((out/'profile-addresses.json').read_text());assert len(addresses)==1
jit=Path(capture['jit_directory']);dst=out/'jit';dst.mkdir(exist_ok=True)
for name in ('kernel.asc','kernel.o','meta.json'):
 if (jit/name).exists():shutil.copy2(jit/name,dst/name)
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
original=harness/'history'/case/'kernel.asc'
source_matches=original.exists() and digest(original)==digest(jit/'kernel.asc')
events=[x for x in log.splitlines() if 'DBI record core:' in x]
stores=[x for x in events if 'dst:(type:GM;' in x and 'src:(type:UB;' in x]
cores=sorted({int(m.group(1)) for line in stores if (m:=re.search(r'DBI record core:(\d+)',line))})
result={'case':case,'status':'identity_checked_address_audit_pending','correctness':'passed',
 'historical_true_inputs_match':True,'output_prestate':output_prestate,'capture':capture,'historical_jit_source_sha256_match':source_matches,
 'all_dbi_records':len(events),'ub_to_gm_records':len(stores),'raw_store_core_labels':cores,
 'limitation':'raw DBI core labels are not yet mapped to AIV block roles; absence of records is not established zero',
 'health_before':(out/'provenance/health-before.txt').read_text().strip(),
 'health_after':(out/'provenance/health-after.txt').read_text().strip()}
(out/'capture-inspection.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
