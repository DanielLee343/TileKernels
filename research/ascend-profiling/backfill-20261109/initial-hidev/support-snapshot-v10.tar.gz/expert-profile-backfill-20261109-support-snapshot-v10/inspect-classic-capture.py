"""Identify a capture; intentionally does not claim complete address coverage."""
import csv,hashlib,json,os,re,sys
from pathlib import Path
root=Path(os.environ['BACKFILL_ROOT']);repo=Path('/workspace/tilekernels-env-20261101/src/TileKernels-private')
target,attempt=sys.argv[1:];batch,case=target.split('/');items=json.loads((root/'classic-pending.json').read_text());item,=(x for x in items if x['target']==target)
p=root/'classic-runs'/batch/case/'hidev-npu0'/attempt/'detail';a=json.loads((p/'metadata/application.json').read_text());old_path=repo/item['metadata_repo_path'];old=json.loads(old_path.read_text())
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
assert sha(old_path)==item['metadata_sha256'] and old['source_sha256']==item['source_sha256']
assert a['status']==old['status']=='passed' and a['visible_devices']=='0'
for key in ('runtime_kernel','inputs','outputs'):assert a[key]==old[key],key
assert a['runtime_kernel']==item['kernel']
new_source=p/'metadata/default-kernel.cpp';old_source=old_path.parent/'default-kernel.cpp'
assert sha(new_source)==a['source_sha256'] and sha(old_source)==old['source_sha256']
old_text=old_source.read_text().replace(r'\/workspace\/tilekernels-env-20261101\/src\/TileKernels\/',r'\/workspace\/tilekernels-env-20261101\/src\/TileKernels-private\/')
assert new_source.read_text()==old_text,'generated source differs beyond embedded checkout path'
m=json.loads((p/'monitor-summary.json').read_text());assert m['status']=='passed' and m['max_seconds_between_successful_queries']<=3
op,=list((p/'capture').rglob('OpBasicInfo.csv'))
with op.open(encoding='utf-8-sig',newline='') as f:basic,=list(csv.DictReader(f))
assert basic['Op Name']==item['kernel'] and basic['Device Id']=='0';mem=op.with_name('Memory.csv');assert mem.is_file()
binary=op.parent/'dump/aicore_binary.o';bsha=sha(binary)
assert any(s.startswith(bsha+' ') and s.rstrip().endswith('/kernel.aibin') for s in (p/'cache-sha256.txt').read_text().splitlines())
log=(p/'profile.log').read_text(errors='replace');stores=[x for x in log.splitlines() if 'DBI record core:' in x and 'dst:(type:GM;' in x and 'src:(type:UB;' in x]
metrics=re.findall(r'processedRecord: (\d+), droppedRecord: (\d+).*?memoryCorruption (\d+)',log)
out={'target':target,'status':'capture_identified_address_audit_pending','correctness':'passed','historical_true_inputs_and_source_match':True,
 'source_comparison':'exact after substituting the diagnostic checkout path','capture_binary_sha256':bsha,
 'raw_ub_to_gm_events':len(stores),'parser_metrics':metrics,'reason':'source-specific output coverage, dynamic core mapping and per-core request totals require independent audit',
 'detail_path':str(p)}
(p/'capture-inspection.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
