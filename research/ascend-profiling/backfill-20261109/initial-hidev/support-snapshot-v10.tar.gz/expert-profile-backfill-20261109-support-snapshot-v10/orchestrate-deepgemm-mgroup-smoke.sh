#!/usr/bin/env bash
set -Eeuo pipefail
root=/workspace/expert-profile-backfill-20261109-hidev;previous="$root/deepgemm-paged-meta-smoke-hidev-npu0"
q="$root/deepgemm-mgroup-smoke-hidev-npu0";mkdir -p "$q"
trap 'rc=$?; printf "exit=%s at=%s\n" "$rc" "$(date -u +%FT%TZ)" > "$q/exit.txt"' EXIT
pid=$(cat "$previous/pid")
while ps -p "$pid" -o args= | grep -Fq "$root/orchestrate-deepgemm-paged-meta-smoke.sh";do sleep 10;done
export CASE_ID=mgroup-fp8fp8-nt-g4-m128-n256-k512 ATTEMPT=attempt-001
bash "$root/run-hidev-deepgemm-mgroup.sh"
python3 -B "$root/inspect-deepgemm-mgroup.py" "$CASE_ID" "$ATTEMPT"
echo 'identity smoke complete; grouped output coverage audit remains required'
