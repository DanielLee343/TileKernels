"""Index transform audits and raw evidence hashes without modifying attempts."""
import hashlib,json,time
from pathlib import Path
root=Path('/workspace/expert-profile-backfill-20261109-hidev');cases=[]
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for chunk in iter(lambda:f.read(1024*1024),b''):h.update(chunk)
 return h.hexdigest()
for audit in sorted((root/'deepgemm-runs').glob('transform-*/hidev-npu0/attempt-*/address-audit.json')):
 p=audit.parent;a=json.loads(audit.read_text());assert a['status']=='passed' and a['correctness']=='passed'
 assert a['historical_target_input_and_jit_source_match'] and a['dbi_requested_bytes']==a['output_bytes']
 files=[audit,p/'prepare.json',p/'profile.json',p/'profile-addresses.json',p/'capture-inspection.json',p/'device-kernel.isa',
        p/'jit/kernel.asc',p/'jit/kernel.o',p/'detail/profile.log',p/'detail/monitor-summary.json',p/'detail/command.json',
        p/'provenance/health-before.txt',p/'provenance/health-after.txt']
 files+=list((p/'detail/capture').rglob('OpBasicInfo.csv'))+list((p/'detail/capture').rglob('Memory.csv'))
 assert all(x.is_file() for x in files)
 hashes={str(x.relative_to(root)):sha(x) for x in files}
 cases.append({'case':a['case'],'audit':a,'raw_dir':str(p),'files_sha256':hashes,'health':'Alarm 8C4BA00C'})
out={'created_unix':time.time(),'count':len(cases),'cases':cases,'scope':'one independent MemoryDetail window per case; requests, not physical main-memory writes'}
(root/'deepgemm-transform-index.json').write_text(json.dumps(out,indent=2)+'\n')
print('indexed',len(cases),'transform captures')
