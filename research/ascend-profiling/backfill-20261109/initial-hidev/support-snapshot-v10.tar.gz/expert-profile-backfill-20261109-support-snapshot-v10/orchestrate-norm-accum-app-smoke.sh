#!/usr/bin/env bash
set -Eeuo pipefail
root=/workspace/expert-profile-backfill-20261109-hidev
q="$root/extra-norm-accum-app-smoke-hidev-npu0";mkdir -p "$q"
trap 'rc=$?;printf "exit=%s at=%s\n" "$rc" "$(date -u +%FT%TZ)" > "$q/exit.txt"' EXIT
previous="$root/extra-engram-gate-bwd-mask-smoke-hidev-npu0";pid=$(cat "$previous/pid")
while ps -p "$pid" -o args= | grep -Fq "$root/orchestrate-engram-gate-bwd-mask-smoke.sh";do sleep 10;done
export TARGET_ID=unified-extra3/quant_norm_backward-08 ATTEMPT=attempt-001
bash "$root/run-hidev-extra-norm-accum-app.sh"
echo NORM_ACCUM_APPLICATION_CAPTURE_REPLAY_STATE_AND_ADDRESS_AUDIT_PENDING
