"""Audit the one-core paged MQA metadata UB-to-GM output request."""
import csv,hashlib,json,os,re,subprocess,sys
from decimal import Decimal
from importlib.machinery import SourceFileLoader
from pathlib import Path
root=Path(os.environ.get('BACKFILL_ROOT','/workspace/expert-profile-backfill-20261109-hidev'))
case,attempt=sys.argv[1:];assert re.fullmatch(r'paged[-_a-zA-Z0-9]+',case)
p=root/'deepgemm-runs'/case/'hidev-npu0'/attempt
ident=json.loads((p/'capture-inspection.json').read_text());assert ident['correctness']=='passed' and ident['historical_true_inputs_match'] and ident['historical_jit_source_sha256_match']
mon=json.loads((p/'detail/monitor-summary.json').read_text());assert mon['status']=='passed' and mon['max_seconds_between_successful_queries']<=3
addr,=json.loads((p/'profile-addresses.json').read_text());out=addr['returned'];assert out['dtype']=='torch.int32' and len(out['shape'])==2 and out['shape'][1]==2 and out['stride']==[2,1]
wrapper=(p/'jit/kernel.asc').read_text();m=re.search(r'paged_mqa_logits_metadata_simt_impl<\s*\d+\s*,\s*\d+\s*,\s*(\d+)\s*>',wrapper);assert m
cores=int(m.group(1));size=(cores+1)*2*4;assert out['shape']==[cores+1,2] and out['element_size']==4
src_repo=Path('/workspace/deepgemm-ascend-20261107/source');rel='deep_gemm/include/deep_gemm/paged_mqa_logits_metadata.hpp';src=src_repo/rel
assert subprocess.check_output(['git','-C',str(src_repo),'rev-parse','HEAD'],text=True).strip()=='3a35326271b069b8b5bf1a754435acd6cc91575b'
assert subprocess.check_output(['git','-C',str(src_repo),'hash-object',str(src)],text=True).strip()==subprocess.check_output(['git','-C',str(src_repo),'rev-parse','HEAD:'+rel],text=True).strip()
code=src.read_text();assert 'if (block_idx != 0)' in code and 'asc_copy_ub2gm_align(metadata, metadata_ub, 1, (kNumCores + 1) * 2 * sizeof(uint32_t)' in code
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
op,=list((p/'detail/capture').rglob('OpBasicInfo.csv'))
def read(path):
 with path.open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
basic,=read(op);assert basic['Op Type']=='vector' and basic['Block Dim']=='1' and basic['Device Id']=='0' and 'paged_mqa_logits_metadata_simt_impl' in basic['Op Name']
binary=op.parent/'dump/aicore_binary.o';assert sha(binary)==ident['capture']['jit_binary_sha256']==sha(p/'jit/kernel.o')
tool='/workspace/tilekernels-env-20261101/cann/cann-9.2.1/tools/bisheng_compiler/bin/llvm-objdump'
isa=subprocess.check_output([tool,'-d',str(binary)],text=True);(p/'device-kernel.isa').write_text(isa)
assert not re.search(r'\bSTG\b',isa)
raw=(p/'detail/profile.log').read_text(errors='replace');stores=[x for x in raw.splitlines() if 'DBI record core:' in x and 'dst:(type:GM;' in x and 'src:(type:UB;' in x]
R=SourceFileLoader('r',str(root/'audit-reduce-family.py')).load_module().REGEX;events=R.findall(raw);assert len(stores)==len(events)==1
metrics=re.findall(r'processedRecord: (\d+), droppedRecord: (\d+).*?memoryCorruption (\d+)',raw);assert metrics and all(d=='0' and m=='0' for _,d,m in metrics)
c,pc,dst,stride,l1s,l2s,src,srcstride,srcl1s,srcl2s,burst,length,dtype,l1,l2,left,right=events[0]
assert int(c)==0 and int(dst,16)==int(out['address'],16) and int(burst)==1 and int(length)==size
assert int(l1)==int(l2)==0 and int(left)==int(right)==0
assert any(re.match(r'^\s*'+format(int(pc,16),'x')+r':',line) and 'MOV_UB_TO_OUT' in line for line in isa.splitlines())
mem,=read(op.with_name('Memory.csv'));assert mem['block_id']=='0' and mem['sub_block_id']=='vector0'
rounded=(size+31)//32*32;assert abs(Decimal(mem['UB_to_GM_datas(KB)'])*1024-rounded)<=Decimal('0.000512')
result={'case':'campaign-13/'+case,'target':'paged_mqa_logits_metadata_simt_impl','status':'passed','device':'hidev NPU 0',
 'device_health':'Alarm 8C4BA00C','correctness':'passed','historical_true_inputs_and_jit_source_match':True,
 'output_shape':out['shape'],'output_bytes':size,'dbi_requested_bytes':size,'per_vector_block_requested_bytes':{'0':size},
 'capture_binary_sha256':sha(binary),'dbi_pc':[pc],'csv_rounded_bytes':rounded,
 'scope':'one vector-core MemoryDetail window; UB to GM request bytes; not physical DRAM transactions'}
Path(os.environ.get('AUDIT_OUTPUT',str(p/'address-audit.json'))).write_text(json.dumps(result,indent=2)+'\n');print('PASS',case,size)
