"""Audit a transform_sf output; reject layouts or traffic not independently covered."""
import bisect,csv,hashlib,itertools,json,math,os,re,subprocess,sys
from collections import Counter
from decimal import Decimal
from importlib.machinery import SourceFileLoader
from pathlib import Path
root=Path(os.environ.get('BACKFILL_ROOT','/workspace/expert-profile-backfill-20261109-hidev'));case,attempt=sys.argv[1:]
assert re.fullmatch(r'transform-[a-z0-9-]+',case)
p=root/'deepgemm-runs'/case/'hidev-npu0'/attempt
inspection=json.loads((p/'capture-inspection.json').read_text())
assert inspection['correctness']=='passed' and inspection.get('historical_true_inputs_match',inspection.get('historical_target_input_match')) is True and inspection['historical_jit_source_sha256_match']
mon=json.loads((p/'detail/monitor-summary.json').read_text());assert mon['status']=='passed' and mon['max_seconds_between_successful_queries']<=3
addr,=json.loads((p/'profile-addresses.json').read_text());out=addr['returned']
shape=out['shape'];stride=out['stride'];size=out['element_size'];base=int(out['address'],16)
assert shape and len(shape)==len(stride) and all(x>0 for x in shape) and all(x>=0 for x in stride)
axis=next(i for i,s in enumerate(stride) if s==1)
other=[i for i in range(len(shape)) if i!=axis];assert math.prod(shape[i] for i in other)<=1000000
def merge(intervals):
 out=[]
 for lo,hi in sorted(intervals):
  assert lo<hi
  if out and lo<out[-1][1]:raise AssertionError(('overlap',lo,hi,out[-1]))
  if out and lo==out[-1][1]:out[-1]=(out[-1][0],hi)
  else:out.append((lo,hi))
 return out
expected=[]
for coords in itertools.product(*(range(shape[i]) for i in other)):
 lo=base+size*sum(c*stride[i] for c,i in zip(coords,other));expected.append((lo,lo+shape[axis]*size))
expected=merge(expected);starts=[x[0] for x in expected]
def sha(x):return hashlib.sha256(x.read_bytes()).hexdigest()
def read(path):
 with path.open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
op,=list((p/'detail/capture').rglob('OpBasicInfo.csv'));basic,=read(op)
assert basic['Op Type']=='vector' and basic['Block Dim']=='56' and basic['Device Id']=='0' and 'transform_sf' in basic['Op Name']
header=Path('/workspace/deepgemm-ascend-20261107/source/deep_gemm/include/deep_gemm/transform_sf.hpp');code=header.read_text()
assert 'const uint32_t num_blocks_per_core = ceil_div(num_blocks, kNumCores);' in code
assert 'const uint32_t block_begin = block_idx * num_blocks_per_core;' in code and 'copy_ub_to_gm(dst_gm + dst_offset' in code
repo=header.parents[3];blob=subprocess.check_output(['git','-C',str(repo),'hash-object',str(header)],text=True).strip()
committed=subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD:deep_gemm/include/deep_gemm/transform_sf.hpp'],text=True).strip();assert blob==committed
binary=op.parent/'dump/aicore_binary.o';assert sha(binary)==inspection['capture']['jit_binary_sha256']==sha(p/'jit/kernel.o')
tool='/workspace/tilekernels-env-20261101/cann/cann-9.2.1/tools/bisheng_compiler/bin/llvm-objdump'
isa=subprocess.check_output([tool,'-d',str(binary)],text=True);Path(os.environ.get('AUDIT_ISA',str(p/'device-kernel.isa'))).write_text(isa)
raw=(p/'detail/profile.log').read_text(errors='replace');stores=[x for x in raw.splitlines() if 'DBI record core:' in x and 'dst:(type:GM;' in x and 'src:(type:UB;' in x]
R=SourceFileLoader('r',str(root/'audit-reduce-family.py')).load_module().REGEX;events=R.findall(raw);assert len(stores)==len(events)>0
metrics=re.findall(r'processedRecord: (\d+), droppedRecord: (\d+).*?memoryCorruption (\d+)',raw);assert metrics and all(d=='0' and m=='0' for _,d,m in metrics)
percore=Counter();rounded=Counter();actual=[];pcs=set()
for c,pc,addr,stride,l1s,l2s,srcaddr,srcstride,srcl1s,srcl2s,burst,length,dtype,l1,l2,left,right in events:
 c=int(c);assert c%3 in (0,1) and c//3<28;pcs.add(int(pc,16));addr=int(addr,16)
 stride=int(stride);l1s=int(l1s);l2s=int(l2s);n=int(burst);length=int(length);l1=int(l1);l2=int(l2)
 assert n>0 and length>0 and l1>=1 and l2>=1 and int(left)==int(right)==0
 percore[c]+=n*length*l1*l2
 rounded[c]+=(((n*length+31)//32)*32 if int(srcstride)==length else n*((length+31)//32)*32)*l1*l2
 for z in range(l2):
  for y in range(l1):
   for x in range(n):
    lo=addr+z*l2s+y*l1s+x*stride;hi=lo+length;i=bisect.bisect_right(starts,lo)-1
    assert i>=0 and expected[i][0]<=lo and hi<=expected[i][1],(hex(lo),hex(hi))
    actual.append((lo,hi))
assert merge(actual)==expected
for pc in pcs:assert any(re.match(r'^\s*'+format(pc,'x')+r':',line) and 'MOV_UB_TO_OUT' in line for line in isa.splitlines()),hex(pc)
mem=read(op.with_name('Memory.csv'));assert len(mem)==56
for j,row in enumerate(mem):
 assert int(row['block_id'])==j and row['sub_block_id']=='vector0';value=row['UB_to_GM_datas(KB)'];total=rounded[3*j]+rounded[3*j+1] if j<28 else None
 if j<28 and value not in ('NA',''):assert abs(Decimal(value)*1024-total)<=Decimal('0.000512'),(j,value,total)
 elif j<28:assert total==0
 else:assert value in ('NA','')
result={'case':'campaign-13/'+case,'target':'transform_sf','status':'passed','device':'hidev NPU 0',
 'device_health':'Alarm 8C4BA00C','correctness':'passed','historical_target_input_and_jit_source_match':True,
 'output_shape':shape,'output_stride':out['stride'],'output_bytes':math.prod(shape)*size,'dbi_requested_bytes':sum(percore.values()),
 'per_vector_block_requested_bytes':{i:percore[3*(i//2)+i%2] for i in range(56)},'capture_binary_sha256':sha(binary),
 'cpp_header_sha256':sha(header),'dbi_pc':[hex(x) for x in sorted(pcs)],'csv_pair_totals_match':True,
 'scope':'one MemoryDetail window; requested UB to GM bytes, not physical DRAM transactions'}
assert result['dbi_requested_bytes']==result['output_bytes']
Path(os.environ.get('AUDIT_OUTPUT',str(p/'address-audit.json'))).write_text(json.dumps(result,indent=2)+'\n');print('PASS',case,result['dbi_requested_bytes'])
