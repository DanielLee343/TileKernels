import csv,json,sys
from collections import Counter
from decimal import Decimal
from pathlib import Path
from importlib.machinery import SourceFileLoader
root=Path('/workspace/expert-profile-backfill-20261109-hidev')
R=SourceFileLoader('reduce_audit',str(root/'audit-reduce-family.py')).load_module().REGEX
for case in sys.argv[1:]:
 p=root/'topk-runs'/case/'hidev-npu0/attempt-001/detail'
 if not (p/'profile.log').exists():continue
 logical=Counter();rounded=Counter();spanned=Counter();events=R.findall((p/'profile.log').read_text(errors='replace'))
 for c,pc,addr,stride,l1s,l2s,srcaddr,srcstride,srcl1s,srcl2s,burst,length,dtype,l1,l2,left,right in events:
  c=int(c);n=int(length);a=int(addr,16);group=c//3
  logical[group]+=n;rounded[group]+=((n+31)//32)*32;spanned[group]+=((a%32+n+31)//32)*32
 op,=list((p/'capture').rglob('Memory.csv'))
 with op.open() as f:rows=list(csv.DictReader(f))
 errs={name:0 for name in ['logical','rounded','spanned']};examples=[]
 for j in range(28):
  value=rows[j]['UB_to_GM_datas(KB)'];actual=Decimal(0) if value in ('NA','') else Decimal(value)*1024
  for name,d in [('logical',logical),('rounded',rounded),('spanned',spanned)]:
   if abs(actual-d[j])>Decimal('0.000512'):errs[name]+=1
  if j<3:examples.append([j,str(actual),logical[j],rounded[j],spanned[j]])
 print(case,'events',len(events),'group_mismatch_counts',errs,'examples csv/request/rounded/span',examples)
