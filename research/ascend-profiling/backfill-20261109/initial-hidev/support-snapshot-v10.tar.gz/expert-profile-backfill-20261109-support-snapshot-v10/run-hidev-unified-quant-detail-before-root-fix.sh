#!/usr/bin/env bash
set -Eeo pipefail
root=/workspace/expert-profile-backfill-20261109-hidev;envdir=/workspace/tilekernels-env-20261101;repo="$envdir/src/TileKernels-private"
case_id="${CASE_ID:?}";attempt="${ATTEMPT:?}"
[[ "$case_id" =~ ^quant_per_token_cast-(0[1-9]|1[0-9]|20)$ ]] || exit 2
unset LD_LIBRARY_PATH PYTHONPATH LD_PRELOAD MEMORYCHART_ROOT MEMORYCHART_LOG
source "$envdir/activate.sh"
set -u
[[ "$(realpath "$ASCEND_HOME_PATH")" == *cann-9.2.1* ]]
export TILEKERNELS_ROOT="$repo" TILELANG_DEFAULT_TARGET=ascend TILELANG_CACHE_DIR="$root/unified-quant-cache/$case_id"
export ASCEND_RT_VISIBLE_DEVICES=0 PYTHONDONTWRITEBYTECODE=1 MSOPT_LOG_LEVEL=0 GUARD_DEADLINE_SECONDS=900 GUARD_MAX_LOG_BYTES=536870912
exec 9> /workspace/.puma-hidev-npu0.lock;flock -n 9
test "$(git -C "$repo" rev-parse HEAD)" = bb866a442c59464902dc2e93916ceea82e7471d9
test -z "$(git -C "$repo" status --porcelain --untracked-files=no)"
out="$root/unified-quant-runs/$case_id/hidev-npu0/$attempt/detail";test ! -e "$out";mkdir -p "$out/provenance"
timeout 10 npu-smi info -t board -i 0 > "$out/provenance/board.txt";grep -qi '0000:8b:00.0' "$out/provenance/board.txt"
timeout 10 npu-smi info -t health -i 0 > "$out/provenance/health-before.txt"
msprof op --version > "$out/provenance/msprof-version.txt";grep -q 884ac969494a186a9c63ac45c4c39ad7289b3215 "$out/provenance/msprof-version.txt"
git -C "$repo" rev-parse HEAD > "$out/provenance/commit.txt";printf '%s\n' "$ASCEND_HOME_PATH" > "$out/provenance/cann-path.txt"
cp "$root/unified-quant-harness"/*.py "$root/unified-quant-harness"/*.json "$root/guard-v4.py" "$root/run-hidev-unified-quant-detail.sh" "$out/provenance/"
(cd "$out/provenance" && sha256sum *.py *.json *.sh *.txt > sha256.txt)
params=$(python - "$root/unified-quant-harness/cases.json" "$case_id" <<'PY'
import base64,json,sys
cases=json.load(open(sys.argv[1]))['cases'];case,=(x for x in cases if x['id']==sys.argv[2]);print(base64.urlsafe_b64encode(json.dumps(case['params'],separators=(',',':')).encode()).decode())
PY
)
old="$repo/research/ascend-profiling/runs/hidev-20261106-unified-quant/cases/$case_id/default.json"
kernel=$(python -c 'import json,sys;print(json.load(open(sys.argv[1]))["runtime_kernel"])' "$old")
[[ "$kernel" =~ ^[A-Za-z0-9_]+$ ]]
cd "$root";export GUARD_REQUIRE_PROFILE=1
python -B guard-v4.py 0 "$out" \
 msprof op "--output=$out/capture" --aic-metrics=MemoryDetail,Default --replay-mode=kernel \
 --mstx=true --mstx-include=quant_target "--kernel-name=$kernel" --launch-count=1 --warm-up=5 --kill=false \
 python -B "$root/unified-quant-harness/quant_hook.py" quant_per_token_cast "$params" default "$out/application.json"
timeout 10 npu-smi info -t health -i 0 > "$out/provenance/health-after.txt"
find "$TILELANG_CACHE_DIR" -type f -exec sha256sum {} + | sort > "$out/cache-sha256.txt"
printf '%s\n' 'capture complete; identity and address audits remain pending'
