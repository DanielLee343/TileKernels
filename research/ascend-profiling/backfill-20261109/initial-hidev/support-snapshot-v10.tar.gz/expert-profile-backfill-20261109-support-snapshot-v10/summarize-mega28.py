import hashlib,json,time
from pathlib import Path
root=Path('/workspace/expert-profile-backfill-20261109-hidev');cases=[]
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
for audit in sorted((root/'mega28-runs').rglob('dbi-window-inspection.json')):
 p=audit.parent;a=json.loads(audit.read_text());assert a['status']=='dbi_window_correct_output_covered_scratch_completeness_unverified'
 op,=list((p/'detail/capture').rglob('OpBasicInfo.csv'));pid=a['dbi_pid']
 scratch_path=p/'scratch-coverage.json';scratch=json.loads(scratch_path.read_text()) if scratch_path.exists() else None
 if scratch:assert scratch['case']==a['case'] and scratch['dbi_pid']==pid and scratch['status']=='expected_workspace_and_output_bytes_covered_once'
 files=[audit,p/'prepare.json',p/f'profile-result-{pid}.json',p/f'profile-addresses-{pid}.json',p/'device-kernel.isa',
        p/'detail/profile.log',p/'detail/monitor-summary.json',p/'detail/command.json',p/'provenance/health-before.txt',
        p/'provenance/health-after.txt',op,op.with_name('Memory.csv'),op.parent/'dump/aicore_binary.o']
 if scratch:files.append(scratch_path)
 hashes={str(x.relative_to(root)):sha(x) for x in files if x.is_file()};assert len(hashes)==len(files)
 cases.append({'case':a['case'],'audit':a,'scratch_coverage':scratch,'raw_dir':str(p),'files_sha256':hashes,'health':'Alarm 8C4BA00C'})
doc={'created_unix':time.time(),'count':len(cases),'cases':cases,'scope':'separate application-replay DBI stage; scratch completeness unverified'}
(root/'mega28-dbi-index.json').write_text(json.dumps(doc,indent=2)+'\n');print('indexed',len(cases),'MegaMoE partial DBI windows')
