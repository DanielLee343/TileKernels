"""Sequential reduce-family collection; every result is audited before next case."""
import fcntl,json,os,re,subprocess,sys,time
from pathlib import Path
root=Path('/workspace/expert-profile-backfill-20261109-hidev')
queue=root/'reduce-queue-hidev-npu0';queue.mkdir(exist_ok=True)
lock=(queue/'queue.lock').open('w');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
env=os.environ.copy();env.update(BACKFILL_ROOT=str(root),BACKFILL_HOST='hidev',
 BACKFILL_OBJDUMP='/workspace/tilekernels-env-20261101/cann/cann-9.2.1/tools/bisheng_compiler/bin/llvm-objdump')
for i in range(2,21):
 case=f'reduce-{i:02d}';base=root/'runs'/case/'hidev-npu0'
 attempts=sorted(base.glob('attempt-*')) if base.exists() else []
 if any((a/'detail/audit-result.json').exists() and json.loads((a/'detail/audit-result.json').read_text()).get('status')=='passed' for a in attempts):
  print(case,'already audited; skip',flush=True);continue
 indexes=[int(a.name.removeprefix('attempt-')) for a in attempts if re.fullmatch(r'attempt-\d+',a.name)]
 attempt=f'attempt-{max(indexes,default=0)+1:03d}';out=base/attempt;out.mkdir(parents=True,exist_ok=False)
 status={'case':case,'device':'hidev-npu0','attempt':attempt,'status':'running','started_unix':time.time(),
         'device_health':'Alarm 8C4BA00C observed in preflight; inspect per-case health records'}
 (out/'queue-status.json').write_text(json.dumps(status,indent=2)+'\n')
 caseenv=env|{'CASE_ID':case,'ATTEMPT':attempt}
 with (out/'launcher-console.log').open('w') as log:
  capture=subprocess.run(['bash',str(root/'run-hidev-reduce.sh')],env=caseenv,stdout=log,stderr=subprocess.STDOUT)
 status['capture_exit']=capture.returncode
 if capture.returncode==0:
  with (out/'audit-console.log').open('w') as log:
   audit=subprocess.run([sys.executable,'-B',str(root/'audit-reduce-family.py'),case,'0',attempt],env=env,stdout=log,stderr=subprocess.STDOUT)
  status['audit_exit']=audit.returncode;status['status']='passed' if audit.returncode==0 else 'audit_failed'
 else:status['status']='capture_failed'
 status['finished_unix']=time.time();tmp=out/'queue-status.tmp';tmp.write_text(json.dumps(status,indent=2)+'\n');tmp.replace(out/'queue-status.json')
 print(case,status['status'],flush=True)
 if status['status']!='passed':sys.exit(1)
print('ALL_REDUCE_CASES_AUDITED',flush=True)
