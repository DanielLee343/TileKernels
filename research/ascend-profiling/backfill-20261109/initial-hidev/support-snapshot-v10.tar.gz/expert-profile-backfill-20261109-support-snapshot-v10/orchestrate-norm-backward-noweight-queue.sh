#!/usr/bin/env bash
set -Eeuo pipefail
root=/workspace/expert-profile-backfill-20261109-hidev
q="$root/extra-norm-backward-noweight-queue-hidev-npu0";mkdir -p "$q"
trap 'rc=$?;printf "exit=%s at=%s\n" "$rc" "$(date -u +%FT%TZ)" > "$q/exit.txt"' EXIT
grep -q ALL_NORM_BACKWARD_NOWEIGHT_CANDIDATES_PASSED "$root/norm-backward-noweight-candidates.log"
grep -q ALL_NORM_BACKWARD_NOWEIGHT_NEGATIVE_TESTS_PASSED "$root/norm-backward-noweight-tests.log"
for n in 06 07;do
 p="$root/extra-proxy-runs/unified-extra3/quant_norm_backward-$n/hidev-npu0/attempt-001/detail"
 python3 - "$p" "$n" <<'PY'
import json,sys
from pathlib import Path
p=Path(sys.argv[1]);a=p/'candidate-audit-result.json';b=p/'audit-result.json';d=json.loads(a.read_text())
assert d['status']=='passed' and d['target'].endswith('quant_norm_backward-'+sys.argv[2]) and not b.exists();b.write_bytes(a.read_bytes())
PY
done
previous="$root/extra-engram-gate-fwd-unmasked-queue-hidev-npu0";pid=$(cat "$previous/pid")
while ps -p "$pid" -o args= | grep -Fq "$root/orchestrate-engram-gate-fwd-unmasked-queue.sh";do sleep 10;done
python3 -B "$root/hidev-extra-norm-backward-noweight-queue.py"
