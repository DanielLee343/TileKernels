"""Check saved expert sleep kernels have no AIV UB-to-GM instructions."""
import csv,hashlib,json,re,subprocess
from pathlib import Path
root=Path('/workspace/expert-profile-backfill-20261109-hidev')
repo=Path('/workspace/tilekernels-env-20261101/src/TileKernels-private/research/ascend-profiling/deepgemm-ascend/campaign-13/runs')
src=Path('/workspace/deepgemm-ascend-20261107/source/deep_gemm/include/deep_gemm/sleep.hpp')
source_repo=Path('/workspace/deepgemm-ascend-20261107/source')
objdump=Path('/workspace/tilekernels-env-20261101/cann/cann-9.2.1/tools/bisheng_compiler/bin/llvm-objdump')
cases=['sleep-cycles100000-marker1','sleep-cycles10000-marker2','sleep-cycles1000000-marker3','sleep-cycles5000000-marker4']
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
code=src.read_text();assert 'void sleep_impl(int64_t sleep_cycles)' in code and 'asc_nop()' in code and 'asc_get_system_cycle()' in code
assert 'copy' not in code.lower() and '__gm__' not in code.lower()
assert subprocess.check_output(['git','-C',str(source_repo),'rev-parse','HEAD'],text=True).strip()=='3a35326271b069b8b5bf1a754435acd6cc91575b'
rel=src.relative_to(source_repo).as_posix()
assert subprocess.check_output(['git','-C',str(source_repo),'hash-object',str(src)],text=True).strip()==subprocess.check_output(['git','-C',str(source_repo),'rev-parse','HEAD:'+rel],text=True).strip()
out=root/'deepgemm-sleep-static-audit';out.mkdir(exist_ok=True)
(out/'sleep.hpp').write_bytes(src.read_bytes())
allowed={'MOVI','MOVK','MOV','ADD','SHRI','AND','ADDI','SHLI','MADD','LD_IO','SBITSET0','OR','MOVEMASK','NEG','SUB','CMP','JUMPCI','JUMPI','JUMP','NOP','DCCI','END'}
records=[]
for case in cases:
 dirs=list(repo.glob('*/'+case));assert len(dirs)==1,case;d=dirs[0]
 op,=list((d/'profile').rglob('OpBasicInfo.csv'))
 with op.open(encoding='utf-8-sig',newline='') as f:basic,=list(csv.DictReader(f))
 assert 'sleep_impl' in basic['Op Name'] and basic['Op Type']=='mix'
 bin=op.parent/'dump/aicore_binary.o';assert bin.is_file()
 text=subprocess.check_output([str(objdump),'-d',str(bin)],text=True)
 assert re.search(r'<[^>]*sleep_impl[^>]*_mix_aiv>:',text) and re.search(r'<[^>]*sleep_impl[^>]*_mix_aic>:',text)
 instruction_lines=re.findall(r'^\s*[0-9a-f]+:\s+[0-9a-f]+\s+.*$',text,re.M)
 instructions=re.findall(r'^\s*[0-9a-f]+:\s+[0-9a-f]+\s+([A-Z][A-Z0-9_]*)',text,re.M)
 assert len(instructions)==len(instruction_lines)>0 and set(instructions)<=allowed,(case,sorted(set(instructions)-allowed))
 assert not any(x in instructions for x in ('MOV_UB_TO_OUT','STG'))
 isa=out/(case+'.isa');isa.write_text(text)
 records.append({'target':'campaign-13/'+case,'status':'aiv_ub_to_gm_not_applicable',
  'binary_sha256':sha(bin),'binary_path':str(bin),'opbasic_path':str(op),'generated_wrapper_sha256':sha(d/'jit/kernel.asc'),
  'isa_path':str(isa),'isa_sha256':sha(isa),'instruction_count':len(instructions),'opcodes':sorted(set(instructions)),
  'reason':'saved mixed AIC/AIV binary contains no UB-to-GM movement; source is a cycle wait with no tensor arguments'})
result={'source_commit':'3a35326271b069b8b5bf1a754435acd6cc91575b','header_path':str(src),'header_sha256':sha(src),
 'cases':records,'scope':'only UB-to-GM requested bytes for these exact saved binaries; not a claim about all device memory activity'}
(out/'audit.json').write_text(json.dumps(result,indent=2)+'\n');print('AUDITED_SLEEP_NO_UBGM',len(records),sha(out/'audit.json'))
