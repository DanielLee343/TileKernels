"""Survey original vector binaries; do not change any ledger status."""
import csv,hashlib,json,re,subprocess
from pathlib import Path
repo=Path('/workspace/tilekernels-env-20261101/src/TileKernels-private/research/ascend-profiling/deepgemm-ascend/campaign-13/runs')
root=Path('/workspace/expert-profile-backfill-20261109-hidev')
tool=Path('/workspace/tilekernels-env-20261101/cann/cann-9.2.1/tools/bisheng_compiler/bin/llvm-objdump')
items=[]
for profile in repo.glob('*/*/profile/OPPROF_*'):
 op=profile/'OpBasicInfo.csv';binary=profile/'dump/aicore_binary.o'
 if not op.is_file() or not binary.is_file():continue
 with op.open(encoding='utf-8-sig',newline='') as f:
  rows=list(csv.DictReader(f))
 if len(rows)!=1 or rows[0]['Op Type']!='vector':continue
 name=rows[0]['Op Name']
 if not any(s in name for s in ('paged_mqa_logits_metadata_simt_impl','paged_sparse_mqa_prepare_impl','sparse_mqa_logits_metadata')):continue
 text=subprocess.check_output([str(tool),'-d',str(binary)],text=True)
 lines=re.findall(r'^\s*[0-9a-f]+:\s+[0-9a-f]+\s+.*$',text,re.M)
 instructions=re.findall(r'^\s*[0-9a-f]+:\s+[0-9a-f]+\s+([A-Z][A-Z0-9_]*)',text,re.M)
 items.append({'case':profile.parent.parent.name,'op_name':name,'binary':str(binary),
  'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),
  'decoded_lines':len(instructions),'instruction_lines':len(lines),'opcodes':sorted(set(instructions)),
  'has_ub_to_out':any(x.startswith('MOV_UB_TO_OUT') for x in instructions),'has_stg':any(x.startswith('STG') for x in instructions)})
out=root/'deepgemm-vector-isa-survey.json';out.write_text(json.dumps({'cases':items,'status':'survey_only'},indent=2)+'\n')
print('VECTOR_ISA_SURVEY',len(items),'incomplete',sum(x['decoded_lines']!=x['instruction_lines'] for x in items),
      'has_ub_to_out',sum(x['has_ub_to_out'] for x in items),'has_stg',sum(x['has_stg'] for x in items))
for x in items:print(x['case'],x['has_ub_to_out'],x['has_stg'],','.join(x['opcodes']))
