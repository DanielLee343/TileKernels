"""Classify saved head backward binaries by exact ISA and source evidence."""
import ast,csv,hashlib,json,re,subprocess
from pathlib import Path
root=Path('/workspace/expert-profile-backfill-20261109-hidev')
repo=Path('/workspace/tilekernels-env-20261101/src/TileKernels-private')
source=repo/'tile_kernels/mhc/head_compute_mix_asc.py'
tool=Path('/workspace/tilekernels-env-20261101/cann/cann-9.2.1/tools/bisheng_compiler/bin/llvm-objdump')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip()=='bb866a442c59464902dc2e93916ceea82e7471d9'
rel=source.relative_to(repo).as_posix()
assert subprocess.check_output(['git','-C',str(repo),'hash-object',str(source)],text=True).strip()==subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD:'+rel],text=True).strip()
text=source.read_text();tree=ast.parse(text);fun,=(x for x in tree.body if isinstance(x,ast.FunctionDef) and x.name=='mhc_head_compute_mix_bwd_asc')
body=ast.get_source_segment(text,fun);assert 'T.SimtVF' in body and 'T.alloc_fragment' in body and 'T.alloc_shared' not in body
assert 'input_mix_grad[i, j] =' in body and 'mhc_scale_grad_partial[pid, :]' in body and 'mhc_base_grad_partial[pid, :]' in body
allowed=set('ADD ADDI AND BAR BRANCH DCCI END END_DVG FADD FDIV FEXPDIF FFMA FMUL IADD IMAD IMUL INSERT ISETP LDG LDP LDS LD_IO LEA LOP3 MADD MOV MOVEMASK MOVI MOVK NEG NOP OR PLOP3 PUSH_PB S2R SBITSET0 SHFI SHFL SHLI SHRI START_DVG STG STS VF_SIMT'.split())
survey=json.loads((root/'main-pending-isa-survey.json').read_text())['cases']
items=[x for x in survey if x['target'].startswith('unified-extra/mhc_head_compute_mix_bwd-')];assert len(items)==20
out=root/'head-bwd-static-audit';out.mkdir(exist_ok=True);(out/source.name).write_bytes(source.read_bytes());records=[]
for item in items:
 profile=repo/item['profile'];binary=profile/'dump/aicore_binary.o';meta=profile.parent.parent/'default.json'
 assert sha(binary)==item['binary_sha256'];m=json.loads(meta.read_text());assert m['status']=='passed' and m['matched']==1
 assert m['runtime_kernel']==item['op_name']=='mhc_head_compute_mix_bwd_asc_kernel'
 assert m['precision'] and all(x['passed'] for x in m['precision'])
 with (profile/'OpBasicInfo.csv').open(encoding='utf-8-sig',newline='') as f:basic,=list(csv.DictReader(f))
 assert basic['Op Name']==item['op_name'] and basic['Op Type']=='vector'
 asm=subprocess.check_output([str(tool),'-d',str(binary)],text=True)
 lines=re.findall(r'^\s*[0-9a-f]+:\s+[0-9a-f]+\s+.*$',asm,re.M)
 ins=re.findall(r'^\s*[0-9a-f]+:\s+[0-9a-f]+\s+([A-Z][A-Z0-9_]*)',asm,re.M)
 assert len(ins)==len(lines)>0 and set(ins)<=allowed,(item['target'],sorted(set(ins)-allowed))
 assert 'STG' in ins and 'VF_SIMT' in ins and not any(x.startswith('MOV_UB_TO_OUT') for x in ins)
 isa=out/(item['target'].split('/')[-1]+'.isa');isa.write_text(asm)
 records.append({'target':item['target'],'status':'aiv_ub_to_gm_not_applicable','correctness':'passed',
  'binary_sha256':sha(binary),'binary_path':item['profile']+'/dump/aicore_binary.o','metadata_sha256':sha(meta),
  'generated_source_sha256':m['source_sha256'],'isa_sha256':sha(isa),'instruction_count':len(ins),'opcodes':sorted(set(ins)),
  'evidence':'original implementation uses SIMT and fragments; exact captured vector binary has STG but no UB-to-GM instructions',
  'scope':'UB-to-GM only; SIMT directly writes GM'})
doc={'source_commit':'bb866a442c59464902dc2e93916ceea82e7471d9','source_path':rel,'source_sha256':sha(source),
 'method':'pinned source, individual correctness metadata, and exact saved binary ISA; no new replay assumed','cases':records}
(out/'audit.json').write_text(json.dumps(doc,indent=2)+'\n');print('HEAD_BWD_STATIC_AUDIT',len(records),sha(out/'audit.json'))
