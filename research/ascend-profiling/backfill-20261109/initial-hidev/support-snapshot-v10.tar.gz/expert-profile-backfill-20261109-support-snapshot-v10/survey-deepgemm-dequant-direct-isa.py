"""Survey original direct-store dequant GEMMs; no ledger changes."""
import csv,hashlib,json,re,subprocess
from pathlib import Path
root=Path('/workspace/expert-profile-backfill-20261109-hidev')
repo=Path('/workspace/tilekernels-env-20261101/src/TileKernels-private/research/ascend-profiling/deepgemm-ascend/campaign-13/runs')
tool=Path('/workspace/tilekernels-env-20261101/cann/cann-9.2.1/tools/bisheng_compiler/bin/llvm-objdump')
cases=[]
for wrapper in repo.glob('*/gemm-fp8fp4-*/jit/kernel.asc'):
 text=wrapper.read_text()
 if not re.search(r'\btrue,\s*true,\s*false>\);',text):continue
 d=wrapper.parent.parent;op,=list((d/'profile').rglob('OpBasicInfo.csv'))
 with op.open(encoding='utf-8-sig',newline='') as f:basic,=list(csv.DictReader(f))
 assert 'fp8_dequant_gemm_impl' in basic['Op Name'] and basic['Op Type']=='mix'
 binary=op.parent/'dump/aicore_binary.o';asm=subprocess.check_output([str(tool),'-d',str(binary)],text=True)
 lines=re.findall(r'^\s*[0-9a-f]+:\s+[0-9a-f]+\s+.*$',asm,re.M)
 ins=re.findall(r'^\s*[0-9a-f]+:\s+[0-9a-f]+\s+([A-Z][A-Z0-9_]*)',asm,re.M)
 cases.append({'case':d.name,'binary_path':str(binary),'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),
  'wrapper_path':str(wrapper),'decoded_lines':len(ins),'instruction_lines':len(lines),'opcodes':sorted(set(ins)),
  'ub_to_out':[x for x in sorted(set(ins)) if x.startswith('MOV_UB_TO_OUT')],
  'ub_to_l1':[x for x in sorted(set(ins)) if x.startswith('MOV_UB_TO_L1')],
  'stg':[x for x in sorted(set(ins)) if x.startswith('STG')]})
assert len(cases)==9,len(cases)
doc={'status':'survey_only','cases':cases};(root/'deepgemm-dequant-direct-isa-survey.json').write_text(json.dumps(doc,indent=2)+'\n')
print('DIRECT_DEQUANT_SURVEY',len(cases),'incomplete',sum(x['decoded_lines']!=x['instruction_lines'] for x in cases),
 'ub_to_out',sum(bool(x['ub_to_out']) for x in cases),'ub_to_l1',sum(bool(x['ub_to_l1']) for x in cases),'stg',sum(bool(x['stg']) for x in cases))
print('ALL_OPCODES',','.join(sorted(set().union(*(set(x['opcodes']) for x in cases)))))
