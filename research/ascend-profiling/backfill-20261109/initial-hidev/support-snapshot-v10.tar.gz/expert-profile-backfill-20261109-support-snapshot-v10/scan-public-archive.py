"""Conservative credential-marker scan before publishing; never print secrets."""
import re,sys
from pathlib import Path

root=Path(sys.argv[1]).resolve(strict=True)
patterns={
 'private-key':re.compile(rb'-----BEGIN (?:RSA |EC |OPENSSH |DSA )?PRIVATE KEY-----'),
 'github-token':re.compile(rb'(?<![A-Za-z0-9_])(?:gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{40,})'),
}
matches=[];count=0
for path in root.rglob('*'):
 if not path.is_file() or path.is_symlink():continue
 count+=1;tail=b'';seen=set()
 with path.open('rb') as f:
  while block:=f.read(1024*1024):
   data=tail+block
   for label,pattern in patterns.items():
    if label not in seen and pattern.search(data):seen.add(label)
   tail=data[-256:]
 for label in sorted(seen):matches.append((str(path.relative_to(root)),label))
print('FILES_SCANNED',count,'MATCHES',len(matches))
for path,label in matches:print(label,path)
sys.exit(bool(matches))
