"""Snapshot the completed ordinary and paged MQA case directories."""
import importlib.util,sys
from pathlib import Path
root=Path('/workspace/expert-profile-backfill-20261109-hidev')
spec=importlib.util.spec_from_file_location('archive_captures',root/'archive-captures.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
m.GROUPS=('deepgemm-runs',);original=m.scan_units
m.scan_units=lambda r:(x for x in original(r) if x[1].startswith(('mqa-','paged-mqa-','paged_mqa_logits_impl-')))
def no_support(source,out):
 p=out/'support.jsonl';p.write_bytes(b'');return 0,m.sha(p)
m.copy_support=no_support
sys.argv=['archive-captures.py','--root',str(root),'--out','/workspace/expert-profile-backfill-20261109-mqa-completed-snapshot-archive']
m.main()
