"""Inspect every process of FIRST application replay; byte audit is separate."""
import hashlib,importlib.util,json,re,shutil,sys
from pathlib import Path
root=Path('/workspace/expert-profile-backfill-20261109-hidev');case,attempt=sys.argv[1:]
assert re.fullmatch(r'paged-sparse-first-[01]-[a-z0-9-]+',case) and re.fullmatch(r'attempt-[0-9]+',attempt)
p=root/'deepgemm-runs'/case/'hidev-npu0'/attempt;h=root/'deepgemm-paged-sparse-app-harness'
spec=importlib.util.spec_from_file_location('collector',h/'campaign-13/collect.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
manifest=json.loads((h/'campaign-13/cases.json').read_text());selected,=(x for x in manifest['cases'] if x['id']==case)
assert selected.get('sparse_phase')=='first'
command=json.loads((p/'detail/command.json').read_text());assert '--replay-mode=application' in command and '--warm-up=5' in command
old=json.loads((h/'history'/case/'profile.json').read_text());prep=json.loads((p/'prepare.json').read_text())
assert old['status']==prep['status']=='passed' and old['target_input']==prep['target_input']
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
apps=sorted(p.glob('profile-[0-9]*.json'));assert len(apps)>=2
records=[];addresses=None
for f in apps:
 pid=f.stem.removeprefix('profile-');assert pid.isdigit();a=json.loads(f.read_text())
 assert a['status']=='passed' and a['target_input']==old['target_input'] and a['target_input']['kwargs']['metadata']['phase']=='first'
 af=p/('profile-addresses-'+pid+'.json');meta=p/('paged-sparse-input-files-'+pid+'.json');after=p/('paged-sparse-metadata-after-'+pid+'.bin')
 assert af.is_file() and meta.is_file() and after.is_file()
 current=json.loads(af.read_text());assert len(current)==1
 if addresses is None:addresses=current
 else:assert current==addresses,'addresses differ across application replay processes'
 saved=json.loads(meta.read_text());assert saved
 for x in saved:
  file=p/x['path'];assert file.is_file() and sha(file)==x['sha256']
  if x['name'].startswith('factory-args-'):
   i=int(x['name'].rsplit('-',1)[1]);oldarg=a['target_input']['kwargs']['metadata']['factory_args'][i]
   assert oldarg['sha256']==x['sha256'] and oldarg['shape']==x['shape'] and oldarg['dtype']==x['dtype']
 records.append({'pid':pid,'profile':f.name,'profile_sha256':sha(f),'addresses':af.name,'addresses_sha256':sha(af),'metadata_index':meta.name,'metadata_index_sha256':sha(meta),'metadata_after':after.name,'metadata_after_sha256':sha(after),'saved_files':saved})
capture=mod.inspect_profile(selected,p/'detail/capture',root/'deepgemm-cache'/case)
jit=Path(capture['jit_directory']);historical=h/'history'/case/'kernel.asc';assert sha(historical)==sha(jit/'kernel.asc')
dest=p/'jit';dest.mkdir(exist_ok=True)
for n in ('kernel.asc','kernel.o','meta.json'):
 if (jit/n).is_file():shutil.copy2(jit/n,dest/n)
monitor=json.loads((p/'detail/monitor-summary.json').read_text());assert monitor['status']=='passed' and monitor['max_seconds_between_successful_queries']<=3
log=(p/'detail/profile.log').read_text(errors='replace');metrics=re.findall(r'processedRecord: (\d+), droppedRecord: (\d+).*?memoryCorruption (\d+)',log)
assert metrics and all(d=='0' and m=='0' for _,d,m in metrics)
out={'case':'campaign-13/'+case,'status':'identity_checked_address_audit_pending','correctness':'passed','historical_true_inputs_and_jit_source_match':True,
 'capture':capture,'parser_metrics':metrics,'representative_pid':records[0]['pid'],'application_records':records,
 'scope':'FIRST application replay, each observed process passed with historical factory inputs; kernel-internal replay and output-address coverage remain unverified; separate from historical range replay'}
(p/'capture-inspection.json').write_text(json.dumps(out,indent=2)+'\n');print('PAGED_SPARSE_FIRST_APP_PROCESSES_VALIDATED',len(records))
