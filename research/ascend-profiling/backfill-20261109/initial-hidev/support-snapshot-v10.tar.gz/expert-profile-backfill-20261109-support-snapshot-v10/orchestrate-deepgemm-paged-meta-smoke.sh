#!/usr/bin/env bash
set -Eeuo pipefail
root=/workspace/expert-profile-backfill-20261109-hidev;previous="$root/extra-castback-queue-hidev-npu0"
q="$root/deepgemm-paged-meta-smoke-hidev-npu0";mkdir -p "$q"
trap 'rc=$?; printf "exit=%s at=%s\n" "$rc" "$(date -u +%FT%TZ)" > "$q/exit.txt"' EXIT
pid=$(cat "$previous/followup.pid")
while ps -p "$pid" -o args= | grep -Fq "$root/orchestrate-castback-queue.sh";do sleep 10;done
export CASE_ID=paged-meta-b2-k256-h8-d128-p64 ATTEMPT=attempt-001
bash "$root/run-hidev-deepgemm-paged-meta.sh"
python3 -B "$root/inspect-deepgemm-paged-meta.py" "$CASE_ID" "$ATTEMPT"
echo 'identity smoke complete; source-specific output address audit remains required'
