#!/usr/bin/env bash
set -Eeuo pipefail
root=/workspace/expert-profile-backfill-20261109-hidev
q="$root/extra-swiglu-forward-queue-hidev-npu0";mkdir -p "$q"
trap 'rc=$?; printf "exit=%s at=%s\n" "$rc" "$(date -u +%FT%TZ)" > "$q/exit.txt"' EXIT
grep -q ALL_SWIGLU_GENERAL_CANDIDATES_PASSED "$root/swiglu-general-candidates.log"
grep -q ALL_SWIGLU_GENERAL_NEGATIVE_TESTS_PASSED "$root/swiglu-general-negative-tests.log"
for n in 02 07 08;do
 d="$root/extra-proxy-runs/unified-extra3/quant_swiglu_forward-$n/hidev-npu0/attempt-001/detail"
 python3 - "$d" "$n" <<'PY'
import json,sys
from pathlib import Path
p=Path(sys.argv[1]);a=p/'candidate-audit-result.json';b=p/'audit-result.json'; x=json.loads(a.read_text())
assert x['status']=='passed' and x['target'].endswith('quant_swiglu_forward-'+sys.argv[2]);assert not b.exists()
b.write_bytes(a.read_bytes())
PY
done
previous="$root/extra-norm-forward-queue-hidev-npu0";pid=$(cat "$previous/pid")
while ps -p "$pid" -o args= | grep -Fq "$root/hidev-extra-norm-forward-queue.py";do sleep 10;done
python3 -B "$root/hidev-extra-swiglu-forward-queue.py"
