"""Fail-closed audit for fused-weight contiguous stores and their block mapping."""
import csv,hashlib,json,os,re,subprocess,sys
from collections import Counter
from decimal import Decimal
from pathlib import Path
from importlib.machinery import SourceFileLoader
root=Path(os.environ.get('BACKFILL_ROOT',str(Path.home()/'expert-profile-backfill-20261109')))
R=SourceFileLoader('reduce_audit',str(root/'audit-reduce-family.py')).load_module().REGEX
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):
 with p.open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def main():
 case,device,attempt=sys.argv[1:];assert re.fullmatch(r'fused-(0[1-9]|1[0-9]|20)',case) and device in ('0','3')
 host=os.environ.get('BACKFILL_HOST','tbe');p=root/'fused-runs'/case/(host+'-npu'+device)/attempt/'detail'
 app=json.loads((p/'metadata/application.json').read_text());hist=json.loads((root/'fused-history'/case/'default.json').read_text())
 monitor=json.loads((p/'monitor-summary.json').read_text())
 assert app['status']=='passed' and app['visible_devices']==device and monitor['status']=='passed' and monitor['max_seconds_between_successful_queries']<=3
 for key in ('runtime_kernel','source_sha256','inputs','outputs'):assert app[key]==hist[key],key
 src=p/'metadata/default-kernel.cpp';assert sha(src)==app['source_sha256'];code=src.read_text()
 h=app['case']['hidden'];assert h%256==0 and app['case']['family']=='engram_fused_weight'
 assert app['outputs'][0]['shape']==[4,h] and app['outputs'][0]['dtype']=='float32' and app['outputs'][0]['bytes']==4*h*4
 assert code.count('asc_copy_ub2gm_align(')==1
 line=next(s for s in code.splitlines() if 'asc_copy_ub2gm_align(' in s)
 assert 'weight_fused[' in line and re.search(r',\s*1,\s*1024,\s*static_cast<asc_store_l2_cache_mode>',line)
 if h==256:assert 'block_idx) * 256' in line
 else:assert 'block_idx) % 4' in line and 'block_idx) / 4' in line and ('w * 3584' in line if h>3584 else True)
 op,=list((p/'capture').rglob('OpBasicInfo.csv'));basic,=read(op)
 assert basic['Op Name']==app['runtime_kernel'] and basic['Op Type']=='vector' and basic['Block Dim']=='56' and basic['Device Id']==device
 binary=op.parent/'dump/aicore_binary.o';bsha=sha(binary)
 assert any(x.startswith(bsha+' ') and x.rstrip().endswith('/kernel.aibin') for x in (p/'cache-sha256.txt').read_text().splitlines())
 objdump=os.environ.get('BACKFILL_OBJDUMP','/home/pkg/cann920/cann-9.2.0/tools/bisheng_compiler/bin/llvm-objdump')
 isa=subprocess.check_output([objdump,'-d',str(binary)],text=True);(p/'device-kernel.isa').write_text(isa)
 raw=(p/'profile.log').read_text(errors='replace');stores=[x for x in raw.splitlines() if 'DBI record core:' in x and 'dst:(type:GM;' in x and 'src:(type:UB;' in x]
 rec=R.findall(raw);expected=4*h//256;assert len(stores)==len(rec)==expected,(len(stores),len(rec),expected)
 base=int(app['device_output_addresses'][0],16);segments=Counter();blocks=Counter();pcs=set()
 for c,pc,addr,stride,l1s,l2s,srcaddr,srcstride,srcl1s,srcl2s,burst,length,dtype,l1,l2,left,right in rec:
  c=int(c);addr=int(addr,16);offset=addr-base;row,within=divmod(offset,h*4);chunk,rem=divmod(within,1024)
  assert 0<=row<4 and 0<=chunk<h//256 and rem==0
  assert (int(burst),int(length),int(l1),int(l2),int(left),int(right))==(1,1024,1,1,0,0)
  block=(chunk%14)*4+row;assert (c//3,c%3)==divmod(block,2)
  segments[(row,chunk)]+=1;blocks[block]+=1024;pcs.add(int(pc,16))
 assert len(segments)==expected and all(v==1 for v in segments.values())
 for pc in pcs:assert any(re.match(r'^\s*'+format(pc,'x')+r':',line) and 'MOV_UB_TO_OUT' in line for line in isa.splitlines())
 memory=read(op.with_name('Memory.csv'));assert len(memory)==56
 for i,row in enumerate(memory):
  assert int(row['block_id'])==i and row['sub_block_id']=='vector0'
  value=row['UB_to_GM_datas(KB)'];expected_pair=blocks[2*i]+blocks[2*i+1] if i<28 else None
  if i<28 and value not in ('NA',''):assert Decimal(value)*1024==expected_pair
  elif i<28:assert expected_pair==0
  else:assert value in ('NA','')
 result={'target':'starter/'+case,'status':'passed','device':host+' NPU '+device,'correctness':'passed',
  'historical_input_and_source_match':True,'runtime_kernel':basic['Op Name'],'dbi_requested_bytes':sum(blocks.values()),
  'output_logical_bytes':4*h*4,'per_vector_block_requested_bytes':{i:blocks[i] for i in range(56)},
  'capture_binary_sha256':bsha,'dbi_pc':[hex(x) for x in sorted(pcs)],'csv_pair_totals_match':True,
  'scope':'one MemoryDetail window; requested UB to GM bytes, not physical DRAM transactions',
  'max_seconds_between_successful_device_queries':monitor['max_seconds_between_successful_queries']}
 (p/'audit-result.json').write_text(json.dumps(result,indent=2)+'\n');print('PASS',case,sum(blocks.values()))
if __name__=='__main__':main()
