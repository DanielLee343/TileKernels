"""Test whether historical head-fwd binaries have any UB-to-GM opcode."""
import csv,hashlib,json,re,subprocess
from pathlib import Path
repo=Path('/workspace/tilekernels-env-20261101/src/TileKernels-private')
base=repo/'research/ascend-profiling/runs/hidev-20261106-third/cases';tool='/workspace/tilekernels-env-20261101/cann/cann-9.2.1/tools/bisheng_compiler/bin/llvm-objdump'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
results=[]
for i in range(1,21):
 case=f'head-fwd-{i:02d}';d=base/case
 try:
  j=json.loads((d/'default.json').read_text());assert j['status']=='passed'
  src=d/'default-kernel.cpp';assert sha(src)==j['source_sha256'];text=src.read_text()
  op,=list((d/'capture').rglob('OpBasicInfo.csv'))
  with op.open(encoding='utf-8-sig',newline='') as f:basic,=list(csv.DictReader(f))
  binary=op.parent/'dump/aicore_binary.o';isa=subprocess.check_output([tool,'-d',str(binary)],text=True)
  assert basic['Op Name']==j['runtime_kernel']=='mhc_head_compute_mix_fwd_asc_kernel' and basic['Op Type']=='vector'
  assert '__simt_vf__' in text and 'output_mix[' in text and re.search(r'\bSTG\.',isa)
  assert not re.search(r'asc_copy_ub2gm|copy_ubuf_to_gm',text,re.I)
  assert not re.search(r'MOV_UB_TO_OUT|UBUF_TO_GM',isa,re.I)
  results.append({'target':'third/'+case,'status':'aiv_ub_to_gm_not_applicable','correctness':'passed',
   'source_sha256':sha(src),'metadata_sha256':sha(d/'default.json'),'binary_sha256':sha(binary),
   'opbasic_sha256':sha(op),'binary_path':binary.relative_to(repo).as_posix(),
   'metadata_path':(d/'default.json').relative_to(repo).as_posix(),'output_shape':j['outputs'][0]['shape'],
   'evidence':'original generated source and captured ISA have no UB-to-GM move; binary contains SIMT STG',
   'scope':'UB-to-GM only; direct SIMT GM stores exist and must not be reported as zero total GM writes'})
  print(case,'static_no_ub_gm','shape',j['outputs'][0]['shape'],'binary_sha256',sha(binary),flush=True)
 except Exception as e:print(case,'NEEDS_REVIEW',type(e).__name__,str(e),flush=True)
out=Path('/workspace/expert-profile-backfill-20261109-hidev/historical-head-no-ub-gm.json')
out.write_text(json.dumps({'method':'static historical source and captured device ISA; see also new dynamic representative',
 'tool':tool,'cases':results},indent=2)+'\n')
print('saved',len(results),'of 20',flush=True)
