#!/usr/bin/env bash
set -Eeuo pipefail
root=/workspace/expert-profile-backfill-20261109-hidev
q="$root/extra-norm-backward-smoke-hidev-npu0";mkdir -p "$q"
trap 'rc=$?;printf "exit=%s at=%s\n" "$rc" "$(date -u +%FT%TZ)" > "$q/exit.txt"' EXIT
previous="$root/extra-quant-cast-smoke-hidev-npu0";pid=$(cat "$previous/pid")
while ps -p "$pid" -o args= | grep -Fq "$root/orchestrate-quant-cast-smoke.sh";do sleep 10;done
export TARGET_ID=unified-extra3/quant_norm_backward-01 ATTEMPT=attempt-001
bash "$root/run-hidev-extra-norm-backward-detail.sh"
python3 -B "$root/inspect-extra-norm-backward.py" "$TARGET_ID" "$ATTEMPT"
echo NORM_BACKWARD_SMOKE_CAPTURE_IDENTIFIED_ADDRESS_AUDIT_PENDING
