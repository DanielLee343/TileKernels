#!/usr/bin/env bash
set -Eeuo pipefail
root=/workspace/expert-profile-backfill-20261109-hidev
previous="$root/unified-quant-block-sfonly-queue-hidev-npu0"
q="$root/unified-quant-block-castonly-queue-hidev-npu0"
mkdir -p "$q"
trap 'rc=$?; printf "exit=%s at=%s\n" "$rc" "$(date -u +%FT%TZ)" > "$q/followup-exit.txt"' EXIT
pid=$(cat "$previous/queue.pid")
while ps -p "$pid" -o args= | grep -Fq "$root/hidev-uq-block-sfonly-queue.py"; do sleep 10; done
echo 'previous queue exited; beginning independent smoke'
export CASE_ID=quant_per_block_cast_with_precomputed_sf-01 ATTEMPT=attempt-001
bash "$root/run-hidev-unified-quant-extra-detail.sh"
python3 -B "$root/inspect-unified-quant-extra.py" "$CASE_ID" "$ATTEMPT"
python3 -B "$root/audit-uq-block-castonly.py" "$CASE_ID" "$ATTEMPT"
bash "$root/test-uq-block-castonly-audit.sh"
echo 'representative and negative tests passed; start group queue'
python3 -B "$root/hidev-uq-block-castonly-queue.py"
echo 'group queue finished; run per-channel identity smoke'
export TARGET_ID=unified-extra2/quant_per_channel_cast-01 ATTEMPT=attempt-001
bash "$root/run-hidev-extra-proxy-detail.sh"
python3 -B "$root/inspect-extra-proxy.py" "$TARGET_ID" "$ATTEMPT"
echo 'per-channel identity smoke finished; independent address audit still required'
