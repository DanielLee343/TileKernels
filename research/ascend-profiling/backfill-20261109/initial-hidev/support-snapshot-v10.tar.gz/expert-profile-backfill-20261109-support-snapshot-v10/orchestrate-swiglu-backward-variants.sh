#!/usr/bin/env bash
set -Eeuo pipefail
root=/workspace/expert-profile-backfill-20261109-hidev
q="$root/extra-swiglu-backward-variants-smoke-hidev-npu0";mkdir -p "$q"
trap 'rc=$?;printf "exit=%s at=%s\n" "$rc" "$(date -u +%FT%TZ)" > "$q/exit.txt"' EXIT
previous="$root/dg-bf16-mgroup-smoke-hidev-npu0";pid=$(cat "$previous/pid")
while ps -p "$pid" -o args= | grep -Fq "$root/orchestrate-dg-bf16-mgroup-smoke.sh";do sleep 10;done
for n in 13 12 07 08;do
 export TARGET_ID="unified-extra4/quant_swiglu_backward-$n" ATTEMPT=attempt-001
 bash "$root/run-hidev-extra-swiglu-backward-detail.sh"
 python3 -B "$root/inspect-extra-swiglu-backward.py" "$TARGET_ID" "$ATTEMPT"
 echo "$TARGET_ID identity checked; address audit pending"
done
