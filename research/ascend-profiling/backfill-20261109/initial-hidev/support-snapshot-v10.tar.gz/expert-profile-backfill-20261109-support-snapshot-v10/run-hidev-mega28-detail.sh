#!/usr/bin/env bash
set -Eeo pipefail
root=/workspace/expert-profile-backfill-20261109-hidev
dg=/workspace/deepgemm-ascend-20261107
case_id="${CASE_ID:?}";attempt="${ATTEMPT:?}";replay="${REPLAY_MODE:-range}";metrics="${METRIC_SET:-MemoryDetail,Default}"
case "$case_id" in mega-h256-i512-e4-top2-t16|mega-h256-i512-e4-top2-t64|mega-h512-i1024-e8-top4-t64|mega-h512-i512-e8-top2-t32) ;; *) exit 2;; esac
case "$replay" in range|kernel|application) ;; *) exit 2;; esac
case "$metrics" in MemoryDetail|MemoryDetail,Default) ;; *) exit 2;; esac
unset LD_LIBRARY_PATH PYTHONPATH LD_PRELOAD MEMORYCHART_ROOT MEMORYCHART_LOG MSOPT_LOG_LEVEL
source "$dg/activate.sh"
set -u
export ASCEND_HOME_PATH="$dg/cann-compat-quant" BISHENG_HOME="$dg/cann-compat-quant"
export PYTHONPATH="$dg/mega-port28-experiment/packages${PYTHONPATH:+:$PYTHONPATH}"
export ASCEND_RT_VISIBLE_DEVICES=0 PYTHONDONTWRITEBYTECODE=1 GUARD_DEADLINE_SECONDS=900 GUARD_MAX_LOG_BYTES=536870912
export DG_JIT_CACHE_DIR="$root/mega28-cache/$case_id"
exec 9> /workspace/.puma-hidev-npu0.lock
flock -n 9
test "$(git -C "$dg/source" rev-parse HEAD)" = 3a35326271b069b8b5bf1a754435acd6cc91575b
test -z "$(git -C "$dg/source" status --porcelain --untracked-files=no)"
orig="$dg/source/deep_gemm/include/deep_gemm/common.hpp";port="$dg/mega-port28-experiment/source/deep_gemm/include/deep_gemm/common.hpp"
echo '665037e4dbe5801d70847a3da77eec78e7b25874d899f478ab8310cae4b9d590  '"$orig" | sha256sum -c
echo 'e765ea8e9ff6a17c71c16f71f487de2cef945d219e45d631251be27416315896  '"$port" | sha256sum -c
out="$root/mega28-runs/$case_id/hidev-npu0/$attempt"
test ! -e "$out";mkdir -p "$out/provenance"
trap 'timeout 10 npu-smi info -t health -i 0 > "$out/provenance/health-after.txt" 2>&1 || true' EXIT
timeout 10 npu-smi info -t board -i 0 > "$out/provenance/board.txt";grep -qi '0000:8b:00.0' "$out/provenance/board.txt"
timeout 10 npu-smi info -t health -i 0 > "$out/provenance/health-before.txt"
msprof op --version > "$out/provenance/msprof-version.txt";grep -q 884ac969494a186a9c63ac45c4c39ad7289b3215 "$out/provenance/msprof-version.txt"
git -C "$dg/source" rev-parse HEAD > "$out/provenance/commit.txt"
printf '%s\n' "$ASCEND_HOME_PATH" > "$out/provenance/cann-path.txt"
cp "$root/guard-v6.py" "$root/run-hidev-mega28-detail.sh" "$root/mega28-profile-harness/provenance.json" "$out/provenance/"
(cd "$out/provenance" && sha256sum *.py *.json *.sh *.txt > sha256.txt)
harness="$root/mega28-profile-harness/campaign-13/mega_port_run.py";source_dir="$dg/mega-port28-experiment/source"
cd "$root";export GUARD_REQUIRE_PROFILE=0
python -B guard-v6.py 0 "$out/prepare-monitor" python -B "$harness" --worker --case "$case_id" --source "$source_dir" --stage prepare --output "$out/prepare.json"
export GUARD_REQUIRE_PROFILE=1 MSOPT_LOG_LEVEL=0
python -B guard-v6.py 0 "$out/detail" \
 msprof op "--output=$out/detail/capture" "--aic-metrics=$metrics" "--replay-mode=$replay" \
 --mstx=true --mstx-include=dg_mega_port '--kernel-name=*mega_moe_impl*' --launch-count=1 --warm-up=0 \
 python -B "$harness" --worker --case "$case_id" --source "$source_dir" --stage profile --output "$out/profile.json"
if grep -Eq 'Child process exited with return value -?[1-9][0-9]*|\[ERROR\]' "$out/detail/profile.log";then
 echo 'profiler reported a child or collection error; capture not accepted' >&2;exit 2
fi
timeout 10 npu-smi info -t health -i 0 > "$out/provenance/health-after.txt"
printf '%s\n' 'capture complete; correctness identity, DBI completeness and core mapping must still be audited'
