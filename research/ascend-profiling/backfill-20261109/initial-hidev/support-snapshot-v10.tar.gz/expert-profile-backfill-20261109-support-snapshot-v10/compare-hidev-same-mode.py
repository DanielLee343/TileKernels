"""Compare three fresh Default captures against the archived Default for reduce-01."""
import csv,hashlib,json,statistics
from pathlib import Path
root=Path('/workspace/expert-profile-backfill-20261109-hidev')
old=Path('/workspace/tilekernels-expert-profiles-second-20261106/cases/reduce-01')
def read(p):
 with p.open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def numbers(folder,table,field):
 op,=list((folder/'capture').rglob('OpBasicInfo.csv'));rows=read(op.with_name(table+'.csv'))
 return [float(r[field]) for r in rows]
def main():
 oldmeta=json.loads((old/'default.json').read_text());oldop,=list((old/'capture').rglob('OpBasicInfo.csv'));basic,=read(oldop)
 oldbinary=oldop.parent/'dump/aicore_binary.o'
 fields=[('Memory','aiv_mte2_instructions'),('Memory','aiv_mte3_instructions'),('Memory','GM_to_UB_datas(KB)'),
         ('Memory','write_main_memory_datas(KB)'),('PipeUtilization','aiv_total_cycles'),('PipeUtilization','aiv_vec_time(us)'),
         ('PipeUtilization','aiv_mte2_time(us)'),('PipeUtilization','aiv_mte3_time(us)')]
 historical={field:numbers(old,table,field) for table,field in fields}
 results=[]
 for idx in ('001','002','003'):
  p=root/'smoke-default/reduce-01'/('attempt-'+idx);app=json.loads((p/'metadata/application.json').read_text());mon=json.loads((p/'monitor-summary.json').read_text())
  assert app['status']=='passed' and app['mode']=='default' and mon['status']=='passed'
  for key in ('runtime_kernel','source_sha256','inputs','outputs'):assert app[key]==oldmeta[key],key
  op,=list((p/'capture').rglob('OpBasicInfo.csv'));b,=read(op)
  assert b['Op Name']==basic['Op Name'] and b['Block Dim']==basic['Block Dim']=='4' and b['Current Freq']==basic['Current Freq']
  result={'attempt':idx,'task_us':float(b['Task Duration(us)']),
    'relative_task_pct':(float(b['Task Duration(us)'])/float(basic['Task Duration(us)'])-1)*100,
    'binary_sha256':sha(op.parent/'dump/aicore_binary.o'),'metrics':{field:numbers(p,table,field) for table,field in fields},
    'health_before':(p/'provenance/health-before.txt').read_text().strip(),
    'health_after':(p/'provenance/health-after.txt').read_text().strip(),
    'monitor_max_gap_seconds':mon['max_seconds_between_successful_queries']}
  results.append(result)
 out={'case':'engram_sinkhorn_step_reduce/01','historical_task_us':float(basic['Task Duration(us)']),
      'historical_binary_sha256':sha(oldbinary),'historical_metrics':historical,'new_attempts':results,
      'new_median_task_us':statistics.median(r['task_us'] for r in results),
      'matching_context':'same hidev PCI 0000:8B:00.0, CANN 9.2.1, msopprof build, Default kernel replay, five application and profiler warmups, matched case/input/source',
      'qualification':'one historical sample and three fresh samples do not establish a complete variance distribution; device remains in Alarm.'}
 (root/'smoke-default/comparison.json').write_text(json.dumps(out,indent=2)+'\n')
 print(json.dumps(out,indent=2))
if __name__=='__main__':main()
