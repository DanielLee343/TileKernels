#!/usr/bin/env bash
set -Eeuo pipefail
root=/workspace/expert-profile-backfill-20261109-hidev
q="$root/dg-bf16-mgroup-smoke-hidev-npu0";mkdir -p "$q"
trap 'rc=$?;printf "exit=%s at=%s\n" "$rc" "$(date -u +%FT%TZ)" > "$q/exit.txt"' EXIT
previous="$root/extra-norm-backward-smoke-hidev-npu0";pid=$(cat "$previous/pid")
while ps -p "$pid" -o args= | grep -Fq "$root/orchestrate-norm-backward-smoke.sh";do sleep 10;done
export CASE_ID=mgroup-bf16bf16-nt-g4-m128-n256-k512 ATTEMPT=attempt-001
bash "$root/run-hidev-deepgemm-bf16-mgroup.sh"
python3 -B "$root/inspect-deepgemm-bf16-mgroup.py" "$CASE_ID" "$ATTEMPT"
echo DG_BF16_MGROUP_SMOKE_IDENTITY_CHECKED_ADDRESS_AUDIT_PENDING
