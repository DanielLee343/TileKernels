"""Collect the remaining FIRST cases serially and validate each independently."""
import fcntl,hashlib,json,os,re,shutil,subprocess,sys,time
from pathlib import Path
root=Path('/workspace/expert-profile-backfill-20261109-hidev');q=root/'deepgemm-paged-first-app-queue-hidev-npu0';q.mkdir(exist_ok=True)
lock=(q/'queue.lock').open('w');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
items=[x for x in json.loads((root/'deepgemm-paged-sparse-app-harness/campaign-13/cases.json').read_text())['cases'] if x.get('sparse_phase')=='first'];assert len(items)==4
for item in items:
 case=item['id'];assert re.fullmatch(r'paged-sparse-first-[01]-[a-z0-9-]+',case)
 base=root/'deepgemm-runs'/case/'hidev-npu0';attempts=sorted(base.glob('attempt-*')) if base.exists() else []
 if any((a/'address-audit.json').exists() and json.loads((a/'address-audit.json').read_text()).get('status')=='passed' for a in attempts):print(case,'already audited; skip',flush=True);continue
 ids=[int(a.name.removeprefix('attempt-')) for a in attempts if re.fullmatch(r'attempt-\d+',a.name)];attempt=f'attempt-{max(ids,default=0)+1:03d}';work=q/(case+'-'+attempt);work.mkdir(exist_ok=False);out=base/attempt
 status={'case':case,'attempt':attempt,'status':'running','started_unix':time.time()};(work/'queue-status.json').write_text(json.dumps(status,indent=2)+'\n')
 env=os.environ.copy();env.update(CASE_ID=case,ATTEMPT=attempt)
 # The inspector imports the fixed DeepGEMM collector; run it in that environment.
 inspect="unset LD_LIBRARY_PATH PYTHONPATH LD_PRELOAD; source /workspace/deepgemm-ascend-20261107/activate.sh; export ASCEND_HOME_PATH=/workspace/deepgemm-ascend-20261107/cann-compat-quant BISHENG_HOME=/workspace/deepgemm-ascend-20261107/cann-compat-quant ASCEND_RT_VISIBLE_DEVICES=0 PYTHONDONTWRITEBYTECODE=1; exec python3 -B /workspace/expert-profile-backfill-20261109-hidev/inspect-paged-sparse-first-app.py \"$CASE_ID\" \"$ATTEMPT\""
 stages=[('capture',['bash',str(root/'run-hidev-deepgemm-paged-sparse-first-app.sh')]),('inspection',['bash','-c',inspect]),('audit',[sys.executable,'-B',str(root/'audit-paged-sparse-first-app-candidate-v2.py'),case,attempt]),('negative_tests',['bash',str(root/'test-paged-first-generic-v2.sh'),case,attempt])]
 for stage,cmd in stages:
  with (work/(stage+'-console.log')).open('w') as f:run=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
  status[stage+'_exit']=run.returncode
  if run.returncode:status['status']=stage+'_failed';break
 else:
  log=(work/'negative_tests-console.log').read_text();assert 'PASS rejects missing compact/logits records, duplicate record, wrong CSV and unauthorized alias' in log
  before=(out/'provenance/health-before.txt').read_text(errors='replace');after=(out/'provenance/health-after.txt').read_text(errors='replace');assert '8C4BA00C' in before and '8C4BA00C' in after
  candidate=out/'candidate-address-audit-v2.json';final=out/'address-audit.json';audit=json.loads(candidate.read_text());assert audit['case']=='campaign-13/'+case and audit['status']=='passed' and audit['dbi_requested_bytes']==sum(audit['expected_requested_bytes'].values()) and not final.exists();final.write_bytes(candidate.read_bytes())
  def sha(f):
   h=hashlib.sha256()
   with f.open('rb') as z:
    for chunk in iter(lambda:z.read(1024*1024),b''):h.update(chunk)
   return h.hexdigest()
  files={str(f.relative_to(root)):sha(f) for f in sorted(out.rglob('*')) if f.is_file() and not f.is_symlink()};assert any(x.endswith('Memory.csv') for x in files) and any(x.endswith('OpBasicInfo.csv') for x in files)
  evidence={'case':audit['case'],'audit':audit,'raw_dir':str(out),'files_sha256':files,'health':'Alarm 8C4BA00C','negative_test_log':str(work/'negative_tests-console.log'),'negative_test_sha256':sha(work/'negative_tests-console.log')};(work/'index.json').write_text(json.dumps(evidence,indent=2)+'\n');status['status']='passed'
 status['finished_unix']=time.time();tmp=work/'queue-status.tmp';tmp.write_text(json.dumps(status,indent=2)+'\n');tmp.replace(work/'queue-status.json');print(case,status['status'],flush=True)
 if status['status']!='passed':sys.exit(1)
print('ALL_PAGED_FIRST_APPLICATION_AUDITED',flush=True)
