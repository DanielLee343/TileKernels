"""Bind an actual mask copy to the historical input hash for a masked capture."""
import hashlib,json,subprocess,sys
from pathlib import Path
root=Path('/workspace/expert-profile-backfill-20261109-hidev');target,attempt=sys.argv[1:]
assert target.startswith('unified-extra5/engram_gate_fwd-')
subprocess.run([sys.executable,'-B',str(root/'inspect-extra-engram-gate-fwd.py'),target,attempt],check=True)
p=root/'extra-proxy-runs'/target/'hidev-npu0'/attempt/'detail'
a=json.loads((p/'application.json').read_text());data=(p/'mask-uint8.bin').read_bytes()
record,=(x['tensor'] for x in a['inputs'] if x['name']=='image_token_mask')
assert a['params']['with_mask'] and len(data)==a['params']['num_tokens'] and set(data)<={0,1}
assert record['dtype']=='torch.bool' and record['shape']==[len(data)] and hashlib.sha256(data).hexdigest()==record['sha256']
d=json.loads((p/'capture-inspection.json').read_text());d['mask_sha256']=record['sha256'];d['masked_tokens']=sum(data);d['unmasked_tokens']=len(data)-sum(data)
(p/'capture-inspection.json').write_text(json.dumps(d,indent=2)+'\n')
print('MASK_BYTES_BOUND_TO_HISTORICAL_INPUT',d['masked_tokens'],d['unmasked_tokens'])
