"""Audit sparse-metadata AIV binaries and resolve each indirect debug call."""
import csv,hashlib,json,re,subprocess
from pathlib import Path
root=Path('/workspace/expert-profile-backfill-20261109-hidev')
source_repo=Path('/workspace/deepgemm-ascend-20261107/source')
src=source_repo/'deep_gemm/include/deep_gemm/sparse_mqa_logits_metadata.hpp'
tool=Path('/workspace/tilekernels-env-20261101/cann/cann-9.2.1/tools/bisheng_compiler/bin/llvm-objdump')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert subprocess.check_output(['git','-C',str(source_repo),'rev-parse','HEAD'],text=True).strip()=='3a35326271b069b8b5bf1a754435acd6cc91575b'
rel=src.relative_to(source_repo).as_posix()
assert subprocess.check_output(['git','-C',str(source_repo),'hash-object',str(src)],text=True).strip()==subprocess.check_output(['git','-C',str(source_repo),'rev-parse','HEAD:'+rel],text=True).strip()
source=src.read_text();assert 'void sparse_mqa_logits_metadata(' in source and 'copy_gm_to_ub(' in source and 'asc_vf_call<sparse_mqa_logits_metadata_vf' in source
allowed=set('ADD ADDI AND BAR BRANCH CALL CMP CMPN DCCI DSB END END_DVG F2I FDIV I2F IADD IMAD IMNMX IMUL INSERT ISETP JUMPCI JUMPI LD LDG LDK LDP LDS LD_DEV LD_IO LEA LOP3 MADD MEMBAR MIN MOV MOVEMASK MOVI MOVK MOV_OUT_TO_UB_ALIGN_V2 MUL MULI NEG NOP OR P2R PLOP3 POPC PSET PUSH_PB REDUX REM RET S2R SADD SADDI SAND SBITSET0 SBITSET1 SCMP SEL SEND SET_CROSS_CORE_V SET_FLAG SET_FLAG_V SHF SHFI SHFL SHLI SHRI SIGNEXT SMEM_BAR SMIN SMOV SMOVI SMOVK SSHLI SSHRI SSUB ST START_DVG STG STI STI_IO STK STP STS ST_IO SUB SUBI SXOR SZEROEXT TRAP VADDS VBR VF VF_SIMT VLDI VLOOPV2_V310 VOTE VSHLI VST VSTI WAIT_FLAG WAIT_FLAG_DEV WAIT_FLAG_V ZEROEXT'.split())
survey=json.loads((root/'deepgemm-vector-isa-survey.json').read_text())['cases']
items=[x for x in survey if 'sparse_mqa_logits_metadata26sparse_mqa_logits_metadata' in x['op_name']];assert len(items)==8
out=root/'deepgemm-sparse-meta-static-audit';out.mkdir(exist_ok=True);(out/src.name).write_bytes(src.read_bytes());records=[]
for item in items:
 binary=Path(item['binary']);assert sha(binary)==item['binary_sha256'];profile=binary.parents[1];d=profile.parent.parent;case=d.name
 result=json.loads((d/'result.json').read_text());assert result['status']=='passed' and result['capture']['jit_binary_sha256']==sha(binary)
 wrapper=d/'jit/kernel.asc';assert 'sparse_mqa_logits_metadata<' in wrapper.read_text()
 with (profile/'OpBasicInfo.csv').open(encoding='utf-8-sig',newline='') as f:basic,=list(csv.DictReader(f))
 assert basic['Op Name']==item['op_name'] and basic['Op Type']=='vector'
 asm=subprocess.check_output([str(tool),'-d',str(binary)],text=True)
 symbols={int(pc,16):name for pc,name in re.findall(r'^([0-9a-f]+) <([^>]+)>:',asm,re.M)}
 rows=re.findall(r'^\s*([0-9a-f]+):\s+[0-9a-f]+\s+(.+)$',asm,re.M)
 ins=[re.match(r'([A-Z][A-Z0-9_]*)',x[1]).group(1) for x in rows]
 assert rows and set(ins)<=allowed,(case,sorted(set(ins)-allowed))
 assert 'STG' in ins and not any(x.startswith('MOV_UB_TO_OUT') for x in ins)
 calls=[]
 for i,(pc,inst) in enumerate(rows):
  if not inst.startswith('CALL'):continue
  assert i>=3 and re.match(r'CALL\s+X24\b',inst)
  m=re.match(r'MOVI\s+X24,\s*#(\d+)',rows[i-3][1]);assert m
  assert re.match(r'MOVK\s+X24,\s*#0,\s*#1',rows[i-2][1]) and re.match(r'MOVK\s+X24,\s*#0,\s*#2',rows[i-1][1])
  target=int(pc,16)+4*int(m.group(1));name=symbols[target];assert 'AscVFDebug' in name
  calls.append({'pc':pc,'target':hex(target),'symbol':name})
 assert calls
 isa=out/(case+'.isa');isa.write_text(asm)
 records.append({'target':'campaign-13/'+case,'status':'aiv_ub_to_gm_not_applicable','correctness':'passed',
  'binary_sha256':sha(binary),'binary_path':str(binary),'wrapper_sha256':sha(wrapper),'isa_path':str(isa),'isa_sha256':sha(isa),
  'instruction_count':len(ins),'opcodes':sorted(set(ins)),'resolved_calls':calls,
  'reason':'original AIV binary has SIMT GM stores but no UB-to-GM instruction; all indirect calls resolved to saved debug functions'})
doc={'source_commit':'3a35326271b069b8b5bf1a754435acd6cc91575b','header_sha256':sha(src),'cases':records,
 'scope':'UB-to-GM movement only; SIMT and scalar GM accesses are outside the field'}
(out/'audit.json').write_text(json.dumps(doc,indent=2)+'\n');print('SPARSE_META_STATIC_AUDIT',len(records),sha(out/'audit.json'))
