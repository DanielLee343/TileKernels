"""Audit out and out_sf address coverage for the tested per-token kernel."""
import csv,hashlib,itertools,json,os,re,subprocess,sys
from collections import Counter
from decimal import Decimal
from importlib.machinery import SourceFileLoader
from pathlib import Path

root=Path(os.environ.get('BACKFILL_ROOT','/workspace/expert-profile-backfill-20261109-hidev'))
case,attempt=sys.argv[1:];assert case=='quant_swiglu_backward-01'
p=root/'extra-proxy-runs'/'unified-extra4'/case/'hidev-npu0'/attempt/'detail'
ident=json.loads((p/'capture-inspection.json').read_text());assert ident['status']=='capture_identified_address_audit_pending'
assert ident['correctness']=='passed' and ident['historical_input_and_source_match']
assert all(d=='0' and m=='0' for _,d,m in ident['parser_metrics']) and ident['parser_metrics']
a=json.loads((p/'tensor-addresses.json').read_text());assert len(a)==12 and a[0] and a[2] and a[9] and all(a[i] is None for i in (1,3,4,5,6,7,8,10,11))
assert a[0]['shape']==a[9]['shape']==[128,256] and a[2]['shape']==[128,128]
def span(t):
 lo=int(t['address'],16);hi=lo+t['element_size']*(1+sum((n-1)*stride for n,stride in zip(t['shape'],t['stride'])))
 return lo,hi
for x in (a[0],a[2]):
 l1,h1=span(x);l2,h2=span(a[9]);assert h1<=l2 or h2<=l1,'input/output buffer overlap'
source=(p/'generated-kernel.cpp').read_text();lines=[x for x in source.splitlines() if 'asc_copy_ub2gm_align(' in x]
assert len(lines)==2 and all('x_grad[' in x.split('(__ubuf__',1)[0] for x in lines) and 'block_idx' in source
op,=list((p/'capture').rglob('OpBasicInfo.csv'))
def read(path):
 with path.open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
basic,=read(op);assert basic['Op Type']=='vector' and basic['Block Dim']=='56' and basic['Device Id']=='0'
binary=op.parent/'dump/aicore_binary.o';assert hashlib.sha256(binary.read_bytes()).hexdigest()==ident['capture_binary_sha256']
isa=subprocess.check_output(['/workspace/tilekernels-env-20261101/cann/cann-9.2.1/tools/bisheng_compiler/bin/llvm-objdump','-d',str(binary)],text=True)
(p/'device-kernel.isa').write_text(isa)
R=SourceFileLoader('r',str(root/'audit-reduce-family.py')).load_module().REGEX
log=(p/'profile.log').read_text(errors='replace');events=R.findall(log)
stores=[x for x in log.splitlines() if 'DBI record core:' in x and 'dst:(type:GM;' in x and 'src:(type:UB;' in x]
assert len(events)==len(stores)>0
def merge(intervals):
 out=[]
 for lo,hi in sorted(intervals):
  assert lo<hi
  if out and lo<out[-1][1]:raise AssertionError(('overlap',lo,hi,out[-1]))
  if out and lo==out[-1][1]:out[-1]=(out[-1][0],hi)
  else:out.append((lo,hi))
 return out
expected=[]
for item in a[9:10]:
 shape=item['shape'];stride=item['stride'];size=item['element_size'];base=int(item['address'],16)
 assert shape and len(shape)==len(stride) and stride[-1]==1 and all(x>0 for x in shape) and all(x>=0 for x in stride)
 assert __import__('math').prod(shape[:-1])<=1000000
 intervals=[]
 for coords in itertools.product(*(range(n) for n in shape[:-1])):
  lo=base+size*sum(c*s for c,s in zip(coords,stride));intervals.append((lo,lo+shape[-1]*size))
 expected.append(merge(intervals))
actual=[[]];percore=Counter();rounded=Counter();pcs=set()
for c,pc,addr,stride,l1s,l2s,srcaddr,srcstride,srcl1s,srcl2s,burst,length,dtype,l1,l2,left,right in events:
 c=int(c);assert c%3 in (0,1) and c//3<28;pcs.add(int(pc,16));addr=int(addr,16)
 stride=int(stride);l1s=int(l1s);l2s=int(l2s);n=int(burst);length=int(length);l1=int(l1);l2=int(l2)
 assert n>0 and length>0 and l1>=1 and l2>=1 and int(left)==int(right)==0
 percore[c]+=n*length*l1*l2
 rounded[c]+=(((n*length+31)//32)*32 if int(srcstride)==length else n*((length+31)//32)*32)*l1*l2
 for z in range(l2):
  for y in range(l1):
   for x in range(n):
    lo=addr+z*l2s+y*l1s+x*stride;hi=lo+length
    candidates=[i for i,intervals in enumerate(expected) if any(a<=lo and hi<=b for a,b in intervals)]
    assert len(candidates)==1,(hex(lo),hex(hi),candidates);actual[candidates[0]].append((lo,hi))
assert all(merge(actual[i])==expected[i] for i in (0,))
for pc in pcs:assert any(re.match(r'^\s*'+format(pc,'x')+r':',line) and 'MOV_UB_TO_OUT' in line for line in isa.splitlines()),hex(pc)
mem=read(op.with_name('Memory.csv'));assert len(mem)==56
for j,row in enumerate(mem):
 assert int(row['block_id'])==j and row['sub_block_id']=='vector0';value=row['UB_to_GM_datas(KB)'];total=rounded[3*j]+rounded[3*j+1] if j<28 else None
 if j<28 and value not in ('NA',''):assert abs(Decimal(value)*1024-total)<=Decimal('0.000512'),(j,value,total)
 elif j<28:assert total==0
 else:assert value in ('NA','')
result={'target':'unified-extra4/'+case,'status':'passed','device':'hidev NPU 0','correctness':'passed',
 'historical_input_and_source_match':True,'runtime_kernel':basic['Op Name'],'dbi_requested_bytes':sum(percore.values()),
 'output_logical_bytes':sum(item['logical_bytes'] for item in a[9:10]),'per_vector_block_requested_bytes':{i:percore[3*(i//2)+i%2] for i in range(56)},
 'capture_binary_sha256':ident['capture_binary_sha256'],'dbi_pc':[hex(x) for x in sorted(pcs)],'csv_pair_totals_match':True,
 'scope':'one MemoryDetail window; requested UB to GM bytes, not physical DRAM transactions'}
assert result['dbi_requested_bytes']==result['output_logical_bytes']
(p/'candidate-audit-result.json').write_text(json.dumps(result,indent=2)+'\n');print('PASS',case,result['dbi_requested_bytes'])
