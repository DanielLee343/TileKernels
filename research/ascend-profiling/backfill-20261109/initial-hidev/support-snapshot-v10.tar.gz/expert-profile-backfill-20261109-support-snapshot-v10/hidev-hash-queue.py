"""Sequentially capture and audit hash cases on hidev."""
import fcntl,json,os,re,subprocess,sys,time
from pathlib import Path
root=Path('/workspace/expert-profile-backfill-20261109-hidev');q=root/'hash-queue-hidev-npu0';q.mkdir(exist_ok=True)
lock=(q/'queue.lock').open('w');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
cases=json.loads((root/'hash-pending.json').read_text());assert len(cases)==20
for item in cases:
 case=item['case'];base=root/'hash-runs'/case/'hidev-npu0'
 if case in ('hash-17','hash-18'):
  print(item['target'],'large input deferred pending profiler-record integrity fix',flush=True);continue
 attempts=sorted(base.glob('attempt-*')) if base.exists() else []
 if any((a/'detail/audit-result.json').exists() and json.loads((a/'detail/audit-result.json').read_text()).get('status')=='passed' for a in attempts):
  print(item['target'],'already audited; skip',flush=True);continue
 if any((a/'queue-status.json').exists() and json.loads((a/'queue-status.json').read_text()).get('capture_exit')==0 for a in attempts):
  print(item['target'],'capture retained; audit pending; skip recapture',flush=True);continue
 if any((a/'detail/guard-error.txt').exists() and 'profile deadline exceeded' in (a/'detail/guard-error.txt').read_text() for a in attempts):
  print(item['target'],'previous profile timeout retained; skip for separate investigation',flush=True);continue
 if any((a/'detail/agent-stopped-hang.txt').exists() for a in attempts):
  print(item['target'],'previous stalled profile stopped; skip for separate investigation',flush=True);continue
 indexes=[int(a.name.removeprefix('attempt-')) for a in attempts if re.fullmatch(r'attempt-\d+',a.name)]
 attempt=f'attempt-{max(indexes,default=0)+1:03d}';out=base/attempt;out.mkdir(parents=True,exist_ok=False)
 status={'target':item['target'],'device':'hidev-npu0','attempt':attempt,'status':'running','started_unix':time.time(),
         'device_health':'Alarm 8C4BA00C observed in preflight; inspect per-case health records'}
 (out/'queue-status.json').write_text(json.dumps(status,indent=2)+'\n')
 env=os.environ.copy();env.update(CASE_ID=case,ATTEMPT=attempt)
 with (out/'launcher-console.log').open('w') as log:
  capture=subprocess.run(['bash',str(root/'run-hidev-hash-detail.sh')],env=env,stdout=log,stderr=subprocess.STDOUT)
 status['capture_exit']=capture.returncode
 if capture.returncode==0:
  with (out/'audit-console.log').open('w') as log:
   audit=subprocess.run([sys.executable,'-B',str(root/'audit-hash-detail.py'),case,'0',attempt],env=env,stdout=log,stderr=subprocess.STDOUT)
  status['audit_exit']=audit.returncode;status['status']='passed' if audit.returncode==0 else 'audit_failed'
 else:status['status']='capture_failed'
 status['finished_unix']=time.time();tmp=out/'queue-status.tmp';tmp.write_text(json.dumps(status,indent=2)+'\n');tmp.replace(out/'queue-status.json')
 print(item['target'],status['status'],flush=True)
 if status['status']=='capture_failed':
  error=out/'detail/guard-error.txt'
  if error.exists() and 'profile deadline exceeded' in error.read_text():
   print(item['target'],'profile timeout retained; continue other cases',flush=True);continue
  sys.exit(1)
print('ALL_HASH_CASES_CAPTURED_OR_AUDITED',flush=True)
