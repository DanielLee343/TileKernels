"""Audit full 16-row UB stores; the source handles an incomplete tail via SIMT."""
import csv,hashlib,json,os,re,subprocess,sys
from collections import Counter
from decimal import Decimal
from pathlib import Path
from importlib.machinery import SourceFileLoader
root=Path(os.environ['BACKFILL_ROOT']);R=SourceFileLoader('r',str(root/'audit-reduce-family.py')).load_module().REGEX
case,attempt=sys.argv[1:];assert re.fullmatch(r'reduce-rms-bwd-(0[1-9]|1[0-9]|20)',case)
p=root/'classic-runs/fourth'/case/'hidev-npu0'/attempt/'detail';a=json.loads((p/'metadata/application.json').read_text());ident=json.loads((p/'capture-inspection.json').read_text())
assert ident['status']=='capture_identified_address_audit_pending' and ident['correctness']=='passed' and ident['historical_true_inputs_and_source_match']
assert a['runtime_kernel']=='mhc_reduce_partials_and_rmsnorm_bwd_asc_kernel' and a['case']['family']=='mhc_reduce_partials_and_rmsnorm_bwd'
n=a['case']['tokens'];outs=a['outputs'];assert [x['shape'] for x in outs]==[[n,1,24],[n,1]] and all(x['dtype']=='float32' for x in outs)
widths=(96,4);bases=[int(x,16) for x in a['device_output_addresses']];ends=[b+n*w for b,w in zip(bases,widths)]
assert ends[0]<=bases[1] or ends[1]<=bases[0]
code=(p/'metadata/default-kernel.cpp').read_text();lines=[x for x in code.splitlines() if 'asc_copy_ub2gm_align(' in x]
assert len(lines)==2 and all(any((name+'[') in x for x in lines) for name in ('out_mul_grad','sqrsum_grad'))
assert '((num_tokens + 15) >> 4)' in code and '<= num_tokens' in code and 'threadIdx.x' in code
def sha(x):return hashlib.sha256(x.read_bytes()).hexdigest()
def read(x):
 with x.open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
op,=list((p/'capture').rglob('OpBasicInfo.csv'));basic,=read(op)
assert (basic['Op Type'],basic['Block Dim'],basic['Device Id'])==('vector','56','0') and basic['Op Name']==a['runtime_kernel']
binary=op.parent/'dump/aicore_binary.o';assert sha(binary)==ident['capture_binary_sha256']
isa=subprocess.check_output([os.environ['BACKFILL_OBJDUMP'],'-d',str(binary)],text=True);(p/'device-kernel.isa').write_text(isa)
if n%16:assert re.search(r'\bSTG(?:_|[.\s])',isa),'tail SIMT store instruction not found'
raw=(p/'profile.log').read_text(errors='replace');stores=[x for x in raw.splitlines() if 'DBI record core:' in x and 'dst:(type:GM;' in x and 'src:(type:UB;' in x];records=R.findall(raw)
expected_records=2*(n//16);assert len(stores)==len(records)==expected_records,(len(stores),len(records),expected_records)
hits=Counter();blocks=Counter();rounded=Counter();pcs=set()
for c,pc,addr,stride,l1s,l2s,srcaddr,srcstride,srcl1s,srcl2s,burst,length,dtype,l1,l2,left,right in records:
 c=int(c);addr=int(addr,16);which=[i for i in range(2) if bases[i]<=addr<ends[i]];assert len(which)==1
 i=which[0];start,rem=divmod(addr-bases[i],widths[i]);assert rem==0 and start%16==0 and start+16<=n
 block=(start//16)%56;assert (c//3,c%3)==divmod(block,2)
 burst=int(burst);length=int(length);stride=int(stride);assert (int(l1),int(l2),int(left),int(right))==(1,1,0,0)
 pieces=sorted((addr+j*stride,addr+j*stride+length) for j in range(burst));cursor=addr
 for lo,hi in pieces:assert lo==cursor;cursor=hi
 assert cursor==addr+16*widths[i]
 hits[(i,start)]+=1;size=burst*length;blocks[block]+=size
 rounded[block]+=(((size+31)//32)*32 if int(srcstride)==length else burst*((length+31)//32)*32);pcs.add(int(pc,16))
assert hits==Counter((i,start) for i in range(2) for start in range(0,n//16*16,16))
for pc in pcs:assert any(re.match(r'^\s*'+format(pc,'x')+r':',line) and 'MOV_UB_TO_OUT' in line for line in isa.splitlines())
mem=read(op.with_name('Memory.csv'));assert len(mem)==56
for j,row in enumerate(mem):
 assert int(row['block_id'])==j and row['sub_block_id']=='vector0';value=row['UB_to_GM_datas(KB)'];expected=rounded[2*j]+rounded[2*j+1] if j<28 else None
 if j<28 and value not in ('NA',''):assert abs(Decimal(value)*1024-expected)<=Decimal('0.000512')
 elif j<28:assert expected==0
 else:assert value in ('NA','')
result={'target':'fourth/'+case,'status':'passed','device':'hidev NPU 0','correctness':'passed','historical_input_and_source_match':True,
 'runtime_kernel':basic['Op Name'],'dbi_requested_bytes':sum(blocks.values()),'output_logical_bytes':sum(x['bytes'] for x in outs),
 'expected_ub_to_gm_bytes':(n//16)*16*sum(widths),'simt_tail_tokens':n%16,
 'per_vector_block_requested_bytes':{i:blocks[i] for i in range(56)},'capture_binary_sha256':sha(binary),'dbi_pc':[hex(x) for x in sorted(pcs)],
 'csv_pair_totals_match':True,'scope':'full 16-token tiles use UB to GM; incomplete tail uses source SIMT direct stores and is excluded from this field'}
assert result['dbi_requested_bytes']==result['expected_ub_to_gm_bytes']
(p/'audit-result.json').write_text(json.dumps(result,indent=2)+'\n');print('PASS',case,sum(blocks.values()),'simt_tail',n%16)
