#!/usr/bin/env bash
set -Eeuo pipefail
root=/workspace/expert-profile-backfill-20261109-hidev;previous="$root/extra-lossless-smoke-hidev-npu0"
q="$root/extra-castback-smoke-hidev-npu0";mkdir -p "$q"
trap 'rc=$?; printf "exit=%s at=%s\n" "$rc" "$(date -u +%FT%TZ)" > "$q/exit.txt"' EXIT
pid=$(cat "$previous/pid")
while ps -p "$pid" -o args= | grep -Fq "$root/orchestrate-lossless-smoke.sh";do sleep 10;done
export TARGET_ID=unified-extra2/quant_cast_back_per_token-01 ATTEMPT=attempt-001
bash "$root/run-hidev-extra-castback-detail.sh"
python3 -B "$root/inspect-extra-castback.py" "$TARGET_ID" "$ATTEMPT"
echo 'identity smoke finished; independent address audit remains required'
