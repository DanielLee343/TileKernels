"""Check three captured pilot direct-store dequant GEMMs."""
import csv,hashlib,json,re,subprocess
from pathlib import Path
root=Path('/workspace/expert-profile-backfill-20261109-hidev')
private=Path('/workspace/tilekernels-env-20261101/src/TileKernels-private')
source_repo=Path('/workspace/deepgemm-ascend-20261107/source')
src=source_repo/'deep_gemm/include/deep_gemm/fp8_dequant_gemm.hpp'
tool=Path('/workspace/tilekernels-env-20261101/cann/cann-9.2.1/tools/bisheng_compiler/bin/llvm-objdump')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert subprocess.check_output(['git','-C',str(source_repo),'rev-parse','HEAD'],text=True).strip()=='3a35326271b069b8b5bf1a754435acd6cc91575b'
rel=src.relative_to(source_repo).as_posix()
assert subprocess.check_output(['git','-C',str(source_repo),'hash-object',str(src)],text=True).strip()==subprocess.check_output(['git','-C',str(source_repo),'rev-parse','HEAD:'+rel],text=True).strip()
source=src.read_text();assert 'bool kDirectStore = false, bool kDualAIVDequant = false' in source
assert 'if constexpr (kDirectStore) return;' in source and 'copy_l0c_to_gm' in source
allowed=set('ADD ADDI AND CMP CMPN DCCI DIV END FIX_L0C_TO_OUT INSERT JUMPCI JUMPI LDP LD_IO LOAD_L1_TO_L0A_2DV2 LOAD_L1_TO_L0A_MX_2DV2 LOAD_L1_TO_L0B_2DV2 LOAD_L1_TO_L0B_MX_2DV2 MADD MIN MMAD_MX MOV MOVEMASK MOVI MOVK MOV_OUT_TO_L1_MULTI_ND2NZ MOV_OUT_TO_UB_ALIGN_V2 MOV_UB_TO_L1 MUL MULI NEG NOP OR PSET PUSH_PB SBITSET0 SBITSET1 SEL SEND SET_FLAG SET_FLAG_V SET_INTRA_BLOCK SHLI SHRI SIGNEXT SMOV ST_IO SUB SUBI VADDS VAND VBR VCI VCMPS VF VINTLV VLDI VLOOPV2_V310 VMOV VOR VSEL VSELR VSHLI VSHRI VSSTB VST VSTI WAIT_FLAG WAIT_FLAG_V WAIT_INTRA_BLOCK XOR ZEROEXT'.split())
survey=json.loads((root/'deepgemm-pending-isa-survey.json').read_text())['cases']
items=[x for x in survey if x['status']=='surveyed' and not x['ub_to_out']];assert len(items)==3
out=root/'deepgemm-pilot-direct-static-audit';out.mkdir(exist_ok=True);(out/src.name).write_bytes(src.read_bytes());records=[]
for item in items:
 profile=private/item['profile'];binary=profile/'dump/aicore_binary.o';d=profile.parent.parent;wrapper=d/'jit/kernel.asc'
 assert sha(binary)==item['binary_sha256'] and re.search(r'\btrue,\s*(true|false),\s*(true|false)>\);',wrapper.read_text())
 result=json.loads((d/'result.json').read_text());assert result['status']=='passed' and result['capture']['binary_sha256']==sha(binary)
 with (profile/'OpBasicInfo.csv').open(encoding='utf-8-sig',newline='') as f:basic,=list(csv.DictReader(f))
 assert basic['Op Name']==item['op_name'] and basic['Op Type']=='mix' and 'fp8_dequant_gemm_impl' in basic['Op Name']
 asm=subprocess.check_output([str(tool),'-d',str(binary)],text=True)
 lines=re.findall(r'^\s*[0-9a-f]+:\s+[0-9a-f]+\s+.*$',asm,re.M)
 ins=re.findall(r'^\s*[0-9a-f]+:\s+[0-9a-f]+\s+([A-Z][A-Z0-9_]*)',asm,re.M)
 assert len(lines)==len(ins)>0 and set(ins)<=allowed,(item['target'],sorted(set(ins)-allowed))
 assert 'MOV_UB_TO_L1' in ins and 'FIX_L0C_TO_OUT' in ins and not any(x.startswith(('MOV_UB_TO_OUT','STG')) for x in ins)
 isa=out/(item['target'].split('/')[-1]+'.isa');isa.write_text(asm)
 records.append({'target':item['target'],'status':'aiv_ub_to_gm_not_applicable','correctness':'passed',
  'binary_sha256':sha(binary),'binary_path':item['profile']+'/dump/aicore_binary.o','wrapper_sha256':sha(wrapper),
  'isa_sha256':sha(isa),'instruction_count':len(ins),'opcodes':sorted(set(ins)),
  'reason':'direct-store specialization writes output from Cube; AIV moves dequant data UB to L1'})
doc={'source_commit':'3a35326271b069b8b5bf1a754435acd6cc91575b','header_sha256':sha(src),'cases':records,
 'scope':'AIV UB-to-GM only; Cube stores and AIV UB-to-L1 transfers occur'}
(out/'audit.json').write_text(json.dumps(doc,indent=2)+'\n');print('PILOT_DIRECT_STATIC_AUDIT',len(records),sha(out/'audit.json'))
