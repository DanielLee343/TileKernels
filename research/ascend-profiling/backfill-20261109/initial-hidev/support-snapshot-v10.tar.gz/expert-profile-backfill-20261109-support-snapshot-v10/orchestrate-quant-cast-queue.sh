#!/usr/bin/env bash
set -Eeuo pipefail
root=/workspace/expert-profile-backfill-20261109-hidev
q="$root/extra-quant-cast-queue-hidev-npu0";mkdir -p "$q"
trap 'rc=$?;printf "exit=%s at=%s\n" "$rc" "$(date -u +%FT%TZ)" > "$q/exit.txt"' EXIT
ionice -c 3 nice -n 15 bash "$root/test-quant-cast-general.sh"
python3 - "$root" <<'PY'
import json,sys
from pathlib import Path
p=Path(sys.argv[1])/'extra-proxy-runs/unified-extra/quant_cast-01/hidev-npu0/attempt-001/detail';a=p/'candidate-audit-result.json';b=p/'audit-result.json';d=json.loads(a.read_text())
assert d['status']=='passed' and d['target']=='unified-extra/quant_cast-01' and not b.exists();b.write_bytes(a.read_bytes())
PY
previous="$root/extra-swiglu-backward-variants-smoke-hidev-npu0";pid=$(cat "$previous/pid")
while ps -p "$pid" -o args= | grep -Fq "$root/orchestrate-swiglu-backward-variants.sh";do sleep 10;done
python3 -B "$root/hidev-extra-quant-cast-queue.py"
