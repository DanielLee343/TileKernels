"""Recollect only three second-collector cast-back cases with address gates."""
import fcntl,json,os,re,subprocess,sys,time
from pathlib import Path
root=Path('/workspace/expert-profile-backfill-20261109-hidev');q=root/'classic-castback-queue-hidev-npu0';q.mkdir(exist_ok=True)
lock=(q/'queue.lock').open('w');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
cases=[x for x in json.loads((root/'classic-pending.json').read_text()) if x['target'] in ('second/castback-05','second/castback-09','second/castback-15')];assert len(cases)==3
for item in cases:
 batch=item['batch'];case=item['case'];target=item['target'];base=root/'classic-runs'/batch/case/'hidev-npu0'
 attempts=sorted(base.glob('attempt-*')) if base.exists() else []
 if any((a/'detail/audit-result.json').exists() and json.loads((a/'detail/audit-result.json').read_text()).get('status')=='passed' for a in attempts):
  print(target,'already audited; skip',flush=True);continue
 indexes=[int(a.name.removeprefix('attempt-')) for a in attempts if re.fullmatch(r'attempt-\d+',a.name)]
 attempt=f'attempt-{max(indexes,default=0)+1:03d}';out=base/attempt;out.mkdir(parents=True,exist_ok=False)
 status={'target':target,'attempt':attempt,'status':'running','started_unix':time.time()};(out/'queue-status.json').write_text(json.dumps(status,indent=2)+'\n')
 env=os.environ.copy();env.update(CASE_ID=case,CASE_BATCH=batch,ATTEMPT=attempt,KERNEL_NAME=item['kernel'],BACKFILL_ROOT=str(root))
 stages=[('capture',['bash',str(root/'run-hidev-classic-detail.sh')]),
         ('inspection',[sys.executable,'-B',str(root/'inspect-classic-capture.py'),target,attempt]),
         ('audit',[sys.executable,'-B',str(root/'audit-classic-castback.py'),case,attempt])]
 for stage,cmd in stages:
  with (out/(stage+'-console.log')).open('w') as f:r=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
  status[stage+'_exit']=r.returncode
  if r.returncode:status['status']=stage+'_failed';break
 else:status['status']='passed'
 status['finished_unix']=time.time();tmp=out/'queue-status.tmp';tmp.write_text(json.dumps(status,indent=2)+'\n');tmp.replace(out/'queue-status.json')
 print(target,status['status'],flush=True)
 if status['status']!='passed':sys.exit(1)
print('ALL_CLASSIC_CASTBACK_SELECTED_AUDITED',flush=True)
