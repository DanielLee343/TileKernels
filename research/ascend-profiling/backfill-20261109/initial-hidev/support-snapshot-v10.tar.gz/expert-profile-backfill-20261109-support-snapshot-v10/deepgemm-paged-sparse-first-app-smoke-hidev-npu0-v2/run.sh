#!/usr/bin/env bash
set -Eeuo pipefail
r=/workspace/expert-profile-backfill-20261109-hidev;q="$r/deepgemm-paged-sparse-first-app-smoke-hidev-npu0-v2"
trap 'rc=$?;printf "exit=%s at=%s\n" "$rc" "$(date -u +%FT%TZ)" > "$q/exit.txt"' EXIT
prev="$r/extra-engram-step-app-smoke-hidev-npu0-v2";pid=$(cat "$prev/pid")
while ps -p "$pid" -o args= | grep -Fq "$prev/run.sh";do sleep 10;done
export CASE_ID=paged-sparse-first-0-q4-k256-h8-b8-p64
export ATTEMPT=$(python3 - "$r/deepgemm-runs/$CASE_ID/hidev-npu0" <<'PY'
from pathlib import Path
import re,sys
p=Path(sys.argv[1]);ids=[int(x.name[8:]) for x in p.glob('attempt-*') if re.fullmatch(r'attempt-\d+',x.name)]
print(f'attempt-{max(ids,default=0)+1:03d}')
PY
)
printf '%s\n' "$ATTEMPT" > "$q/attempt.txt"
bash "$r/run-hidev-deepgemm-paged-sparse-first-app.sh"
echo PAGED_SPARSE_FIRST_APP_CAPTURED_IDENTITY_PENDING
