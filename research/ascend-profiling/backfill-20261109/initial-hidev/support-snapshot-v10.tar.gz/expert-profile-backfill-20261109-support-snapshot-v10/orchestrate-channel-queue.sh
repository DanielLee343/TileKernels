#!/usr/bin/env bash
set -Eeuo pipefail
root=/workspace/expert-profile-backfill-20261109-hidev;previous="$root/deepgemm-dequant-smoke-hidev-npu0"
q="$root/extra-channel-queue-hidev-npu0";mkdir -p "$q"
trap 'rc=$?; printf "exit=%s at=%s\n" "$rc" "$(date -u +%FT%TZ)" > "$q/followup-exit.txt"' EXIT
pid=$(cat "$previous/pid")
while ps -p "$pid" -o args= | grep -Fq "$root/orchestrate-deepgemm-dequant-smoke.sh";do sleep 10;done
python3 -B "$root/hidev-extra-channel-queue.py"
