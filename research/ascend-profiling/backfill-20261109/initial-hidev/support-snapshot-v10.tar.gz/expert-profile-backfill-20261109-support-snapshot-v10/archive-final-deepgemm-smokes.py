"""Snapshot the completed BF16/pilot and failed paged-sparse smoke attempts."""
import importlib.util,sys
from pathlib import Path
root=Path('/workspace/expert-profile-backfill-20261109-hidev')
spec=importlib.util.spec_from_file_location('archive_captures',root/'archive-captures.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
m.GROUPS=('deepgemm-runs','deepgemm-pilot-runs');original=m.scan_units
def wanted(x):
 group,name,_=x
 return group=='deepgemm-pilot-runs' or (group=='deepgemm-runs' and name in ('gemm-bf16bf16-nt-k-m4096-n576-k7168','paged-sparse-fp8-q4-k256-h8-b8','paged-sparse-first-0-q4-k256-h8-b8-p64'))
m.scan_units=lambda r:(x for x in original(r) if wanted(x))
def no_support(source,out):
 p=out/'support.jsonl';p.write_bytes(b'');return 0,m.sha(p)
m.copy_support=no_support
sys.argv=['archive-captures.py','--root',str(root),'--out','/workspace/expert-profile-backfill-20261109-final-deepgemm-smokes-snapshot-archive']
m.main()
