"""Check pilot input/output identity and captured binary before address audit."""
import hashlib,importlib.util,json,re,shutil,sys
from pathlib import Path
root=Path('/workspace/expert-profile-backfill-20261109-hidev');case,attempt=sys.argv[1:]
assert re.fullmatch(r'(?:bf16|fp8fp8|fp4fp4|fp8fp4)-m1-n32768-k512',case) and re.fullmatch(r'attempt-[0-9]+',attempt)
family='pilot-bf16' if case.startswith('bf16-') else 'pilot-quant'
h=root/'deepgemm-pilot-m1-harness';p=root/'deepgemm-pilot-runs'/case/'hidev-npu0'/attempt
spec=importlib.util.spec_from_file_location('pilot_base',h/'pilot-bf16/collect.py');base=importlib.util.module_from_spec(spec);spec.loader.exec_module(base)
a=json.loads((p/'prepare.json').read_text());b=json.loads((p/'profile.json').read_text());old=json.loads((h/'history'/case/'profile.json').read_text())
base.validate_stages(a,b,case);base.validate_stage(old,case)
for key in ('input_a_sha256','input_b_sha256','reference_sha256','output_sha256'):
 assert a[key]==b[key]==old[key],key
op,=list((p/'detail/capture').rglob('OpBasicInfo.csv'));binary=op.parent/'dump/aicore_binary.o'
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();digest=sha(binary)
matches=[x.parent for x in (root/'deepgemm-cache'/case/'cache').glob('*/kernel.o') if sha(x)==digest];assert len(matches)==1
jit=matches[0];hist=h/'history'/case/'kernel.asc';assert sha(hist)==sha(jit/'kernel.asc')
dest=p/'jit';dest.mkdir(exist_ok=True)
for n in ('kernel.asc','kernel.o','meta.json'):
 if (jit/n).is_file():shutil.copy2(jit/n,dest/n)
mon=json.loads((p/'detail/monitor-summary.json').read_text());assert mon['status']=='passed' and mon['max_seconds_between_successful_queries']<=3
raw=(p/'detail/profile.log').read_text(errors='replace');metrics=re.findall(r'processedRecord: (\d+), droppedRecord: (\d+).*?memoryCorruption (\d+)',raw)
assert metrics and all(d=='0' and m=='0' for _,d,m in metrics)
addresses=json.loads((p/'profile-addresses.json').read_text())
result={'case':family+'/'+case,'status':'identity_checked_address_audit_pending','correctness':'passed',
 'historical_input_output_and_jit_match':True,'capture_binary_sha256':digest,'parser_metrics':metrics,'addresses':addresses,
 'scope':'separate MemoryDetail window, requested bytes not physical DRAM traffic; per-core address audit pending'}
(p/'capture-inspection.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
