"""Snapshot finished representative captures and unsuccessful attempts."""
import importlib.util,sys
from pathlib import Path
root=Path('/workspace/expert-profile-backfill-20261109-hidev')
spec=importlib.util.spec_from_file_location('archive_captures',root/'archive-captures.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
m.GROUPS=('deepgemm-runs','extra-proxy-runs','classic-runs');original=m.scan_units
allowed={'deepgemm-runs':{'paged-sparse-first-0-q4-k256-h8-b8-p64'},'classic-runs':{'starter__normalize-01','starter__normalize-04'},'extra-proxy-runs':{'unified-extra5__engram_sinkhorn_step-01','unified-extra5__engram_sinkhorn_momentum_update-01','unified-extra4__rotary_embedding-01-q','unified-extra4__quant_per_token_cast_and_cast_back-01','unified-extra3__moe_topk_gate_forward-01'}}
m.scan_units=lambda r:(x for x in original(r) if x[1] in allowed.get(x[0],set()))
def no_support(source,out):
 p=out/'support.jsonl';p.write_bytes(b'');return 0,m.sha(p)
m.copy_support=no_support
sys.argv=['archive-captures.py','--root',str(root),'--out','/workspace/expert-profile-backfill-20261109-representatives-v2-snapshot-archive']
m.main()
