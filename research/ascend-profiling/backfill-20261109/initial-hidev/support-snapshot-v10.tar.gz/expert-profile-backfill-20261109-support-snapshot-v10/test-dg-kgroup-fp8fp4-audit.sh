#!/usr/bin/env bash
set -Eeuo pipefail
printf '%s\n' __DG_KGROUP_FP8FP4_AUDIT_TEST_BEGIN__
root=/workspace/expert-profile-backfill-20261109-hidev
tmp=$(mktemp -d "$root/dg-transform-audit-test.XXXXXXXX")
trap 'rm -rf -- "$tmp"' EXIT
case_id=kgroup-fp8fp4-tn-g4-m64-n256-k512
base="deepgemm-runs/$case_id/hidev-npu0/attempt-001"
mkdir -p "$tmp/$(dirname "$base")";cp -a "$root/$base" "$tmp/$base"
cp "$root/audit-reduce-family.py" "$tmp/";cp -a "$root/deepgemm-kgroup-harness" "$tmp/";export BACKFILL_ROOT="$tmp"
python3 -B "$root/audit-dg-kgroup-dequant-candidate.py" "$case_id" attempt-001
detail="$tmp/$base/detail";cp "$detail/profile.log" "$tmp/original-profile.log"
python3 - "$detail/profile.log" <<'PY'
from pathlib import Path
import sys
p=Path(sys.argv[1]);lines=p.read_text().splitlines(keepends=True)
i=next(i for i,s in enumerate(lines) if 'DBI record core:' in s and 'dst:(type:GM;' in s and 'src:(type:UB;' in s)
del lines[i];p.write_text(''.join(lines))
PY
if python3 -B "$root/audit-dg-kgroup-dequant-candidate.py" "$case_id" attempt-001 > "$tmp/missing.out" 2>&1;then echo MISSING_RECORD_UNDETECTED;exit 1;fi
cp "$tmp/original-profile.log" "$detail/profile.log"
mem=$(find "$detail/capture" -name Memory.csv -print -quit)
cp "$mem" "$tmp/original-memory.csv"
python3 - "$mem" <<'PY'
from pathlib import Path
import csv,io,sys
p=Path(sys.argv[1]);r=csv.DictReader(io.StringIO(p.read_text(encoding='utf-8-sig')));rows=list(r)
row=next(x for x in rows if x['sub_block_id']=='vector1' and x['UB_to_GM_datas(KB)'] not in ('NA',''));row['UB_to_GM_datas(KB)']=str(float(row['UB_to_GM_datas(KB)'])+1)
with p.open('w',encoding='utf8',newline='') as f:
 w=csv.DictWriter(f,fieldnames=r.fieldnames);w.writeheader();w.writerows(rows)
PY
if python3 -B "$root/audit-dg-kgroup-dequant-candidate.py" "$case_id" attempt-001 > "$tmp/csv.out" 2>&1;then echo WRONG_CSV_UNDETECTED;exit 1;fi
cp "$tmp/original-memory.csv" "$mem"
python3 - "$tmp/$base/profile-addresses.json" <<'PY'
import json,sys
from pathlib import Path
p=Path(sys.argv[1]);d=json.loads(p.read_text());d[0]['args'][2]['address']=d[0]['args'][0][0]['address'];p.write_text(json.dumps(d))
PY
if python3 -B "$root/audit-dg-kgroup-dequant-candidate.py" "$case_id" attempt-001 > "$tmp/alias.out" 2>&1;then echo INPUT_ALIAS_UNDETECTED;exit 1;fi
echo 'PASS rejects missing store, altered CSV and input/output alias'

printf '%s\n' __DG_KGROUP_FP8FP4_AUDIT_TEST_END__
