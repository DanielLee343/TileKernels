#!/usr/bin/env bash
set -Eeuo pipefail
root=/workspace/expert-profile-backfill-20261109-hidev
q="$root/dg-paged-mqa-smoke-hidev-npu0";mkdir -p "$q"
trap 'rc=$?;printf "exit=%s at=%s\n" "$rc" "$(date -u +%FT%TZ)" > "$q/exit.txt"' EXIT
previous="$root/extra-norm-accum-app-queue-hidev-npu0";pid=$(cat "$previous/pid")
while ps -p "$pid" -o args= | grep -Fq "$root/orchestrate-norm-accum-app-queue.sh";do sleep 10;done
export CASE_ID=paged-mqa-fp8-b2-k256-h8-d128-p64 ATTEMPT=attempt-001
bash "$root/run-hidev-deepgemm-paged-mqa.sh"
python3 -B "$root/inspect-deepgemm-paged-mqa.py" "$CASE_ID" "$ATTEMPT"
echo DG_PAGED_MQA_SMOKE_IDENTITY_CHECKED_ADDRESS_AUDIT_PENDING
