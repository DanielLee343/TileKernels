"""Make a verified immutable batch from completed reduce runs only."""
import importlib.util,json,sys
from pathlib import Path
root=Path('/workspace/expert-profile-backfill-20261109-hidev')
spec=importlib.util.spec_from_file_location('archive_captures',root/'archive-captures.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
m.GROUPS=('runs',)
def no_support(source,out):
 p=out/'support.jsonl';p.write_bytes(b'');return 0,m.sha(p)
m.copy_support=no_support
sys.argv=['archive-captures.py','--root',str(root),'--out','/workspace/expert-profile-backfill-20261109-reduce-static-archive']
m.main()
