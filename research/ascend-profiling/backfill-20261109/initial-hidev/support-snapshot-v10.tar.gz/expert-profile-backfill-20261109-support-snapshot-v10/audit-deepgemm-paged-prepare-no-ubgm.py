"""Audit exact saved paged sparse prepare binaries without MTE3 transfers."""
import csv,hashlib,json,re,subprocess
from pathlib import Path
root=Path('/workspace/expert-profile-backfill-20261109-hidev')
repo=Path('/workspace/tilekernels-env-20261101/src/TileKernels-private/research/ascend-profiling/deepgemm-ascend/campaign-13/runs')
src=Path('/workspace/deepgemm-ascend-20261107/source/deep_gemm/include/deep_gemm/paged_sparse_mqa_logits_metadata.hpp')
source_repo=Path('/workspace/deepgemm-ascend-20261107/source')
tool=Path('/workspace/tilekernels-env-20261101/cann/cann-9.2.1/tools/bisheng_compiler/bin/llvm-objdump')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
allowed=set('ADD ADDI AND BAR BRANCH CMP CMPN DCCI DIV END END_DVG F2I FDIV I2F IADD IMAD IMNMX IMUL INSERT ISETP JUMPCI JUMPI LD LDG LDK LDP LDS LD_IO LEA LOP3 MADD MAX MOV MOVEMASK MOVI MOVK MOV_OUT_TO_UB_ALIGN_V2 MUL NEG NOP OR P2R PLOP3 POPC PUSH_PB S2R SBITSET0 SEL SET_CROSS_CORE_V SET_FLAG SET_FLAG_V SHF SHFI SHFL SHLI SHRI SIGNEXT START_DVG STG STK STS ST_IO SUB SUBI VF_SIMT WAIT_FLAG WAIT_FLAG_DEV WAIT_FLAG_V XOR ZEROEXT'.split())
survey=json.loads((root/'deepgemm-vector-isa-survey.json').read_text())['cases']
items=[x for x in survey if 'paged_sparse_mqa_prepare_impl' in x['op_name']]
assert len(items)==8 and len({x['case'] for x in items})==8
source=src.read_text();assert 'void paged_sparse_mqa_prepare_impl(' in source and 'asc_vf_call<publish_kv_split_range>' in source
assert subprocess.check_output(['git','-C',str(source_repo),'rev-parse','HEAD'],text=True).strip()=='3a35326271b069b8b5bf1a754435acd6cc91575b'
rel=src.relative_to(source_repo).as_posix()
assert subprocess.check_output(['git','-C',str(source_repo),'hash-object',str(src)],text=True).strip()==subprocess.check_output(['git','-C',str(source_repo),'rev-parse','HEAD:'+rel],text=True).strip()
out=root/'deepgemm-paged-prepare-static-audit';out.mkdir(exist_ok=True)
(out/'paged_sparse_mqa_logits_metadata.hpp').write_bytes(src.read_bytes())
records=[]
for item in items:
 case=item['case'];binary=Path(item['binary']);assert sha(binary)==item['binary_sha256']
 profile=binary.parents[1];d=profile.parent.parent
 result=json.loads((d/'result.json').read_text());assert result['status']=='passed'
 assert result['capture']['jit_binary_sha256']==sha(binary)
 wrapper=d/'jit/kernel.asc';assert 'paged_sparse_mqa_prepare_impl<' in wrapper.read_text()
 op=profile/'OpBasicInfo.csv'
 with op.open(encoding='utf-8-sig',newline='') as f:basic,=list(csv.DictReader(f))
 assert basic['Op Type']=='vector' and basic['Op Name']==item['op_name']
 text=subprocess.check_output([str(tool),'-d',str(binary)],text=True)
 lines=re.findall(r'^\s*[0-9a-f]+:\s+[0-9a-f]+\s+.*$',text,re.M)
 ins=re.findall(r'^\s*[0-9a-f]+:\s+[0-9a-f]+\s+([A-Z][A-Z0-9_]*)',text,re.M)
 assert len(ins)==len(lines)>0 and set(ins)<=allowed,(case,sorted(set(ins)-allowed))
 assert 'STG' in ins and not any(x.startswith('MOV_UB_TO_OUT') for x in ins)
 isa=out/(case+'.isa');isa.write_text(text)
 records.append({'target':'campaign-13/'+case,'status':'aiv_ub_to_gm_not_applicable','correctness':'passed',
  'binary_sha256':sha(binary),'binary_path':str(binary),'wrapper_sha256':sha(wrapper),'isa_path':str(isa),
  'isa_sha256':sha(isa),'instruction_count':len(ins),'opcodes':sorted(set(ins)),
  'reason':'no UB-to-GM instruction in the exact original vector binary; output contains SIMT STG stores'})
doc={'source_commit':'3a35326271b069b8b5bf1a754435acd6cc91575b','header_path':str(src),'header_sha256':sha(src),
 'cases':records,'scope':'UB-to-GM movement only; SIMT GM stores exist and are not counted as UB-to-GM'}
(out/'audit.json').write_text(json.dumps(doc,indent=2)+'\n');print('PAGED_PREPARE_STATIC_AUDIT',len(records),sha(out/'audit.json'))
