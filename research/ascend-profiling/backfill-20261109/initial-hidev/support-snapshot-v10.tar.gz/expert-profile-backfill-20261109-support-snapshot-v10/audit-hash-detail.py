"""Audit Engram hash output requests, matching source and original input."""
import csv,hashlib,json,os,re,subprocess,sys
from collections import Counter
from decimal import Decimal
from pathlib import Path
from importlib.machinery import SourceFileLoader
root=Path(os.environ['BACKFILL_ROOT']);R=SourceFileLoader('reduce_audit',str(root/'audit-reduce-family.py')).load_module().REGEX
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):
 with p.open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
case,device,attempt=sys.argv[1:];assert re.fullmatch(r'hash-(0[1-9]|1[0-9]|20)',case) and device=='0'
p=root/'hash-runs'/case/'hidev-npu0'/attempt/'detail';app=json.loads((p/'metadata/application.json').read_text());hist=json.loads((root/'hash-history'/case/'default.json').read_text())
mon=json.loads((p/'monitor-summary.json').read_text());assert app['status']=='passed' and app['visible_devices']==device and mon['status']=='passed' and mon['max_seconds_between_successful_queries']<=3
for key in ('runtime_kernel','source_sha256','inputs','outputs'):assert app[key]==hist[key],key
src=p/'metadata/default-kernel.cpp';assert sha(src)==app['source_sha256'];code=src.read_text()
assert sha(root/'hash-history'/case/'default-kernel.cpp')==hist['source_sha256']
shape=app['outputs'][0]['shape'];assert len(shape)==3 and shape[0]==2 and app['outputs'][0]['dtype']=='int32'
n=shape[1];rowbytes=shape[2]*4;assert n==app['case']['tokens'] and rowbytes in (64,96)
assert code.count('asc_copy_ub2gm_align(')==1 and '((num_tokens + 127) >> 7)' in code
line=next(s for s in code.splitlines() if 'asc_copy_ub2gm_align(' in s)
assert f'(int64_t){128*shape[2]}' in line and f'(int64_t){7168*shape[2]}' in line and f'(num_tokens * {rowbytes})' in line
op,=list((p/'capture').rglob('OpBasicInfo.csv'));basic,=read(op)
assert basic['Op Name']==app['runtime_kernel'] and basic['Op Type']=='vector' and basic['Block Dim']=='56' and basic['Device Id']==device
binary=op.parent/'dump/aicore_binary.o';bsha=sha(binary)
assert any(x.startswith(bsha+' ') and x.rstrip().endswith('/kernel.aibin') for x in (p/'cache-sha256.txt').read_text().splitlines())
isa=subprocess.check_output([os.environ['BACKFILL_OBJDUMP'],'-d',str(binary)],text=True);(p/'device-kernel.isa').write_text(isa)
raw=(p/'profile.log').read_text(errors='replace');stores=[x for x in raw.splitlines() if 'DBI record core:' in x and 'dst:(type:GM;' in x and 'src:(type:UB;' in x];rec=R.findall(raw)
assert len(stores)==len(rec)==(n+127)//128
base=int(app['device_output_addresses'][0],16);hits=Counter();blocks=Counter();pcs=set()
for c,pc,addr,stride,l1s,l2s,srcaddr,srcstride,srcl1s,srcl2s,burst,length,dtype,l1,l2,left,right in rec:
 c=int(c);start,rem=divmod(int(addr,16)-base,rowbytes);assert rem==0 and start%128==0 and start<n
 block=(start//128)%56;width=min(128,n-start)*rowbytes
 assert (c//3,c%3)==divmod(block,2)
 assert (int(burst),int(length),int(stride),int(l1),int(l2),int(left),int(right))==(2,width,n*rowbytes,1,1,0,0)
 hits[start]+=1;blocks[block]+=2*width;pcs.add(int(pc,16))
assert hits==Counter(range(0,n,128))
for pc in pcs:assert any(re.match(r'^\s*'+format(pc,'x')+r':',line) and 'MOV_UB_TO_OUT' in line for line in isa.splitlines())
mem=read(op.with_name('Memory.csv'));assert len(mem)==56
for i,row in enumerate(mem):
 assert int(row['block_id'])==i and row['sub_block_id']=='vector0';value=row['UB_to_GM_datas(KB)'];expected=blocks[2*i]+blocks[2*i+1] if i<28 else None
 if i<28 and value not in ('NA',''):assert abs(Decimal(value)*1024-expected)<=Decimal('0.000512')
 elif i<28:assert expected==0
 else:assert value in ('NA','')
result={'target':'starter/'+case,'status':'passed','device':'hidev NPU 0','correctness':'passed','historical_input_and_source_match':True,
 'runtime_kernel':basic['Op Name'],'dbi_requested_bytes':sum(blocks.values()),'output_logical_bytes':n*rowbytes*2,
 'per_vector_block_requested_bytes':{i:blocks[i] for i in range(56)},'capture_binary_sha256':bsha,'dbi_pc':[hex(x) for x in sorted(pcs)],
 'csv_pair_totals_match':True,'scope':'one MemoryDetail window; requested UB to GM bytes, not physical DRAM transactions',
 'max_seconds_between_successful_device_queries':mon['max_seconds_between_successful_queries']}
(p/'audit-result.json').write_text(json.dumps(result,indent=2)+'\n');print('PASS',case,sum(blocks.values()))
