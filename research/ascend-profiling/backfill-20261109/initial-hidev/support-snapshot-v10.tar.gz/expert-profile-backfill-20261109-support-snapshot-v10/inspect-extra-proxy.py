"""Identity inspection only; does not assert complete address collection."""
import csv,hashlib,json,re,sys
from pathlib import Path
root=Path('/workspace/expert-profile-backfill-20261109-hidev')
target,attempt=sys.argv[1:]
assert re.fullmatch(r'unified-extra\d*/[A-Za-z0-9_.-]+',target) and re.fullmatch(r'attempt-\d+',attempt)
p=root/'extra-proxy-runs'/target/'hidev-npu0'/attempt/'detail'
a=json.loads((p/'application.json').read_text());old=json.loads((p/'provenance/historical-default.json').read_text())
assert a['status']==old['status']=='passed' and a['matched']==old['matched']==1
for key in ('runtime_kernel','inputs','source_sha256'):assert a[key]==old[key],key
sha=lambda x:hashlib.sha256(x.read_bytes()).hexdigest()
assert sha(p/'generated-kernel.cpp')==a['source_sha256']
mon=json.loads((p/'monitor-summary.json').read_text());assert mon['status']=='passed' and mon['max_seconds_between_successful_queries']<=3
op,=list((p/'capture').rglob('OpBasicInfo.csv'))
with op.open(encoding='utf-8-sig',newline='') as f:basic,=list(csv.DictReader(f))
assert basic['Op Name']==a['runtime_kernel'] and basic['Device Id']=='0' and basic['Op Type']=='vector'
binary=op.parent/'dump/aicore_binary.o';bsha=sha(binary)
assert any(x.startswith(bsha+' ') and x.rstrip().endswith('/kernel.aibin') for x in (p/'cache-sha256.txt').read_text().splitlines())
addresses=json.loads((p/'tensor-addresses.json').read_text());assert addresses and all(x is None or x['device'].startswith('npu') for x in addresses)
log=(p/'profile.log').read_text(errors='replace')
stores=[x for x in log.splitlines() if 'DBI record core:' in x and 'dst:(type:GM;' in x and 'src:(type:UB;' in x]
metrics=re.findall(r'processedRecord: (\d+), droppedRecord: (\d+).*?memoryCorruption (\d+)',log)
assert metrics and all(d=='0' and m=='0' for _,d,m in metrics)
result={'target':target,'status':'capture_identified_address_audit_pending','correctness':'passed',
 'historical_input_and_source_match':True,'capture_binary_sha256':bsha,'op_basic':basic,
 'tensor_addresses':addresses,'raw_ub_to_gm_events':len(stores),'parser_metrics':metrics,
 'replay_note':'initially restricted to the stateless per-channel quantization representative; source-aware audit pending'}
(p/'capture-inspection.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
