"""Fail closed: audit each reduce case against source, binary, addresses and CSV."""
import csv,hashlib,json,os,re,subprocess,sys
from collections import Counter
from decimal import Decimal
from pathlib import Path
REGEX=re.compile(r'DBI record core:(\d+);pc:0x([0-9a-f]+);dst:\(type:GM;addr:0x([0-9a-f]+);stride:(\d+);loop1Stride:(\d+);loop2Stride:(\d+)\);src:\(type:UB;addr:0x([0-9a-f]+);stride:(\d+);loop1Stride:(\d+);loop2Stride:(\d+)\);nBurst:(\d+);lenBurst:(\d+);dataType:([^;]+);loop1Size:(\d+);loop2Size:(\d+);leftPaddingNum:(\d+);rightPaddingNum:(\d+)',re.I)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):
 with p.open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def main():
 root=Path(os.environ.get('BACKFILL_ROOT',str(Path.home()/'expert-profile-backfill-20261109')));case=sys.argv[1];device=sys.argv[2];attempt=sys.argv[3]
 assert re.fullmatch(r'reduce-(0[1-9]|1[0-9]|20)',case) and device in ('0','3','4')
 host=os.environ.get('BACKFILL_HOST','tbe');p=root/'runs'/case/(host+'-npu'+device)/attempt/'detail'
 app=json.loads((p/'metadata/application.json').read_text());hist=json.loads((root/'history'/case/'default.json').read_text());monitor=json.loads((p/'monitor-summary.json').read_text())
 assert app['status']=='passed' and app['visible_devices']==device and monitor['status']=='passed' and monitor['max_seconds_between_successful_queries']<=3
 for key in ('runtime_kernel','source_sha256','inputs','outputs'):assert app[key]==hist[key],key
 src=p/'metadata/default-kernel.cpp';assert sha(src)==app['source_sha256']
 code=src.read_text();assert code.count('asc_copy_ub2gm_align(')==1
 line=next(x for x in code.splitlines() if 'asc_copy_ub2gm_align(' in x)
 assert re.search(r',\s*1,\s*1024,\s*static_cast<asc_store_l2_cache_mode>',line)
 op,=list((p/'capture').rglob('OpBasicInfo.csv'));basic,=read(op)
 h=app['case']['head_dim']; assert h%256==0
 n=h//256;assert basic['Op Name']==app['runtime_kernel'] and basic['Op Type']=='vector' and int(basic['Block Dim'])==n and int(basic['Device Id'])==int(device)
 assert app['outputs'][0]['shape']==[h] and app['outputs'][0]['dtype']=='float32' and app['outputs'][0]['bytes']==h*4
 assert ('col_sumsq[0]' in line) if n==1 else ('col_sumsq[(((int32_t)block_idx) * 256)]' in line)
 binary=op.parent/'dump/aicore_binary.o';binarysha=sha(binary)
 cache=(p/'cache-sha256.txt').read_text();assert any(x.startswith(binarysha+' ') and x.rstrip().endswith('/kernel.aibin') for x in cache.splitlines())
 objdump=os.environ.get('BACKFILL_OBJDUMP','/home/pkg/cann920/cann-9.2.0/tools/bisheng_compiler/bin/llvm-objdump')
 isa=subprocess.check_output([objdump,'-d',str(binary)],text=True)
 (p/'device-kernel.isa').write_text(isa)
 raw=(p/'profile.log').read_text(errors='replace');allstores=[x for x in raw.splitlines() if 'DBI record core:' in x and 'dst:(type:GM;' in x and 'src:(type:UB;' in x]
 rec=REGEX.findall(raw);assert len(allstores)==len(rec)==n,(len(allstores),len(rec),n)
 base=int(app['device_output_addresses'][0],16);blocks=Counter();segments=[];pcs=set()
 for core,pc,addr,stride,l1s,l2s,ub,us,ul1,ul2,burst,length,dtype,l1,l2,left,right in rec:
  core=int(core);block=2*(core//3)+core%3;addr=int(addr,16);pc=int(pc,16)
  assert core%3 in (0,1) and 0<=block<n
  assert (int(burst),int(length),int(l1),int(l2),int(left),int(right))==(1,1024,1,1,0,0)
  assert addr==base+block*1024
  blocks[block]+=int(length);segments.append((addr,addr+int(length)));pcs.add(pc)
 assert set(blocks)==set(range(n)) and sorted(segments)==[(base+i*1024,base+(i+1)*1024) for i in range(n)]
 for pc in pcs:assert any(re.match(r'^\s*'+format(pc,'x')+r':',line) and 'MOV_UB_TO_OUT' in line for line in isa.splitlines())
 memory=read(op.with_name('Memory.csv'));assert len(memory)==n
 # Do not assume tool uses pair totals for a different block count: test it.
 for i,row in enumerate(memory):
  assert int(row['block_id'])==i and row['sub_block_id']=='vector0'
  if i<(n+1)//2:assert Decimal(row['UB_to_GM_datas(KB)'])*1024==blocks[2*i]+blocks[2*i+1]
  else:assert row['UB_to_GM_datas(KB)']=='NA'
 result={'case':case,'device':device,'status':'passed','historical_input_and_source_match':True,'correctness':'passed',
         'block_dim':n,'output_logical_bytes':h*4,'dbi_requested_bytes':sum(blocks.values()),
         'per_vector_block_requested_bytes':dict(blocks),'csv_pair_totals_match':True,'dbi_pc':[hex(pc) for pc in sorted(pcs)],
         'capture_binary_sha256':binarysha,'scope':'MemoryDetail window, requested UB to GM bytes, not DRAM transactions',
         'max_seconds_between_successful_device_queries':monitor['max_seconds_between_successful_queries']}
 (p/'audit-result.json').write_text(json.dumps(result,indent=2)+'\n');print('PASS',json.dumps(result))
if __name__=='__main__':main()
