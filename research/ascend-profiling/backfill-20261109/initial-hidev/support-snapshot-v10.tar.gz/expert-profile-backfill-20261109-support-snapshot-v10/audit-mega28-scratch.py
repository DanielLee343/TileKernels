"""Check expected addressed regions for this single-rank, no-shared-expert contract.

This is coverage evidence, not proof that duplicate writes were all recorded.
"""
import json,re,sys
from collections import defaultdict
from importlib.machinery import SourceFileLoader
from pathlib import Path

root=Path('/workspace/expert-profile-backfill-20261109-hidev')
case,attempt=sys.argv[1:]
spec=re.fullmatch(r'mega-h(\d+)-i(\d+)-e(\d+)-top(\d+)-t(\d+)',case)
assert spec
h,inter,experts,topk,t=map(int,spec.groups())
p=root/'mega28-runs'/case/'hidev-npu0'/attempt
prior=json.loads((p/'dbi-window-inspection.json').read_text())
assert prior['case']==case and prior['correctness']=='passed' and prior['historical_input_and_output_hashes_match']
a=json.loads((p/f"profile-addresses-{prior['dbi_pid']}.json").read_text());views=a['symmetric_buffer_views']
assert views['x']['shape'][1]==h and views['topk_idx']['shape'][1]==topk and a['output']['shape']==[t,h]
max_tokens=views['x']['shape'][0];assert t<=max_tokens
names=('l1_acts','l1_acts_sf','l2_acts','l2_acts_sf')
rr={k:(int(views[k]['address'],16),int(views[k]['address'],16)+views[k]['bytes']) for k in names}
ring_rows=views['l1_acts']['shape'][0];assert views['l2_acts']['shape']==[ring_rows,inter]
assert views['l1_acts']['shape']==[ring_rows,h] and h%64==0 and inter%128==0
combine=((rr['l2_acts_sf'][1]+511)//512)*512+ring_rows*h*2
rr['combine']=(combine,combine+max_tokens*topk*h*2)
rr['output']=(int(a['output']['address'],16),int(a['output']['address'],16)+a['output']['bytes'])
log=(p/'detail/profile.log').read_text(errors='replace')
segments=re.split(r'(?=\[DEBUG\].*Application mode count is \d+, dbiFlag is 0x[0-9a-f]+)',log)
stage,=[s for s in segments if 'DBI record core:' in s]
R=SourceFileLoader('r',str(root/'audit-reduce-family.py')).load_module().REGEX
intervals=defaultdict(list)
for c,pc,addr,stride,l1s,l2s,srcaddr,srcstride,srcl1s,srcl2s,burst,length,dtype,l1,l2,left,right in R.findall(stage):
 addr=int(addr,16);stride=int(stride);l1s=int(l1s);l2s=int(l2s);length=int(length)
 for z in range(int(l2)):
  for y in range(int(l1)):
   for x in range(int(burst)):
    lo=addr+z*l2s+y*l1s+x*stride;hi=lo+length
    labels=[k for k,(start,end) in rr.items() if start<=lo and hi<=end]
    assert len(labels)==1,(hex(lo),hex(hi),labels)
    intervals[labels[0]].append((lo,hi))
def byte_set(items):return {j for lo,hi in items for j in range(lo,hi)}
def rows_expected(key,width,rows):return {rr[key][0]+r*width+x for r in rows for x in range(width)}
rows={(lo-rr['l1_acts'][0])//h for lo,hi in intervals['l1_acts']}
assert len(rows)==t*topk
checks={
 'l1_acts':rows_expected('l1_acts',h,rows),
 'l1_acts_sf':rows_expected('l1_acts_sf',h//32,rows),
 'l2_acts':rows_expected('l2_acts',inter,rows),
 'l2_acts_sf':{rr['l2_acts_sf'][0]+2*((r//256)*256*(inter//64)+sf*256+(r%256))+b for r in rows for sf in range(inter//64) for b in (0,1)},
 'combine':{rr['combine'][0]+2*((slot*max_tokens+token)*h+col)+b for slot in range(topk) for token in range(t) for col in range(h) for b in (0,1)},
 'output':set(range(*rr['output']))}
summary={}
for key,expected in checks.items():
 observed=byte_set(intervals[key]);total=sum(hi-lo for lo,hi in intervals[key])
 assert observed==expected,(key,len(observed),len(expected),len(expected-observed),len(observed-expected))
 assert total==len(observed),(key,'overlapping records',total,len(observed))
 summary[key]={'covered_bytes':len(observed),'address_intervals':len(intervals[key]),'overlap':False}
doc={'case':case,'attempt':attempt,'dbi_pid':prior['dbi_pid'],'contract':'single rank, no shared experts, all topk routes valid',
 'status':'expected_workspace_and_output_bytes_covered_once', 'observed_route_rows':len(rows),'expected_route_rows':t*topk,
 'regions':summary,'limit':'coverage cannot rule out an unrecorded write to an already covered address; other replay stages failed and remain separate'}
(p/'scratch-coverage.json').write_text(json.dumps(doc,indent=2)+'\n')
print(json.dumps(doc,indent=2))
