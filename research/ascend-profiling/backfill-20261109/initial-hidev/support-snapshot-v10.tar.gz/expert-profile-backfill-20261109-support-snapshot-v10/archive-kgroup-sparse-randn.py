"""Snapshot completed K-group, non-paged sparse MQA and randn attempts."""
import importlib.util,sys
from pathlib import Path
root=Path('/workspace/expert-profile-backfill-20261109-hidev')
spec=importlib.util.spec_from_file_location('archive_captures',root/'archive-captures.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
m.GROUPS=('deepgemm-runs','extra-proxy-runs');original=m.scan_units
def wanted(x):
 group,name,_=x
 return (group=='deepgemm-runs' and name.startswith(('kgroup-','sparse-fp8-','sparse_mqa_logits_impl-'))) or (group=='extra-proxy-runs' and name.startswith('unified-extra2__randn-'))
m.scan_units=lambda r:(x for x in original(r) if wanted(x))
def no_support(source,out):
 p=out/'support.jsonl';p.write_bytes(b'');return 0,m.sha(p)
m.copy_support=no_support
sys.argv=['archive-captures.py','--root',str(root),'--out','/workspace/expert-profile-backfill-20261109-kgroup-sparse-randn-snapshot-archive']
m.main()
