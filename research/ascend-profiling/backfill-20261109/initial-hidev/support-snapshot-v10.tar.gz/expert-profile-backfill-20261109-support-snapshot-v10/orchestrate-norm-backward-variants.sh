#!/usr/bin/env bash
set -Eeuo pipefail
root=/workspace/expert-profile-backfill-20261109-hidev
q="$root/extra-norm-backward-variants-smoke-hidev-npu0";mkdir -p "$q"
trap 'rc=$?;printf "exit=%s at=%s\n" "$rc" "$(date -u +%FT%TZ)" > "$q/exit.txt"' EXIT
previous="$root/extra-swiglu-backward-queue-hidev-npu0";pid=$(cat "$previous/pid")
while ps -p "$pid" -o args= | grep -Fq "$root/orchestrate-swiglu-backward-queue.sh";do sleep 10;done
for n in 03 06 07;do
 export TARGET_ID="unified-extra3/quant_norm_backward-$n" ATTEMPT=attempt-001
 bash "$root/run-hidev-extra-norm-backward-variants.sh"
 python3 -B "$root/inspect-extra-norm-backward.py" "$TARGET_ID" "$ATTEMPT"
 echo "$TARGET_ID identity checked; address audit pending"
done
