"""Identify one correct MegaMoE DBI replay; do not infer missing scratch stores."""
import csv,hashlib,json,re,subprocess,sys
from collections import Counter
from decimal import Decimal
from pathlib import Path
from importlib.machinery import SourceFileLoader
root=Path('/workspace/expert-profile-backfill-20261109-hidev');R=SourceFileLoader('r',str(root/'audit-reduce-family.py')).load_module().REGEX
case,attempt=sys.argv[1:];p=root/'mega28-runs'/case/'hidev-npu0'/attempt;hist=root/'mega28-profile-harness/history'/case
def sha(x):return hashlib.sha256(x.read_bytes()).hexdigest()
def read(x):
 with x.open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
old=json.loads((hist/'profile.json').read_text());prepare=json.loads((p/'prepare.json').read_text());assert old['status']==prepare['status']=='passed' and old['input_hashes']==prepare['input_hashes']
log=(p/'detail/profile.log').read_text(errors='replace');segments=re.split(r'(?=\[DEBUG\].*Application mode count is \d+, dbiFlag is 0x[0-9a-f]+)',log)
stages=[s for s in segments if 'DBI record core:' in s];assert len(stages)==1;stage=stages[0]
st=re.search(r'Application mode count is (\d+), dbiFlag is (0x[0-9a-f]+)',stage);assert st
pids=re.findall(r'\[(\d+)\] \[ProfDataCollect.cpp:1270\].*Start profiling on device 0, kernel:.*mega_moe',stage);assert len(set(pids))==1;pid=pids[0]
assert not re.search(r'Child process exited with return value -?[1-9]\d*',stage)
result=json.loads((p/f'profile-result-{pid}.json').read_text());addresses=json.loads((p/f'profile-addresses-{pid}.json').read_text())
assert result['status']=='passed' and result['input_hashes']==old['input_hashes'] and result['output_sha256']==old['output_sha256']
assert addresses['pid']==int(pid) and addresses['output']['device'].startswith('npu')
metrics=re.findall(r'processedRecord: (\d+), droppedRecord: (\d+).*?memoryCorruption (\d+)',stage);assert metrics and all(d=='0' and m=='0' for _,d,m in metrics)
op,=list((p/'detail/capture').rglob('OpBasicInfo.csv'));basic,=read(op);assert basic['Op Type']=='mix' and basic['Block Dim']=='28' and basic['Mix Block Dim']=='56'
assert 'mega_moe_impl' in basic['Op Name'];binary=op.parent/'dump/aicore_binary.o';digest=sha(binary)
cache=root/'mega28-cache'/case/'cache';matches=[x for x in cache.glob('*/kernel.o') if sha(x)==digest];assert len(matches)==1
jit=matches[0].parent;assert sha(jit/'kernel.asc')==sha(hist/'kernel.asc')
tool='/workspace/tilekernels-env-20261101/cann/cann-9.2.1/tools/bisheng_compiler/bin/llvm-objdump';isa=subprocess.check_output([tool,'-d',str(binary)],text=True);(p/'device-kernel.isa').write_text(isa)
stores=[x for x in stage.splitlines() if 'DBI record core:' in x and 'dst:(type:GM;' in x and 'src:(type:UB;' in x];events=R.findall(stage);assert len(stores)==len(events)>0
out=addresses['output'];base=int(out['address'],16);end=base+out['bytes'];buffer=addresses['symmetric_buffer_views']['buffer'];lo=int(buffer['address'],16);hi=lo+buffer['bytes']
percore=Counter();rounded=Counter();intervals=[];pcs=set();buffer_events=0
for c,pc,addr,stride,l1s,l2s,srcaddr,srcstride,srcl1s,srcl2s,burst,length,dtype,l1,l2,left,right in events:
 c=int(c);assert c%3 in (0,1) and c//3<28;pc=int(pc,16);pcs.add(pc)
 addr=int(addr,16);stride=int(stride);l1s=int(l1s);l2s=int(l2s);n=int(burst);length=int(length);l1=int(l1);l2=int(l2)
 assert n>0 and length>0 and l1>=1 and l2>=1 and int(left)==int(right)==0
 percore[c]+=n*length*l1*l2
 rounded[c]+=( ((n*length+31)//32)*32 if int(srcstride)==length else n*((length+31)//32)*32 )*l1*l2
 for z in range(l2):
  for y in range(l1):
   for x in range(n):
    start=addr+z*l2s+y*l1s+x*stride;stop=start+length
    if base<=start and stop<=end:intervals.append((start,stop))
    else:assert lo<=start and stop<=hi;buffer_events+=1
for pc in pcs:assert any(re.match(r'^\s*'+format(pc,'x')+r':',s) and 'MOV_UB_TO_OUT' in s for s in isa.splitlines()),hex(pc)
intervals.sort();cursor=base
for start,stop in intervals:assert start==cursor;(cursor:=stop)
assert cursor==end
memory=read(op.with_name('Memory.csv'));assert len(memory)==84
for j,row in enumerate(memory):
 group,role=divmod(j,3);assert int(row['block_id'])==group and row['sub_block_id']==('cube0','vector0','vector1')[role]
 if role==0:continue
 value=row['UB_to_GM_datas(KB)'];expected=rounded[3*group+role-1]
 if value in ('NA',''):assert expected==0
 else:assert abs(Decimal(value)*1024-expected)<=Decimal('0.000512'),(j,value,expected)
outdoc={'case':case,'target':'mega_moe_impl','status':'dbi_window_correct_output_covered_scratch_completeness_unverified',
 'experimental_28_core_port':True,'replay':'application','dbi_stage':int(st.group(1)),'dbi_flag':st.group(2),'dbi_pid':int(pid),
 'correctness':'passed','historical_input_and_output_hashes_match':True,'capture_binary_sha256':digest,'historical_jit_source_match':True,
 'dbi_store_records':len(events),'dbi_requested_bytes':sum(percore.values()),'per_raw_core_requested_bytes':dict(sorted(percore.items())),
 'output_bytes':out['bytes'],'output_coverage':'complete exactly once','buffer_burst_count':buffer_events,
 'csv_per_aiv_rounded_totals_match':True,'other_replay_failures':len(re.findall(r'Child process exited with return value -?[1-9]\d*',log))-int(bool(re.search(r'Child process exited with return value -?[1-9]\d*',stage))),
 'limitation':'scratch/workspace store completeness is unproven; failed PMU replays and historical range-replay Default stay separate'}
(p/'dbi-window-inspection.json').write_text(json.dumps(outdoc,indent=2)+'\n');print(json.dumps(outdoc,indent=2))
