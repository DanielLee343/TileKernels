"""Audit one paged sparse FIRST application window and its compact workspace."""
import csv,hashlib,json,math,os,re,struct,subprocess,sys
from collections import Counter,defaultdict
from decimal import Decimal
from importlib.machinery import SourceFileLoader
from pathlib import Path
root=Path(os.environ.get('BACKFILL_ROOT','/workspace/expert-profile-backfill-20261109-hidev'));case,attempt=sys.argv[1:]
assert re.fullmatch(r'paged-sparse-first-[01]-[a-z0-9-]+',case) and re.fullmatch(r'attempt-[0-9]+',attempt)
p=root/'deepgemm-runs'/case/'hidev-npu0'/attempt;ins=json.loads((p/'capture-inspection.json').read_text());assert ins['status']=='identity_checked_address_audit_pending' and ins['correctness']=='passed' and ins['historical_true_inputs_and_jit_source_match']
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
manifest=json.loads((root/'deepgemm-paged-sparse-app-harness/campaign-13/cases.json').read_text());doc,=(x for x in manifest['cases'] if x['id']==case)
assert doc['sparse_phase']=='first' and doc['paged'] and not doc['fp4'] and doc['sparse_block']==8
records=ins['application_records'];assert len(records)>=2
pid=ins['representative_pid'];addr,=json.loads((p/('profile-addresses-'+pid+'.json')).read_text());out=addr['returned'];meta=addr['kwargs']['metadata']
assert out['dtype']=='torch.bfloat16' and out['shape']==[doc['q'],doc['max_blocks']*doc['sparse_block']] and out['stride'][1]==1 and out['element_size']==2
assert meta['dtype']=='torch.uint8' and len(meta['shape'])==1 and meta['stride']==[1]
base=int(out['address'],16);mbase=int(meta['address'],16);mend=mbase+meta['shape'][0];outend=base+2*(1+sum((n-1)*s for n,s in zip(out['shape'],out['stride'])));assert outend<=mbase or mend<=base
blocks=28;nr=2*blocks;align=lambda x:(x+511)//512*512;ceil=lambda a,b:(a+b-1)//b
q=doc['q'];maxb=doc['max_blocks'];sk=doc['sparse_block'];split=256;rowcap=16384//sk
nrec=nr*ceil(q,nr)*(ceil(4*maxb,split//sk)+15)+blocks*16
ko=align(q*rowcap*2);po=align(ko+nr*8+nrec*40);nphys=q*(maxb+32)+blocks*16*(64//sk);co=po+align(nphys*4);size=co+align(nphys*sk*132);assert size==meta['shape'][0]
rep=next(x for x in records if x['pid']==pid);saved=rep['saved_files'];fn,=(x['path'] for x in saved if x['name']=='metadata-before');data=(p/fn).read_bytes();assert len(data)==size
ranges=[struct.unpack_from('<II',data,ko+8*i) for i in range(nr)];used=set()
for beg,end in ranges:assert beg<=end<=nrec;used.update(range(beg,end))
for rec in records:
 assert sha(p/rec['profile'])==rec['profile_sha256'] and sha(p/rec['addresses'])==rec['addresses_sha256'] and sha(p/rec['metadata_index'])==rec['metadata_index_sha256'] and sha(p/rec['metadata_after'])==rec['metadata_after_sha256']
 assert json.loads((p/rec['addresses']).read_text())==[addr]
 m,=(x for x in rec['saved_files'] if x['name']=='metadata-before');assert sha(p/m['path'])==m['sha256'];before=(p/m['path']).read_bytes();after=(p/rec['metadata_after']).read_bytes();assert len(before)==len(after)==size
 for l,h in [(ko,ko+nr*8)]+[(ko+nr*8+i*40,ko+nr*8+(i+1)*40) for i in used]:assert before[l:h]==data[l:h]==after[l:h]
repo=Path('/workspace/deepgemm-ascend-20261107/source');headers=[]
for rel in ('deep_gemm/include/deep_gemm/paged_sparse_mqa_logits.hpp','deep_gemm/include/deep_gemm/layout/sparse_mqa_logits.hpp','csrc/jit_kernels/paged_sparse_mqa_logits.hpp'):
 f=repo/rel;headers.append(f.read_text());assert subprocess.check_output(['git','-C',str(repo),'hash-object',str(f)],text=True).strip()==subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD:'+rel],text=True).strip()
assert 'rows * kSparseSFBytes' in headers[0] and 'output + begin * 32' in headers[0] and 'SplitKV::kQBlockEnd' in headers[0] and 'sizeof(SplitKV) == 10 * sizeof(uint32_t)' in headers[1] and 'compact_offset = physical_blocks_offset' in headers[2]
expected=defaultdict(list);types=Counter()
for block in range(blocks):
 sequence=[]
 for rid in (2*block,2*block+1):
  beg,end=ranges[rid];sequence+=list(range(beg,end))
 begins={}
 for idx,j in enumerate(sequence):
  w=struct.unpack_from('<10I',data,ko+nr*8+j*40);page,ctl,qbegin,numsplit=w[:4];nblocks=(ctl>>4)&127;nrows=ceil(nblocks*sk,64)*64;assert nblocks>0 and nrows<=split and page*64*132+nrows*132<=nphys*sk*132
  core=3*block+((idx^1)&1);lo=mbase+co+page*64*132;expected[core].append((lo,lo+nrows*132));types['compact']+=nrows*132
  numq=(ctl>>11)&7;assert 0<numq<=4 and qbegin+numq<=q
  if ctl&(1<<14):
   begins={i:w[6+i]&65535 for i in range(numq)}
  if ctl&(1<<15):
   assert len(begins)==numq
   for i in range(numq):
    desc=w[6+i];beg=begins[i];end=(desc&65535)+(desc>>16);assert 0<=beg<=end<=out['shape'][1]
    if end>beg:
     lo=base+2*((qbegin+i)*out['stride'][0]+beg);expected[3*block+i//2].append((lo,lo+2*(end-beg)));types['logits']+=2*(end-beg)
   begins={}
 assert not begins
assert types['compact'] and types['logits']
def merge(xs):
 out=[]
 for lo,hi in sorted(xs):
  assert lo<hi
  if out and lo<out[-1][1]:raise AssertionError(('overlap',hex(lo),hex(hi),out[-1]))
  if out and lo==out[-1][1]:out[-1]=(out[-1][0],hi)
  else:out.append((lo,hi))
 return out
expected={c:merge(v) for c,v in expected.items()}
def read(path):
 with path.open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
op,=list((p/'detail/capture').rglob('OpBasicInfo.csv'));basic,=read(op);assert basic['Op Type']=='mix' and int(basic['Block Dim'])==blocks and int(basic['Mix Block Dim'])==nr and basic['Device Id']=='0' and 'paged_sparse_mqa_logits_impl' in basic['Op Name']
binary=op.parent/'dump/aicore_binary.o';assert sha(binary)==ins['capture']['jit_binary_sha256']==sha(p/'jit/kernel.o')
isa=subprocess.check_output(['/workspace/tilekernels-env-20261101/cann/cann-9.2.1/tools/bisheng_compiler/bin/llvm-objdump','-d',str(binary)],text=True);(p/'device-kernel.isa').write_text(isa)
raw=(p/'detail/profile.log').read_text(errors='replace');R=SourceFileLoader('r',str(root/'audit-reduce-family.py')).load_module().REGEX;events=R.findall(raw);stores=[x for x in raw.splitlines() if 'DBI record core:' in x and 'dst:(type:GM;' in x and 'src:(type:UB;' in x];assert len(events)==len(stores)>0
metrics=re.findall(r'processedRecord: (\d+), droppedRecord: (\d+).*?memoryCorruption (\d+)',raw);assert metrics and all(d=='0' and m=='0' for _,d,m in metrics)
actual=defaultdict(list);percore=Counter();rounded=Counter();pcs=set()
for c,pc,addr,stride,l1s,l2s,srcaddr,srcstride,srcl1s,srcl2s,burst,length,dtype,l1,l2,left,right in events:
 c=int(c);assert c%3 in (0,1) and c//3<blocks;pcs.add(int(pc,16));addr=int(addr,16);stride=int(stride);l1s=int(l1s);l2s=int(l2s);n=int(burst);length=int(length);l1=int(l1);l2=int(l2)
 assert n>0 and length>0 and l1>=1 and l2>=1 and int(left)==int(right)==0
 percore[c]+=n*length*l1*l2;rounded[c]+=(((n*length+31)//32)*32 if int(srcstride)==length else n*((length+31)//32)*32)*l1*l2
 for z in range(l2):
  for y in range(l1):
   for x in range(n):
    lo=addr+z*l2s+y*l1s+x*stride;actual[c].append((lo,lo+length))
assert {c:merge(v) for c,v in actual.items()}==expected
for pc in pcs:assert any(re.match(r'^\s*'+format(pc,'x')+r':',line) and 'MOV_UB_TO_OUT' in line for line in isa.splitlines()),hex(pc)
mem=read(op.with_name('Memory.csv'));assert len(mem)==3*blocks
for j,row in enumerate(mem):
 group,role=divmod(j,3);assert int(row['block_id'])==group and row['sub_block_id']==('cube0','vector0','vector1')[role];value=row['UB_to_GM_datas(KB)']
 if role:
  total=rounded[3*group+role-1]
  if value not in ('NA',''):assert abs(Decimal(value)*1024-total)<=Decimal('0.000512')
  else:assert total==0
 else:assert value in ('NA','') or Decimal(value)==0
assert sum(percore.values())==sum(types.values())
result={'case':'campaign-13/'+case,'target':'paged_sparse_mqa_logits_impl','status':'passed','device':'hidev NPU 0','correctness':'passed','historical_true_inputs_and_jit_source_match':True,'replay_mode':'application','application_processes':len(records),'expected_requested_bytes':dict(types),'dbi_requested_bytes':sum(percore.values()),'per_vector_block_requested_bytes':{i:percore[3*(i//2)+i%2] for i in range(nr)},'capture_binary_sha256':sha(binary),'dbi_pc':[hex(x) for x in sorted(pcs)],'csv_pair_totals_match':True,'scope':'FIRST application-replay AIV UB to GM requests for compact workspace and logits; not Cube traffic or physical DRAM transactions; historical range replay is a separate window'}
(p/'candidate-address-audit.json').write_text(json.dumps(result,indent=2)+'\n');print('PASS',case,result['dbi_requested_bytes'],dict(types))
