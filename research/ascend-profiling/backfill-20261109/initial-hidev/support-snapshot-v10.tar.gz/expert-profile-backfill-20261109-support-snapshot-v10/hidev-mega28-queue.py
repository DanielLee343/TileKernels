"""Collect isolated MegaMoE DBI windows; flag scratch completeness separately."""
import fcntl,json,os,subprocess,sys,time
from pathlib import Path
root=Path('/workspace/expert-profile-backfill-20261109-hidev');q=root/'mega28-queue-hidev-npu0';q.mkdir(exist_ok=True)
lock=(q/'queue.lock').open('w');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
cases=['mega-h256-i512-e4-top2-t64','mega-h512-i1024-e8-top4-t64','mega-h512-i512-e8-top2-t32']
for case in cases:
 base=root/'mega28-runs'/case/'hidev-npu0';attempts=sorted(base.glob('attempt-*')) if base.exists() else []
 if any((a/'dbi-window-inspection.json').exists() for a in attempts):print(case,'window already inspected; skip',flush=True);continue
 nums=[int(a.name.removeprefix('attempt-')) for a in attempts];attempt=f'attempt-{max(nums,default=0)+1:03d}'
 env=os.environ.copy();env.update(CASE_ID=case,ATTEMPT=attempt,REPLAY_MODE='application',METRIC_SET='MemoryDetail')
 log=q/(case+'-'+attempt+'.log');state={'case':case,'attempt':attempt,'status':'running','started_unix':time.time()}
 with log.open('w') as f:run=subprocess.run(['bash',str(root/'run-hidev-mega28-detail.sh')],env=env,stdout=f,stderr=subprocess.STDOUT)
 state['capture_exit']=run.returncode;out=base/attempt
 if run.returncode not in (0,2):state['status']='capture_or_monitor_failed'
 else:
  with (q/(case+'-'+attempt+'-inspect.log')).open('w') as f:
   inspect=subprocess.run([sys.executable,'-B',str(root/'inspect-mega28-dbi.py'),case,attempt],env=env,stdout=f,stderr=subprocess.STDOUT)
  state['inspection_exit']=inspect.returncode;state['status']='dbi_window_partial_scratch_unverified' if inspect.returncode==0 else 'dbi_inspection_failed'
 state['finished_unix']=time.time();(out/'queue-status.json').write_text(json.dumps(state,indent=2)+'\n')
 print(case,state['status'],flush=True)
 if state['status']!='dbi_window_partial_scratch_unverified':sys.exit(1)
print('ALL_MEGA28_DBI_WINDOWS_CAPTURED_SCRATCH_UNVERIFIED',flush=True)
