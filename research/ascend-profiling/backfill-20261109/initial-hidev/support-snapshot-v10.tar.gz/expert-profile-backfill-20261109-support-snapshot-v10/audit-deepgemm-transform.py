"""Audit one exact DeepGEMM transform case; no claims about other layouts."""
import csv,hashlib,json,re,subprocess
from collections import Counter
from decimal import Decimal
from pathlib import Path
from importlib.machinery import SourceFileLoader
root=Path('/workspace/expert-profile-backfill-20261109-hidev')
R=SourceFileLoader('reduce_audit',str(root/'audit-reduce-family.py')).load_module().REGEX
case='transform-float32-k-g1-mn256-k2048'
p=root/'deepgemm-runs'/case/'hidev-npu0/attempt-001'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):
 with p.open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
inspection=json.loads((p/'capture-inspection.json').read_text());assert inspection['correctness']=='passed' and inspection['historical_target_input_match'] and inspection['historical_jit_source_sha256_match']
mon=json.loads((p/'detail/monitor-summary.json').read_text());assert mon['status']=='passed' and mon['max_seconds_between_successful_queries']<=3
addr,=json.loads((p/'profile-addresses.json').read_text());inp=addr['args'][0];out=addr['returned']
assert inp['shape']==[256,64] and inp['dtype']=='torch.float32' and out['shape']==[256,32] and out['stride']==[1,256] and out['dtype']=='torch.int16'
base=int(out['address'],16);assert out['element_size']==2
op,=list((p/'detail/capture').rglob('OpBasicInfo.csv'));basic,=read(op)
assert basic['Op Type']=='vector' and basic['Block Dim']=='56' and basic['Device Id']=='0' and 'transform_sf' in basic['Op Name']
src=(p/'jit/kernel.asc').read_text();assert 'true, Major::K, 128, 128, GemmType::Normal, 56, 256, 1' in src
header=Path('/workspace/deepgemm-ascend-20261107/source/deep_gemm/include/deep_gemm/transform_sf.hpp')
code=header.read_text();assert 'const uint32_t num_blocks_per_core = ceil_div(num_blocks, kNumCores);' in code
assert 'const uint32_t block_begin = block_idx * num_blocks_per_core;' in code and 'copy_ub_to_gm(dst_gm + dst_offset' in code
repo=header.parents[3];blob=subprocess.check_output(['git','-C',str(repo),'hash-object',str(header)],text=True).strip()
committed=subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD:deep_gemm/include/deep_gemm/transform_sf.hpp'],text=True).strip();assert blob==committed
binary=op.parent/'dump/aicore_binary.o';assert sha(binary)==inspection['capture']['jit_binary_sha256']==sha(p/'jit/kernel.o')
tool='/workspace/tilekernels-env-20261101/cann/cann-9.2.1/tools/bisheng_compiler/bin/llvm-objdump'
isa=subprocess.check_output([tool,'-d',str(binary)],text=True);(p/'device-kernel.isa').write_text(isa)
raw=(p/'detail/profile.log').read_text(errors='replace');stores=[line for line in raw.splitlines() if 'DBI record core:' in line and 'dst:(type:GM;' in line and 'src:(type:UB;' in line]
events=R.findall(raw);assert len(stores)==len(events)==2
blocks=Counter();segments=Counter();pcs=set()
for c,pc,addr,stride,l1s,l2s,srcaddr,srcstride,srcl1s,srcl2s,burst,length,dtype,l1,l2,left,right in events:
 c=int(c);pc=int(pc,16);addr=int(addr,16);assert c in (0,1) and addr==base+c*256
 assert (int(burst),int(length),int(stride),int(l1),int(l2),int(left),int(right))==(32,256,512,1,1,0,0)
 for k in range(32):segments[(k,c)]+=1
 blocks[c]+=32*256;pcs.add(pc)
assert segments==Counter((k,c) for k in range(32) for c in (0,1))
for pc in pcs:assert any(re.match(r'^\s*'+format(pc,'x')+r':',line) and 'MOV_UB_TO_OUT' in line for line in isa.splitlines())
mem=read(op.with_name('Memory.csv'));assert len(mem)==56
for i,row in enumerate(mem):
 assert int(row['block_id'])==i and row['sub_block_id']=='vector0'
 value=row['UB_to_GM_datas(KB)']
 if i==0:assert Decimal(value)*1024==blocks[0]+blocks[1]
 else:assert value in ('NA','') or Decimal(value)==0
result={'case':'campaign-13/'+case,'target':'transform_sf','status':'passed','device':'hidev NPU 0',
 'device_health':'Alarm 8C4BA00C','correctness':'passed','historical_target_input_and_jit_source_match':True,
 'output_shape':[256,32],'output_stride':[1,256],'output_bytes':16384,'dbi_requested_bytes':sum(blocks.values()),
 'per_vector_block_requested_bytes':{i:blocks[i] for i in range(56)},'capture_binary_sha256':sha(binary),
 'cpp_header_sha256':sha(header),'dbi_pc':[hex(x) for x in sorted(pcs)],'csv_first_pair_total_matches':True,
 'scope':'one MemoryDetail window; requested UB to GM bytes, not DRAM transactions'}
(p/'address-audit.json').write_text(json.dumps(result,indent=2)+'\n');print('PASS',json.dumps(result))
