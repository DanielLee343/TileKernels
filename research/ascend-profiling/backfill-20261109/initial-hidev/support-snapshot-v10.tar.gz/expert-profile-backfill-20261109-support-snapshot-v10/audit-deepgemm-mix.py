"""Audit this one mixed GEMM's recorded AIV output stores."""
import csv,hashlib,json,re,subprocess
from collections import Counter
from decimal import Decimal
from pathlib import Path
from importlib.machinery import SourceFileLoader
root=Path('/workspace/expert-profile-backfill-20261109-hidev')
R=SourceFileLoader('reduce_audit',str(root/'audit-reduce-family.py')).load_module().REGEX
case='gemm-fp4fp4-nn-mn-m64-n576-k7168';p=root/'deepgemm-runs'/case/'hidev-npu0/attempt-001'
def sha(x):return hashlib.sha256(x.read_bytes()).hexdigest()
def read(x):
 with x.open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
i=json.loads((p/'capture-inspection.json').read_text())
assert i['correctness']=='passed' and i['historical_true_inputs_match'] and i['historical_jit_source_sha256_match']
assert i['output_prestate']['reason'].startswith('historical snapshot before warmups')
m=json.loads((p/'detail/monitor-summary.json').read_text());assert m['status']=='passed' and m['max_seconds_between_successful_queries']<=3
addr,=json.loads((p/'profile-addresses.json').read_text());out=addr['args'][2]
assert (out['shape'],out['stride'],out['dtype'],out['element_size'])==([64,576],[576,1],'torch.bfloat16',2)
base=int(out['address'],16)
op,=list((p/'detail/capture').rglob('OpBasicInfo.csv'));basic,=read(op)
assert (basic['Op Type'],basic['Block Dim'],basic['Mix Block Dim'],basic['Device Id'])==('mix','28','56','0')
assert 'fp8_gemm_impl' in basic['Op Name'] and i['capture']['op_name']==basic['Op Name']
src=(p/'jit/kernel.asc').read_text();assert '64, 64, 1024,' in src and '64, 64, 512,' in src and '256,\n        false, true>' in src
repo=Path('/workspace/deepgemm-ascend-20261107/source');headers=[]
for rel in ['deep_gemm/include/deep_gemm/fp8_gemm.hpp','deep_gemm/include/deep_gemm/epilogue.hpp']:
 f=repo/rel;headers.append(f.read_text());assert subprocess.check_output(['git','-C',str(repo),'hash-object',str(f)],text=True).strip()==subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD:'+rel],text=True).strip()
assert '__mix__(1, kDirectStore ? 0 : 2)' in headers[0] and 'kNumEpilogueStages, 2,' in headers[0]
assert 'aiv_id != 2 - kNumAIVs + s_epi % kNumAIVs' in headers[1] and 'copy_ub_to_gm(d.index(block.m_idx, block.n_idx)' in headers[1]
binary=op.parent/'dump/aicore_binary.o';assert sha(binary)==i['capture']['jit_binary_sha256']==sha(p/'jit/kernel.o')
tool='/workspace/tilekernels-env-20261101/cann/cann-9.2.1/tools/bisheng_compiler/bin/llvm-objdump';isa=subprocess.check_output([tool,'-d',str(binary)],text=True);(p/'device-kernel.isa').write_text(isa)
raw=(p/'detail/profile.log').read_text(errors='replace');stores=[s for s in raw.splitlines() if 'DBI record core:' in s and 'dst:(type:GM;' in s and 'src:(type:UB;' in s];events=R.findall(raw)
assert len(stores)==len(events)==9
blocks=Counter();covered=Counter();pcs=set()
for c,pc,address,stride,l1s,l2s,srcaddr,srcstride,srcl1s,srcl2s,burst,length,dtype,l1,l2,left,right in events:
 c=int(c);address=int(address,16);pc=int(pc,16);assert c%3==0 and c//3<9
 tile=c//3;assert address==base+tile*128
 assert (int(burst),int(length),int(stride),int(l1),int(l2),int(left),int(right))==(64,128,1152,1,1,0,0)
 for row in range(64):covered[(row,tile)]+=1
 blocks[2*tile]+=64*128;pcs.add(pc)
assert covered==Counter((row,tile) for row in range(64) for tile in range(9))
for pc in pcs:assert any(re.match(r'^\s*'+format(pc,'x')+r':',s) and 'MOV_UB_TO_OUT' in s for s in isa.splitlines())
mem=read(op.with_name('Memory.csv'));assert len(mem)==84
for j,row in enumerate(mem):
 group,role=divmod(j,3);assert int(row['block_id'])==group and row['sub_block_id']==('cube0','vector0','vector1')[role]
 value=row['UB_to_GM_datas(KB)']
 if role==1 and group<9:assert Decimal(value)*1024==blocks[2*group]+blocks[2*group+1]
 elif role==1:assert value in ('NA','') or Decimal(value)==0
result={'case':'campaign-13/'+case,'target':'fp8_gemm_impl','status':'passed','device':'hidev NPU 0',
 'device_health':'Alarm 8C4BA00C','correctness':'passed','historical_true_inputs_and_jit_source_match':True,
 'historical_output_snapshot':'pre-warmup zeros; new output snapshot post-warmup','output_shape':[64,576],
 'output_bytes':73728,'dbi_requested_bytes':sum(blocks.values()),'per_vector_block_requested_bytes':{j:blocks[j] for j in range(56)},
 'capture_binary_sha256':sha(binary),'dbi_pc':[hex(x) for x in sorted(pcs)],'csv_group_totals_match':True,
 'scope':'one mixed-kernel MemoryDetail window, AIV UB to GM requests, not Cube traffic or DRAM transactions'}
(p/'address-audit.json').write_text(json.dumps(result,indent=2)+'\n');print('PASS',json.dumps(result))
