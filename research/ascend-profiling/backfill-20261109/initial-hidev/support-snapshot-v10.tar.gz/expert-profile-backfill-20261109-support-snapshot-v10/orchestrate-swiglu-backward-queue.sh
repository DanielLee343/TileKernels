#!/usr/bin/env bash
set -Eeuo pipefail
root=/workspace/expert-profile-backfill-20261109-hidev
q="$root/extra-swiglu-backward-queue-hidev-npu0";mkdir -p "$q"
trap 'rc=$?;printf "exit=%s at=%s\n" "$rc" "$(date -u +%FT%TZ)" > "$q/exit.txt"' EXIT
grep -q ALL_SWIGLU_BACKWARD_CANDIDATES_PASSED "$root/swiglu-backward-candidates.log"
grep -q 'PASS rejects missing records for all five outputs' "$root/swiglu-backward-general-test.log"
for n in 13 12 07 08;do
 p="$root/extra-proxy-runs/unified-extra4/quant_swiglu_backward-$n/hidev-npu0/attempt-001/detail"
 python3 - "$p" "$n" <<'PY'
import json,sys
from pathlib import Path
p=Path(sys.argv[1]);a=p/'candidate-audit-result.json';b=p/'audit-result.json';d=json.loads(a.read_text())
assert d['status']=='passed' and d['target'].endswith('quant_swiglu_backward-'+sys.argv[2]) and not b.exists();b.write_bytes(a.read_bytes())
PY
done
previous="$root/deepgemm-bf16-mgroup-queue-hidev-npu0";pid=$(cat "$previous/pid")
while ps -p "$pid" -o args= | grep -Fq "$root/orchestrate-dg-bf16-mgroup-queue.sh";do sleep 10;done
python3 -B "$root/hidev-extra-swiglu-backward-queue.py"
