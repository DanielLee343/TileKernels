#!/usr/bin/env bash
set -Eeuo pipefail
root=/workspace/expert-profile-backfill-20261109-hidev;previous="$root/classic-castback-queue-hidev-npu0"
q="$root/extra-block-castback-queue-hidev-npu0";mkdir -p "$q"
trap 'rc=$?; printf "exit=%s at=%s\n" "$rc" "$(date -u +%FT%TZ)" > "$q/followup-exit.txt"' EXIT
pid=$(cat "$previous/followup.pid")
while ps -p "$pid" -o args= | grep -Fq "$root/orchestrate-classic-castback-queue.sh";do sleep 10;done
python3 -B "$root/hidev-extra-block-castback-queue.py"
