"""Audit one exact SIMT head case for absence of UB-to-GM instructions."""
import csv,hashlib,json,os,re,subprocess
from pathlib import Path
root=Path('/workspace/expert-profile-backfill-20261109-hidev');case='head-fwd-01'
p=root/'classic-runs/third'/case/'hidev-npu0/attempt-001/detail'
identity=json.loads((p/'capture-inspection.json').read_text());assert identity['status']=='capture_identified_address_audit_pending' and identity['correctness']=='passed'
assert identity['historical_true_inputs_and_source_match'] and identity['parser_metrics']==[['5','0','0']]
app=json.loads((p/'metadata/application.json').read_text());assert app['runtime_kernel']=='mhc_head_compute_mix_fwd_asc_kernel'
assert app['outputs'][0]['shape']==[1,4] and app['outputs'][0]['dtype']=='float32'
source=(p/'metadata/default-kernel.cpp').read_text();assert '__simt_vf__' in source and 'output_mix[' in source and 'asc_copy_gm2ub_align(' in source
assert not re.search(r'asc_copy_ub2gm|copy_ubuf_to_gm',source,re.I)
op,=list((p/'capture').rglob('OpBasicInfo.csv'));binary=op.parent/'dump/aicore_binary.o';sha=lambda x:hashlib.sha256(x.read_bytes()).hexdigest()
assert sha(binary)==identity['capture_binary_sha256']
tool='/workspace/tilekernels-env-20261101/cann/cann-9.2.1/tools/bisheng_compiler/bin/llvm-objdump'
isa=subprocess.check_output([tool,'-d',str(binary)],text=True);(p/'device-kernel.isa').write_text(isa)
assert not re.search(r'MOV_UB_TO_OUT|UBUF_TO_GM',isa,re.I)
assert re.search(r'\bSTG\.',isa)
log=(p/'profile.log').read_text(errors='replace')
assert not any('DBI record core:' in x and 'dst:(type:GM;' in x and 'src:(type:UB;' in x for x in log.splitlines())
events=[x for x in log.splitlines() if 'DBI record core:' in x and 'memType:GM' in x and 'simtType:STG' in x]
assert len(events)==1 and 'addr:'+app['device_output_addresses'][0] in events[0] and 'memSize:4' in events[0]
with op.open(encoding='utf-8-sig',newline='') as f:basic,=list(csv.DictReader(f))
assert basic['Op Type']=='vector' and basic['Block Dim']=='56' and basic['Device Id']=='0'
with op.with_name('Memory.csv').open(encoding='utf-8-sig',newline='') as f:rows=list(csv.DictReader(f))
assert len(rows)==56 and all(x['UB_to_GM_datas(KB)'] in ('NA','') for x in rows)
result={'target':'third/'+case,'status':'aiv_ub_to_gm_not_applicable','correctness':'passed',
 'historical_input_and_source_match':True,'capture_binary_sha256':sha(binary),'dbi_ub_to_gm_records':0,
 'evidence':'generated source and captured ISA have no UB-to-GM move; observed SIMT STG instruction and output-address record',
 'scope':'UB-to-GM movement only; SIMT directly writes GM and total GM writes are not zero',
 'output_logical_bytes':16,'simt_store_record_bytes':4,
 'limitation':'one recorded SIMT store is not used to estimate all output lanes or total GM traffic'}
(p/'no-ub-gm-audit.json').write_text(json.dumps(result,indent=2)+'\n');print('PASS',json.dumps(result))
