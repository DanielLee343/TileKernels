"""Survey saved historical binaries; no status changes or zero claims."""
import csv,hashlib,json,re,subprocess,time
from pathlib import Path
root=Path('/workspace/expert-profile-backfill-20261109-hidev')
repo=Path('/workspace/tilekernels-env-20261101/src/TileKernels-private')
tool=Path('/workspace/tilekernels-env-20261101/cann/cann-9.2.1/tools/bisheng_compiler/bin/llvm-objdump')
inputs=json.loads((root/'deepgemm-pending-isa-survey-input.json').read_text())['cases'];cache={};records=[]
for x in inputs:
 profile=repo/x['profile'];binary=profile/'dump/aicore_binary.o';basic=profile/'OpBasicInfo.csv'
 record={'target':x['target'],'op_name':x['op_name'],'profile':x['profile']}
 if not binary.is_file() or not basic.is_file():record['status']='binary_or_basic_missing';records.append(record);continue
 with basic.open(encoding='utf-8-sig',newline='') as f:rows=list(csv.DictReader(f))
 if len(rows)!=1 or rows[0]['Op Name']!=x['op_name'] or rows[0]['Op Type']!=x['op_type']:
  record['status']='identity_mismatch';records.append(record);continue
 digest=hashlib.sha256(binary.read_bytes()).hexdigest()
 if digest not in cache:
  proc=subprocess.run([str(tool),'-d',str(binary)],capture_output=True,text=True)
  if proc.returncode:cache[digest]={'status':'disassembly_failed'}
  else:
   lines=re.findall(r'^\s*[0-9a-f]+:\s+[0-9a-f]+\s+.*$',proc.stdout,re.M)
   ins=re.findall(r'^\s*[0-9a-f]+:\s+[0-9a-f]+\s+([A-Z][A-Z0-9_]*)',proc.stdout,re.M)
   cache[digest]={'status':'surveyed' if len(lines)==len(ins)>0 else 'incomplete_decode',
    'instruction_count':len(ins),'opcodes':sorted(set(ins)),
    'ub_to_out':[s for s in sorted(set(ins)) if s.startswith('MOV_UB_TO_OUT')],
    'stg':[s for s in sorted(set(ins)) if s.startswith('STG')],
    'call':'CALL' in ins}
 record.update(binary_sha256=digest,**cache[digest]);records.append(record)
out={'created_unix':time.time(),'status':'survey_only','count':len(records),'unique_binaries':len(cache),'cases':records,
     'caution':'absence from opcode list is not alone a proof; inspect source, indirect calls and unknown variants before classification'}
(root/'deepgemm-pending-isa-survey.json').write_text(json.dumps(out,indent=2)+'\n')
from collections import Counter
print('DEEPGEMM_ISA_SURVEY',len(records),'unique_binaries',len(cache),'statuses',dict(Counter(x['status'] for x in records)),
      'no_ub_out_candidates',sum(x['status']=='surveyed' and not x['ub_to_out'] for x in records),flush=True)
