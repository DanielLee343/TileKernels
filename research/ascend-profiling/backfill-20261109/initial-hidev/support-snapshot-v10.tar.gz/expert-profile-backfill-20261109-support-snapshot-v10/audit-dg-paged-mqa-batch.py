"""Audit an ordinary mixed GEMM output; reject unverified traffic or layouts."""
import bisect,csv,hashlib,itertools,json,math,os,re,struct,subprocess,sys
from collections import Counter
from decimal import Decimal
from importlib.machinery import SourceFileLoader
from pathlib import Path
root=Path(os.environ.get('BACKFILL_ROOT','/workspace/expert-profile-backfill-20261109-hidev'));case,attempt=sys.argv[1:]
assert re.fullmatch(r'paged[-_][a-z0-9_-]+',case) and re.fullmatch(r'attempt-[0-9]+',attempt)
p=root/'deepgemm-runs'/case/'hidev-npu0'/attempt
inspection=json.loads((p/'capture-inspection.json').read_text())
assert inspection['correctness']=='passed' and inspection.get('historical_true_inputs_match',inspection.get('historical_target_input_match')) is True and inspection['historical_jit_source_sha256_match']
mon=json.loads((p/'detail/monitor-summary.json').read_text());assert mon['status']=='passed' and mon['max_seconds_between_successful_queries']<=3
addr,=json.loads((p/'profile-addresses.json').read_text());out=addr['returned']
shape=out['shape'];stride=out['stride'];size=out['element_size'];base=int(out['address'],16)
assert len(shape)==2 and len(stride)==2 and stride[1]==1 and size==2 and out['dtype']=='torch.bfloat16'
def tensors(value):
 if isinstance(value,dict):
  if 'address' in value:yield value
  else:
   for x in value.values():yield from tensors(x)
 elif isinstance(value,(list,tuple)):
  for x in value:yield from tensors(x)
def span(t):
 lo=int(t['address'],16);hi=lo+t['element_size']*(1+sum((n-1)*s for n,s in zip(t['shape'],t['stride'])))
 return lo,hi
lo,hi=span(out)
for t in tensors(addr['args']):
 l,h=span(t);assert hi<=l or h<=lo,'input/output buffer overlap'
profile=json.loads((p/'profile.json').read_text());hashes={}
raw=(p/'paged-mqa-context-lens.bin').read_bytes();record=profile['target_input']['args'][3]
digest=hashlib.sha256(raw).hexdigest();assert record['dtype']=='torch.int32' and math.prod(record['shape'])==shape[0] and record['sha256']==digest
assert len(raw)==4*shape[0];lengths=list(struct.unpack('<'+'i'*shape[0],raw));hashes['context_lens']=digest
assert all(0<=length<=shape[1] for length in lengths) and stride[0]>=shape[1]
def merge(intervals):
 out=[]
 for lo,hi in sorted(intervals):
  assert lo<hi
  if out and lo<out[-1][1]:raise AssertionError(('overlap',lo,hi,out[-1]))
  if out and lo==out[-1][1]:out[-1]=(out[-1][0],hi)
  else:out.append((lo,hi))
 return out
expected=[]
for row,count in enumerate(lengths):
 if count:
  lo=base+size*row*stride[0];expected.append((lo,lo+count*size))
expected=merge(expected);starts=[x[0] for x in expected]
def sha(x):return hashlib.sha256(x.read_bytes()).hexdigest()
def read(path):
 with path.open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
op,=list((p/'detail/capture').rglob('OpBasicInfo.csv'));basic,=read(op)
assert (basic['Op Type'],basic['Block Dim'],basic['Mix Block Dim'],basic['Device Id'])==('mix','28','56','0') and 'paged_mqa_logits_impl' in basic['Op Name']
repo=Path('/workspace/deepgemm-ascend-20261107/source');headers=[]
for rel in ['deep_gemm/include/deep_gemm/mqa_logits.hpp']:
 f=repo/rel;headers.append(f.read_text());assert subprocess.check_output(['git','-C',str(repo),'hash-object',str(f)],text=True).strip()==subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD:'+rel],text=True).strip()
assert 'PagedMQALogitsScheduler<' in headers[0] and 'kIsPaged ? 0u' in headers[0]
assert 'copy_gm_to_ub(ub_seq_end.ptr(), scheduler.context_lens + q_base' in headers[0]
assert 'return ub_seq_end.ptr()[q_in_block];' in headers[0]
assert '__mix__(1, 2)' in headers[0] and 'const uint32_t dst_col = store_begin - ks;' in headers[0]
assert 'const uint32_t store_begin = max(kv_idx, ks);' in headers[0] and 'const uint32_t store_end = min(kv_idx + actual_kv, ke);' in headers[0]

binary=op.parent/'dump/aicore_binary.o';assert sha(binary)==inspection['capture']['jit_binary_sha256']==sha(p/'jit/kernel.o')
tool='/workspace/tilekernels-env-20261101/cann/cann-9.2.1/tools/bisheng_compiler/bin/llvm-objdump'
isa=subprocess.check_output([tool,'-d',str(binary)],text=True);Path(os.environ.get('AUDIT_ISA',str(p/'device-kernel.isa'))).write_text(isa)
raw=(p/'detail/profile.log').read_text(errors='replace');stores=[x for x in raw.splitlines() if 'DBI record core:' in x and 'dst:(type:GM;' in x and 'src:(type:UB;' in x]
R=SourceFileLoader('r',str(root/'audit-reduce-family.py')).load_module().REGEX;events=R.findall(raw);assert len(stores)==len(events)>0
metrics=re.findall(r'processedRecord: (\d+), droppedRecord: (\d+).*?memoryCorruption (\d+)',raw);assert metrics and all(d=='0' and m=='0' for _,d,m in metrics)
percore=Counter();rounded=Counter();actual=[];pcs=set()
for c,pc,addr,stride,l1s,l2s,srcaddr,srcstride,srcl1s,srcl2s,burst,length,dtype,l1,l2,left,right in events:
 c=int(c);assert c%3 in (0,1) and c//3<28;pcs.add(int(pc,16));addr=int(addr,16)
 stride=int(stride);l1s=int(l1s);l2s=int(l2s);n=int(burst);length=int(length);l1=int(l1);l2=int(l2)
 assert n>0 and length>0 and l1>=1 and l2>=1 and int(left)==int(right)==0
 percore[c]+=n*length*l1*l2
 rounded[c]+=(((n*length+31)//32)*32 if int(srcstride)==length else n*((length+31)//32)*32)*l1*l2
 for z in range(l2):
  for y in range(l1):
   for x in range(n):
    lo=addr+z*l2s+y*l1s+x*stride;hi=lo+length;i=bisect.bisect_right(starts,lo)-1
    assert i>=0 and expected[i][0]<=lo and hi<=expected[i][1],(hex(lo),hex(hi))
    actual.append((lo,hi))
assert merge(actual)==expected
for pc in pcs:assert any(re.match(r'^\s*'+format(pc,'x')+r':',line) and 'MOV_UB_TO_OUT' in line for line in isa.splitlines()),hex(pc)
mem=read(op.with_name('Memory.csv'));assert len(mem)==84
for j,row in enumerate(mem):
 group,role=divmod(j,3);assert int(row['block_id'])==group and row['sub_block_id']==('cube0','vector0','vector1')[role]
 value=row['UB_to_GM_datas(KB)']
 if role:
  total=rounded[3*group+role-1]
  if value not in ('NA',''):assert abs(Decimal(value)*1024-total)<=Decimal('0.000512'),(j,value,total)
  else:assert total==0
 else:assert value in ('NA','') or Decimal(value)==0

result={'case':'campaign-13/'+case,'target':'paged_mqa_logits_impl','status':'passed','device':'hidev NPU 0',
 'device_health':'Alarm 8C4BA00C','correctness':'passed','historical_true_inputs_and_jit_source_match':True,
 'output_shape':shape,'output_stride':out['stride'],'output_logical_bytes':math.prod(shape)*size,'expected_written_bytes':sum(lengths)*size,'range_input_sha256':hashes,'dbi_requested_bytes':sum(percore.values()),
 'per_vector_block_requested_bytes':{i:percore[3*(i//2)+i%2] for i in range(56)},'capture_binary_sha256':sha(binary),
 'dbi_pc':[hex(x) for x in sorted(pcs)],'csv_pair_totals_match':True,
 'scope':'one mixed-kernel MemoryDetail window; AIV UB to GM requests, not Cube traffic or physical DRAM transactions'}
assert result['dbi_requested_bytes']==result['expected_written_bytes']
Path(os.environ.get('AUDIT_OUTPUT',str(p/'address-audit.json'))).write_text(json.dumps(result,indent=2)+'\n');print('PASS',case,result['dbi_requested_bytes'])
