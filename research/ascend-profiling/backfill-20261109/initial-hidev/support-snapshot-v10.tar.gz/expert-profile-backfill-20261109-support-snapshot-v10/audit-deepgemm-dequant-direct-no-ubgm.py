"""Audit captured direct-store fp8/fp4 GEMMs without AIV UB-to-GM stores."""
import csv,hashlib,json,re,subprocess
from pathlib import Path
root=Path('/workspace/expert-profile-backfill-20261109-hidev')
repo=Path('/workspace/deepgemm-ascend-20261107/source')
src=repo/'deep_gemm/include/deep_gemm/fp8_dequant_gemm.hpp';epi=repo/'deep_gemm/include/deep_gemm/epilogue.hpp'
tool=Path('/workspace/tilekernels-env-20261101/cann/cann-9.2.1/tools/bisheng_compiler/bin/llvm-objdump')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for path in (src,epi):
 rel=path.relative_to(repo).as_posix()
 assert subprocess.check_output(['git','-C',str(repo),'hash-object',str(path)],text=True).strip()==subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD:'+rel],text=True).strip()
source=src.read_text();assert 'bool kDirectStore = false, bool kDualAIVDequant = false' in source
assert 'if constexpr (kDirectStore) return;' in source and 'copy_l0c_to_gm' in source
allowed=set('ADD ADDI AND CMP CMPN DCCI END FIX_L0C_TO_OUT INSERT JUMPCI JUMPI LDP LD_IO LOAD_L1_TO_L0A_2DV2 LOAD_L1_TO_L0A_MX_2DV2 LOAD_L1_TO_L0B_2DV2 LOAD_L1_TO_L0B_MX_2DV2 MADD MIN MMAD_MX MOV MOVEMASK MOVI MOVK MOV_OUT_TO_L1_MULTI_ND2NZ MOV_OUT_TO_UB_ALIGN_V2 MOV_UB_TO_L1 MUL MULI NEG NOP OR PSET PUSH_PB SBITSET0 SBITSET1 SEL SEND SET_FLAG SET_FLAG_V SET_INTRA_BLOCK SET_L1_2D SHLI SHRI SIGNEXT SMOV ST_IO SUB SUBI VADDS VAND VBR VCI VCMPS VF VINTLV VLDI VLOOPV2_V310 VMOV VOR VSEL VSELR VSHLI VSHRI VSSTB VST VSTI WAIT_FLAG WAIT_FLAG_V WAIT_INTRA_BLOCK XOR ZEROEXT'.split())
items=json.loads((root/'deepgemm-dequant-direct-isa-survey.json').read_text())['cases'];assert len(items)==9
out=root/'deepgemm-dequant-direct-static-audit';out.mkdir(exist_ok=True)
for path in (src,epi):(out/path.name).write_bytes(path.read_bytes())
records=[]
for item in items:
 binary=Path(item['binary_path']);wrapper=Path(item['wrapper_path']);d=wrapper.parent.parent;case=d.name
 assert sha(binary)==item['binary_sha256'] and re.search(r'\btrue,\s*true,\s*false>\);',wrapper.read_text())
 result=json.loads((d/'result.json').read_text());assert result['status']=='passed' and result['capture']['jit_binary_sha256']==sha(binary)
 op=binary.parent.parent/'OpBasicInfo.csv'
 with op.open(encoding='utf-8-sig',newline='') as f:basic,=list(csv.DictReader(f))
 assert basic['Op Type']=='mix' and 'fp8_dequant_gemm_impl' in basic['Op Name']
 asm=subprocess.check_output([str(tool),'-d',str(binary)],text=True)
 lines=re.findall(r'^\s*[0-9a-f]+:\s+[0-9a-f]+\s+.*$',asm,re.M)
 ins=re.findall(r'^\s*[0-9a-f]+:\s+[0-9a-f]+\s+([A-Z][A-Z0-9_]*)',asm,re.M)
 assert len(lines)==len(ins)>0 and set(ins)<=allowed,(case,sorted(set(ins)-allowed))
 assert 'MOV_UB_TO_L1' in ins and 'FIX_L0C_TO_OUT' in ins and not any(x.startswith(('MOV_UB_TO_OUT','STG')) for x in ins)
 isa=out/(case+'.isa');isa.write_text(asm)
 records.append({'target':'campaign-13/'+case,'status':'aiv_ub_to_gm_not_applicable','correctness':'passed',
  'binary_sha256':sha(binary),'binary_path':str(binary),'wrapper_sha256':sha(wrapper),'isa_path':str(isa),'isa_sha256':sha(isa),
  'instruction_count':len(ins),'opcodes':sorted(set(ins)),
  'reason':'direct-store specialization writes output from Cube; AIV moves dequant data UB to L1, not UB to GM'})
doc={'source_commit':'3a35326271b069b8b5bf1a754435acd6cc91575b','header_sha256':sha(src),'epilogue_sha256':sha(epi),
 'cases':records,'scope':'AIV UB-to-GM only; Cube stores and AIV UB-to-L1 transfers still occur'}
(out/'audit.json').write_text(json.dumps(doc,indent=2)+'\n');print('DEQUANT_DIRECT_STATIC_AUDIT',len(records),sha(out/'audit.json'))
