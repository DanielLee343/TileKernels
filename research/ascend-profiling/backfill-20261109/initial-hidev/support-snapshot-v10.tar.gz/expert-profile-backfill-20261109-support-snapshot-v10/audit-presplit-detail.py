"""Audit the three output stores of mHC pre-split forward."""
import csv,hashlib,json,os,re,subprocess,sys
from collections import Counter
from decimal import Decimal
from pathlib import Path
from importlib.machinery import SourceFileLoader
root=Path(os.environ['BACKFILL_ROOT']);R=SourceFileLoader('reduce_audit',str(root/'audit-reduce-family.py')).load_module().REGEX
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):
 with p.open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
case,attempt=sys.argv[1:];assert re.fullmatch(r'presplit-fwd-(0[1-9]|1[0-9]|20)',case)
p=root/'classic-runs/sixth'/case/'hidev-npu0'/attempt/'detail';a=json.loads((p/'metadata/application.json').read_text());identity=json.loads((p/'capture-inspection.json').read_text())
assert identity['status']=='capture_identified_address_audit_pending' and identity['correctness']=='passed' and identity['historical_true_inputs_and_source_match']
assert a['runtime_kernel']=='mhc_pre_split_mixes_fwd_simd_mhc4_asc_kernel' and a['case']['family']=='mhc_pre_split_mixes_fwd'
n=a['case']['tokens'];outs=a['outputs'];assert [x['shape'] for x in outs]==[[n,4],[n,4],[n,16]] and all(x['dtype']=='float32' for x in outs)
widths=(16,16,64);bases=[int(x,16) for x in a['device_output_addresses']];ends=[b+n*w for b,w in zip(bases,widths)]
assert all(ends[i]<=bases[j] or ends[j]<=bases[i] for i in range(3) for j in range(i+1,3))
code=(p/'metadata/default-kernel.cpp').read_text();lines=[x for x in code.splitlines() if 'asc_copy_ub2gm_align(' in x]
assert len(lines)==3 and all(any((name+'[') in x for x in lines) for name in ('pre_layer_mix','post_layer_mix','comb_res_mix'))
assert '((num_tokens + 63) >> 6)' in code
op,=list((p/'capture').rglob('OpBasicInfo.csv'));basic,=read(op)
assert (basic['Op Type'],basic['Block Dim'],basic['Device Id'])==('vector','56','0') and basic['Op Name']==a['runtime_kernel']
binary=op.parent/'dump/aicore_binary.o';assert sha(binary)==identity['capture_binary_sha256']
isa=subprocess.check_output([os.environ['BACKFILL_OBJDUMP'],'-d',str(binary)],text=True);(p/'device-kernel.isa').write_text(isa)
raw=(p/'profile.log').read_text(errors='replace');stores=[x for x in raw.splitlines() if 'DBI record core:' in x and 'dst:(type:GM;' in x and 'src:(type:UB;' in x];rec=R.findall(raw)
assert len(stores)==len(rec)==3*((n+63)//64),(len(stores),len(rec),n)
hits=Counter();blocks=Counter();rounded=Counter();pcs=set()
for c,pc,addr,stride,l1s,l2s,srcaddr,srcstride,srcl1s,srcl2s,burst,length,dtype,l1,l2,left,right in rec:
 c=int(c);addr=int(addr,16);which=[i for i in range(3) if bases[i]<=addr<ends[i]];assert len(which)==1
 i=which[0];start,rem=divmod(addr-bases[i],widths[i]);assert rem==0 and start%64==0 and start<n
 block=(start//64)%56;size=min(64,n-start)*widths[i];assert (c//3,c%3)==divmod(block,2)
 assert (int(burst),int(length),int(l1),int(l2),int(left),int(right))==(1,size,1,1,0,0)
 hits[(i,start)]+=1;blocks[block]+=size;rounded[block]+=((size+31)//32)*32;pcs.add(int(pc,16))
assert hits==Counter((i,start) for i in range(3) for start in range(0,n,64))
for pc in pcs:assert any(re.match(r'^\s*'+format(pc,'x')+r':',line) and 'MOV_UB_TO_OUT' in line for line in isa.splitlines())
mem=read(op.with_name('Memory.csv'));assert len(mem)==56
for j,row in enumerate(mem):
 assert int(row['block_id'])==j and row['sub_block_id']=='vector0';value=row['UB_to_GM_datas(KB)'];expected=rounded[2*j]+rounded[2*j+1] if j<28 else None
 if j<28 and value not in ('NA',''):assert abs(Decimal(value)*1024-expected)<=Decimal('0.000512')
 elif j<28:assert expected==0
 else:assert value in ('NA','')
result={'target':'sixth/'+case,'status':'passed','device':'hidev NPU 0','correctness':'passed','historical_input_and_source_match':True,
 'runtime_kernel':basic['Op Name'],'dbi_requested_bytes':sum(blocks.values()),'output_logical_bytes':sum(x['bytes'] for x in outs),
 'per_vector_block_requested_bytes':{i:blocks[i] for i in range(56)},'capture_binary_sha256':sha(binary),'dbi_pc':[hex(x) for x in sorted(pcs)],
 'csv_pair_totals_match':True,'csv_comparison':'single-burst source sizes rounded up to 32 bytes, observed per group',
 'scope':'one MemoryDetail window; requested UB to GM bytes, not physical DRAM transactions'}
(p/'audit-result.json').write_text(json.dumps(result,indent=2)+'\n');print('PASS',case,sum(blocks.values()))
