#!/usr/bin/env bash
set -Eeuo pipefail
root=/workspace/expert-profile-backfill-20261109-hidev
q="$root/extra-quant-cast-smoke-hidev-npu0";mkdir -p "$q"
trap 'rc=$?;printf "exit=%s at=%s\n" "$rc" "$(date -u +%FT%TZ)" > "$q/exit.txt"' EXIT
previous="$root/extra-swiglu-backward-smoke-hidev-npu0";pid=$(cat "$previous/pid")
while ps -p "$pid" -o args= | grep -Fq "$root/orchestrate-swiglu-backward-smoke.sh";do sleep 10;done
export TARGET_ID=unified-extra/quant_cast-01 ATTEMPT=attempt-001
bash "$root/run-hidev-extra-quant-cast-detail.sh"
python3 -B "$root/inspect-extra-quant-cast.py" "$TARGET_ID" "$ATTEMPT"
echo QUANT_CAST_SMOKE_CAPTURE_IDENTIFIED_ADDRESS_AUDIT_PENDING
