#!/usr/bin/env bash
set -Eeuo pipefail
root=/workspace/expert-profile-backfill-20261109-hidev
q="$root/extra-randn-smoke-hidev-npu0";mkdir -p "$q"
trap 'rc=$?;printf "exit=%s at=%s\n" "$rc" "$(date -u +%FT%TZ)" > "$q/exit.txt"' EXIT
previous="$root/dg-paged-mqa-smoke-hidev-npu0";pid=$(cat "$previous/pid")
while ps -p "$pid" -o args= | grep -Fq "$root/orchestrate-dg-paged-mqa-smoke.sh";do sleep 10;done
export TARGET_ID=unified-extra2/randn-04 ATTEMPT=attempt-001
bash "$root/run-hidev-extra-randn-detail.sh"
python3 -B "$root/inspect-extra-randn.py" "$TARGET_ID" "$ATTEMPT"
echo RANDN_SMOKE_IDENTITY_CHECKED_ADDRESS_AUDIT_PENDING
