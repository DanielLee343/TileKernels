"""Independently check all reported parser diagnostics for completed quant captures."""
import json,re,sys
from pathlib import Path
root=Path('/workspace/expert-profile-backfill-20261109-hidev');cases=[]
keys=('droppedRecord','memoryCopyFailed','invalidParam','overflow','invalidDataCount','memoryCorruption','invalidRecordType','outOfBoundsRead')
for audit in sorted((root/'unified-quant-runs').rglob('audit-result.json')):
 p=audit.parent;raw=(p/'profile.log').read_text(errors='replace');lines=[x for x in raw.splitlines() if 'processedRecord:' in x and 'droppedRecord:' in x]
 errs=[]
 if not lines:errs.append('missing parser summary')
 for line in lines:
  values={k:int(v) for k,v in re.findall(r'(processedRecord|droppedRecord|memoryCopyFailed|invalidParam|receivedPacket|processedPacket|overflow|invalidDataCount|memoryCorruption|invalidRecordType|outOfBoundsRead)[: ]+([0-9]+)',line)}
  for key in keys:
   if key not in values or values[key]!=0:errs.append(f'{key}={values.get(key,"missing")}')
  if 'receivedPacket' not in values or 'processedPacket' not in values or values['receivedPacket']!=values['processedPacket']:errs.append('packet counts missing or differ')
  tail=line.split('each record type process fail count',1)
  if len(tail)!=2 or any(int(x) for x in re.findall(r'\d+',tail[1])):errs.append('record-type failures or missing summary')
 a=json.loads(audit.read_text());cases.append({'target':a['target'],'raw_dir':str(p),'status':'passed' if not errs else 'review_required','errors':errs})
out={'count':len(cases),'review_count':sum(x['status']!='passed' for x in cases),'cases':cases}
(root/'quant-parser-quality.json').write_text(json.dumps(out,indent=2)+'\n')
print('quant captures',out['count'],'parser review required',out['review_count'])
for x in cases:
 if x['errors']:print(x['target'],x['errors'])
sys.exit(bool(out['review_count']))
