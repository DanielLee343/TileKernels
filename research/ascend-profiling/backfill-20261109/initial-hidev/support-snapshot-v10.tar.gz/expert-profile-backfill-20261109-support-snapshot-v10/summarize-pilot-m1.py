"""Index four validated pilot windows and preserve their raw evidence hashes."""
import hashlib,json,time
from pathlib import Path
root=Path('/workspace/expert-profile-backfill-20261109-hidev');cases=[]
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for chunk in iter(lambda:f.read(1024*1024),b''):h.update(chunk)
 return h.hexdigest()
for case in ('bf16-m1-n32768-k512','fp8fp8-m1-n32768-k512','fp4fp4-m1-n32768-k512','fp8fp4-m1-n32768-k512'):
 p=root/'deepgemm-pilot-runs'/case/'hidev-npu0/attempt-001';a=json.loads((p/'address-audit.json').read_text())
 family='pilot-bf16' if case.startswith('bf16-') else 'pilot-quant'
 assert a['case']==family+'/'+case and a['status']=='passed' and a['correctness']=='passed' and a['historical_true_inputs_and_jit_source_match']
 assert a['dbi_requested_bytes']==a['output_bytes']
 files=[p/'address-audit.json',p/'prepare.json',p/'profile.json',p/'profile-addresses.json',p/'capture-inspection.json',p/'device-kernel.isa',p/'jit/kernel.asc',p/'jit/kernel.o',p/'detail/profile.log',p/'detail/monitor-summary.json',p/'detail/command.json',p/'provenance/health-before.txt',p/'provenance/health-after.txt']
 files+=list((p/'detail/capture').rglob('OpBasicInfo.csv'))+list((p/'detail/capture').rglob('Memory.csv'));assert all(x.is_file() for x in files)
 assert '8C4BA00C' in (p/'provenance/health-before.txt').read_text(errors='replace')
 cases.append({'case':a['case'],'audit':a,'raw_dir':str(p),'files_sha256':{str(x.relative_to(root)):sha(x) for x in files},'health':'Alarm 8C4BA00C'})
out={'created_unix':time.time(),'count':len(cases),'cases':cases,'scope':'separate MemoryDetail windows; requested AIV UB to GM bytes, not DRAM transactions'}
(root/'deepgemm-pilot-m1-index.json').write_text(json.dumps(out,indent=2)+'\n');print('indexed',len(cases),'pilot M=1 captures')
