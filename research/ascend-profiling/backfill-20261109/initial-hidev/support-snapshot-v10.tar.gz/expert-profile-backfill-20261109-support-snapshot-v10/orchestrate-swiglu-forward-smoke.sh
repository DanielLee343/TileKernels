#!/usr/bin/env bash
set -Eeuo pipefail
root=/workspace/expert-profile-backfill-20261109-hidev;previous="$root/deepgemm-mgroup-queue-hidev-npu0"
q="$root/extra-swiglu-forward-smoke-hidev-npu0";mkdir -p "$q"
trap 'rc=$?; printf "exit=%s at=%s\n" "$rc" "$(date -u +%FT%TZ)" > "$q/exit.txt"' EXIT
pid=$(cat "$previous/followup.pid")
while ps -p "$pid" -o args= | grep -Fq "$root/orchestrate-dg-mgroup-queue.sh";do sleep 10;done
export TARGET_ID=unified-extra3/quant_swiglu_forward-01 ATTEMPT=attempt-001
bash "$root/run-hidev-extra-swiglu-forward-detail.sh"
python3 -B "$root/inspect-extra-swiglu-forward.py" "$TARGET_ID" "$ATTEMPT"
echo 'identity smoke finished; independent address audit remains required'
