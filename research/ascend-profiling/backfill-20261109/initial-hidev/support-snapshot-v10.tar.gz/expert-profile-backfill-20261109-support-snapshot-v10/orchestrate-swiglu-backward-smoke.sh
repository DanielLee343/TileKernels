#!/usr/bin/env bash
set -Eeuo pipefail
root=/workspace/expert-profile-backfill-20261109-hidev
q="$root/extra-swiglu-backward-smoke-hidev-npu0";mkdir -p "$q"
trap 'rc=$?;printf "exit=%s at=%s\n" "$rc" "$(date -u +%FT%TZ)" > "$q/exit.txt"' EXIT
previous="$root/extra-swiglu-forward-queue-hidev-npu0";pid=$(cat "$previous/pid")
while ps -p "$pid" -o args= | grep -Fq "$root/orchestrate-swiglu-forward-queue.sh";do sleep 10;done
export TARGET_ID=unified-extra4/quant_swiglu_backward-01 ATTEMPT=attempt-001
bash "$root/run-hidev-extra-swiglu-backward-detail.sh"
python3 -B "$root/inspect-extra-swiglu-backward.py" "$TARGET_ID" "$ATTEMPT"
echo SWIGLU_BACKWARD_SMOKE_CAPTURE_IDENTIFIED_ADDRESS_AUDIT_PENDING
