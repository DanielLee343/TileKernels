"""Snapshot replay scripts and immutable harnesses, with per-file hashes."""
import hashlib,json,shutil
from pathlib import Path
r=Path('/workspace/expert-profile-backfill-20261109-hidev');out=Path('/workspace/expert-profile-backfill-20261109-support-snapshot-v5')
assert not out.exists();out.mkdir()
names=('classic-harness','unified-quant-harness','unified-quant-extra-harness','extra-proxy-harness','extra-proxy-mask-harness',
       'extra-proxy-accum-app-harness','extra-proxy-randn-harness','deepgemm-paged-mqa-harness','deepgemm-paged-mqa-lengths-harness','deepgemm-kgroup-harness','deepgemm-sparse-mqa-harness','deepgemm-paged-sparse-harness',
       'deepgemm-profile-harness','deepgemm-transform-harness','deepgemm-mix-harness','deepgemm-dequant-harness',
       'deepgemm-paged-meta-harness','deepgemm-mgroup-harness','deepgemm-bf16-mgroup-harness','deepgemm-dequant-mgroup-harness',
       'deepgemm-mqa-harness','deepgemm-mqa-ranges-harness','mega28-profile-harness','topk-history','hash-history','fused-history','mhc-history','runner-version-evidence')
files=[x for x in r.iterdir() if x.is_file() and not x.is_symlink() and x.suffix in ('.py','.sh','.json','.csv','.md') and not x.name.startswith('deploy-')]
for name in ('moe-backward-audit-test.log','moe-backward-v2-01-test.log','moe-backward-v2-02-test.log','kgroup-bf16-audit-test.log','kgroup-fp8fp8-audit-test.log','kgroup-fp4fp4-audit-test.log','kgroup-fp8fp4-audit-test.log','sparse-mqa-audit-test.log'):
 x=r/name
 if x.is_file() and not x.is_symlink():files.append(x)
for name in names:
 base=r/name
 if not base.is_dir():continue
 for x in base.rglob('*'):
  assert not x.is_symlink(),x
  if x.is_file() and '__pycache__' not in x.parts and x.suffix!='.pyc':files.append(x)
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
records=[]
for src in sorted(set(files)):
 rel=src.relative_to(r);dest=out/rel;dest.parent.mkdir(parents=True,exist_ok=True)
 before=sha(src);shutil.copyfile(src,dest);assert sha(dest)==sha(src)==before,rel
 records.append({'path':rel.as_posix(),'bytes':dest.stat().st_size,'sha256':before})
(out/'support-manifest.json').write_text(json.dumps({'files':records,'count':len(records),'scope':'point-in-time scripts, harnesses, historical bindings and indexes; capture windows are separately archived'},indent=2)+'\n')
print('SUPPORT_SNAPSHOT_VERIFIED',len(records),flush=True)
