# Actual collection runner versions

These files are immutable snapshots of the actual specialized wrappers in use
before their provenance-copy path was corrected. Their SHA-256 values are in
`sha256.txt`. The affected capture's `detail/provenance/` copied the generic
wrapper instead. Comparison shows the old specialized wrappers differed from
the copied base in the target group or additional target-case guard; the
profiler command, replay mode, warmup, hardware guard, and application adapter
were otherwise unchanged. Never substitute the base file as the actual runner.

- `run-hidev-extra-quant-cast-detail.sh`: quant_cast group, all captures in the
  queue started as `extra-quant-cast-queue-hidev-npu0`, including its first
  smoke case. This old wrapper remains in use for the running queue.
- `run-hidev-extra-norm-backward-detail.sh`: quant_norm_backward-01 smoke.
- `run-hidev-extra-swiglu-backward-detail.sh`: quant_swiglu_backward-01 and
  variant smoke cases 07, 08, 12, 13. The later full queue uses the corrected
  wrapper that copies itself.
- `run-hidev-extra-norm-backward-variants.sh` and
  `run-hidev-extra-engram-gate-fwd.sh` were snapshotted before their first use;
  the scheduled captures use the corrected variants that copy themselves.

All original logs and copied base wrappers are preserved. A queue's target,
attempt and monitor logs determine which wrapper revision applied.
