#!/usr/bin/env bash
set -Eeuo pipefail
root=/workspace/expert-profile-backfill-20261109-hidev;previous="$root/extra-swiglu-forward-smoke-hidev-npu0"
q="$root/extra-norm-rowmajor-smoke-hidev-npu0";mkdir -p "$q"
trap 'rc=$?; printf "exit=%s at=%s\n" "$rc" "$(date -u +%FT%TZ)" > "$q/exit.txt"' EXIT
pid=$(cat "$previous/pid")
while ps -p "$pid" -o args= | grep -Fq "$root/orchestrate-swiglu-forward-smoke.sh";do sleep 10;done
for n in 11 08;do
 export TARGET_ID="unified-extra3/quant_norm_forward-$n" ATTEMPT=attempt-001
 bash "$root/run-hidev-extra-norm-forward-detail.sh"
 python3 -B "$root/inspect-extra-norm-forward.py" "$TARGET_ID" "$ATTEMPT"
 echo "$TARGET_ID identity smoke complete; address audit pending"
done
