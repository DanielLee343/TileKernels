#!/usr/bin/env bash
set -Eeuo pipefail
root=/workspace/expert-profile-backfill-20261109-hidev;previous="$root/deepgemm-mgroup-smoke-hidev-npu0"
q="$root/classic-castback-smoke-hidev-npu0";mkdir -p "$q"
trap 'rc=$?; printf "exit=%s at=%s\n" "$rc" "$(date -u +%FT%TZ)" > "$q/exit.txt"' EXIT
pid=$(cat "$previous/pid")
while ps -p "$pid" -o args= | grep -Fq "$root/orchestrate-deepgemm-mgroup-smoke.sh";do sleep 10;done
source /workspace/tilekernels-env-20261101/activate.sh
export BACKFILL_ROOT="$root" BACKFILL_HOST=hidev BACKFILL_OBJDUMP="$ASCEND_HOME_PATH/tools/bisheng_compiler/bin/llvm-objdump"
export CASE_ID=castback-09 CASE_BATCH=second ATTEMPT=attempt-001 KERNEL_NAME=cast_back_kernel_ascend_kernel
cd "$root";bash run-hidev-classic-detail.sh
python -B inspect-classic-capture.py second/castback-09 attempt-001
echo 'historical identity smoke complete; output address audit remains required'
