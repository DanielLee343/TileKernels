"""Archive one specified collection group while that group has no writers."""
import importlib.util,sys
from pathlib import Path
root=Path('/workspace/expert-profile-backfill-20261109-hidev');group=sys.argv[1]
assert group in {'fused-runs','topk-runs','hash-runs','classic-runs','mega28-runs','unified-quant-runs'}
spec=importlib.util.spec_from_file_location('archive_captures',root/'archive-captures.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);m.GROUPS=(group,)
def no_support(source,out):
 p=out/'support.jsonl';p.write_bytes(b'');return 0,m.sha(p)
m.copy_support=no_support
sys.argv=['archive-captures.py','--root',str(root),'--out',f'/workspace/expert-profile-backfill-20261109-{group}-static-archive']
m.main()
