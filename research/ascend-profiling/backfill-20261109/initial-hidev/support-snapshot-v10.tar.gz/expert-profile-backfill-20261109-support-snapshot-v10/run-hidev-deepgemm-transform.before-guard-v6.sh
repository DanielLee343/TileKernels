#!/usr/bin/env bash
set -Eeo pipefail
root=/workspace/expert-profile-backfill-20261109-hidev
dg=/workspace/deepgemm-ascend-20261107
case_id="${CASE_ID:?}";attempt="${ATTEMPT:?}"
[[ "$case_id" =~ ^transform-[a-z0-9-]+$ ]] || exit 2
target=transform_sf
unset LD_LIBRARY_PATH PYTHONPATH LD_PRELOAD MEMORYCHART_ROOT MEMORYCHART_LOG MSOPT_LOG_LEVEL
source "$dg/activate.sh"
set -u
test -d "$dg/cann-compat-quant"
export ASCEND_HOME_PATH="$dg/cann-compat-quant" BISHENG_HOME="$dg/cann-compat-quant"
export ASCEND_RT_VISIBLE_DEVICES=0 PYTHONDONTWRITEBYTECODE=1 GUARD_DEADLINE_SECONDS=900
export DG_JIT_CACHE_DIR="$root/deepgemm-cache/$case_id"
exec 9> /workspace/.puma-hidev-npu0.lock
flock -n 9
test "$(git -C "$dg/source" rev-parse HEAD)" = 3a35326271b069b8b5bf1a754435acd6cc91575b
test -z "$(git -C "$dg/source" status --porcelain --untracked-files=no)"
out="$root/deepgemm-runs/$case_id/hidev-npu0/$attempt"
test ! -e "$out";mkdir -p "$out/provenance"
timeout 10 npu-smi info -t board -i 0 > "$out/provenance/board.txt"
grep -qi '0000:8b:00.0' "$out/provenance/board.txt"
timeout 10 npu-smi info -t health -i 0 > "$out/provenance/health-before.txt"
msprof op --version > "$out/provenance/msprof-version.txt"
grep -q 884ac969494a186a9c63ac45c4c39ad7289b3215 "$out/provenance/msprof-version.txt"
git -C "$dg/source" rev-parse HEAD > "$out/provenance/commit.txt"
printf '%s\n' "$ASCEND_HOME_PATH" > "$out/provenance/cann-path.txt"
harness="$root/deepgemm-transform-harness/campaign-13/collect.py"
cd "$root"
export GUARD_REQUIRE_PROFILE=0
python -B guard-v4.py 0 "$out/prepare-monitor" \
 python -B "$harness" __worker "$case_id" prepare "$out/prepare.json" "$dg/source"
export GUARD_REQUIRE_PROFILE=1 MSOPT_LOG_LEVEL=0
python -B guard-v4.py 0 "$out/detail" \
 msprof op "--output=$out/detail/capture" --aic-metrics=MemoryDetail,Default --replay-mode=kernel \
 --mstx=true --mstx-include=dg_campaign_target "--kernel-name=*$target*" --launch-count=1 --warm-up=5 \
 python -B "$harness" __worker "$case_id" profile "$out/profile.json" "$dg/source"
timeout 10 npu-smi info -t health -i 0 > "$out/provenance/health-after.txt"
echo 'capture complete; identity and address audit pending'
