"""Snapshot a selected quiescent capture group, including its failed attempts."""
import importlib.util,sys
from pathlib import Path
root=Path('/workspace/expert-profile-backfill-20261109-hidev');group=sys.argv[1]
assert group in {'deepgemm-runs','extra-proxy-unified-extra','extra-proxy-unified-extra2','extra-proxy-unified-extra3','extra-proxy-unified-extra4','extra-proxy-unified-extra5'}
spec=importlib.util.spec_from_file_location('archive_captures',root/'archive-captures.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
if group.startswith('extra-proxy-unified-extra'):
 m.GROUPS=('extra-proxy-runs',);original=m.scan_units
 prefix=group.removeprefix('extra-proxy-')+'__'
 m.scan_units=lambda r:(x for x in original(r) if x[1].startswith(prefix))
else:m.GROUPS=(group,)
def no_support(source,out):
 p=out/'support.jsonl';p.write_bytes(b'');return 0,m.sha(p)
m.copy_support=no_support
sys.argv=['archive-captures.py','--root',str(root),'--out',f'/workspace/expert-profile-backfill-20261109-{group}-snapshot-archive']
m.main()
