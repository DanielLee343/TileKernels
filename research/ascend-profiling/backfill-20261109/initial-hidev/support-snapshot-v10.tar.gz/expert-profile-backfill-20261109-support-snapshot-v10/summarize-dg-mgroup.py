"""Index independently audited paged MQA metadata captures."""
import hashlib,json,time
from pathlib import Path
root=Path('/workspace/expert-profile-backfill-20261109-hidev');cases=[]
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for chunk in iter(lambda:f.read(1024*1024),b''):h.update(chunk)
 return h.hexdigest()
items=json.loads((root/'deepgemm-mgroup-harness/campaign-13/cases.json').read_text())['cases'];assert len(items)==6
for x in items:
 case=x['id'];base=root/'deepgemm-runs'/case/'hidev-npu0'
 for audit in sorted(base.glob('attempt-*/address-audit.json')):
  p=audit.parent;a=json.loads(audit.read_text());assert a['case']=='campaign-13/'+case and a['status']=='passed' and a['correctness']=='passed'
  assert a['historical_true_inputs_and_jit_source_match'] and a['dbi_requested_bytes']==a['output_bytes']
  files=[audit,p/'prepare.json',p/'profile.json',p/'profile-addresses.json',p/'capture-inspection.json',p/'device-kernel.isa',
         p/'jit/kernel.asc',p/'jit/kernel.o',p/'detail/profile.log',p/'detail/monitor-summary.json',p/'detail/command.json',
         p/'provenance/health-before.txt',p/'provenance/health-after.txt']
  files+=list((p/'detail/capture').rglob('OpBasicInfo.csv'))+list((p/'detail/capture').rglob('Memory.csv'))
  assert all(z.is_file() for z in files)
  health=(p/'provenance/health-before.txt').read_text(errors='replace');assert '8C4BA00C' in health
  cases.append({'case':a['case'],'audit':a,'raw_dir':str(p),'files_sha256':{str(z.relative_to(root)):sha(z) for z in files},'health':'Alarm 8C4BA00C'})
assert len(cases)==6 and len({x['case'] for x in cases})==6
out={'created_unix':time.time(),'count':len(cases),'cases':cases,'scope':'one independent MemoryDetail window per case; requests, not physical main-memory writes'}
(root/'deepgemm-mgroup-index.json').write_text(json.dumps(out,indent=2)+'\n');print('indexed',len(cases),'grouped GEMM captures')
