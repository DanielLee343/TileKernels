"""Collect per-token quant cases, stopping on any failed identity or audit."""
import fcntl,json,os,re,subprocess,sys,time
from pathlib import Path
root=Path('/workspace/expert-profile-backfill-20261109-hidev');q=root/'unified-quant-castonly-queue-hidev-npu0';q.mkdir(exist_ok=True)
lock=(q/'queue.lock').open('w');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
items=[x for x in json.loads((root/'unified-quant-extra-harness/cases.json').read_text())['cases'] if x['group']=='quant_per_token_cast_with_precomputed_sf'];assert len(items)==20
for x in items:
 case=x['id'];base=root/'unified-quant-runs'/case/'hidev-npu0';attempts=sorted(base.glob('attempt-*')) if base.exists() else []
 if any((a/'detail/audit-result.json').exists() and json.loads((a/'detail/audit-result.json').read_text()).get('status')=='passed' for a in attempts):
  print(case,'already audited; skip',flush=True);continue
 indices=[int(a.name.removeprefix('attempt-')) for a in attempts if re.fullmatch(r'attempt-\d+',a.name)]
 attempt=f'attempt-{max(indices,default=0)+1:03d}';out=base/attempt;out.mkdir(parents=True,exist_ok=False)
 status={'target':'unified-quant/'+case,'attempt':attempt,'status':'running','started_unix':time.time()}
 (out/'queue-status.json').write_text(json.dumps(status,indent=2)+'\n')
 env=os.environ.copy();env.update(CASE_ID=case,ATTEMPT=attempt)
 with (out/'launcher-console.log').open('w') as f:
  capture=subprocess.run(['bash',str(root/'run-hidev-unified-quant-extra-detail.sh')],env=env,stdout=f,stderr=subprocess.STDOUT)
 status['capture_exit']=capture.returncode
 if capture.returncode==0:
  with (out/'inspection-console.log').open('w') as f:
   inspect=subprocess.run([sys.executable,'-B',str(root/'inspect-unified-quant-extra.py'),case,attempt],env=env,stdout=f,stderr=subprocess.STDOUT)
  status['inspection_exit']=inspect.returncode
  if inspect.returncode==0:
   with (out/'audit-console.log').open('w') as f:
    audit=subprocess.run([sys.executable,'-B',str(root/'audit-uq-castonly.py'),case,attempt],env=env,stdout=f,stderr=subprocess.STDOUT)
   status['audit_exit']=audit.returncode;status['status']='passed' if audit.returncode==0 else 'address_audit_failed'
  else:status['status']='identity_review_required'
 else:status['status']='capture_failed'
 status['finished_unix']=time.time();tmp=out/'queue-status.tmp';tmp.write_text(json.dumps(status,indent=2)+'\n');tmp.replace(out/'queue-status.json')
 print(case,status['status'],flush=True)
 if status['status']!='passed':sys.exit(1)
print('ALL_UNIFIED_QUANT_CASTONLY_SELECTED_AUDITED',flush=True)
