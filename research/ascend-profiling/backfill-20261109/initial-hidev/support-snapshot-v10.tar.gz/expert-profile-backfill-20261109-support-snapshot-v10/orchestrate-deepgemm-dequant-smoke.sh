#!/usr/bin/env bash
set -Eeuo pipefail
root=/workspace/expert-profile-backfill-20261109-hidev
previous="$root/unified-quant-block-castonly-queue-hidev-npu0"
q="$root/deepgemm-dequant-smoke-hidev-npu0";mkdir -p "$q"
trap 'rc=$?; printf "exit=%s at=%s\n" "$rc" "$(date -u +%FT%TZ)" > "$q/exit.txt"' EXIT
pid=$(cat "$previous/followup.pid")
while ps -p "$pid" -o args= | grep -Fq "$root/orchestrate-block-castonly-followup.sh";do sleep 10;done
echo 'previous queue exited; begin independent dequant mixed GEMM representative'
export CASE_ID=gemm-fp8fp4-nt-k-m4096-n576-k7168 ATTEMPT=attempt-001
bash "$root/run-hidev-deepgemm-dequant-batch.sh"
python3 -B "$root/inspect-deepgemm-dequant.py" "$CASE_ID" "$ATTEMPT"
python3 -B "$root/audit-deepgemm-dequant.py" "$CASE_ID" "$ATTEMPT"
echo 'candidate audit passed; independent negative tests and acceptance still pending'
