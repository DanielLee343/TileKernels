"""Collect legacy cases serially; identified captures still need address audit."""
import fcntl,json,os,re,subprocess,sys,time
from pathlib import Path
root=Path('/workspace/expert-profile-backfill-20261109-hidev');q=root/'classic-queue-hidev-npu0';q.mkdir(exist_ok=True)
lock=(q/'queue.lock').open('w');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
cases=json.loads((root/'classic-pending.json').read_text());assert len(cases)==176
for item in cases:
 batch=item['batch'];case=item['case'];target=item['target'];base=root/'classic-runs'/batch/case/'hidev-npu0'
 attempts=sorted(base.glob('attempt-*')) if base.exists() else []
 if any((a/'detail/capture-inspection.json').exists() for a in attempts):
  print(target,'already identified; skip',flush=True);continue
 indexes=[int(a.name.removeprefix('attempt-')) for a in attempts if re.fullmatch(r'attempt-\d+',a.name)]
 attempt=f'attempt-{max(indexes,default=0)+1:03d}';out=base/attempt;out.mkdir(parents=True,exist_ok=False)
 status={'target':target,'attempt':attempt,'status':'running','started_unix':time.time()};(out/'queue-status.json').write_text(json.dumps(status,indent=2)+'\n')
 env=os.environ.copy();env.update(CASE_ID=case,CASE_BATCH=batch,ATTEMPT=attempt,KERNEL_NAME=item['kernel'])
 with (out/'launcher-console.log').open('w') as log:
  capture=subprocess.run(['bash',str(root/'run-hidev-classic-detail.sh')],env=env,stdout=log,stderr=subprocess.STDOUT)
 status['capture_exit']=capture.returncode
 if capture.returncode==0:
  with (out/'inspection-console.log').open('w') as log:
   inspect=subprocess.run([sys.executable,'-B',str(root/'inspect-classic-capture.py'),target,attempt],env=env,stdout=log,stderr=subprocess.STDOUT)
  status['inspection_exit']=inspect.returncode;status['status']='captured_address_audit_pending' if inspect.returncode==0 else 'identity_review_required'
 else:status['status']='capture_failed'
 status['finished_unix']=time.time();tmp=out/'queue-status.tmp';tmp.write_text(json.dumps(status,indent=2)+'\n');tmp.replace(out/'queue-status.json')
 print(target,status['status'],flush=True)
 if status['status']=='capture_failed':sys.exit(1)
print('ALL_CLASSIC_CAPTURE_ATTEMPTS_FINISHED',flush=True)
