"""Per-case mHC detail audit using source, historical inputs and DBI output addresses."""
import csv,hashlib,json,os,re,subprocess,sys
from collections import Counter
from decimal import Decimal
from pathlib import Path
from importlib.machinery import SourceFileLoader
root=Path(os.environ.get('BACKFILL_ROOT',str(Path.home()/'expert-profile-backfill-20261109')))
R=SourceFileLoader('reduce_audit',str(root/'audit-reduce-family.py')).load_module().REGEX
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):
 with p.open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def main():
 batch,case,device,attempt=sys.argv[1:];assert batch in ('second','third','fifth') and device in ('0','3')
 host=os.environ.get('BACKFILL_HOST','tbe');p=root/'mhc-runs'/batch/case/(host+'-npu'+device)/attempt/'detail'
 app=json.loads((p/'metadata/application.json').read_text());hist=json.loads((root/'mhc-history'/batch/case/'default.json').read_text())
 monitor=json.loads((p/'monitor-summary.json').read_text())
 assert app['status']=='passed' and app['visible_devices']==device and monitor['status']=='passed' and monitor['max_seconds_between_successful_queries']<=3
 for key in ('runtime_kernel','source_sha256','inputs','outputs'):assert app[key]==hist[key],key
 src=p/'metadata/default-kernel.cpp';assert sha(src)==app['source_sha256'];code=src.read_text()
 spec=app['case'];family=spec['family'];n=spec['tokens'];h=spec['hidden'];assert n>=56 and spec['mhc_mult']==4
 assert family in ('mhc_expand_bwd','mhc_expand_fwd','mhc_post_fwd','mhc_pre_apply_mix_fwd')
 rowbytes=h*2*(4 if family in ('mhc_expand_fwd','mhc_post_fwd') else 1)
 assert app['outputs'][0]['bytes']==n*rowbytes
 assert code.count('asc_copy_ub2gm_align(')==1
 line=next(s for s in code.splitlines() if 'asc_copy_ub2gm_align(' in s)
 m=re.search(r',\s*(\d+),\s*(\d+),\s*static_cast<asc_store_l2_cache_mode>\(\d+\),\s*(\d+),\s*(\d+)\);',line)
 assert m;nburst,width,dst_stride,src_stride=map(int,m.groups());assert rowbytes%(nburst*width)==0
 tiles=rowbytes//(nburst*width);assert f'/ num_tokens) < {tiles})' in code
 assert dst_stride==h*2 or nburst==1
 op,=list((p/'capture').rglob('OpBasicInfo.csv'));basic,=read(op)
 assert basic['Op Name']==app['runtime_kernel'] and basic['Op Type']=='vector' and basic['Block Dim']=='56' and basic['Device Id']==device
 binary=op.parent/'dump/aicore_binary.o';bsha=sha(binary)
 assert any(x.startswith(bsha+' ') and x.rstrip().endswith('/kernel.aibin') for x in (p/'cache-sha256.txt').read_text().splitlines())
 objdump=os.environ.get('BACKFILL_OBJDUMP','/home/pkg/cann920/cann-9.2.0/tools/bisheng_compiler/bin/llvm-objdump')
 isa=subprocess.check_output([objdump,'-d',str(binary)],text=True)
 (p/'device-kernel.isa').write_text(isa)
 raw=(p/'profile.log').read_text(errors='replace');stores=[x for x in raw.splitlines() if 'DBI record core:' in x and 'dst:(type:GM;' in x and 'src:(type:UB;' in x]
 rec=R.findall(raw);assert len(stores)==len(rec)==n*tiles,(len(stores),len(rec),n*tiles)
 base=int(app['device_output_addresses'][0],16);segments=Counter();blocks=Counter();pcs=set();requests=Counter()
 for c,pc,addr,stride,l1s,l2s,srcaddr,srcstride,srcl1s,srcl2s,burst,length,dtype,l1,l2,left,right in rec:
  c=int(c);addr=int(addr,16);row,offset=divmod(addr-base,rowbytes);tile,remain=divmod(offset,width)
  assert 0<=row<n and 0<=tile<tiles and remain==0
  block=(row+tile*n)%56;assert (c//3,c%3)==divmod(block,2)
  assert (int(burst),int(length),int(stride),int(l1),int(l2),int(left),int(right))==(nburst,width,dst_stride,1,1,0,0)
  assert int(srcstride)==src_stride
  for b in range(nburst):
   start=offset+b*dst_stride;assert start+width<=rowbytes;segments[(row,tile,b)]+=1
  blocks[block]+=nburst*width;requests[block]+=1;pcs.add(int(pc,16))
 assert len(segments)==n*tiles*nburst and all(v==1 for v in segments.values())
 intervals=sorted((tile*width+b*dst_stride,tile*width+b*dst_stride+width) for tile in range(tiles) for b in range(nburst))
 assert intervals[0][0]==0 and intervals[-1][1]==rowbytes and all(x[1]==y[0] for x,y in zip(intervals,intervals[1:]))
 assert set(blocks)==set(range(56))
 for block in range(56):assert requests[block]==max(0,(n*tiles+55-block)//56)
 for pc in pcs:assert any(re.match(r'^\s*'+format(pc,'x')+r':',line) and 'MOV_UB_TO_OUT' in line for line in isa.splitlines())
 mem=read(op.with_name('Memory.csv'));assert len(mem)==56
 for i,row in enumerate(mem):
  assert int(row['block_id'])==i and row['sub_block_id']=='vector0'
  if i<28:assert Decimal(row['UB_to_GM_datas(KB)'])*1024==blocks[2*i]+blocks[2*i+1]
  else:assert row['UB_to_GM_datas(KB)']=='NA'
 result={'target':batch+'/'+case,'status':'passed','device':host+' NPU '+device,'correctness':'passed',
  'historical_input_and_source_match':True,'runtime_kernel':basic['Op Name'],'dbi_requested_bytes':sum(blocks.values()),
  'output_logical_bytes':n*rowbytes,'per_vector_block_requested_bytes':dict(blocks),
  'capture_binary_sha256':bsha,'dbi_pc':[hex(x) for x in sorted(pcs)],'csv_pair_totals_match':True,
  'scope':'one MemoryDetail window; requested UB to GM bytes, not physical DRAM transactions',
  'max_seconds_between_successful_device_queries':monitor['max_seconds_between_successful_queries']}
 (p/'audit-result.json').write_text(json.dumps(result,indent=2)+'\n');print('PASS',batch,case,sum(blocks.values()))
if __name__=='__main__':main()
