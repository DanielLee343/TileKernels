#!/usr/bin/env bash
set -Eeuo pipefail
root=/workspace/expert-profile-backfill-20261109-hidev
q="$root/dg-mqa-ranges-smoke-hidev-npu0";mkdir -p "$q"
trap 'rc=$?;printf "exit=%s at=%s\n" "$rc" "$(date -u +%FT%TZ)" > "$q/exit.txt"' EXIT
previous="$root/extra-engram-gate-fwd-mask-queue-hidev-npu0";pid=$(cat "$previous/pid")
while ps -p "$pid" -o args= | grep -Fq "$root/orchestrate-engram-gate-fwd-mask-queue.sh";do sleep 10;done
export CASE_ID=mqa-0-q16-k512-h8-random ATTEMPT=attempt-002
bash "$root/run-hidev-deepgemm-mqa-ranges.sh"
python3 -B "$root/inspect-deepgemm-mqa-ranges.py" "$CASE_ID" "$ATTEMPT"
echo DG_MQA_RANGES_SMOKE_IDENTITY_CHECKED_ADDRESS_AUDIT_PENDING
