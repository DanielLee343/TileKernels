"""Capture same-family finalize cases and stop on the first missing proof."""
import fcntl,json,os,re,subprocess,sys,time
from pathlib import Path
root=Path('/workspace/expert-profile-backfill-20261109-hidev');q=root/'sinkhornbwd-queue-hidev-npu0';q.mkdir(exist_ok=True)
lock=(q/'queue.lock').open('w');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
items=[x for x in json.loads((root/'classic-pending.json').read_text()) if x['target'].startswith('second/sinkhorn-bwd-')];assert len(items)==20
for x in items:
 case=x['case'];target=x['target'];base=root/'classic-runs/second'/case/'hidev-npu0';attempts=sorted(base.glob('attempt-*')) if base.exists() else []
 if any((a/'detail/audit-result.json').exists() and json.loads((a/'detail/audit-result.json').read_text()).get('status')=='passed' for a in attempts):
  print(target,'already audited; skip',flush=True);continue
 indices=[int(a.name.removeprefix('attempt-')) for a in attempts if re.fullmatch(r'attempt-\d+',a.name)]
 attempt=f'attempt-{max(indices,default=0)+1:03d}';out=base/attempt;out.mkdir(parents=True,exist_ok=False)
 status={'target':target,'attempt':attempt,'status':'running','started_unix':time.time()};(out/'queue-status.json').write_text(json.dumps(status,indent=2)+'\n')
 env=os.environ.copy();env.update(CASE_ID=case,CASE_BATCH='second',ATTEMPT=attempt,KERNEL_NAME=x['kernel'])
 with (out/'launcher-console.log').open('w') as log:
  capture=subprocess.run(['bash',str(root/'run-hidev-classic-detail.sh')],env=env,stdout=log,stderr=subprocess.STDOUT)
 status['capture_exit']=capture.returncode
 if capture.returncode==0:
  with (out/'inspection-console.log').open('w') as log:
   inspect=subprocess.run([sys.executable,'-B',str(root/'inspect-classic-capture.py'),target,attempt],env=env,stdout=log,stderr=subprocess.STDOUT)
  status['inspection_exit']=inspect.returncode
  if inspect.returncode==0:
   with (out/'audit-console.log').open('w') as log:
    audit=subprocess.run([sys.executable,'-B',str(root/'audit-sinkhornbwd-detail.py'),case,attempt],env=env,stdout=log,stderr=subprocess.STDOUT)
   status['audit_exit']=audit.returncode;status['status']='passed' if audit.returncode==0 else 'address_audit_failed'
  else:status['status']='identity_review_required'
 else:status['status']='capture_failed'
 status['finished_unix']=time.time();tmp=out/'queue-status.tmp';tmp.write_text(json.dumps(status,indent=2)+'\n');tmp.replace(out/'queue-status.json')
 print(target,status['status'],flush=True)
 if status['status']!='passed':sys.exit(1)
print('ALL_SINKHORNBWD_SELECTED_AUDITED',flush=True)
