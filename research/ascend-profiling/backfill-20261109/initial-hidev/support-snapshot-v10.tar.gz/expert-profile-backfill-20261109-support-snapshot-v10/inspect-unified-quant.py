"""Verify unified quant identity without asserting requested-byte coverage."""
import csv,hashlib,json,os,re,sys
from pathlib import Path
root=Path('/workspace/expert-profile-backfill-20261109-hidev');repo=Path('/workspace/tilekernels-env-20261101/src/TileKernels-private')
case,attempt=sys.argv[1:];assert re.fullmatch(r'quant_per_token_cast-(0[1-9]|1[0-9]|20)',case)
p=root/'unified-quant-runs'/case/'hidev-npu0'/attempt/'detail';a=json.loads((p/'application.json').read_text())
old_path=repo/'research/ascend-profiling/runs/hidev-20261106-unified-quant/cases'/case/'default.json';old=json.loads(old_path.read_text())
assert a['status']==old['status']=='passed' and a['matched']==old['matched']==1
for key in ('runtime_kernel','inputs','source_sha256'):assert a[key]==old[key],key
sha=lambda x:hashlib.sha256(x.read_bytes()).hexdigest();src=p/'generated-kernel.cpp';assert sha(src)==a['source_sha256']
mon=json.loads((p/'monitor-summary.json').read_text());assert mon['status']=='passed' and mon['max_seconds_between_successful_queries']<=3
op,=list((p/'capture').rglob('OpBasicInfo.csv'))
with op.open(encoding='utf-8-sig',newline='') as f:basic,=list(csv.DictReader(f))
assert basic['Op Name']==a['runtime_kernel'] and basic['Device Id']=='0' and basic['Op Type']=='vector'
binary=op.parent/'dump/aicore_binary.o';bsha=sha(binary);assert any(x.startswith(bsha+' ') and x.rstrip().endswith('/kernel.aibin') for x in (p/'cache-sha256.txt').read_text().splitlines())
log=(p/'profile.log').read_text(errors='replace');stores=[x for x in log.splitlines() if 'DBI record core:' in x and 'dst:(type:GM;' in x and 'src:(type:UB;' in x]
addresses=json.loads((p/'tensor-addresses.json').read_text());assert addresses and all(x is None or x['device'].startswith('npu') for x in addresses)
result={'target':'unified-quant/'+case,'status':'capture_identified_address_audit_pending','correctness':'passed',
 'historical_input_and_source_match':True,'capture_binary_sha256':bsha,'op_basic':basic,
 'tensor_addresses':addresses,'raw_ub_to_gm_events':len(stores),
 'parser_metrics':re.findall(r'processedRecord: (\d+), droppedRecord: (\d+).*?memoryCorruption (\d+)',log)}
(p/'capture-inspection.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
