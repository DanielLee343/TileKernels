#!/usr/bin/env bash
set -Eeuo pipefail
root=/workspace/expert-profile-backfill-20261109-hidev
q="$root/extra-engram-gate-fwd-mask-smoke-hidev-npu0";mkdir -p "$q"
trap 'rc=$?;printf "exit=%s at=%s\n" "$rc" "$(date -u +%FT%TZ)" > "$q/exit.txt"' EXIT
previous="$root/extra-engram-gate-bwd-unmasked-queue-hidev-npu0";pid=$(cat "$previous/pid")
while ps -p "$pid" -o args= | grep -Fq "$root/orchestrate-engram-gate-bwd-unmasked-queue.sh";do sleep 10;done
export TARGET_ID=unified-extra5/engram_gate_fwd-03 ATTEMPT=attempt-001
bash "$root/run-hidev-extra-engram-gate-fwd-mask.sh"
python3 -B "$root/inspect-extra-engram-gate-fwd-mask.py" "$TARGET_ID" "$ATTEMPT"
echo ENGRAM_GATE_FWD_MASK_SMOKE_IDENTITY_CHECKED_ADDRESS_AUDIT_PENDING
