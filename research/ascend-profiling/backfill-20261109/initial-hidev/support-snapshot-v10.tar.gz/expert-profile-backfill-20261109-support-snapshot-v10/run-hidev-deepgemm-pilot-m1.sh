#!/usr/bin/env bash
set -Eeo pipefail
root=/workspace/expert-profile-backfill-20261109-hidev;dg=/workspace/deepgemm-ascend-20261107
case_id="${CASE_ID:?}";attempt="${ATTEMPT:?}"
[[ "$attempt" =~ ^attempt-[0-9]+$ ]] || exit 2
case "$case_id" in
 bf16-m1-n32768-k512) family=pilot-bf16;target=bf16_gemm_impl;range=deepgemm_target;;
 fp8fp8-m1-n32768-k512|fp4fp4-m1-n32768-k512) family=pilot-quant;target=fp8_gemm_impl;range=deepgemm_quant_target;;
 fp8fp4-m1-n32768-k512) family=pilot-quant;target=fp8_dequant_gemm_impl;range=deepgemm_quant_target;;
 *) exit 2;;
esac
unset LD_LIBRARY_PATH PYTHONPATH LD_PRELOAD MEMORYCHART_ROOT MEMORYCHART_LOG MSOPT_LOG_LEVEL
source "$dg/activate.sh";set -u
export ASCEND_HOME_PATH="$dg/cann-compat-quant" BISHENG_HOME="$dg/cann-compat-quant"
export ASCEND_RT_VISIBLE_DEVICES=0 PYTHONDONTWRITEBYTECODE=1 GUARD_DEADLINE_SECONDS=900
export DG_JIT_CACHE_DIR="$root/deepgemm-cache/$case_id"
exec 9> /workspace/.puma-hidev-npu0.lock;flock -n 9
test "$(git -C "$dg/source" rev-parse HEAD)" = 3a35326271b069b8b5bf1a754435acd6cc91575b
test -z "$(git -C "$dg/source" status --porcelain --untracked-files=no)"
out="$root/deepgemm-pilot-runs/$case_id/hidev-npu0/$attempt";test ! -e "$out";mkdir -p "$out/provenance"
timeout 10 npu-smi info -t board -i 0 > "$out/provenance/board.txt";grep -qi '0000:8b:00.0' "$out/provenance/board.txt"
timeout 10 npu-smi info -t health -i 0 > "$out/provenance/health-before.txt"
msprof op --version > "$out/provenance/msprof-version.txt";grep -q 884ac969494a186a9c63ac45c4c39ad7289b3215 "$out/provenance/msprof-version.txt"
git -C "$dg/source" rev-parse HEAD > "$out/provenance/commit.txt";printf '%s\n' "$ASCEND_HOME_PATH" > "$out/provenance/cann-path.txt"
harness="$root/deepgemm-pilot-m1-harness/$family/collect.py";extra=();test "$family" = pilot-bf16 || extra=("$dg/source")
cp "$harness" "$root/deepgemm-pilot-m1-harness/$family/cases.json" "$out/provenance/"
cd "$root";export GUARD_REQUIRE_PROFILE=0
python -B guard-v6.py 0 "$out/prepare-monitor" python -B "$harness" __worker "$case_id" prepare "$out/prepare.json" "${extra[@]}"
export GUARD_REQUIRE_PROFILE=1 MSOPT_LOG_LEVEL=0
python -B guard-v6.py 0 "$out/detail" msprof op "--output=$out/detail/capture" --aic-metrics=MemoryDetail,Default --replay-mode=kernel \
 --mstx=true "--mstx-include=$range" "--kernel-name=*$target*" --launch-count=1 --warm-up=5 \
 python -B "$harness" __worker "$case_id" profile "$out/profile.json" "${extra[@]}"
timeout 10 npu-smi info -t health -i 0 > "$out/provenance/health-after.txt"
test -f "$out/profile-addresses.json"
echo 'capture complete; identity and address audit pending'
