"""Resolve one exact manifest entry and validate shell-facing fields."""
import base64,json,re,sys
from pathlib import Path

manifest,target=sys.argv[1:]
entries=json.loads(Path(manifest).read_text())['cases']
case,=(x for x in entries if x['target_id']==target)
for k in ('id','group','adapter','range','historical_op_name'):
    assert re.fullmatch(r'[A-Za-z0-9_.-]+',case[k]),(k,case[k])
assert re.fullmatch(r'unified-extra\d*/[A-Za-z0-9_.-]+',target)
assert case['adapter'].endswith('.py') and '/' not in case['adapter']
meta=case['historical_metadata'];assert meta.startswith('TileKernels-private/research/ascend-profiling/') and '..' not in Path(meta).parts
fields=[case['group'],case['adapter'],case['range'],case['historical_op_name'],meta.removeprefix('TileKernels-private/'),
        base64.urlsafe_b64encode(json.dumps(case['params'],separators=(',',':')).encode()).decode()]
assert all('\n' not in s for s in fields)
print('\n'.join(fields))
