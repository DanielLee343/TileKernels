#!/usr/bin/env bash
set -Eeuo pipefail
root=/workspace/expert-profile-backfill-20261109-hidev
q="$root/deepgemm-dequant-mgroup-queue-hidev-npu0";mkdir -p "$q"
trap 'rc=$?;printf "exit=%s at=%s\n" "$rc" "$(date -u +%FT%TZ)" > "$q/exit.txt"' EXIT
previous="$root/extra-norm-backward-noweight-queue-hidev-npu0";pid=$(cat "$previous/pid")
while ps -p "$pid" -o args= | grep -Fq "$root/orchestrate-norm-backward-noweight-queue.sh";do sleep 10;done
archive_pid=$(cat "$root/selected-snapshot-archives.pid")
while ps -p "$archive_pid" -o stat= | awk '$1 !~ /^Z/ {print $1}' | grep -q .;do sleep 10;done
python3 -B "$root/hidev-dg-dequant-mgroup-queue.py"
