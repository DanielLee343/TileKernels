#!/usr/bin/env bash
set -Eeuo pipefail
root=/workspace/expert-profile-backfill-20261109-hidev
q="$root/extra-norm-accum-app-queue-hidev-npu0";mkdir -p "$q"
trap 'rc=$?;printf "exit=%s at=%s\n" "$rc" "$(date -u +%FT%TZ)" > "$q/exit.txt"' EXIT
grep -q 'PASS rejects missing outputs, duplicate record, wrong CSV and unauthorized input/output alias' "$root/norm-accum-app08-test.log"
p="$root/extra-proxy-runs/unified-extra3/quant_norm_backward-08/hidev-npu0/attempt-001/detail"
python3 - "$p" <<'PY'
import json,sys
from pathlib import Path
p=Path(sys.argv[1]);a=p/'candidate-audit-result.json';b=p/'audit-result.json';d=json.loads(a.read_text())
assert d['status']=='passed' and d['target']=='unified-extra3/quant_norm_backward-08' and d['replay_mode']=='application' and not b.exists();b.write_bytes(a.read_bytes())
PY
previous="$root/extra-engram-gate-bwd-mask-queue-hidev-npu0";pid=$(cat "$previous/pid")
while ps -p "$pid" -o args= | grep -Fq "$root/orchestrate-engram-gate-bwd-mask-queue.sh";do sleep 10;done
python3 -B "$root/hidev-extra-norm-accum-app-queue.py"
