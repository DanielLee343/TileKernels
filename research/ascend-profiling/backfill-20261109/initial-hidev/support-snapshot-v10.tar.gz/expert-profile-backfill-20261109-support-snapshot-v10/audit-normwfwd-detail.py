"""Audit mHC norm-weight merge using its 24-row, 256-column store tiles."""
import csv,hashlib,json,os,re,subprocess,sys
from collections import Counter
from decimal import Decimal
from pathlib import Path
from importlib.machinery import SourceFileLoader
root=Path(os.environ['BACKFILL_ROOT']);R=SourceFileLoader('r',str(root/'audit-reduce-family.py')).load_module().REGEX
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):
 with p.open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
case,attempt=sys.argv[1:];assert re.fullmatch(r'normw-fwd-(0[1-9]|1[0-9]|20)',case)
p=root/'classic-runs/third'/case/'hidev-npu0'/attempt/'detail';a=json.loads((p/'metadata/application.json').read_text());ident=json.loads((p/'capture-inspection.json').read_text())
assert ident['status']=='capture_identified_address_audit_pending' and ident['correctness']=='passed' and ident['historical_true_inputs_and_source_match']
assert a['runtime_kernel']=='mhc_fn_normw_merge_fwd_asc_kernel' and a['case']['family']=='mhc_fn_normw_merge_fwd'
shape=a['outputs'][0]['shape'];assert len(shape)==2 and shape[0]==24 and a['outputs'][0]['dtype']=='float32';h=shape[1];assert h%256==0 and a['outputs'][0]['bytes']==24*h*4
code=(p/'metadata/default-kernel.cpp').read_text();assert code.count('asc_copy_ub2gm_align(')==1
line=next(x for x in code.splitlines() if 'asc_copy_ub2gm_align(' in x);assert 'out_fn[' in line and 'block_idx' in line
op,=list((p/'capture').rglob('OpBasicInfo.csv'));basic,=read(op)
assert basic['Op Type']=='vector' and basic['Block Dim']=='56' and basic['Device Id']=='0' and basic['Op Name']==a['runtime_kernel']
binary=op.parent/'dump/aicore_binary.o';assert sha(binary)==ident['capture_binary_sha256'];isa=subprocess.check_output([os.environ['BACKFILL_OBJDUMP'],'-d',str(binary)],text=True);(p/'device-kernel.isa').write_text(isa)
raw=(p/'profile.log').read_text(errors='replace');stores=[x for x in raw.splitlines() if 'DBI record core:' in x and 'dst:(type:GM;' in x and 'src:(type:UB;' in x];rec=R.findall(raw)
assert len(stores)==len(rec)==h//256,(len(stores),len(rec),h)
base=int(a['device_output_addresses'][0],16);hits=Counter();blocks=Counter();pcs=set()
for c,pc,addr,stride,l1s,l2s,srcaddr,srcstride,srcl1s,srcl2s,burst,length,dtype,l1,l2,left,right in rec:
 c=int(c);offset=int(addr,16)-base;chunk,rem=divmod(offset,1024);assert rem==0 and 0<=chunk<h//256
 block=chunk%56;assert (c//3,c%3)==divmod(block,2)
 expected=(1,24576) if h==256 else (24,1024)
 assert (int(burst),int(length))==expected and (int(l1),int(l2),int(left),int(right))==(1,1,0,0)
 if h>256:assert int(stride)==h*4
 for row in range(24):hits[(row,chunk)]+=1
 blocks[block]+=24576;pcs.add(int(pc,16))
assert hits==Counter((row,chunk) for row in range(24) for chunk in range(h//256))
for pc in pcs:assert any(re.match(r'^\s*'+format(pc,'x')+r':',line) and 'MOV_UB_TO_OUT' in line for line in isa.splitlines())
mem=read(op.with_name('Memory.csv'));assert len(mem)==56
for j,row in enumerate(mem):
 assert int(row['block_id'])==j and row['sub_block_id']=='vector0';value=row['UB_to_GM_datas(KB)'];expected=blocks[2*j]+blocks[2*j+1] if j<28 else None
 if j<28 and value not in ('NA',''):assert abs(Decimal(value)*1024-expected)<=Decimal('0.000512')
 elif j<28:assert expected==0
 else:assert value in ('NA','')
result={'target':'third/'+case,'status':'passed','device':'hidev NPU 0','correctness':'passed','historical_input_and_source_match':True,
 'runtime_kernel':basic['Op Name'],'dbi_requested_bytes':sum(blocks.values()),'output_logical_bytes':24*h*4,
 'per_vector_block_requested_bytes':{i:blocks[i] for i in range(56)},'capture_binary_sha256':sha(binary),'dbi_pc':[hex(x) for x in sorted(pcs)],
 'csv_pair_totals_match':True,'scope':'one MemoryDetail window; requested UB to GM bytes, not physical DRAM transactions'}
(p/'audit-result.json').write_text(json.dumps(result,indent=2)+'\n');print('PASS',case,sum(blocks.values()))
