"""Sequentially capture pending mHC cases and fail closed on first failed audit."""
import fcntl,json,os,re,subprocess,sys,time
from pathlib import Path
root=Path(os.environ.get('BACKFILL_ROOT',str(Path.home()/'expert-profile-backfill-20261109')))
host=os.environ.get('BACKFILL_HOST','tbe');device=os.environ.get('BACKFILL_DEVICE','3')
assert (host,device) in (('tbe','3'),('hidev','0'))
q=root/('mhc-queue-'+host+'-npu'+device);q.mkdir(exist_ok=True)
lock=(q/'queue.lock').open('w');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
cases=json.loads((root/'mhc-pending.json').read_text());assert len(cases)==50
for item in cases:
 batch=item['batch'];case=item['case'];base=root/'mhc-runs'/batch/case/(host+'-npu'+device)
 attempts=sorted(base.glob('attempt-*')) if base.exists() else []
 if any((a/'detail/audit-result.json').exists() and json.loads((a/'detail/audit-result.json').read_text()).get('status')=='passed' for a in attempts):
  print(item['target'],'already audited; skip',flush=True);continue
 indexes=[int(a.name.removeprefix('attempt-')) for a in attempts if re.fullmatch(r'attempt-\d+',a.name)]
 attempt=f'attempt-{max(indexes,default=0)+1:03d}';out=base/attempt;out.mkdir(parents=True,exist_ok=False)
 status={'target':item['target'],'device':host+'-npu'+device,'attempt':attempt,'status':'running','started_unix':time.time()}
 (out/'queue-status.json').write_text(json.dumps(status,indent=2)+'\n')
 env=os.environ.copy();env.update(BATCH=batch,CASE_ID=case,ATTEMPT=attempt)
 runner='run-hidev-mhc-detail.sh' if host=='hidev' else 'run-mhc-detail.sh'
 with (out/'launcher-console.log').open('w') as log:
  capture=subprocess.run(['bash',str(root/runner)],env=env,stdout=log,stderr=subprocess.STDOUT)
 status['capture_exit']=capture.returncode
 if capture.returncode==0:
  with (out/'audit-console.log').open('w') as log:
   audit=subprocess.run([sys.executable,'-B',str(root/'audit-mhc-detail.py'),batch,case,device,attempt],env=env,stdout=log,stderr=subprocess.STDOUT)
  status['audit_exit']=audit.returncode;status['status']='passed' if audit.returncode==0 else 'audit_failed'
 else:status['status']='capture_failed'
 status['finished_unix']=time.time();tmp=out/'queue-status.tmp';tmp.write_text(json.dumps(status,indent=2)+'\n');tmp.replace(out/'queue-status.json')
 print(item['target'],status['status'],flush=True)
 if status['status']!='passed':sys.exit(1)
print('ALL_MHC_CASES_AUDITED',flush=True)
