"""Collect pinned DeepGEMM transform cases with per-attempt audit gates."""
import fcntl,json,os,re,subprocess,sys,time
from pathlib import Path
root=Path('/workspace/expert-profile-backfill-20261109-hidev');q=root/'deepgemm-paged-mqa-queue-hidev-npu0';q.mkdir(exist_ok=True)
lock=(q/'queue.lock').open('w');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
items=[x for x in json.loads((root/'deepgemm-paged-mqa-lengths-harness/campaign-13/cases.json').read_text())['cases'] if x['family']=='paged_mqa'];assert len(items)==8
for x in items:
 case=x['id'];assert x['target']=='paged_mqa_logits_impl';base=root/'deepgemm-runs'/case/'hidev-npu0';attempts=sorted(base.glob('attempt-*')) if base.exists() else []
 if any((a/'address-audit.json').exists() and json.loads((a/'address-audit.json').read_text()).get('status')=='passed' for a in attempts):
  print(case,'already audited; skip',flush=True);continue
 indices=[int(a.name.removeprefix('attempt-')) for a in attempts if re.fullmatch(r'attempt-\d+',a.name)]
 attempt=f'attempt-{max(indices,default=0)+1:03d}';base.mkdir(parents=True,exist_ok=True);out=base/attempt
 status={'target':'campaign-13/'+case,'attempt':attempt,'status':'running','started_unix':time.time()}
 env=os.environ.copy();env.update(CASE_ID=case,ATTEMPT=attempt)
 with (q/(case+'-'+attempt+'-launcher.log')).open('w') as f:
  capture=subprocess.run(['bash',str(root/'run-hidev-deepgemm-paged-mqa-lengths.sh')],env=env,stdout=f,stderr=subprocess.STDOUT)
 status['capture_exit']=capture.returncode
 if capture.returncode==0:
  with (q/(case+'-'+attempt+'-inspection.log')).open('w') as f:
   inspect=subprocess.run([sys.executable,'-B',str(root/'inspect-deepgemm-paged-mqa-lengths.py'),case,attempt],env=env,stdout=f,stderr=subprocess.STDOUT)
  status['inspection_exit']=inspect.returncode
  if inspect.returncode==0:
   with (q/(case+'-'+attempt+'-audit.log')).open('w') as f:
    audit=subprocess.run([sys.executable,'-B',str(root/'audit-dg-paged-mqa-batch.py'),case,attempt],env=env,stdout=f,stderr=subprocess.STDOUT)
   status['audit_exit']=audit.returncode;status['status']='passed' if audit.returncode==0 else 'address_audit_failed'
  else:status['status']='identity_review_required'
 else:status['status']='capture_failed'
 status['finished_unix']=time.time();out.mkdir(parents=True,exist_ok=True)
 (out/'queue-status.json').write_text(json.dumps(status,indent=2)+'\n')
 print(case,status['status'],flush=True)
 if status['status']!='passed':sys.exit(1)
print('ALL_DG_PAGED_MQA_SELECTED_AUDITED',flush=True)
