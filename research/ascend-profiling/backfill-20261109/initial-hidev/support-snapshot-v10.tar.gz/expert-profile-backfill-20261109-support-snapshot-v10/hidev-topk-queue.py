"""Sequentially capture and audit TopK cases on hidev."""
import fcntl,json,os,re,subprocess,sys,time
from pathlib import Path
root=Path('/workspace/expert-profile-backfill-20261109-hidev');q=root/'topk-queue-hidev-npu0';q.mkdir(exist_ok=True)
lock=(q/'queue.lock').open('w');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
cases=json.loads((root/'topk-pending.json').read_text());assert len(cases)==20
for item in cases:
 case=item['case'];base=root/'topk-runs'/case/'hidev-npu0'
 attempts=sorted(base.glob('attempt-*')) if base.exists() else []
 if any((a/'detail/audit-result.json').exists() and json.loads((a/'detail/audit-result.json').read_text()).get('status')=='passed' for a in attempts):
  print(item['target'],'already audited; skip',flush=True);continue
 if any((a/'queue-status.json').exists() and json.loads((a/'queue-status.json').read_text()).get('capture_exit')==0 for a in attempts):
  print(item['target'],'capture retained; audit pending; skip recapture',flush=True);continue
 indexes=[int(a.name.removeprefix('attempt-')) for a in attempts if re.fullmatch(r'attempt-\d+',a.name)]
 attempt=f'attempt-{max(indexes,default=0)+1:03d}';out=base/attempt;out.mkdir(parents=True,exist_ok=False)
 status={'target':item['target'],'device':'hidev-npu0','attempt':attempt,'status':'running','started_unix':time.time(),
         'device_health':'Alarm 8C4BA00C observed in preflight; inspect per-case health records'}
 (out/'queue-status.json').write_text(json.dumps(status,indent=2)+'\n')
 env=os.environ.copy();env.update(CASE_ID=case,ATTEMPT=attempt)
 with (out/'launcher-console.log').open('w') as log:
  capture=subprocess.run(['bash',str(root/'run-hidev-topk-detail.sh')],env=env,stdout=log,stderr=subprocess.STDOUT)
 status['capture_exit']=capture.returncode
 if capture.returncode==0:
  with (out/'audit-console.log').open('w') as log:
   audit=subprocess.run([sys.executable,'-B',str(root/'audit-topk-detail.py'),case,'0',attempt],env=env,stdout=log,stderr=subprocess.STDOUT)
  status['audit_exit']=audit.returncode;status['status']='passed' if audit.returncode==0 else 'audit_failed'
 else:status['status']='capture_failed'
 status['finished_unix']=time.time();tmp=out/'queue-status.tmp';tmp.write_text(json.dumps(status,indent=2)+'\n');tmp.replace(out/'queue-status.json')
 print(item['target'],status['status'],flush=True)
 if status['status']=='capture_failed':sys.exit(1)
print('ALL_TOPK_CASES_CAPTURED_OR_AUDITED',flush=True)
