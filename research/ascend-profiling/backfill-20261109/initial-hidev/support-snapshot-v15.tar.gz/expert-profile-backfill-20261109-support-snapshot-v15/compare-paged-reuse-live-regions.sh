#!/usr/bin/env bash
set -Eeuo pipefail
echo __COMPARE_PAGED_REUSE_REGIONS_BEGIN__
python3 - <<'PY'
from pathlib import Path
import struct,hashlib
r=Path('/workspace/expert-profile-backfill-20261109-hidev/deepgemm-runs');first=r/'paged-sparse-first-0-q4-k256-h8-b8-p64/hidev-npu0/attempt-002';reuse=r/'paged-sparse-fp8-q4-k256-h8-b8/hidev-npu0/attempt-001';b=(first/'paged-sparse-metadata-before-1570403.bin').read_bytes();a=(first/'paged-sparse-metadata-after-1570403.bin').read_bytes();u=(reuse/'paged-sparse-metadata-before.bin').read_bytes();assert len(b)==len(a)==len(u)==4076032
ko=0x4000;po=0x11e00;co=0x15a00;nr=56;ranges=[struct.unpack_from('<II',b,ko+8*i) for i in range(nr)];idx={j for lo,hi in ranges for j in range(lo,hi)}
parts={'mapping':(0,ko),'ranges':(ko,ko+nr*8),'physical':(po,co),'compact_all':(co,len(b))}
for name,(l,h) in parts.items():print(name,'before_vs_reuse',b[l:h]==u[l:h],'first_after_vs_reuse',a[l:h]==u[l:h],'diff_first_after',sum(x!=y for x,y in zip(a[l:h],u[l:h])))
print('active_descriptors_equal',all(b[ko+nr*8+j*40:ko+nr*8+(j+1)*40]==u[ko+nr*8+j*40:ko+nr*8+(j+1)*40] for j in idx),'count',len(idx))
pages=[]
for j in sorted(idx):
 w=struct.unpack_from('<10I',b,ko+nr*8+j*40);page=w[0];n=(((((w[1]>>4)&127)*8)+63)//64)*64;l=co+page*64*132;h=l+n*132;pages.append((l,h))
print('used_compact_pages',len(pages),'first_after_equals_reuse',all(a[l:h]==u[l:h] for l,h in pages),'different_pages',sum(a[l:h]!=u[l:h] for l,h in pages))
for l,h in pages:
 if a[l:h]!=u[l:h]:print('first_diff',hex(l),hex(h),sum(x!=y for x,y in zip(a[l:h],u[l:h])));break
PY
echo __COMPARE_PAGED_REUSE_REGIONS_END__
