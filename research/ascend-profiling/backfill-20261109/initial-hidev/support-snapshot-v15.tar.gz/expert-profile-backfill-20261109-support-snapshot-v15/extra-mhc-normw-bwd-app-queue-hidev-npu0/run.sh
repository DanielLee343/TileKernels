#!/usr/bin/env bash
set -Eeuo pipefail
r=/workspace/expert-profile-backfill-20261109-hidev;q="$r/extra-mhc-normw-bwd-app-queue-hidev-npu0"
trap 'rc=$?;printf "exit=%s at=%s\n" "$rc" "$(date -u +%FT%TZ)" > "$q/exit.txt"' EXIT
prev="$r/extra-mhc-normw-bwd-app-smoke-hidev-npu0";pid=$(cat "$prev/pid")
while ps -p "$pid" -o args= | grep -Fq "$prev/run.sh";do sleep 10;done
grep -q '^exit=0 ' "$prev/exit.txt";attempt=$(cat "$prev/attempt.txt")
python3 -B "$r/inspect-mhc-normw-bwd-app.py" unified-extra5/mhc_fn_normw_merge_bwd-01 "$attempt"
python3 -B "$r/audit-mhc-normw-bwd-app-candidate.py" mhc_fn_normw_merge_bwd-01 "$attempt"
export AUDIT_ATTEMPT="$attempt"
bash "$r/test-mhc-normw-bwd-app-audit.sh" > "$r/mhc-normw-bwd-app-audit-test.log" 2>&1
cat "$r/mhc-normw-bwd-app-audit-test.log"
grep -q '^PASS rejects missing outputs, duplicate record, wrong CSV and unauthorized input/output alias$' "$r/mhc-normw-bwd-app-audit-test.log"
python3 - "$r" "$attempt" <<'PY'
import json,sys
from pathlib import Path
r=Path(sys.argv[1]);p=r/'extra-proxy-runs/unified-extra5/mhc_fn_normw_merge_bwd-01/hidev-npu0'/sys.argv[2]/'detail';a=p/'candidate-audit-result.json';b=p/'audit-result.json';d=json.loads(a.read_text());assert d['status']=='passed' and d['target']=='unified-extra5/mhc_fn_normw_merge_bwd-01' and not b.exists();b.write_bytes(a.read_bytes());print('PROMOTED',d['target'],d['dbi_requested_bytes'])
PY
python3 -B "$r/hidev-mhc-normw-bwd-app-queue.py"
