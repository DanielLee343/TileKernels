#!/usr/bin/env bash
set -Eeuo pipefail
r=/workspace/expert-profile-backfill-20261109-hidev;q="$r/extra-mhc-big-fuse-app-inspection-hidev-npu0"
trap 'rc=$?;printf "exit=%s at=%s\n" "$rc" "$(date -u +%FT%TZ)" > "$q/exit.txt"' EXIT
prev="$r/extra-mhc-big-fuse-app-smoke-hidev-npu0";pid=$(cat "$prev/pid")
while ps -p "$pid" -o args= | grep -Fq "$prev/run.sh";do sleep 10;done
grep -q '^exit=0 ' "$prev/exit.txt";attempt=$(cat "$prev/attempt.txt")
python3 -B "$r/inspect-mhc-big-fuse-app.py" unified-extra3/mhc_pre_big_fuse_fwd-01 "$attempt"
echo MHC_BIG_FUSE_IDENTITY_CHECKED_OUTPUT_ADDRESS_AUDIT_PENDING
