#!/usr/bin/env bash
set -Eeuo pipefail
echo __COMPARE_PAGED_REUSE_VALID_DATA_BEGIN__
python3 - <<'PY'
from pathlib import Path
import struct
r=Path('/workspace/expert-profile-backfill-20261109-hidev/deepgemm-runs');first=r/'paged-sparse-first-0-q4-k256-h8-b8-p64/hidev-npu0/attempt-002';reuse=r/'paged-sparse-fp8-q4-k256-h8-b8/hidev-npu0/attempt-001';b=(first/'paged-sparse-metadata-before-1570403.bin').read_bytes();a=(first/'paged-sparse-metadata-after-1570403.bin').read_bytes();u=(reuse/'paged-sparse-metadata-before.bin').read_bytes();ko=0x4000;co=0x15a00;nr=56;ranges=[struct.unpack_from('<II',b,ko+8*i) for i in range(nr)];idx={j for lo,hi in ranges for j in range(lo,hi)};regions=[]
for j in sorted(idx):
 w=struct.unpack_from('<10I',b,ko+nr*8+j*40);page=w[0];valid=((w[1]>>4)&127)*8;n=((valid+63)//64)*64;start=co+page*64*132
 for frag in range(4):regions.append((start+frag*n*32,start+frag*n*32+valid*32,'data'))
 regions.append((start+n*128,start+n*128+valid*4,'scale'))
for typ in ('data','scale'):
 group=[(l,h) for l,h,t in regions if t==typ];print(typ,'ranges',len(group),'all_equal',all(a[l:h]==u[l:h] for l,h in group),'mismatched',sum(a[l:h]!=u[l:h] for l,h in group),'diff_bytes',sum(sum(x!=y for x,y in zip(a[l:h],u[l:h])) for l,h in group))
PY
echo __COMPARE_PAGED_REUSE_VALID_DATA_END__
