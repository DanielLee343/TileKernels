#!/usr/bin/env bash
set -Eeuo pipefail
r=/workspace/expert-profile-backfill-20261109-hidev;q="$r/extra-mhc-pre-apply-bwd-app-inspection-hidev-npu0"
trap 'rc=$?;printf "exit=%s at=%s\n" "$rc" "$(date -u +%FT%TZ)" > "$q/exit.txt"' EXIT
prev="$r/extra-mhc-pre-apply-bwd-app-smoke-hidev-npu0";pid=$(cat "$prev/pid")
while ps -p "$pid" -o args= | grep -Fq "$prev/run.sh";do sleep 10;done
grep -q '^exit=0 ' "$prev/exit.txt";attempt=$(cat "$prev/attempt.txt")
python3 -B "$r/inspect-mhc-pre-apply-bwd-app.py" unified-extra4/mhc_pre_apply_mix_bwd-01 "$attempt"
echo MHC_PRE_APPLY_BWD_IDENTITY_CHECKED_OUTPUT_ADDRESS_AUDIT_PENDING
