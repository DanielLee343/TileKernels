#!/usr/bin/env bash
set -Eeuo pipefail
r=/workspace/expert-profile-backfill-20261109-hidev;q="$r/extra-mhc-presplit-bwd-app-inspection-hidev-npu0"
trap 'rc=$?;printf "exit=%s at=%s\n" "$rc" "$(date -u +%FT%TZ)" > "$q/exit.txt"' EXIT
prev="$r/extra-mhc-presplit-bwd-app-smoke-hidev-npu0";pid=$(cat "$prev/pid")
while ps -p "$pid" -o args= | grep -Fq "$prev/run.sh";do sleep 10;done
grep -q '^exit=0 ' "$prev/exit.txt";attempt=$(cat "$prev/attempt.txt")
python3 -B "$r/inspect-mhc-presplit-bwd-app.py" unified-extra5/mhc_pre_split_mixes_bwd-01 "$attempt"
echo MHC_PRESPLIT_BWD_IDENTITY_CHECKED_OUTPUT_ADDRESS_AUDIT_PENDING
