#!/usr/bin/env bash
set -Eeuo pipefail
r=/workspace/expert-profile-backfill-20261109-hidev;q="$r/deepgemm-paged-reuse-frozen-inspection-hidev-npu0"
trap 'rc=$?;printf "exit=%s at=%s\n" "$rc" "$(date -u +%FT%TZ)" > "$q/exit.txt"' EXIT
prev="$r/deepgemm-paged-reuse-frozen-app-smoke-hidev-npu0";pid=$(cat "$prev/pid")
while ps -p "$pid" -o args= | grep -Fq "$prev/run.sh";do sleep 10;done
grep -q '^exit=0 ' "$prev/exit.txt";attempt=$(cat "$prev/attempt.txt")
unset LD_LIBRARY_PATH PYTHONPATH LD_PRELOAD
source /workspace/deepgemm-ascend-20261107/activate.sh
export ASCEND_HOME_PATH=/workspace/deepgemm-ascend-20261107/cann-compat-quant BISHENG_HOME=/workspace/deepgemm-ascend-20261107/cann-compat-quant ASCEND_RT_VISIBLE_DEVICES=0 PYTHONDONTWRITEBYTECODE=1
python3 -B "$r/inspect-paged-reuse-frozen-app.py" paged-sparse-fp8-q4-k256-h8-b8 "$attempt"
echo FROZEN_REUSE_INSPECTED_BYTE_AUDIT_PENDING
