echo __MOE_ARCHIVE_SIZE_BEGIN__
stat -c '%s bytes' /workspace/expert-profile-backfill-20261109-hidev/moe-backward-snapshot-archive-bundle.tar.gz
echo __MOE_ARCHIVE_SIZE_END__
