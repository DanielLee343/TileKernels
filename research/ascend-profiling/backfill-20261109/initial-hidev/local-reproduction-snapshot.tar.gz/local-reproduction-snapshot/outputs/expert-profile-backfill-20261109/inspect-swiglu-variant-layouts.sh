#!/usr/bin/env bash
set -u
echo __INSPECT_SWIGLU_LAYOUTS_BEGIN__
root=/workspace/expert-profile-backfill-20261109-hidev
python3 - "$root" <<'PY'
import json,sys
from pathlib import Path
root=Path(sys.argv[1]); m=json.loads((root/'extra-proxy-harness/cases.json').read_text())['cases']
for n in ('01','02','07','08'):
 case='quant_swiglu_forward-'+n;p=root/'extra-proxy-runs/unified-extra3'/case/'hidev-npu0/attempt-001/detail'
 print('\n###',case)
 print('params',next(x['params'] for x in m if x['id']==case))
 for i,a in enumerate(json.loads((p/'tensor-addresses.json').read_text())):print('arg',i,a)
 print('\n'.join(x.strip() for x in (p/'generated-kernel.cpp').read_text().splitlines() if 'asc_copy_ub2gm_align(' in x))
PY
echo __INSPECT_SWIGLU_LAYOUTS_END__
