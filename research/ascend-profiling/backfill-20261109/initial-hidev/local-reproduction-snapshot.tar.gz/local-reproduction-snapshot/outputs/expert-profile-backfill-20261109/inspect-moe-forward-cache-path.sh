echo __MOE_FORWARD_CACHE_PATH_BEGIN__
p=/workspace/expert-profile-backfill-20261109-hidev/extra-proxy-runs/unified-extra3/moe_topk_gate_forward-01/hidev-npu0/attempt-001/detail
grep 'ba9bbc44d6a66a1557722fa5d3af1924ce2c36e0d0a2fe37abe884962cc51162' "$p/cache-sha256.txt" || true
echo __MOE_FORWARD_CACHE_PATH_END__
