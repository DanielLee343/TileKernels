"""Copy MQA range inputs for auditing; keep the device kernel unchanged."""
import hashlib,json,shutil
from pathlib import Path
p=Path(__file__).resolve().parent;src=p/'deepgemm-mqa-harness';dst=p/'deepgemm-mqa-ranges-harness'
assert not dst.exists();shutil.copytree(src,dst)
f=dst/'campaign-13/collect.py';s=f.read_text();needle="        calls[0]={'args':describe(args),'kwargs':describe(recorded_kwargs)}\n"
insert="""        if stage=='profile' and case['family']=='mqa':
            assert len(args)>=5 and args[3].dtype==torch.int32 and args[4].dtype==torch.int32
            for idx,label in ((3,'start'),(4,'end')):
                raw=args[idx].detach().cpu().contiguous().view(torch.uint8).numpy().tobytes()
                Path(output).with_name('mqa-range-'+label+'.bin').write_bytes(raw)
"""
assert s.count(needle)==1;s=s.replace(needle,insert+needle);f.write_text(s,encoding='utf8',newline='\n')
(dst/'range-instrumentation.json').write_text(json.dumps({'scope':'copy native int32 range inputs; device kernel and input tensors unchanged','source_collector_sha256':hashlib.sha256((src/'campaign-13/collect.py').read_bytes()).hexdigest(),'instrumented_collector_sha256':hashlib.sha256(f.read_bytes()).hexdigest()},indent=2)+'\n')
r=(p/'run-hidev-deepgemm-mqa.sh').read_text().replace('deepgemm-mqa-harness','deepgemm-mqa-ranges-harness')
(p/'run-hidev-deepgemm-mqa-ranges.sh').write_text(r,encoding='utf8',newline='\n')
i=(p/'inspect-deepgemm-mqa.py').read_text().replace('deepgemm-mqa-harness','deepgemm-mqa-ranges-harness')
append='''\nfor idx,label in ((3,'start'),(4,'end')):
 raw=(out/('mqa-range-'+label+'.bin')).read_bytes();a=b['target_input']['args'][idx]
 assert a['dtype']=='torch.int32' and len(raw)==4*a['shape'][0] and hashlib.sha256(raw).hexdigest()==a['sha256']
print('MQA_RANGE_INPUT_BYTES_BOUND_TO_HISTORICAL_HASH')\n'''
(p/'inspect-deepgemm-mqa-ranges.py').write_text(i+append,encoding='utf8',newline='\n')
print('prepared MQA capture with copied and hash-bound range inputs')
