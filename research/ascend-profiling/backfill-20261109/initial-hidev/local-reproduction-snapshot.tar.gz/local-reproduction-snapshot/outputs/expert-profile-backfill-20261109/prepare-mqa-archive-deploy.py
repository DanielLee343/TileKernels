import base64,hashlib
from pathlib import Path
p=Path(__file__).resolve().parent
data=(p/'archive-mqa-completed.py').read_bytes();encoded=base64.b64encode(data).decode();digest=hashlib.sha256(data).hexdigest()
script=f'''set -e
echo __DEPLOY_MQA_ARCHIVE_BEGIN__
p=/workspace/expert-profile-backfill-20261109-hidev/archive-mqa-completed.py
test ! -e "$p"
printf %s {encoded} | base64 -d > "$p"
printf '%s  %s\\n' {digest} "$p" | sha256sum -c
echo __DEPLOY_MQA_ARCHIVE_END__
'''
(p/'deploy-mqa-archive.sh').write_text(script,encoding='utf-8',newline='\n')
