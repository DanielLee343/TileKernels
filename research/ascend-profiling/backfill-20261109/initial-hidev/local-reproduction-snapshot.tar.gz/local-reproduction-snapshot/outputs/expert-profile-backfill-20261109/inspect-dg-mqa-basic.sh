#!/usr/bin/env bash
echo __INSPECT_DG_MQA_BASIC_BEGIN__
p=/workspace/expert-profile-backfill-20261109-hidev/deepgemm-runs/mqa-0-q16-k512-h8-random/hidev-npu0/attempt-002/detail
python3 - "$p" <<'PY'
import csv,sys
from pathlib import Path
p=Path(sys.argv[1]);op,=p.rglob('OpBasicInfo.csv')
with op.open(encoding='utf-8-sig',newline='') as f:b,=csv.DictReader(f)
print({k:b[k] for k in ('Op Type','Block Dim','Mix Block Dim','Device Id')})
with op.with_name('Memory.csv').open(encoding='utf-8-sig',newline='') as f:r=list(csv.DictReader(f))
print('rows',len(r),'first',[(x['block_id'],x['sub_block_id'],x['UB_to_GM_datas(KB)']) for x in r[:6]])
PY
echo __INSPECT_DG_MQA_BASIC_END__
