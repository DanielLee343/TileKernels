import base64,hashlib,io,tarfile
from pathlib import Path
p=Path(__file__).resolve().parent;mem=io.BytesIO()
files=['classic-pending.json','run-hidev-classic-detail.sh','inspect-classic-capture.py','hidev-classic-queue.py']
with tarfile.open(fileobj=mem,mode='w:gz') as t:
 for name in files:t.add(p/name,arcname=name,recursive=False)
data=mem.getvalue();encoded=base64.b64encode(data).decode();digest=hashlib.sha256(data).hexdigest()
for i in range(0,len(encoded),6000):
 part=i//6000;mode='>' if part==0 else '>>'
 (p/f'deploy-classic-part-{part}.sh').write_text(f"printf '%s' '{encoded[i:i+6000]}' {mode} /workspace/expert-profile-backfill-20261109-hidev/classic-deploy.b64\nprintf '%s\\n' __HIDEV_CLASSIC_PART_{part}__\n",encoding='utf8',newline='\n')
finish=f'''set -e
root=/workspace/expert-profile-backfill-20261109-hidev
repo=/workspace/tilekernels-env-20261101/src/TileKernels-private
base64 -d "$root/classic-deploy.b64" > "$root/classic-deploy.tar.gz"
echo '{digest}  '"$root/classic-deploy.tar.gz" | sha256sum -c
tar -xzf "$root/classic-deploy.tar.gz" -C "$root"
mkdir -p "$root/classic-harness"
cp "$root/application.py" "$root/classic-harness/application.py"
for batch in starter second third fourth fifth sixth; do
 suffix="_$batch";test "$batch" != second || suffix=''
 cp "$repo/research/ascend-profiling/collector/$batch/collect.py" "$root/classic-harness/collector${{suffix}}.py"
 cp "$repo/research/ascend-profiling/collector/$batch/cases.json" "$root/classic-harness/cases${{suffix}}.json"
done
printf '%s\\n' __HIDEV_CLASSIC_DEPLOY_DONE__
'''
(p/'deploy-classic-finish.sh').write_text(finish,encoding='utf8',newline='\n')
print('archive',len(data),'parts',(len(encoded)+5999)//6000,'sha256',digest)
