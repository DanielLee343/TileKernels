echo __MOE_CASE02_SOURCE_BEGIN__
p=/workspace/expert-profile-backfill-20261109-hidev/extra-proxy-runs/unified-extra4/moe_topk_gate_backward-02/hidev-npu0/attempt-001/detail
python3 - "$p" <<'PY'
from pathlib import Path
import sys
p=Path(sys.argv[1]);s=(p/'generated-kernel.cpp').read_text().splitlines()
for i,line in enumerate(s):
 if 'asc_copy_ub2gm' in line:
  for n in range(max(0,i-4),min(len(s),i+3)):
   print(n+1,s[n][:800])
PY
echo __MOE_CASE02_SOURCE_END__
