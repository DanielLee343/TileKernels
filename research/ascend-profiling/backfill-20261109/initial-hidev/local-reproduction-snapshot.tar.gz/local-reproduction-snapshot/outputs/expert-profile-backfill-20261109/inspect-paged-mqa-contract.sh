#!/usr/bin/env bash
echo __PAGED_MQA_CONTRACT_BEGIN__
f=/workspace/deepgemm-ascend-20261107/source/build/lib.linux-x86_64-cpython-312/deep_gemm/include/deep_gemm/mqa_logits.hpp
sed -n '480,515p;575,606p;645,680p' "$f"
echo __PAGED_MQA_CONTRACT_END__
