from pathlib import Path
p=Path(__file__).resolve().parent
s=(p/'prepare-dg-bf16-mgroup-smoke.py').read_text()
for old,new in [('bf16-mgroup','mqa'),("startswith('campaign-13/mgroup-bf16')","startswith('campaign-13/mqa-')"),
                ('bf16_gemm_impl','mqa_logits_impl'),('mgroup-bf16bf16-[a-z0-9-]+','mqa-[a-z0-9-]+'),
                ('len(manifest[\'cases\'])==len(ids)==3','len(manifest[\'cases\'])==len(ids)==10'),
                ("'case_count':3","'case_count':10"),('BF16 M-group','MQA logits')]:
 assert old in s,old;s=s.replace(old,new)
exec(compile(s,str(p/'prepare-dg-bf16-mgroup-smoke.py'),'exec'))
