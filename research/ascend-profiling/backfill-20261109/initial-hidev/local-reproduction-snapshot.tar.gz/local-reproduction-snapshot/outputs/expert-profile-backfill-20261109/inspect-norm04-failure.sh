#!/usr/bin/env bash
set -u
echo __INSPECT_NORM04_FAILURE_BEGIN__
r=/workspace/expert-profile-backfill-20261109-hidev/extra-proxy-runs/unified-extra3/quant_norm_forward-04/hidev-npu0
for d in "$r"/attempt-*; do
 echo "--- $d ---"
 cat "$d/queue-status.json" 2>/dev/null || true
 tail -n 25 "$d/audit-console.log" 2>/dev/null || true
done
echo __INSPECT_NORM04_FAILURE_END__
