import base64,hashlib
from pathlib import Path
HERE=Path(__file__).resolve().parent
data=(HERE/'hidev-reduce-queue.py').read_bytes();encoded=base64.b64encode(data).decode()
script="""#!/usr/bin/env bash
set -Eeo pipefail
cd /workspace/expert-profile-backfill-20261109-hidev
test ! -e hidev-reduce-queue.py
printf '%s' 'DATA' | base64 -d > hidev-reduce-queue.py
printf '%s  %s\\n' HASH hidev-reduce-queue.py | sha256sum -c
printf '%s\\n' __HIDEV_QUEUE_DEPLOY_DONE__
""".replace('DATA',encoded).replace('HASH',hashlib.sha256(data).hexdigest())
(HERE/'deploy-hidev-queue.sh').write_text(script,encoding='utf-8',newline='\n')
print('queue package bytes',len(script))
