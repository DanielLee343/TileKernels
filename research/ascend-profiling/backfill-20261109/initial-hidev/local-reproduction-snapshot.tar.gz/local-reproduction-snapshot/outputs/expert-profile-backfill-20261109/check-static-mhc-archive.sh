#!/usr/bin/env bash
echo __CHECK_STATIC_MHC_ARCHIVE_BEGIN__
r=/workspace/expert-profile-backfill-20261109-hidev
ps -p "$(cat "$r/static-mhc-archive.pid")" -o pid=,stat=,args= || true
tail -n 8 "$r/static-mhc-archive.log"
test ! -f "$r/mhc-static-archive-bundle.tar.gz" || ls -lh "$r/mhc-static-archive-bundle.tar.gz"
echo __CHECK_STATIC_MHC_ARCHIVE_END__
