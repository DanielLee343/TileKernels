from pathlib import Path
p=Path(__file__).resolve().parent;s=(p/'test-castback-audit.sh').read_text()
for old,new in [('extra-proxy-runs/unified-extra2/quant_cast_back_per_token-01','classic-runs/second/castback-09'),
                ('quant_cast_back_per_token-01','castback-09'),
                ('audit-extra-castback.py','audit-classic-castback.py'),
                ('CASTBACK_AUDIT_TEST','CLASSIC_CASTBACK_AUDIT_TEST')]:
 assert old in s;s=s.replace(old,new)
(p/'test-classic-castback-audit.sh').write_text(s,encoding='utf8',newline='\n')
print('classic cast-back negative tests prepared')
