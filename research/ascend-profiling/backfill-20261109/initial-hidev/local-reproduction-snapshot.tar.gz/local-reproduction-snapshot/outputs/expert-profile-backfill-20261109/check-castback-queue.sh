#!/usr/bin/env bash
echo __CHECK_CASTBACK_QUEUE_BEGIN__
q=/workspace/expert-profile-backfill-20261109-hidev/extra-castback-queue-hidev-npu0
ps -p "$(cat "$q/followup.pid")" -o pid,stat,etime,args || true
tail -n 25 "$q/console.log"
if test -f "$q/followup-exit.txt";then cat "$q/followup-exit.txt";fi
echo __CHECK_CASTBACK_QUEUE_END__
