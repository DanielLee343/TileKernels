from pathlib import Path
p=Path(__file__).resolve().parent
for old,new in [('run-hidev-extra-engram-gate-fwd.sh','run-hidev-extra-engram-gate-bwd.sh'),
                ('inspect-extra-engram-gate-fwd.py','inspect-extra-engram-gate-bwd.py')]:
 s=(p/old).read_text().replace('engram_gate_fwd','engram_gate_bwd').replace('engram-gate-fwd','engram-gate-bwd')
 s=s.replace('Engram gate forward, save-for-backward non-inplace mode','Engram gate backward, unmasked pilot')
 (p/new).write_text(s,encoding='utf8',newline='\n')
print('prepared unmasked Engram backward pilot')
