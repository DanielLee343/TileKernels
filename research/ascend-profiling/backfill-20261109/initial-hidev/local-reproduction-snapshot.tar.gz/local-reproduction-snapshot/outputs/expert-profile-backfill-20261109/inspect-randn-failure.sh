#!/usr/bin/env bash
echo __RANDN_FAILURE_BEGIN__
p=/workspace/expert-profile-backfill-20261109-hidev/extra-proxy-runs/unified-extra2/randn-04/hidev-npu0/attempt-001/detail
python3 - "$p" <<'PY'
import json,re,sys
from pathlib import Path
p=Path(sys.argv[1]);s=(p/'profile.log').read_text(errors='replace')
for name in ('application.json','tensor-addresses.json','monitor-summary.json'):
 print(name, (p/name).read_text()[:2200])
for text in ('DBI record core:', 'processedRecord:', 'droppedRecord:', 'memoryCorruption', 'ERROR', 'WARNING'):
 print(text, s.count(text))
for line in s.splitlines():
 if any(x in line for x in ('processedRecord:', 'droppedRecord:', 'memoryCorruption', 'ERROR', 'DBI record core:')):
  print(line[:1000])
PY
echo __RANDN_FAILURE_END__
