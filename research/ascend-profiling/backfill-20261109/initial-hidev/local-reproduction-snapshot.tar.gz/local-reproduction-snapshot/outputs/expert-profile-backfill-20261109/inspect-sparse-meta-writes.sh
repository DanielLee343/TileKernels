echo __SPARSE_META_WRITES_BEGIN__
f=/workspace/deepgemm-ascend-20261107/source/deep_gemm/include/deep_gemm/sparse_mqa_logits_metadata.hpp
grep -nE 'q_block_headers\[|kv_split_outputs\[|output_ranges|num_merged_kv_blocks|q_block_idx' "$f" | tail -n 45
echo __SPARSE_META_WRITES_END__
