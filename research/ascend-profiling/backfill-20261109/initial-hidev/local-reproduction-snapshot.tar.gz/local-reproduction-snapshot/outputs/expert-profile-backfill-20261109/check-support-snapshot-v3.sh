#!/usr/bin/env bash
echo __CHECK_SUPPORT_SNAPSHOT_V3_BEGIN__
r=/workspace/expert-profile-backfill-20261109-hidev
ps -p "$(cat "$r/support-snapshot-v3.pid")" -o pid=,stat=,etime=,args= || true
tail -n 8 "$r/support-snapshot-v3.log"
echo __CHECK_SUPPORT_SNAPSHOT_V3_END__
