echo __INSPECT_SPARSE_SOURCE_BEGIN__
r=/workspace/deepgemm-ascend-20261107/source
grep -nE 'def run_sparse_mqa_logits_case|fp8_fp4_sparse_mqa_logits\(' "$r/tests/test_attention.py" | head -n 12
echo __INSPECT_SPARSE_SOURCE_END__
