#!/usr/bin/env bash
set -u
echo __CHECK_HIDEV_NETWORK_BEGIN__
for host in github.com api.github.com;do
 if timeout 8 bash -c 'exec 3<>/dev/tcp/"$1"/443' _ "$host" 2>/dev/null;then echo "$host tcp443 reachable";else echo "$host tcp443 unreachable";fi
done
df -h /workspace | tail -n 1
du -sh /workspace/expert-profile-backfill-20261109-hidev
echo __CHECK_HIDEV_NETWORK_END__
