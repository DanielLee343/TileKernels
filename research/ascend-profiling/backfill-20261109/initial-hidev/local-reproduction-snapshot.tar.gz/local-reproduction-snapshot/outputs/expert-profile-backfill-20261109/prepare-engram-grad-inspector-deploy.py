import base64,hashlib,io,tarfile
from pathlib import Path
p=Path(__file__).resolve().parent;b=io.BytesIO();name='inspect-engram-grad-app.py'
with tarfile.open(fileobj=b,mode='w:gz') as t:t.add(p/name,arcname=name)
data=b.getvalue();enc=base64.b64encode(data).decode();sha=hashlib.sha256(data).hexdigest()
for i in range(0,len(enc),5500):
 part=i//5500;mode='>' if part==0 else '>>'
 (p/f'deploy-engram-grad-inspector-part-{part}.sh').write_text(f"printf '%s' '{enc[i:i+5500]}' {mode} /workspace/expert-profile-backfill-20261109-hidev/engram-grad-inspector-deploy.b64\necho __ENGRAM_GRAD_INSPECTOR_PART_{part}__\n",encoding='utf-8',newline='\n')
script=f'''set -e
echo __DEPLOY_ENGRAM_GRAD_INSPECTOR_BEGIN__
r=/workspace/expert-profile-backfill-20261109-hidev
base64 -d "$r/engram-grad-inspector-deploy.b64" > "$r/engram-grad-inspector-deploy.tar.gz"
printf '%s  %s\\n' {sha} "$r/engram-grad-inspector-deploy.tar.gz" | sha256sum -c
test ! -e "$r/{name}"
tar -xzf "$r/engram-grad-inspector-deploy.tar.gz" -C "$r"
echo __DEPLOY_ENGRAM_GRAD_INSPECTOR_END__
'''
(p/'deploy-engram-grad-inspector-finish.sh').write_text(script,encoding='utf-8',newline='\n')
print('parts',(len(enc)+5499)//5500)
