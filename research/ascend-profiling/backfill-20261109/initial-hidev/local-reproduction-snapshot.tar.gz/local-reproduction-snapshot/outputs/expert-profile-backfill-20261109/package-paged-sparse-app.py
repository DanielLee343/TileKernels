import base64,hashlib,io,tarfile
from pathlib import Path
p=Path(__file__).resolve().parent;b=io.BytesIO()
with tarfile.open(fileobj=b,mode='w:gz') as t:
 for n in ('deepgemm-paged-sparse-app-harness','run-hidev-deepgemm-paged-sparse-first-app.sh'):
  t.add(p/n,arcname=n,filter=lambda x:None if '__pycache__' in x.name else x)
data=b.getvalue();enc=base64.b64encode(data).decode();sha=hashlib.sha256(data).hexdigest()
for i in range(0,len(enc),5500):
 part=i//5500;mode='>' if part==0 else '>>'
 (p/f'deploy-paged-sparse-app-part-{part}.sh').write_text(f"printf '%s' '{enc[i:i+5500]}' {mode} /workspace/expert-profile-backfill-20261109-hidev/paged-sparse-app-deploy.b64\necho __PAGED_SPARSE_APP_PART_{part}__\n",encoding='utf-8',newline='\n')
script=f'''set -e
echo __DEPLOY_PAGED_SPARSE_APP_BEGIN__
r=/workspace/expert-profile-backfill-20261109-hidev
base64 -d "$r/paged-sparse-app-deploy.b64" > "$r/paged-sparse-app-deploy.tar.gz"
printf '%s  %s\\n' {sha} "$r/paged-sparse-app-deploy.tar.gz" | sha256sum -c
test ! -e "$r/deepgemm-paged-sparse-app-harness"
tar -xzf "$r/paged-sparse-app-deploy.tar.gz" -C "$r"
bash -n "$r/run-hidev-deepgemm-paged-sparse-first-app.sh"
python3 -B -c 'import ast,pathlib;ast.parse(pathlib.Path("/workspace/expert-profile-backfill-20261109-hidev/deepgemm-paged-sparse-app-harness/campaign-13/collect.py").read_text())'
echo __DEPLOY_PAGED_SPARSE_APP_END__
'''
(p/'deploy-paged-sparse-app-finish.sh').write_text(script,encoding='utf-8',newline='\n')
print('parts',(len(enc)+5499)//5500)
