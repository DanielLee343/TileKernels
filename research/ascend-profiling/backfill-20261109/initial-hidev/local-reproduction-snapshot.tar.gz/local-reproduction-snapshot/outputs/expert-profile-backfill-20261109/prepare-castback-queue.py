from pathlib import Path
p=Path(__file__).resolve().parent;s=(p/'hidev-extra-channel-queue.py').read_text()
for old,new in [('quant_per_channel_cast','quant_cast_back_per_token'),
                ('extra-channel-queue','extra-castback-queue'),
                ('run-hidev-extra-proxy-detail.sh','run-hidev-extra-castback-detail.sh'),
                ('inspect-extra-proxy.py','inspect-extra-castback.py'),
                ('audit-extra-channel.py','audit-extra-castback.py'),
                ('assert len(items)==20','assert len(items)==17'),
                ('ALL_CHANNEL_SELECTED_AUDITED','ALL_CASTBACK_SELECTED_AUDITED')]:
 assert old in s;s=s.replace(old,new)
(p/'hidev-extra-castback-queue.py').write_text(s,encoding='utf8',newline='\n')
print('17 per-token cast-back cases prepared; three other planned cases use an earlier collector and remain separate')
