from pathlib import Path
p=Path(__file__).resolve().parent
s=(p/'package-deepgemm-mgroup.py').read_text()
s=s.replace('deepgemm-mgroup-harness','deepgemm-bf16-mgroup-harness')
s=s.replace('run-hidev-deepgemm-mgroup.sh','run-hidev-deepgemm-bf16-mgroup.sh')
s=s.replace('inspect-deepgemm-mgroup.py','inspect-deepgemm-bf16-mgroup.py')
s=s.replace('deploy-dg-mgroup','deploy-dg-bf16-mgroup').replace('dg-mgroup-deploy','dg-bf16-mgroup-deploy').replace('__DG_MGROUP_','__DG_BF16_MGROUP_')
exec(compile(s,str(p/'package-deepgemm-mgroup.py'),'exec'))
