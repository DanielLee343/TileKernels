echo __KGROUP_QUANT_DETAILS_BEGIN__
r=/workspace/expert-profile-backfill-20261109-hidev/deepgemm-runs
python3 - "$r" <<'PY'
import json,sys
from pathlib import Path
r=Path(sys.argv[1])
for case in ('kgroup-fp8fp8-tn-g4-m64-n256-k512','kgroup-fp4fp4-tn-g4-m64-n256-k512','kgroup-fp8fp4-tn-g4-m64-n256-k512'):
 p=r/case/'hidev-npu0/attempt-001';d=json.loads((p/'capture-inspection.json').read_text());a,=json.loads((p/'profile-addresses.json').read_text())
 print('CASE',case,'op',d['capture']['op_type'],'stores',d['ub_to_gm_records'],'cores',d['raw_store_core_labels'])
 print('ARGS',json.dumps(a['args'],separators=(',',':')))
 print('JIT',(p/'jit/kernel.asc').read_text()[:1800])
 for line in (p/'detail/profile.log').read_text(errors='replace').splitlines():
  if 'processedRecord:' in line:print(line)
PY
echo __KGROUP_QUANT_DETAILS_END__
