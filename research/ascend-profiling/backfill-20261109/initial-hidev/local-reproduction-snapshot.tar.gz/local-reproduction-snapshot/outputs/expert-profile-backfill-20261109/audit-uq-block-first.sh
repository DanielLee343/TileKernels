#!/usr/bin/env bash
printf '%s\n' __UQ_BLOCK_FIRST_AUDIT_BEGIN__
root=/workspace/expert-profile-backfill-20261109-hidev
python3 -B "$root/audit-unified-quant-block.py" quant_per_block_cast-01 attempt-001
printf '%s\n' __UQ_BLOCK_FIRST_AUDIT_END__
