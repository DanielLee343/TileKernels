from pathlib import Path
p=Path(__file__).resolve().parent;s=(p/'package-norm-accum-app.py').read_text(encoding='utf-8')
for old,new in (
 ('extra-proxy-accum-app-harness','extra-proxy-engram-grad-app-harness'),
 ('run-hidev-extra-norm-accum-app.sh','run-hidev-extra-engram-grad-app.sh'),
 ('extra_norm_bwd.py','extra_engram_grad.py'),
 ('deploy-norm-accum-app','deploy-engram-grad-app'),
 ('norm-accum-app-deploy','engram-grad-app-deploy'),
 ('__NORM_ACCUM_APP_','__ENGRAM_GRAD_APP_'),
):
 assert old in s,old;s=s.replace(old,new)
exec(compile(s,str(p/'package-norm-accum-app.py'),'exec'))
