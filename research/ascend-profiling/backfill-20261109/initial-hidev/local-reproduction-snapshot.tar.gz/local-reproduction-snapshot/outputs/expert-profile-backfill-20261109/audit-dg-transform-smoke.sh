#!/usr/bin/env bash
printf '%s\n' __DG_TRANSFORM_SMOKE_AUDIT_BEGIN__
root=/workspace/expert-profile-backfill-20261109-hidev
python3 -B "$root/audit-deepgemm-transform-general.py" transform-float32-k-g8-mn128-k7168 attempt-002
printf '%s\n' __DG_TRANSFORM_SMOKE_AUDIT_END__
