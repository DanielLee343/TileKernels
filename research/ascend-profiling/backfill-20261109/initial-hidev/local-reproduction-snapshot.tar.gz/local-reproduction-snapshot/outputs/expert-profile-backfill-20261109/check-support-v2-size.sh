echo __CHECK_SUPPORT_V2_SIZE_BEGIN__
stat -c '%s bytes' /workspace/expert-profile-backfill-20261109-hidev/support-snapshot-v2.tar.gz
echo __CHECK_SUPPORT_V2_SIZE_END__
