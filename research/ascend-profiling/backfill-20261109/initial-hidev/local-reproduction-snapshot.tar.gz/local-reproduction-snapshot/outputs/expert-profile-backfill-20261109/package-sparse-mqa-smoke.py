from pathlib import Path
p=Path(__file__).resolve().parent;s=(p/'package-deepgemm-mgroup.py').read_text(encoding='utf-8')
for old,new in (
 ('deepgemm-mgroup-harness','deepgemm-sparse-mqa-harness'),
 ('run-hidev-deepgemm-mgroup.sh','run-hidev-deepgemm-sparse-mqa.sh'),
 ('inspect-deepgemm-mgroup.py','inspect-deepgemm-sparse-mqa.py'),
 ('deploy-dg-mgroup','deploy-dg-sparse-mqa'),
 ('dg-mgroup-deploy','dg-sparse-mqa-deploy'),
 ('__DG_MGROUP_','__DG_SPARSE_MQA_'),
):
 assert old in s,old;s=s.replace(old,new)
exec(compile(s,str(p/'package-deepgemm-mgroup.py'),'exec'))
