#!/usr/bin/env bash
echo __CHECK_NORM_ACCUM_ACTIVE_CASE_BEGIN__
r=/workspace/expert-profile-backfill-20261109-hidev
for n in 02 04 05 08 09 10 17 18 20;do
 d="$r/extra-proxy-runs/unified-extra3/quant_norm_backward-$n/hidev-npu0"
 test ! -d "$d" || find "$d" -name queue-status.json -maxdepth 3 -print -exec cat {} \;
done
echo __CHECK_NORM_ACCUM_ACTIVE_CASE_END__
