echo __CHECK_ENGRAM_GRAD_APP_BEGIN__
q=/workspace/expert-profile-backfill-20261109-hidev/extra-engram-grad-app-smoke-hidev-npu0
ps -p "$(cat "$q/pid")" -o pid,stat,etime,args || true
test ! -f "$q/attempt.txt" || cat "$q/attempt.txt"
test ! -f "$q/exit.txt" || cat "$q/exit.txt"
tail -n 10 "$q/console.log"
echo __CHECK_ENGRAM_GRAD_APP_END__
