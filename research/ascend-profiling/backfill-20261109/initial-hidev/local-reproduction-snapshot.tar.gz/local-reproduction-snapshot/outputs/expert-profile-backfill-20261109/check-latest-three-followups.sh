#!/usr/bin/env bash
echo __CHECK_LATEST_THREE_FOLLOWUPS_BEGIN__
r=/workspace/expert-profile-backfill-20261109-hidev
for x in extra-swiglu-backward-queue-hidev-npu0 extra-norm-backward-variants-smoke-hidev-npu0 extra-engram-gate-fwd-smoke-hidev-npu0;do
 q="$r/$x";echo "--- $x ---";ps -p "$(cat "$q/pid")" -o pid=,stat=,args= || true;test ! -f "$q/exit.txt" || cat "$q/exit.txt";tail -n 12 "$q/console.log" 2>/dev/null || true
done
echo __CHECK_LATEST_THREE_FOLLOWUPS_END__
