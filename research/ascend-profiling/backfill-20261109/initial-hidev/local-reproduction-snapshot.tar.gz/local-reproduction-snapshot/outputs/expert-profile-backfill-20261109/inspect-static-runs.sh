#!/usr/bin/env bash
echo __INSPECT_STATIC_RUNS_BEGIN__
r=/workspace/expert-profile-backfill-20261109-hidev/runs
find "$r" -maxdepth 1 -mindepth 1 -type d -printf '%f\n' | sort
echo __INSPECT_STATIC_RUNS_END__
