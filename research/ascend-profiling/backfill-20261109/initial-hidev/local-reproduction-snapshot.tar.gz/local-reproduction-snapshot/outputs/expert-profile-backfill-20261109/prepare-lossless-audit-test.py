from pathlib import Path
p=Path(__file__).resolve().parent;s=(p/'test-channel-audit.sh').read_text()
for old,new in [('quant_per_channel_cast','quant_per_block_cast_lossless'),
                ('audit-extra-channel.py','audit-extra-lossless.py'),
                ('CHANNEL_AUDIT_TEST','LOSSLESS_AUDIT_TEST')]:
 assert old in s;s=s.replace(old,new)
(p/'test-lossless-audit.sh').write_text(s,encoding='utf8',newline='\n')
print('prepared lossless negative tests')
