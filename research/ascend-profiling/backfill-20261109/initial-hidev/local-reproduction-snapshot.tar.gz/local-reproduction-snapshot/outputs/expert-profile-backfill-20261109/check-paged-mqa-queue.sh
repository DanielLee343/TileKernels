echo __CHECK_PAGED_MQA_QUEUE_BEGIN__
q=/workspace/expert-profile-backfill-20261109-hidev/deepgemm-paged-mqa-queue-hidev-npu0
ps -p "$(cat "$q/pid")" -o pid,stat,etime,args || true
tail -n 12 "$q/console.log"
echo __CHECK_PAGED_MQA_QUEUE_END__
