#!/usr/bin/env bash
echo __PAGED_MQA_SOURCE_BEGIN__
p=/workspace/expert-profile-backfill-20261109-hidev/deepgemm-runs/paged-mqa-fp8-b2-k256-h8-d128-p64/hidev-npu0/attempt-001
f=/workspace/deepgemm-ascend-20261107/source/csrc/include/deep_gemm/mqa_logits.hpp
if ! test -f "$f"; then f=$(find /workspace/deepgemm-ascend-20261107/source -path '*/deep_gemm/mqa_logits.hpp' -print -quit); fi
echo SOURCE="$f"
grep -nE 'paged_mqa_logits_impl|Copy.*(Out|Gm)|copy.*(out|gm)|logits|output' "$f" | tail -n 55
echo STORES
grep -E 'DBI record core:.*dst:\(type:GM;.*src:\(type:UB;' "$p/detail/profile.log"
echo MEMORY
find "$p/detail/capture" -name Memory.csv -print -exec head -n 4 {} \;
echo __PAGED_MQA_SOURCE_END__
