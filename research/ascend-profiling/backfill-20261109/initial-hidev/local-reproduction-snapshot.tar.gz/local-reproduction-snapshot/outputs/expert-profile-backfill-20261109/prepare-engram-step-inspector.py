from pathlib import Path
p=Path(__file__).resolve().parent;s=(p/'inspect-engram-grad-app.py').read_text(encoding='utf-8')
for old,new in (
 ('engram_grad_w_reduce','engram_sinkhorn_step'),
 ("assert a['inputs']==old['inputs'] and a['params']==old['params']", "assert a['inputs']==old['inputs'] and a['params']==old['params'] and a['source_files_sha256']==old['source_files_sha256']"),
):
 assert old in s,old;s=s.replace(old,new)
(p/'inspect-engram-step-app.py').write_text(s,encoding='utf-8',newline='\n');compile(s,str(p/'inspect-engram-step-app.py'),'exec')
