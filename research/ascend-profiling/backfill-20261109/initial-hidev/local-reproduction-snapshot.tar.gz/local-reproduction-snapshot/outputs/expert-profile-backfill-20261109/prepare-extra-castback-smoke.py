"""Stage a stateless per-token cast-back smoke, requiring full identity checks."""
from pathlib import Path
p=Path(__file__).resolve().parent
runner=(p/'run-hidev-extra-proxy-detail.sh').read_text()
assert 'test "$group" = quant_per_channel_cast' in runner
runner=runner.replace('test "$group" = quant_per_channel_cast','test "$group" = quant_cast_back_per_token')
runner=runner.replace('run-hidev-extra-proxy-detail.sh','run-hidev-extra-castback-detail.sh')
(p/'run-hidev-extra-castback-detail.sh').write_text(runner,encoding='utf8',newline='\n')
inspector=(p/'inspect-extra-proxy.py').read_text().replace('stateless per-channel quantization representative','stateless per-token cast-back representative')
anchor="for key in ('runtime_kernel','inputs','source_sha256'):assert a[key]==old[key],key"
assert anchor in inspector
inspector=inspector.replace(anchor,anchor+"\nfor key in ('group','params','source_files_sha256','seed'):assert a[key]==old[key],key")
(p/'inspect-extra-castback.py').write_text(inspector,encoding='utf8',newline='\n')
print('prepared cast-back smoke; byte audit remains independent')
