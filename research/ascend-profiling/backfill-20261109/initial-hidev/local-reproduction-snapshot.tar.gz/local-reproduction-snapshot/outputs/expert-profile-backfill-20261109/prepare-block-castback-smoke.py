"""Stage block cast-back representative without altering the token queue."""
from pathlib import Path
p=Path(__file__).resolve().parent
runner=(p/'run-hidev-extra-castback-detail.sh').read_text()
assert 'test "$group" = quant_cast_back_per_token' in runner
runner=runner.replace('test "$group" = quant_cast_back_per_token','test "$group" = quant_cast_back_block')
runner=runner.replace('run-hidev-extra-castback-detail.sh','run-hidev-extra-block-castback-detail.sh')
(p/'run-hidev-extra-block-castback-detail.sh').write_text(runner,encoding='utf8',newline='\n')
inspector=(p/'inspect-extra-castback.py').read_text().replace('stateless per-token cast-back representative','stateless block cast-back representative')
(p/'inspect-extra-block-castback.py').write_text(inspector,encoding='utf8',newline='\n')
audit=(p/'audit-extra-castback.py').read_text().replace('quant_cast_back_per_token-','quant_cast_back_block-')
assert "p/'audit-result.json'" in audit
audit=audit.replace("p/'audit-result.json'","p/'candidate-audit-result.json'")
(p/'audit-extra-block-castback.py').write_text(audit,encoding='utf8',newline='\n')
print('block cast-back smoke and candidate audit prepared; actual capture still required')
