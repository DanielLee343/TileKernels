echo __PAGED_SPARSE_DIFF_BEGIN__
r=/workspace/expert-profile-backfill-20261109-hidev
python3 - "$r" <<'PY'
import json,sys
from pathlib import Path
r=Path(sys.argv[1]);case='paged-sparse-fp8-q4-k256-h8-b8';p=r/'deepgemm-runs'/case/'hidev-npu0/attempt-001'
for n in ('prepare.json','profile.json'):
 d=json.loads((p/n).read_text());print(n,'status',d['status'],'validation',d['validation'])
a=json.loads((p/'profile.json').read_text())['target_input'];b=json.loads((r/'deepgemm-paged-sparse-harness/history'/case/'profile.json').read_text())['target_input']
def diff(a,b,path=''):
 if type(a)!=type(b):print(path,'type',type(a).__name__,type(b).__name__);return
 if isinstance(a,dict):
  for k in sorted(a.keys()|b.keys()):
   if k not in a or k not in b:print(path,k,'missing')
   else:diff(a[k],b[k],path+'/'+k)
 elif isinstance(a,list):
  if len(a)!=len(b):print(path,'lengths',len(a),len(b))
  for i,(x,y) in enumerate(zip(a,b)):diff(x,y,path+'/'+str(i))
 elif a!=b:print(path,'CURRENT',str(a)[:200],'HISTORICAL',str(b)[:200])
diff(a,b)
PY
echo __PAGED_SPARSE_DIFF_END__
