import base64,hashlib,io,tarfile
from pathlib import Path
p=Path(__file__).resolve().parent;b=io.BytesIO()
with tarfile.open(fileobj=b,mode='w:gz') as t:
 for n in ('summarize-dg-kgroup-bf16.py','test-dg-kgroup-audit.sh'):t.add(p/n,arcname=n)
data=b.getvalue();encoded=base64.b64encode(data).decode();sha=hashlib.sha256(data).hexdigest()
for i in range(0,len(encoded),5500):
 part=i//5500;mode='>' if part==0 else '>>'
 (p/f'deploy-kgroup-bf16-index-part-{part}.sh').write_text(f"printf '%s' '{encoded[i:i+5500]}' {mode} /workspace/expert-profile-backfill-20261109-hidev/kgroup-bf16-index-deploy.b64\necho __KGROUP_BF16_INDEX_PART_{part}__\n",encoding='utf-8',newline='\n')
script=f'''set -e
echo __KGROUP_BF16_INDEX_BEGIN__
r=/workspace/expert-profile-backfill-20261109-hidev
base64 -d "$r/kgroup-bf16-index-deploy.b64" > "$r/kgroup-bf16-index-deploy.tar.gz"
printf '%s  %s\\n' {sha} "$r/kgroup-bf16-index-deploy.tar.gz" | sha256sum -c
test ! -e "$r/summarize-dg-kgroup-bf16.py"
tar -xzf "$r/kgroup-bf16-index-deploy.tar.gz" -C "$r"
bash "$r/test-dg-kgroup-audit.sh" > "$r/kgroup-bf16-audit-test.log" 2>&1
grep -q 'PASS rejects missing store, altered CSV and input/output alias' "$r/kgroup-bf16-audit-test.log"
python3 -B "$r/summarize-dg-kgroup-bf16.py"
gzip -n -c "$r/deepgemm-kgroup-bf16-index.json" > "$r/deepgemm-kgroup-bf16-index.json.gz"
sha256sum "$r/deepgemm-kgroup-bf16-index.json.gz"
echo __KGROUP_BF16_INDEX_END__
'''
(p/'deploy-kgroup-bf16-index-finish.sh').write_text(script,encoding='utf-8',newline='\n')
print('parts',(len(encoded)+5499)//5500)
