#!/usr/bin/env bash
echo __CHECK_SUPPORT_SNAPSHOT_V5_BEGIN__
r=/workspace/expert-profile-backfill-20261109-hidev
ps -p "$(cat "$r/support-snapshot-v5.pid")" -o pid=,stat=,etime=,args= || true
tail -n 8 "$r/support-snapshot-v5.log"
echo __CHECK_SUPPORT_SNAPSHOT_V5_END__
