"""Freeze the remaining legacy collector cases for address-detail collection."""
import collections,csv,hashlib,json
from pathlib import Path
p=Path(__file__).resolve().parent;root=p.parents[1]
rows=list(csv.DictReader((p/'targets.csv').open(encoding='utf-8-sig',newline='')))
items=[];batches={'starter','second','third','fourth','fifth','sixth'}
for r in rows:
 if r['batch']!='tilekernels-default' or r['per_core_requested_bytes_status']!='pending':continue
 batch,case=r['target_id'].split('/')
 if batch not in batches or (batch=='starter' and case.startswith('hash-')):continue
 source=(root/r['original_profile_paths'].split(';')[0]).parent.parent
 metadata=source/'default.json';historical=source/'default-kernel.cpp'
 if not metadata.exists() or not historical.exists():
  print('SKIP missing original',r['target_id']);continue
 old=json.loads(metadata.read_text());assert old['runtime_kernel']==r['op_name'] and old['status']=='passed'
 items.append({'target':r['target_id'],'batch':batch,'case':case,'kernel':r['op_name'],
  'metadata_repo_path':metadata.relative_to(root/'TileKernels-private').as_posix(),
  'metadata_sha256':hashlib.sha256(metadata.read_bytes()).hexdigest(),
  'source_sha256':old['source_sha256']})
assert len({i['target'] for i in items})==len(items)
(p/'classic-pending.json').write_text(json.dumps(items,indent=2)+'\n',encoding='utf8')
print('count',len(items),'batches',dict(collections.Counter(x['batch'] for x in items)))
