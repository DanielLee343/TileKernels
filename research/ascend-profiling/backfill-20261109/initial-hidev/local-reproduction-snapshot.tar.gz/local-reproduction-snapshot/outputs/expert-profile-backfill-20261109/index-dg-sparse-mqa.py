"""Register the SHA-verified paged metadata index without merging windows."""
import json
from pathlib import Path
p=Path(__file__).resolve().parent;root=p.parents[1];doc=json.loads((p/'deepgemm-sparse-mqa-index.json').read_text())
assert doc['count']==len(doc['cases'])==8
index=p/'deepgemm-new-captures.json';captures=json.loads(index.read_text());out=p/'deepgemm-sparse-mqa-audits';out.mkdir(exist_ok=True)
for x in doc['cases']:
 a=x['audit'];assert x['case']==a['case'] and a['status']=='passed' and a['correctness']=='passed'
 assert a['historical_true_inputs_and_jit_source_match'] and a['dbi_requested_bytes']==a['expected_written_bytes'] and x['health']=='Alarm 8C4BA00C'
 f=out/(x['case'].replace('/','__')+'.json');f.write_text(json.dumps(a,indent=2)+'\n',encoding='utf8')
 captures[x['case']]={'audit':f.relative_to(root).as_posix(),'remote_detail':x['raw_dir']+'/detail',
  'device':'hidev NPU 0','health':x['health'],'files_sha256':x['files_sha256']}
index.write_text(json.dumps(captures,indent=2)+'\n',encoding='utf8');print('registered',len(doc['cases']),'grouped GEMM audits')
