#!/usr/bin/env bash
echo __CHECK_ENGRAM_MASK_TEST_BEGIN__
r=/workspace/expert-profile-backfill-20261109-hidev
ps -p "$(cat "$r/engram-gate-fwd-mask-test.pid")" -o pid=,stat=,args= || true
tail -n 12 "$r/engram-gate-fwd-mask-test.log"
echo __CHECK_ENGRAM_MASK_TEST_END__
