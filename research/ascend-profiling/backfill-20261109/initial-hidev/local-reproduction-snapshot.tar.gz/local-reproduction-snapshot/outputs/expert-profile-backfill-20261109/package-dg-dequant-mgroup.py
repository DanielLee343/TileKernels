from pathlib import Path
p=Path(__file__).resolve().parent
s=(p/'package-deepgemm-mgroup.py').read_text()
s=s.replace('deepgemm-mgroup-harness','deepgemm-dequant-mgroup-harness')
s=s.replace('run-hidev-deepgemm-mgroup.sh','run-hidev-deepgemm-dequant-mgroup.sh')
s=s.replace('inspect-deepgemm-mgroup.py','inspect-deepgemm-dequant-mgroup.py')
s=s.replace('deploy-dg-mgroup','deploy-dg-dequant-mgroup').replace('dg-mgroup-deploy','dg-dequant-mgroup-deploy').replace('__DG_MGROUP_','__DG_DEQUANT_MGROUP_')
exec(compile(s,str(p/'package-deepgemm-mgroup.py'),'exec'))
