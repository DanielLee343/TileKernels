from pathlib import Path
p=Path(__file__).resolve().parent
s=(p/'prepare-moe-audit-deploy.py').read_text(encoding='utf-8')
for old,new in (
 ('audit-extra-moe-backward-candidate.py','audit-extra-moe-backward-v2.py'),
 ('moe-audit-deploy','moe-audit-v2-deploy'),
 ('deploy-moe-audit-','deploy-moe-audit-v2-'),
 ('__MOE_AUDIT_PART_', '__MOE_AUDIT_V2_PART_'),
 ('__DEPLOY_MOE_AUDIT_', '__DEPLOY_MOE_AUDIT_V2_'),
 ('moe_topk_gate_backward-01','moe_topk_gate_backward-02'),
):
 assert old in s,old;s=s.replace(old,new)
exec(compile(s,str(p/'prepare-moe-audit-deploy.py'),'exec'))
