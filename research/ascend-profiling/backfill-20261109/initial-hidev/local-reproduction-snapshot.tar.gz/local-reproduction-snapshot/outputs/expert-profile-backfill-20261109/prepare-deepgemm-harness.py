"""Copy the frozen DeepGEMM collector and record API tensor addresses separately."""
import hashlib,json
from pathlib import Path
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
base=ROOT/'TileKernels-private/research/ascend-profiling/deepgemm-ascend'
out=HERE/'deepgemm-profile-harness';campaign=out/'campaign-13';pilot=out/'pilot-bf16'
campaign.mkdir(parents=True,exist_ok=True);pilot.mkdir(parents=True,exist_ok=True)
source=base/'campaign-13/collect.py';s=source.read_text(encoding='utf-8')
old='    calls=[]; metadata_factory={}\n';new='    calls=[]; metadata_factory={}; address_records=[]\n'
assert s.count(old)==1;s=s.replace(old,new)
old='    is_paged_sparse=(case[\'family\']==\'sparse\' and case.get(\'paged\') and\n'
new='''    def addresses(value):
        if isinstance(value, torch.Tensor):
            return {'device':str(value.device),'address':hex(value.data_ptr()),'dtype':str(value.dtype),
                    'shape':list(value.shape),'stride':list(value.stride()),'element_size':value.element_size()}
        if isinstance(value,(list,tuple)):return [addresses(x) for x in value]
        if isinstance(value,dict):return {str(k):addresses(v) for k,v in value.items()}
        return None

    is_paged_sparse=(case['family']=='sparse' and case.get('paged') and
'''
assert s.count(old)==1;s=s.replace(old,new)
old='''        torch.npu.synchronize()
        return value

    setattr(owner,case['api'],intercepted)
'''
new='''        torch.npu.synchronize()
        if stage=='profile':address_records.append({'args':addresses(args),'kwargs':addresses(kwargs),'returned':addresses(value)})
        return value

    setattr(owner,case['api'],intercepted)
'''
assert s.count(old)==1;s=s.replace(old,new)
old="    Path(output).write_text(json.dumps({'case_id':case['id'],'stage':stage,'status':'passed',\n"
new="    if stage=='profile':Path(output).with_name('profile-addresses.json').write_text(json.dumps(address_records,indent=2)+'\\n')\n"+old
assert s.count(old)==1;s=s.replace(old,new)
(campaign/'collect.py').write_text(s,encoding='utf-8',newline='\n')
(pilot/'collect.py').write_bytes((base/'pilot-bf16/collect.py').read_bytes())
manifest=json.loads((base/'campaign-13/cases-last.json').read_text(encoding='utf-8-sig'))
ids={'transform-float32-k-g1-mn256-k2048','gemm-fp4fp4-nn-mn-m64-n576-k7168'}
manifest['cases']=[x for x in manifest['cases'] if x['id'] in ids]
assert {x['id'] for x in manifest['cases']}==ids
(campaign/'cases.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
for case in sorted(ids):
 original=base/'campaign-13/runs/campaign-expanded'/case
 hist=out/'history'/case;hist.mkdir(parents=True,exist_ok=True)
 for filename in ('profile.json','result.json'):
  (hist/filename).write_bytes((original/filename).read_bytes())
 if (original/'jit/kernel.asc').exists():(hist/'kernel.asc').write_bytes((original/'jit/kernel.asc').read_bytes())
source_digest=hashlib.sha256(source.read_bytes()).hexdigest()
(out/'provenance.json').write_text(json.dumps({'original_collector':str(source.relative_to(ROOT)),
 'original_collector_sha256':source_digest,'change':'record API argument and return tensor addresses in a separate file; preserve original target_input comparison and references',
 'cases':sorted(ids)},indent=2)+'\n',encoding='utf-8')
compile(s,str(campaign/'collect.py'),'exec')
print('prepared isolated harness for',len(ids),'cases; original sha256',source_digest)
