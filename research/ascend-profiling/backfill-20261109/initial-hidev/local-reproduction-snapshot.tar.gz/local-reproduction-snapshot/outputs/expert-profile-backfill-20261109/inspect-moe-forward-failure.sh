echo __MOE_FORWARD_FAILURE_BEGIN__
p=/workspace/expert-profile-backfill-20261109-hidev/extra-proxy-runs/unified-extra3/moe_topk_gate_forward-01/hidev-npu0/attempt-001/detail
python3 - "$p" <<'PY'
import json,sys
from pathlib import Path
p=Path(sys.argv[1]);a=json.loads((p/'application.json').read_text());b=json.loads((p/'provenance/historical-default.json').read_text())
for k in ('status','correctness','runtime_kernel','source_sha256','group','params','seed','route_counts','scalar_inputs','requested_fix_routing'):
 print(k,'CURRENT',a.get(k),'HIST',b.get(k),'MATCH',a.get(k)==b.get(k))
for x,y in zip(a['inputs'],b['inputs']):
 print('INPUT',x['name'],x==y,'current',None if x['tensor'] is None else x['tensor']['sha256'],'historical',None if y['tensor'] is None else y['tensor']['sha256'])
print('STORES',sum('DBI record core:' in s and 'dst:(type:GM;' in s and 'src:(type:UB;' in s for s in (p/'profile.log').read_text(errors='replace').splitlines()))
PY
echo __MOE_FORWARD_FAILURE_END__
