"""Prepare per-token cast-back output-address candidate."""
from pathlib import Path
p=Path(__file__).resolve().parent;s=(p/'audit-uq-block-castonly.py').read_text()
for old,new in [('quant_per_block_cast_with_precomputed_sf-', 'quant_cast_back_per_token-'),
                ("p=root/'unified-quant-runs'/case/", "p=root/'extra-proxy-runs'/'unified-extra2'/case/"),
                ('assert len(a)==3 and a[1]', 'assert len(a)==3 and a[2]'),
                ('a[1:2]', 'a[2:3]'),
                ("'target':'unified-quant/'+case", "'target':'unified-extra2/'+case")]:
 assert old in s,old;s=s.replace(old,new)
(p/'audit-extra-castback.py').write_text(s,encoding='utf8',newline='\n')
print('per-token cast-back candidate prepared; run and challenge separately')
