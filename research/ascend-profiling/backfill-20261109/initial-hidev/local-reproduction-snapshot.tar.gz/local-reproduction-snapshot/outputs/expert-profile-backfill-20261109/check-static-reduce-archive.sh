#!/usr/bin/env bash
echo __CHECK_STATIC_REDUCE_ARCHIVE_BEGIN__
r=/workspace/expert-profile-backfill-20261109-hidev
ps -p "$(cat "$r/static-reduce-archive.pid")" -o pid=,stat=,args= || true
tail -n 8 "$r/static-reduce-archive.log"
test ! -f "$r/reduce-static-archive-bundle.tar.gz" || ls -lh "$r/reduce-static-archive-bundle.tar.gz"
echo __CHECK_STATIC_REDUCE_ARCHIVE_END__
