#!/usr/bin/env bash
echo __CHECK_MASK_AND_MQA_SMOKES_BEGIN__
r=/workspace/expert-profile-backfill-20261109-hidev
for x in extra-engram-gate-fwd-mask-smoke-hidev-npu0 dg-mqa-smoke-hidev-npu0;do
 q="$r/$x";echo "--- $x ---";ps -p "$(cat "$q/pid")" -o pid=,stat=,args= || true;test ! -f "$q/exit.txt" || cat "$q/exit.txt";tail -n 15 "$q/console.log" 2>/dev/null || true
done
echo __CHECK_MASK_AND_MQA_SMOKES_END__
