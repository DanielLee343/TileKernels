#!/usr/bin/env bash
echo __CHECK_ENGRAM_BWD_AND_PROXY_SNAPSHOTS_BEGIN__
r=/workspace/expert-profile-backfill-20261109-hidev;q="$r/extra-engram-gate-bwd-unmasked-queue-hidev-npu0"
echo '--- engram bwd ---';ps -p "$(cat "$q/pid")" -o pid=,stat=,args= || true;test ! -f "$q/exit.txt" || cat "$q/exit.txt";tail -n 8 "$q/console.log"
echo '--- archive ---';ps -p "$(cat "$r/extra-proxy-snapshots.pid")" -o pid=,stat=,args= || true
grep -E 'EXTRA_PROXY_SNAPSHOT_VERIFIED|ALL_EXTRA_PROXY_SNAPSHOTS_VERIFIED|snapshot-archive-bundle.tar.gz$|Traceback|AssertionError' "$r/extra-proxy-snapshots.log" | tail -n 10 || true
echo __CHECK_ENGRAM_BWD_AND_PROXY_SNAPSHOTS_END__
