echo __MOE_OLD_SOURCES_BEGIN__
p=/workspace/tilekernels-expert-unified-extra3-20261106/cases/moe_topk_gate_forward-01
find "$p" -maxdepth 2 -type f \( -name '*.cpp' -o -name '*.cc' -o -name '*.cu' \) -print
echo __MOE_OLD_SOURCES_END__
