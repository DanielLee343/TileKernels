#!/usr/bin/env bash
echo __CHECK_SWIGLU_BACKWARD_CANDIDATES_BEGIN__
r=/workspace/expert-profile-backfill-20261109-hidev
ps -p "$(cat "$r/swiglu-backward-candidates.pid")" -o pid=,stat=,args= || true
tail -n 20 "$r/swiglu-backward-candidates.log"
echo __CHECK_SWIGLU_BACKWARD_CANDIDATES_END__
