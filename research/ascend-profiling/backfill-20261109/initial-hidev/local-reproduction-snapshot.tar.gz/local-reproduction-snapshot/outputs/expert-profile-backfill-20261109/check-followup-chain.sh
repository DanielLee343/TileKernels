#!/usr/bin/env bash
echo __CHECK_FOLLOWUP_CHAIN_BEGIN__
root=/workspace/expert-profile-backfill-20261109-hidev
for stem in deepgemm-paged-meta deepgemm-mgroup classic-castback extra-block-castback extra-norm-forward;do
 q="$root/$stem-smoke-hidev-npu0";echo "SMOKE=$stem"
 ps -p "$(cat "$q/pid")" -o pid,stat,etime,args || true
 tail -n 8 "$q/console.log"
 if test -f "$q/exit.txt";then cat "$q/exit.txt";fi
done
echo __CHECK_FOLLOWUP_CHAIN_END__
