from pathlib import Path
p=Path(__file__).resolve().parent;s=(p/'summarize-dg-bf16-mgroup.py').read_text(encoding='utf-8')
old="items=json.loads((root/'deepgemm-bf16-mgroup-harness/campaign-13/cases.json').read_text())['cases'];assert len(items)==3"
new="items=[x for x in json.loads((root/'deepgemm-kgroup-harness/campaign-13/cases.json').read_text())['cases'] if x['id'].startswith('kgroup-bf16bf16-')];assert len(items)==1"
assert old in s;s=s.replace(old,new)
s=s.replace("assert len(cases)==3 and len({x['case'] for x in cases})==3","assert len(cases)==1 and len({x['case'] for x in cases})==1").replace('deepgemm-bf16-mgroup-index.json','deepgemm-kgroup-bf16-index.json')
(p/'summarize-dg-kgroup-bf16.py').write_text(s,encoding='utf-8',newline='\n')
s=(p/'index-dg-bf16-mgroup.py').read_text(encoding='utf-8').replace('deepgemm-bf16-mgroup-index.json','deepgemm-kgroup-bf16-index.json').replace('deepgemm-bf16-mgroup-audits','deepgemm-kgroup-bf16-audits').replace('==3','==1')
(p/'index-dg-kgroup-bf16.py').write_text(s,encoding='utf-8',newline='\n')
