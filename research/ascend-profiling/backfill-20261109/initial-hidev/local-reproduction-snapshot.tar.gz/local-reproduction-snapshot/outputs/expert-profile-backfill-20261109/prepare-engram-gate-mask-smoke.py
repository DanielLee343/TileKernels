"""Capture the mask bytes as input evidence; leave upstream kernel unchanged."""
import hashlib,json,shutil
from pathlib import Path
p=Path(__file__).resolve().parent;src=p/'extra-proxy-harness';dst=p/'extra-proxy-mask-harness';dst.mkdir(exist_ok=True)
for name in ('cases.json','provenance.json'):shutil.copyfile(src/name,dst/name)
s=(src/'extra_engram_gate_fwd.py').read_text()
needle="                        _puma_meta=[]\n"
insert="""                        assert params['with_mask'] and tensors[3] is not None and tensors[3].dtype == torch.bool
                        _puma_mask = tensors[3].detach().contiguous().view(torch.uint8).cpu().numpy().tobytes()
                        assert len(_puma_mask) == params['num_tokens'] and set(_puma_mask) <= {0, 1}
                        Path(record_path).with_name('mask-uint8.bin').write_bytes(_puma_mask)
"""
assert s.count(needle)==1;s=s.replace(needle,insert+needle)
(dst/'extra_engram_gate_fwd.py').write_text(s,encoding='utf8',newline='\n')
(dst/'mask-instrumentation.json').write_text(json.dumps({'scope':'copy native boolean mask before warmup; no modification to kernel or input','source_adapter_sha256':hashlib.sha256((src/'extra_engram_gate_fwd.py').read_bytes()).hexdigest(),'instrumented_adapter_sha256':hashlib.sha256((dst/'extra_engram_gate_fwd.py').read_bytes()).hexdigest()},indent=2)+'\n')
r=(p/'run-hidev-extra-engram-gate-fwd.sh').read_text().replace('extra-proxy-harness','extra-proxy-mask-harness')
r=r.replace('unified-extra5/engram_gate_fwd-01','unified-extra5/engram_gate_fwd-03').replace('$root/run-hidev-extra-engram-gate-fwd.sh','$root/run-hidev-extra-engram-gate-fwd-mask.sh')
(p/'run-hidev-extra-engram-gate-fwd-mask.sh').write_text(r,encoding='utf8',newline='\n')
print('prepared isolated masked pilot with copied mask bytes')
