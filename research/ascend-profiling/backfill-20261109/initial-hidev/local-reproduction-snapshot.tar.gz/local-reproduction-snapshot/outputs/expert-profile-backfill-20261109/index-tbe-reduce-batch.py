"""Register the 12 recomputed TBE results without merging capture windows."""
import json
from pathlib import Path
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
verification=json.loads((HERE/'tbe-reduce-02-13-verification.json').read_text());assert verification['recomputed']==12
path=HERE/'new-captures.json';captures=json.loads(path.read_text())
for item in verification['cases']:
 case=item['case'];audit=HERE/'tbe-evidence/batch-reduce-02-13/runs'/case/'tbe-npu3/attempt-001/detail/audit-result.json'
 d=json.loads(audit.read_text());assert d['status']=='passed' and d['case']==case
 captures['second/'+case]={'audit':audit.relative_to(ROOT).as_posix(),
   'remote_detail':'/home/lyuze/expert-profile-backfill-20261109/runs/'+case+'/tbe-npu3/attempt-001/detail',
   'device':'tbe NPU 3'}
path.write_text(json.dumps(captures,indent=2)+'\n',encoding='utf-8')
print('registered',len(captures),'total tbe captures')
