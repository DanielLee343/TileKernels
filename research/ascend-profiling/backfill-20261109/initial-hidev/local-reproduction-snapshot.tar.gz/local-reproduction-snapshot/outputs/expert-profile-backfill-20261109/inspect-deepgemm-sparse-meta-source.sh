#!/usr/bin/env bash
set -e
echo __INSPECT_DG_SPARSE_META_SOURCE_BEGIN__
repo=/workspace/tilekernels-env-20261101/src/TileKernels-private/research/ascend-profiling/deepgemm-ascend/campaign-13/runs
find "$repo" -path '*/sparse-meta-fp8-q4-k256-h8-b8/jit/kernel.asc' -type f -exec cat {} \;
src=/workspace/deepgemm-ascend-20261107/source/deep_gemm
grep -R -n 'void sparse_mqa_logits_metadata(' "$src" --include='*.hpp' | head -10
sed -n '300,380p' "$src/include/deep_gemm/sparse_mqa_logits_metadata.hpp"
grep -nE 'ub2gm|ub_to_gm|copy_ub|__gm__|asc_vf_call' "$src/include/deep_gemm/sparse_mqa_logits_metadata.hpp" | tail -n 45
echo __INSPECT_DG_SPARSE_META_SOURCE_END__
