from pathlib import Path
p=Path(__file__).resolve().parent;s=(p/'prepare-norm-archive-deploy.py').read_text(encoding='utf-8')
for old,new in (('archive-norm-backward.py','archive-final-deepgemm-smokes.py'),('deploy-norm-archive.sh','deploy-final-deepgemm-archive.sh'),('__DEPLOY_NORM_ARCHIVE_','__DEPLOY_FINAL_DEEPGEMM_ARCHIVE_')):
 assert old in s;s=s.replace(old,new)
exec(compile(s,str(p/'prepare-norm-archive-deploy.py'),'exec'))
