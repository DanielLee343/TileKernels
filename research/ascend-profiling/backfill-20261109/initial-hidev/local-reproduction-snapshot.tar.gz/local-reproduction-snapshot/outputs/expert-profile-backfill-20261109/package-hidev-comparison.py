import base64,hashlib
from pathlib import Path
HERE=Path(__file__).resolve().parent;data=(HERE/'compare-hidev-same-mode.py').read_bytes()
script="""#!/usr/bin/env bash
set -Eeo pipefail
printf '%s\\n' __HIDEV_SAME_MODE_COMPARE_BEGIN__
root=/workspace/expert-profile-backfill-20261109-hidev
printf '%s' 'PAYLOAD' | base64 -d > \"$root/compare-hidev-same-mode.py\"
printf '%s  %s\\n' HASH \"$root/compare-hidev-same-mode.py\" | sha256sum -c
python3 -B \"$root/compare-hidev-same-mode.py\"
printf '%s\\n' __HIDEV_SAME_MODE_COMPARE_END__
""".replace('PAYLOAD',base64.b64encode(data).decode()).replace('HASH',hashlib.sha256(data).hexdigest())
(HERE/'deploy-and-compare-hidev.sh').write_text(script,encoding='utf-8',newline='\n')
