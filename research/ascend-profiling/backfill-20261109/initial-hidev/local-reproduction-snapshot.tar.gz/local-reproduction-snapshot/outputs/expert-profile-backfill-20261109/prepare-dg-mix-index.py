from pathlib import Path
p=Path(__file__).resolve().parent;s=(p/'summarize-dg-transform.py').read_text()
for old,new in [("glob('transform-*/hidev-npu0/attempt-*/address-audit.json')","glob('gemm-*/hidev-npu0/attempt-*/address-audit.json')"),
 ("a['historical_target_input_and_jit_source_match']","a['historical_true_inputs_and_jit_source_match']"),
 ('deepgemm-transform-index.json','deepgemm-mix-index.json'),('transform captures','mixed GEMM captures')]:
 assert old in s,old;s=s.replace(old,new)
(p/'summarize-dg-mix.py').write_text(s,encoding='utf8',newline='\n')
s=(p/'export-dg-transform-index.sh').read_text()
for old,new in [('summarize-dg-transform.py','summarize-dg-mix.py'),('deepgemm-transform-index.json','deepgemm-mix-index.json'),
                ('DG_TRANSFORM_INDEX','DG_MIX_INDEX')]:assert old in s;s=s.replace(old,new)
(p/'export-dg-mix-index.sh').write_text(s,encoding='utf8',newline='\n')
s=(p/'index-dg-transform.py').read_text()
for old,new in [('deepgemm-transform-index-capture.txt','deepgemm-mix-index-capture.txt'),('DG_TRANSFORM_INDEX','DG_MIX_INDEX'),
 ('deepgemm-transform-index.json','deepgemm-mix-index.json'),('deepgemm-transform-audits','deepgemm-mix-audits'),
 ("a['historical_target_input_and_jit_source_match']","a['historical_true_inputs_and_jit_source_match']"),('transform cases','mixed GEMM cases')]:
 assert old in s,old;s=s.replace(old,new)
(p/'index-dg-mix.py').write_text(s,encoding='utf8',newline='\n')
print('prepared mixed GEMM indexing')
