#!/usr/bin/env bash
echo __INSPECT_DG_MQA_SOURCE_BEGIN__
r=/workspace/deepgemm-ascend-20261107/source/deep_gemm/include/deep_gemm
find "$r" -iname '*mqa*' -maxdepth 2 -type f -printf '%f\n'
grep -n -E 'kv_start|kv_end|kv_range|copy_ub_to_gm|__mix__' "$r/mqa_logits.hpp" | head -n 80 || true
echo __INSPECT_DG_MQA_SOURCE_END__
