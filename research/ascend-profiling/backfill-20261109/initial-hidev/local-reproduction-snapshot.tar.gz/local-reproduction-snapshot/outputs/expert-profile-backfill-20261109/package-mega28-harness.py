import base64,hashlib,io,tarfile
from pathlib import Path
p=Path(__file__).resolve().parent;buf=io.BytesIO()
with tarfile.open(fileobj=buf,mode='w:gz') as t:
 t.add(p/'mega28-profile-harness',arcname='mega28-profile-harness')
 t.add(p/'run-hidev-mega28-detail.sh',arcname='run-hidev-mega28-detail.sh')
data=buf.getvalue();payload=base64.b64encode(data).decode();digest=hashlib.sha256(data).hexdigest()
for i in range(0,len(payload),6000):
 part=i//6000;mode='>' if part==0 else '>>'
 (p/f'deploy-mega28-part-{part}.sh').write_text(f"printf '%s' '{payload[i:i+6000]}' {mode} /workspace/expert-profile-backfill-20261109-hidev/mega28-deploy.b64\nprintf '%s\\n' __HIDEV_MEGA28_PART_{part}__\n",encoding='utf8',newline='\n')
script=f'''set -e
root=/workspace/expert-profile-backfill-20261109-hidev
base64 -d "$root/mega28-deploy.b64" > "$root/mega28-deploy.tar.gz"
echo '{digest}  '"$root/mega28-deploy.tar.gz" | sha256sum -c
if test -e "$root/mega28-profile-harness";then
 test ! -e "$root/mega28-profile-harness/history"
 tar -xzf "$root/mega28-deploy.tar.gz" -C "$root" mega28-profile-harness/history
else
 tar -xzf "$root/mega28-deploy.tar.gz" -C "$root"
fi
printf '%s\\n' __HIDEV_MEGA28_DEPLOY_DONE__
'''
(p/'deploy-mega28-finish.sh').write_text(script,encoding='utf8',newline='\n')
print('archive',len(data),'parts',(len(payload)+5999)//6000,'sha256',digest)
