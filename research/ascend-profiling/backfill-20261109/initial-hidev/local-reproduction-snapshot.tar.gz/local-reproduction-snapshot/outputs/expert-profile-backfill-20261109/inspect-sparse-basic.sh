echo __SPARSE_BASIC_BEGIN__
p=/workspace/expert-profile-backfill-20261109-hidev/deepgemm-runs/sparse-fp8-q4-k256-h8-b8/hidev-npu0/attempt-001
python3 - "$p" <<'PY'
import csv,sys
from pathlib import Path
f,=list(Path(sys.argv[1]).rglob('OpBasicInfo.csv'))
with f.open(encoding='utf-8-sig',newline='') as fp:r,=list(csv.DictReader(fp))
for k in ('Op Name','Op Type','Block Dim','Mix Block Dim','Device Id'):print(k,r[k])
PY
echo __SPARSE_BASIC_END__
