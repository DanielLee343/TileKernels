#!/usr/bin/env bash
echo __CHECK_NORM_BACKWARD_WEIGHT_TEST_BEGIN__
r=/workspace/expert-profile-backfill-20261109-hidev
ps -p "$(cat "$r/norm-backward-weight-test.pid")" -o pid=,stat=,args= || true
tail -n 12 "$r/norm-backward-weight-test.log"
echo __CHECK_NORM_BACKWARD_WEIGHT_TEST_END__
