"""Prepare isolated, checksummed two-case DeepGEMM profiling package."""
import base64,hashlib,io,tarfile
from pathlib import Path
HERE=Path(__file__).resolve().parent
files={name:HERE/name for name in ('guard-v3.py','run-hidev-deepgemm-smoke.sh','inspect-deepgemm-capture.py')}
files.update({p.relative_to(HERE).as_posix():p for p in (HERE/'deepgemm-profile-harness').rglob('*') if p.is_file()})
buf=io.BytesIO()
with tarfile.open(fileobj=buf,mode='w:gz') as tar:
 for name,path in sorted(files.items()):tar.add(path,arcname=name,recursive=False)
payload=base64.b64encode(buf.getvalue()).decode('ascii')
for idx in range(0,len(payload),5000):
 part=idx//5000
 body=('mkdir -p /workspace/expert-profile-backfill-20261109-hidev\n'
       +(': > /workspace/expert-profile-backfill-20261109-hidev/deepgemm-package.b64\n' if part==0 else '')
       +"printf '%s' '"+payload[idx:idx+5000]+"' >> /workspace/expert-profile-backfill-20261109-hidev/deepgemm-package.b64\n"
       +f"printf '%s\\n' __HIDEV_DEEPGEMM_PART_{part:02d}_DONE__\n")
 (HERE/f'deploy-hidev-deepgemm-part-{part:02d}.sh').write_text(body,encoding='utf-8',newline='\n')
hashes='\n'.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+name for name,p in sorted(files.items()))
script="""#!/usr/bin/env bash
set -Eeo pipefail
cd /workspace/expert-profile-backfill-20261109-hidev
test ! -e deepgemm-package.done
printf '%s  %s\\n' PACKAGE_HASH deepgemm-package.b64 | sha256sum -c
base64 -d deepgemm-package.b64 | tar -xz
cat > deepgemm-package-sha256.txt <<'EOF'
HASHES
EOF
sha256sum -c deepgemm-package-sha256.txt
touch deepgemm-package.done
printf '%s\\n' __HIDEV_DEEPGEMM_DEPLOY_DONE__
""".replace('PACKAGE_HASH',hashlib.sha256(payload.encode()).hexdigest()).replace('HASHES',hashes)
(HERE/'deploy-hidev-deepgemm-final.sh').write_text(script,encoding='utf-8',newline='\n')
print('files',len(files),'bytes',len(buf.getvalue()),'parts',(len(payload)+4999)//5000)
