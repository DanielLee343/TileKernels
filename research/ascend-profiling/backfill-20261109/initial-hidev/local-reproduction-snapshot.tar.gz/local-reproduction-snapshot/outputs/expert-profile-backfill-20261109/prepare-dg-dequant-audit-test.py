from pathlib import Path
p=Path(__file__).resolve().parent;s=(p/'test-dg-mix-audit.sh').read_text()
for old,new in [('gemm-fp4fp4-nn-mn-m64-n576-k7168','gemm-fp8fp4-nt-k-m4096-n576-k7168'),
                ('audit-deepgemm-mix-general.py','audit-deepgemm-dequant.py'),
                ('DG_MIX_AUDIT_TEST','DG_DEQUANT_AUDIT_TEST'),
                ("rows[1]['UB_to_GM_datas(KB)']","rows[2]['UB_to_GM_datas(KB)']")]:
 assert old in s;s=s.replace(old,new)
(p/'test-dg-dequant-audit.sh').write_text(s,encoding='utf8',newline='\n')
print('candidate negative tests prepared; run only after successful smoke audit')
