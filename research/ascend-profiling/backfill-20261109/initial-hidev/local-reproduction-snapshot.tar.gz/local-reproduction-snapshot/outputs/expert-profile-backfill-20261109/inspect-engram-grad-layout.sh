echo __ENGRAM_GRAD_LAYOUT_BEGIN__
p=/workspace/expert-profile-backfill-20261109-hidev/extra-proxy-runs/unified-extra/engram_grad_w_reduce-01/hidev-npu0/attempt-001/detail
python3 - "$p" <<'PY'
import json,sys
from pathlib import Path
p=Path(sys.argv[1]);d=json.loads((p/'capture-inspection.json').read_text());pid=d['representative_pid'];a=json.loads((p/('tensor-addresses-'+pid+'.json')).read_text())
for i,x in enumerate(a):print('TENSOR',i,json.dumps(x))
for i,line in enumerate((p/('generated-kernel-'+pid+'.cpp')).read_text().splitlines(),1):
 if 'asc_copy_ub2gm' in line:print('SOURCE',i,line[:1500])
n=0
for line in (p/'profile.log').read_text(errors='replace').splitlines():
 if 'DBI record core:' in line and 'dst:(type:GM;' in line and 'src:(type:UB;' in line:
  print('STORE',line);n+=1
  if n>=5:break
PY
echo __ENGRAM_GRAD_LAYOUT_END__
