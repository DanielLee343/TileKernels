"""Prepare quantized norm audit using its actual packed scale storage."""
from pathlib import Path
p=Path(__file__).resolve().parent;s=(p/'audit-extra-channel.py').read_text()
outsetup="""assert len(a)==8 and a[0] and a[1] and a[2] and a[3] and a[5] and all(a[i] is None for i in (4,6,7))
manifest=json.loads((p/'provenance/cases.json').read_text())['cases']
selected,=(x for x in manifest if x['target_id']=='unified-extra3/'+case);params=selected['params'];n=params['num_tokens']
sf=dict(a[2]);assert params['use_packed_ue8m0'] and params['use_tma_aligned_col_major_sf']
assert sf['dtype']=='torch.uint8' and len(sf['shape'])==3 and sf['shape'][0]==1 and sf['shape'][-1]==2*n
sf['logical_bytes']=__import__('math').prod(sf['shape'])*sf['element_size']
outputs=[a[1],sf,a[3],a[5]]
def span(t):
 lo=int(t['address'],16);hi=lo+t['element_size']*(1+sum((n-1)*stride for n,stride in zip(t['shape'],t['stride'])))
 return lo,hi
all_tensors=[a[0]]+outputs
for i,x in enumerate(all_tensors):
 for y in all_tensors[i+1:]:
  l1,h1=span(x);l2,h2=span(y);assert h1<=l2 or h2<=l1,'input/output buffer overlap'"""
check="""assert 'block_idx' in source
for name in ('out[','out_bf16[','out_sf_words','rstd['):assert name in source,name
scale_line,=(x for x in source.splitlines() if 'asc_copy_ub2gm_align(' in x and 'out_sf_words' in x)
assert '__gm__ uint16_t*' in scale_line and '* 2)' in scale_line"""
edits=[
 ("assert re.fullmatch(r'quant_per_channel_cast-(0[1-9]|1[0-9]|20)',case)","assert case=='quant_norm_forward-05'"),
 ("p=root/'extra-proxy-runs'/'unified-extra2'/case/", "p=root/'extra-proxy-runs'/'unified-extra3'/case/"),
 ("assert len(a)==4 and a[1] and a[2]",outsetup),
 ("source.count('asc_copy_ub2gm_align(')==2", "source.count('asc_copy_ub2gm_align(')==4"),
 ("assert ('out_sf[' in source or 'out_sf)[' in source) and ('out[' in source or 'out)[' in source) and 'block_idx' in source",check),
 ('a[1:3]','outputs'),
 ('actual=[[],[]];percore','actual=[[],[],[],[]];percore'),
 ('for i in (0,1)','for i in (0,1,2,3)'),
 ("'target':'unified-extra2/'+case", "'target':'unified-extra3/'+case"),
 ("p/'audit-result.json'", "p/'candidate-audit-result.json'")]
for old,new in edits:assert old in s,old;s=s.replace(old,new)
(p/'audit-extra-norm-forward-05.py').write_text(s,encoding='utf8',newline='\n')
print('quantized norm candidate prepared; packed scale storage uses two bytes per token per row')
