"""Prepare capture-only metadata instrumentation for structurally compatible adapters.

No kernel or upstream correctness code is changed. Each group still requires
its own representative capture and a source-aware address completeness audit.
"""
import ast,csv,hashlib,json,re
from pathlib import Path
p=Path(__file__).resolve().parent;repo=p.parents[1]/'TileKernels-private'
src=repo/'research/ascend-profiling/collector/unified';out=p/'extra-proxy-harness';out.mkdir(exist_ok=True)
survey=json.loads((p/'extra-proxy-survey.json').read_text())['adapters'];selected={x['adapter'] for x in survey if x['single_injection_candidate'] and x['manifest']!='extra6_cases.json'}
records=[]
for name in sorted(selected):
 path=src/name;text=path.read_text(encoding='utf8');tree=ast.parse(text)
 runs=[x for x in tree.body if isinstance(x,ast.FunctionDef) and x.name=='run'];assert len(runs)==1
 args=[x.arg for x in runs[0].args.args];assert args[:3]==['group','params','stage'] and args[3] in ('record','record_path');record=args[3]
 roots=[x for x in tree.body if isinstance(x,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='ROOT' for t in x.targets)]
 assert len(roots)==1 and roots[0].lineno==roots[0].end_lineno
 proxies=[x for x in ast.walk(tree) if isinstance(x,ast.ClassDef) and x.name=='Proxy'];matches=[]
 for proxy in proxies:
  for method in proxy.body:
   if isinstance(method,ast.FunctionDef) and method.name=='__call__' and method.args.vararg and method.args.vararg.arg=='tensors':
    for stmt in ast.walk(method):
     if isinstance(stmt,(ast.Assign,ast.AugAssign)) and "state['matched']" in ast.get_source_segment(text,stmt).replace('"',"'"):matches.append(stmt)
 assert len(matches)==1 and matches[0].lineno==matches[0].end_lineno,(name,len(matches))
 lines=text.splitlines(keepends=True);idx=matches[0].lineno-1;indent=re.match(r'^\s*',lines[idx]).group()
 injected=f'''{indent}if stage == 'default':
{indent}    _puma_meta=[]
{indent}    for _puma_tensor in tensors:
{indent}        if isinstance(_puma_tensor, torch.Tensor):
{indent}            _puma_meta.append({{'address':hex(_puma_tensor.data_ptr()),'device':str(_puma_tensor.device),
{indent}                'shape':list(_puma_tensor.shape),'stride':list(_puma_tensor.stride()),'dtype':str(_puma_tensor.dtype),
{indent}                'element_size':_puma_tensor.element_size(),'logical_bytes':_puma_tensor.numel()*_puma_tensor.element_size()}})
{indent}        else:_puma_meta.append(None)
{indent}    Path({record}).with_name('tensor-addresses.json').write_text(json.dumps(_puma_meta,indent=2)+'\\n')
{indent}    Path({record}).with_name('generated-kernel.cpp').write_text(kernel.get_kernel_source())
'''
 lines.insert(idx+1,injected)
 ridx=roots[0].lineno-1;assert ridx<idx;lines[ridx]="ROOT = Path(os.environ['TILEKERNELS_ROOT'])\n"
 modified=''.join(lines);compile(modified,str(out/name),'exec');(out/name).write_text(modified,encoding='utf8',newline='\n')
 records.append({'adapter':name,'original_sha256':hashlib.sha256(text.encode()).hexdigest(),
  'instrumented_sha256':hashlib.sha256(modified.encode()).hexdigest(),'insertion_line':idx+1,'record_argument':record})
with (p.parents[1]/'outputs/expert-profile-inventory-20261109/captures.csv').open(encoding='utf-8-sig',newline='') as f:
 inventory={x['target_id']:x for x in csv.DictReader(f) if x['batch']=='tilekernels-default'}
cases=[]
for manifest in sorted(src.glob('extra*_cases.json')):
 if manifest.name=='extra6_cases.json':continue
 prefix=manifest.name.replace('_cases.json','').replace('extra','unified-extra',1)
 for x in json.loads(manifest.read_text(encoding='utf8'))['cases']:
  key=prefix+'/'+x['id']
  if x['adapter'] not in selected or key not in inventory:continue
  row=inventory[key];meta=Path(row['profile_path']).parent.parent/'default.json'
  if not (p.parents[1]/meta).is_file():continue
  cases.append(x|{'target_id':key,'historical_metadata':str(meta).replace('\\','/'),'historical_op_name':row['op_name']})
assert len({x['target_id'] for x in cases})==len(cases)
(out/'cases.json').write_text(json.dumps({'cases':cases},indent=2)+'\n',encoding='utf8')
(out/'provenance.json').write_text(json.dumps({'adapter_count':len(records),'case_count':len(cases),'adapters':records,
 'change':'require configured checkout and record native argument addresses and generated source before the target call',
 'limitations':'stateful replay and per-group address completeness need independent verification; no automatic admission'},indent=2)+'\n',encoding='utf8')
print('prepared',len(records),'adapters and',len(cases),'baseline cases; not yet run')
