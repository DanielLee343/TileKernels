#!/usr/bin/env bash
printf '%s\n' __UQ_SFONLY_FIRST_AUDIT_BEGIN__
root=/workspace/expert-profile-backfill-20261109-hidev
python3 -B "$root/audit-uq-sfonly.py" quant_per_token_cast_with_sf_only-01 attempt-001
printf '%s\n' __UQ_SFONLY_FIRST_AUDIT_END__
