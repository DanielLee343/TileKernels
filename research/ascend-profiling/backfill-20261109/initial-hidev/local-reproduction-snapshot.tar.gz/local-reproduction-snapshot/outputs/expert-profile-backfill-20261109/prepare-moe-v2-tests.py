from pathlib import Path
p=Path(__file__).resolve().parent
orig=(p/'test-moe-backward-audit.sh').read_text(encoding='utf-8')
for n in ('01','02'):
 s=orig.replace('audit-extra-moe-backward-candidate.py','audit-extra-moe-backward-v2.py')
 s=s.replace('moe_topk_gate_backward-01','moe_topk_gate_backward-'+n)
 s=s.replace('__MOE_BACKWARD_AUDIT_TEST_',f'__MOE_BACKWARD_AUDIT_V2_{n}_TEST_')
 (p/f'test-moe-backward-v2-{n}.sh').write_text(s,encoding='utf-8',newline='\n')
