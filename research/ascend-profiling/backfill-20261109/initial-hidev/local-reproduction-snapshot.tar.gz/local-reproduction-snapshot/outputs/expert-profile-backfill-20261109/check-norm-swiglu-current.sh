#!/usr/bin/env bash
set -u
echo __CHECK_NORM_SWIGLU_CURRENT_BEGIN__
root=/workspace/expert-profile-backfill-20261109-hidev
for name in extra-norm-forward-queue-hidev-npu0 extra-swiglu-variants-smoke-hidev-npu0; do
 q="$root/$name"
 echo "--- $name ---"
 if test -f "$q/pid"; then ps -p "$(cat "$q/pid")" -o pid=,stat=,args= || true; fi
 test ! -f "$q/exit.txt" || cat "$q/exit.txt"
 test ! -f "$q/console.log" || tail -n 25 "$q/console.log"
done
echo __CHECK_NORM_SWIGLU_CURRENT_END__
