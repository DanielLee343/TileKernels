#!/usr/bin/env bash
echo __INSPECT_DG_MQA_RANGES_VALUES_BEGIN__
p=/workspace/expert-profile-backfill-20261109-hidev/deepgemm-runs/mqa-0-q16-k512-h8-random/hidev-npu0/attempt-002
python3 - "$p" <<'PY'
import struct,sys,json
from pathlib import Path
p=Path(sys.argv[1]);a=json.loads((p/'profile-addresses.json').read_text())[0]['returned']
print('output',a)
for label in ('start','end'):
 b=(p/('mqa-range-'+label+'.bin')).read_bytes();print(label,list(struct.unpack('<'+'i'*(len(b)//4),b)))
PY
echo __INSPECT_DG_MQA_RANGES_VALUES_END__
