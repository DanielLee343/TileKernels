#!/usr/bin/env bash
echo __PAGED_MQA_DETAILS_BEGIN__
p=/workspace/expert-profile-backfill-20261109-hidev/deepgemm-runs/paged-mqa-fp8-b2-k256-h8-d128-p64/hidev-npu0/attempt-001
python3 - "$p" <<'PY'
import json,sys
from pathlib import Path
p=Path(sys.argv[1])
for n in ('profile-addresses.json','capture-inspection.json'):
 d=json.loads((p/n).read_text())
 if n.startswith('capture'):
  d={k:d.get(k) for k in ('case','correctness','historical_true_inputs_match','historical_jit_source_sha256_match','capture','all_dbi_records','ub_to_gm_records','raw_store_core_labels')}
 print(n,json.dumps(d,indent=2))
print('JIT SOURCE')
print((p/'jit/kernel.asc').read_text()[:5000])
print('STORE LINES')
for line in (p/'detail/profile.log').read_text(errors='replace').splitlines():
 if 'DBI record core:' in line and 'dst:(type:GM;' in line and 'src:(type:UB;' in line:
  print(line[:1000]);break
PY
echo __PAGED_MQA_DETAILS_END__
