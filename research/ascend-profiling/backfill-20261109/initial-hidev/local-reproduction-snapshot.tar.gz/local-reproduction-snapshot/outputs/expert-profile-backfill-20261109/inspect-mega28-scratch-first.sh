#!/usr/bin/env bash
printf '%s\n' __MEGA_SCRATCH_FIRST_BEGIN__
python3 - <<'PY'
import json,re,collections
from pathlib import Path
from importlib.machinery import SourceFileLoader
root=Path('/workspace/expert-profile-backfill-20261109-hidev')
p=root/'mega28-runs/mega-h256-i512-e4-top2-t16/hidev-npu0/attempt-004'
a=json.loads((p/'profile-addresses-325752.json').read_text());views=a['symmetric_buffer_views']
rr={k:(int(v['address'],16),int(v['address'],16)+v['bytes']) for k,v in views.items() if k in ('l1_acts','l1_acts_sf','l2_acts','l2_acts_sf')}
l2end=rr['l2_acts_sf'][1];ring_rows=views['l1_acts']['shape'][0];hidden=256
combine=((l2end+511)//512)*512+ring_rows*hidden*2
rr['combine']=(combine,combine+16*2*hidden*2)
rr['output']=(int(a['output']['address'],16),int(a['output']['address'],16)+a['output']['bytes'])
log=(p/'detail/profile.log').read_text(errors='replace');segments=re.split(r'(?=\[DEBUG\].*Application mode count is \d+, dbiFlag is 0x[0-9a-f]+)',log)
stage,=[s for s in segments if 'DBI record core:' in s]
R=SourceFileLoader('r',str(root/'audit-reduce-family.py')).load_module().REGEX
intervals=collections.defaultdict(list);unmapped=[]
for c,pc,addr,stride,l1s,l2s,srcaddr,srcstride,srcl1s,srcl2s,burst,length,dtype,l1,l2,left,right in R.findall(stage):
 addr=int(addr,16);stride=int(stride);l1s=int(l1s);l2s=int(l2s);length=int(length)
 for z in range(int(l2)):
  for y in range(int(l1)):
   for x in range(int(burst)):
    lo=addr+z*l2s+y*l1s+x*stride;hi=lo+length
    labels=[k for k,(start,end) in rr.items() if start<=lo and hi<=end]
    if len(labels)!=1:unmapped.append((hex(lo),hex(hi),labels));continue
    intervals[labels[0]].append((lo,hi))
print('unmapped=',len(unmapped),unmapped[:3])
for k,values in intervals.items():
 values.sort();overlaps=sum(b0<a1 for (_,a1),(b0,_) in zip(values,values[1:]))
 print(k,'range=',tuple(hex(n) for n in rr[k]),'pieces=',len(values),'bytes=',sum(hi-lo for lo,hi in values),'overlap_pairs=',overlaps)
 if k in ('l1_acts','l2_acts'):
  width={'l1_acts':256,'l2_acts':512}[k];rows=collections.Counter()
  for lo,hi in values:
   off=lo-rr[k][0];row=off//width
   if (hi-1-rr[k][0])//width!=row:raise AssertionError('cross-row')
   rows[row]+=hi-lo
  print(k,'rows=',len(rows),'minmax_row_bytes=',(min(rows.values()),max(rows.values())),'row_indices=',sorted(rows))
def byteset(items):
 return {j for lo,hi in items for j in range(lo,hi)}
def expected_full_rows(key,width,rows):
 return {rr[key][0]+r*width+x for r in rows for x in range(width)}
l1base=rr['l1_acts'][0]
rows={((lo-l1base)//256) for lo,hi in intervals['l1_acts']}
assert len(rows)==16*2
assert byteset(intervals['l1_acts'])==expected_full_rows('l1_acts',256,rows)
assert byteset(intervals['l1_acts_sf'])==expected_full_rows('l1_acts_sf',8,rows)
assert byteset(intervals['l2_acts'])==expected_full_rows('l2_acts',512,rows)
expected_sf={rr['l2_acts_sf'][0]+2*((r//256)*256*8+sf*256+(r%256))+b for r in rows for sf in range(8) for b in (0,1)}
assert byteset(intervals['l2_acts_sf'])==expected_sf
for key in ('combine','output'):
 assert byteset(intervals[key])==set(range(*rr[key]))
for key,values in intervals.items():
 assert sum(hi-lo for lo,hi in values)==len(byteset(values)),key
print('PASS first case: six destinations exactly cover expected bytes with no overlap; 32 active rows, known single-rank route contract')
PY
printf '%s\n' __MEGA_SCRATCH_FIRST_END__
