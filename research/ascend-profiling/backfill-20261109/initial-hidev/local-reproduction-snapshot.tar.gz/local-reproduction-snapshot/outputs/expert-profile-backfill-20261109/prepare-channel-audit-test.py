from pathlib import Path
p=Path(__file__).resolve().parent;s=(p/'test-uq-sfonly-audit.sh').read_text()
for old,new in [('quant_per_token_cast_with_sf_only','quant_per_channel_cast'),
                ('unified-quant-runs/quant_per_channel_cast','extra-proxy-runs/unified-extra2/quant_per_channel_cast'),
                ('audit-uq-sfonly.py','audit-extra-channel.py'),
                ('UQ_SFONLY_AUDIT_TEST','CHANNEL_AUDIT_TEST')]:
 assert old in s;s=s.replace(old,new)
(p/'test-channel-audit.sh').write_text(s,encoding='utf8',newline='\n')
print('prepared negative tests for per-channel audit')
