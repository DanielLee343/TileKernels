#!/usr/bin/env bash
echo __CHECK_NORM_AND_ENGRAM_TESTS_BEGIN__
r=/workspace/expert-profile-backfill-20261109-hidev
for n in norm-backward-noweight-tests engram-gate-fwd-test;do
 echo "--- $n ---";ps -p "$(cat "$r/$n.pid")" -o pid=,stat=,args= || true;tail -n 10 "$r/$n.log"
done
echo __CHECK_NORM_AND_ENGRAM_TESTS_END__
