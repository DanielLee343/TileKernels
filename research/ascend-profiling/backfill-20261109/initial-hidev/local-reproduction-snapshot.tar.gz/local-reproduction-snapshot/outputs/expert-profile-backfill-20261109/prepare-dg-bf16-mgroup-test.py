from pathlib import Path
p=Path(__file__).resolve().parent
s=(p/'test-dg-mgroup-audit.sh').read_text().replace('mgroup-fp8fp8-nt-g4-m128-n256-k512','mgroup-bf16bf16-nt-g4-m128-n256-k512')
s=s.replace('audit-deepgemm-mgroup.py','audit-dg-bf16-mgroup-candidate.py').replace('DG_MGROUP_AUDIT_TEST','DG_BF16_MGROUP_AUDIT_TEST')
(p/'test-dg-bf16-mgroup-audit.sh').write_text(s,encoding='utf8',newline='\n')
print('prepared BF16 source-specific negative checks')
