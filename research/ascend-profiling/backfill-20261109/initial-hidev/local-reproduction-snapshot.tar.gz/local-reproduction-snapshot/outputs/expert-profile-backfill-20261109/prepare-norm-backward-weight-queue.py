from pathlib import Path
p=Path(__file__).resolve().parent
a=(p/'audit-extra-norm-backward-weight-candidate.py').read_text();old="p/'candidate-audit-result.json'";assert old in a
(p/'audit-extra-norm-backward-weight.py').write_text(a.replace(old,"p/'audit-result.json'"),encoding='utf8',newline='\n')
r=(p/'run-hidev-extra-norm-backward-noweight.sh').read_text().replace('not p[\'use_weight\']',"p['use_weight']")
r=r.replace('$root/run-hidev-extra-norm-backward-noweight.sh','$root/run-hidev-extra-norm-backward-weight.sh')
(p/'run-hidev-extra-norm-backward-weight.sh').write_text(r,encoding='utf8',newline='\n')
s=(p/'hidev-extra-norm-backward-noweight-queue.py').read_text()
s=s.replace('extra-norm-backward-noweight-queue','extra-norm-backward-weight-queue')
s=s.replace("not x['params']['use_weight']","x['params']['use_weight']").replace('assert len(items)==9','assert len(items)==2')
s=s.replace('run-hidev-extra-norm-backward-noweight.sh','run-hidev-extra-norm-backward-weight.sh')
s=s.replace('audit-extra-norm-backward-noweight.py','audit-extra-norm-backward-weight.py')
s=s.replace('ALL_NORM_BACKWARD_NOWEIGHT_SELECTED_AUDITED','ALL_NORM_BACKWARD_WEIGHT_SELECTED_AUDITED')
(p/'hidev-extra-norm-backward-weight-queue.py').write_text(s,encoding='utf8',newline='\n')
print('prepared the two weighted, non-accumulating backward cases')
