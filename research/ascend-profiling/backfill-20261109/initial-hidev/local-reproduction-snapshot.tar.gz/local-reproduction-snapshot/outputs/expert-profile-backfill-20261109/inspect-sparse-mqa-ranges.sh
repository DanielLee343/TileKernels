echo __SPARSE_MQA_RANGES_BEGIN__
p=/workspace/expert-profile-backfill-20261109-hidev/deepgemm-runs/sparse-fp8-q4-k256-h8-b8/hidev-npu0/attempt-001
python3 - "$p" <<'PY'
from pathlib import Path
import struct,sys
p=Path(sys.argv[1]);b=(p/'sparse-mqa-metadata.bin').read_bytes();cap,physical,offs,sched=struct.unpack_from('<I4xQQQ',b)
print('cap',cap,'offset',offs,'ranges',[(v&65535,v>>16) for v in struct.unpack_from('<4I',b,offs)])
for line in (p/'detail/profile.log').read_text(errors='replace').splitlines():
 if 'DBI record core:' in line and 'dst:(type:GM;' in line and 'src:(type:UB;' in line:print(line)
PY
echo __SPARSE_MQA_RANGES_END__
