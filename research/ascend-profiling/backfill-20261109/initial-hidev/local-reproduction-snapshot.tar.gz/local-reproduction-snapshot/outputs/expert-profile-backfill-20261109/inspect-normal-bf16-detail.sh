echo __NORMAL_BF16_DETAIL_BEGIN__
p=/workspace/expert-profile-backfill-20261109-hidev/deepgemm-runs/gemm-bf16bf16-nt-k-m4096-n576-k7168/hidev-npu0/attempt-001
python3 - "$p" <<'PY'
import json,sys
from pathlib import Path
p=Path(sys.argv[1]);a,=json.loads((p/'profile-addresses.json').read_text());print(json.dumps(a,indent=2));print((p/'jit/kernel.asc').read_text()[:1300])
PY
echo __NORMAL_BF16_DETAIL_END__
