"""List pending main targets with one historical profile; survey does not accept them."""
import csv,json
from pathlib import Path
p=Path(__file__).resolve().parent
with (p/'targets.csv').open(encoding='utf-8-sig',newline='') as f:rows=list(csv.DictReader(f))
selected=[]
for x in rows:
 if x['batch'] not in ('tilekernels-default','tilekernels-precision') or x['per_core_requested_bytes_status']!='pending':continue
 paths=x['original_profile_paths'].split(';')
 if len(paths)!=1 or not paths[0].startswith('TileKernels-private/research/ascend-profiling/'):continue
 selected.append({'target':x['target_id'],'op_name':x['op_name'],'op_type':x['op_type'],
                  'profile':paths[0].removeprefix('TileKernels-private/')})
assert len({x['target'] for x in selected})==len(selected)
(p/'main-pending-isa-survey-input.json').write_text(json.dumps({'cases':selected},indent=2)+'\n',encoding='utf8')
print('prepared',len(selected),'pending targets; survey only')
