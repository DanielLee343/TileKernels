from pathlib import Path
p=Path(__file__).resolve().parent
audit=(p/'audit-deepgemm-mgroup.py').read_text();old="assert case=='mgroup-fp8fp8-nt-g4-m128-n256-k512'"
assert old in audit;audit=audit.replace(old,"assert re.fullmatch(r'mgroup-fp(?:4|8)fp(?:4|8)-[a-z0-9-]+',case)")
(p/'audit-deepgemm-mgroup-batch.py').write_text(audit,encoding='utf8',newline='\n')
s=(p/'hidev-dg-transform-queue.py').read_text()
for old,new in [('deepgemm-transform-queue','deepgemm-mgroup-queue'),
                ('deepgemm-transform-harness','deepgemm-mgroup-harness'),
                ("assert len(items)==14","assert len(items)==6"),
                ("x['target']=='transform_sf'","x['target']=='fp8_gemm_impl'"),
                ('run-hidev-deepgemm-transform.sh','run-hidev-deepgemm-mgroup.sh'),
                ('inspect-deepgemm-transform.py','inspect-deepgemm-mgroup.py'),
                ('audit-deepgemm-transform-general.py','audit-deepgemm-mgroup-batch.py'),
                ('ALL_DG_TRANSFORM_SELECTED_AUDITED','ALL_DG_MGROUP_SELECTED_AUDITED')]:
 assert old in s,old;s=s.replace(old,new)
(p/'hidev-dg-mgroup-queue.py').write_text(s,encoding='utf8',newline='\n')
print('grouped GEMM queue prepared; all six cases retain individual gates')
