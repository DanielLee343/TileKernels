"""Index audited hidev windows separately, retaining recorded device alarm."""
import json
from pathlib import Path
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
index=json.loads((HERE/'hidev-capture-index.json').read_text());assert index['count']==len(index['cases'])
out=HERE/'hidev-audit-records';out.mkdir(exist_ok=True);captures={}
for item in index['cases']:
 audit=item['audit'];target=item['target'];assert audit['status']=='passed' and audit['correctness']=='passed'
 assert audit['historical_input_and_source_match'] and item['device_health']=='Alarm 8C4BA00C'
 expected=audit.get('expected_ub_to_gm_bytes',audit.get('expected_written_bytes',audit['output_logical_bytes']))
 assert audit['dbi_requested_bytes']==expected
 p=out/(target.replace('/','__')+'.json');p.write_text(json.dumps(audit,indent=2)+'\n',encoding='utf-8')
 captures[target]={'audit':p.relative_to(ROOT).as_posix(),'remote_detail':item['raw_dir'],
                   'device':'hidev NPU 0','health':item['device_health'],'files_sha256':item['files_sha256'],
                   'reaudit_status':item.get('reaudit_status')}
(HERE/'new-captures-hidev.json').write_text(json.dumps(captures,indent=2)+'\n',encoding='utf-8')
print('indexed',len(captures),'address-audited hidev captures with health label')
