#!/usr/bin/env bash
echo __CHECK_EXTRA5_SNAPSHOT_BEGIN__
r=/workspace/expert-profile-backfill-20261109-hidev
ps -p "$(cat "$r/extra5-snapshot.pid")" -o pid=,stat=,args= || true
tail -n 8 "$r/extra5-snapshot.log"
test ! -f "$r/extra-proxy-unified-extra5-snapshot-archive-bundle.tar.gz" || ls -lh "$r/extra-proxy-unified-extra5-snapshot-archive-bundle.tar.gz"
echo __CHECK_EXTRA5_SNAPSHOT_END__
