from pathlib import Path
p=Path(__file__).resolve().parent
a=(p/'audit-extra-norm-backward-noweight-candidate.py').read_text();old="p/'candidate-audit-result.json'";assert old in a
(p/'audit-extra-norm-backward-noweight.py').write_text(a.replace(old,"p/'audit-result.json'"),encoding='utf8',newline='\n')
r=(p/'run-hidev-extra-norm-backward-variants.sh').read_text()
old='test "$group" = quant_norm_backward; [[ "$target" =~ ^unified-extra3/quant_norm_backward-(03|06|07)$ ]]'
new='''test "$group" = quant_norm_backward
python3 - "$root/extra-proxy-harness/cases.json" "$target" <<'PYCHECK'
import json,sys
with open(sys.argv[1]) as f:d=json.load(f)
selected,=(x for x in d['cases'] if x['target_id']==sys.argv[2]);p=selected['params']
assert selected['group']=='quant_norm_backward' and not p['accumulate'] and not p['use_weight'] and p['weight_grad_fmt'] is None
PYCHECK'''
assert old in r;r=r.replace(old,new).replace('$root/run-hidev-extra-norm-backward-variants.sh','$root/run-hidev-extra-norm-backward-noweight.sh')
(p/'run-hidev-extra-norm-backward-noweight.sh').write_text(r,encoding='utf8',newline='\n')
s=(p/'hidev-extra-norm-forward-queue.py').read_text()
for old,new in [('quant_norm_forward','quant_norm_backward'),('extra-norm-forward-queue','extra-norm-backward-noweight-queue'),
                ('run-hidev-extra-norm-forward-detail.sh','run-hidev-extra-norm-backward-noweight.sh'),
                ('inspect-extra-norm-forward.py','inspect-extra-norm-backward.py'),
                ('audit-extra-norm-forward-general.py','audit-extra-norm-backward-noweight.py'),
                ('ALL_NORM_FORWARD_SELECTED_AUDITED','ALL_NORM_BACKWARD_NOWEIGHT_SELECTED_AUDITED')]:
 assert old in s,old;s=s.replace(old,new)
old="if x['group']=='quant_norm_backward'];assert len(items)==20"
new="if x['group']=='quant_norm_backward' and not x['params']['accumulate'] and not x['params']['use_weight'] and x['params']['weight_grad_fmt'] is None];assert len(items)==9"
assert old in s;s=s.replace(old,new)
(p/'hidev-extra-norm-backward-noweight-queue.py').write_text(s,encoding='utf8',newline='\n')
print('prepared nine non-accumulating, unweighted cases only')
