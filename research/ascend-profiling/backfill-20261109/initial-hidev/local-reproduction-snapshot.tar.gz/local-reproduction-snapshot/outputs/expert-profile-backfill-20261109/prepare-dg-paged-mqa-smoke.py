from pathlib import Path
p=Path(__file__).resolve().parent;s=(p/'prepare-dg-bf16-mgroup-smoke.py').read_text()
for old,new in [('bf16-mgroup','paged-mqa'),
                ("r['case'].startswith('campaign-13/mgroup-bf16')","(r['case'].startswith('campaign-13/paged-mqa-') or r['case'].startswith('campaign-13/paged_mqa_logits_impl-'))"),
                ('bf16_gemm_impl','paged_mqa_logits_impl'),('mgroup-bf16bf16-[a-z0-9-]+','paged[-_][a-z0-9_-]+'),
                ('len(manifest[\'cases\'])==len(ids)==3','len(manifest[\'cases\'])==len(ids)==8'),
                ("'case_count':3","'case_count':8"),('BF16 M-group','paged MQA logits')]:
 assert old in s,old;s=s.replace(old,new)
exec(compile(s,str(p/'prepare-dg-bf16-mgroup-smoke.py'),'exec'))
