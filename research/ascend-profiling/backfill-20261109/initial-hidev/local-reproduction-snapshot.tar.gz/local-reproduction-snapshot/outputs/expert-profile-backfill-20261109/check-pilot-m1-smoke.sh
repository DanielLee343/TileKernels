echo __CHECK_PILOT_M1_BEGIN__
q=/workspace/expert-profile-backfill-20261109-hidev/deepgemm-pilot-m1-smoke-hidev-npu0
ps -p "$(cat "$q/pid")" -o pid,stat,etime,args || true
test ! -f "$q/exit.txt" || cat "$q/exit.txt"
grep -E 'case=|PILOT_M1_IDENTITY|ALL_PILOT|Traceback|Error|AssertionError' "$q/console.log" | tail -n 12 || true
tail -n 5 "$q/console.log"
echo __CHECK_PILOT_M1_END__
