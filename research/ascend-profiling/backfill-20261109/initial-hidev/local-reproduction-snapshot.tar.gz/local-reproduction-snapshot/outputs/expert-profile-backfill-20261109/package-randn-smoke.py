import base64,hashlib,io,tarfile
from pathlib import Path
p=Path(__file__).resolve().parent;b=io.BytesIO()
with tarfile.open(fileobj=b,mode='w:gz') as t:
 for name in ('extra-proxy-randn-harness','run-hidev-extra-randn-detail.sh','inspect-extra-randn.py'):
  t.add(p/name,arcname=name,filter=lambda info:None if '__pycache__' in info.name else info)
data=b.getvalue();encoded=base64.b64encode(data).decode();digest=hashlib.sha256(data).hexdigest()
for i in range(0,len(encoded),5500):
 part=i//5500;mode='>' if part==0 else '>>'
 (p/f'deploy-randn-part-{part}.sh').write_text(f"printf '%s' '{encoded[i:i+5500]}' {mode} /workspace/expert-profile-backfill-20261109-hidev/randn-deploy.b64\nprintf '%s\\n' __RANDN_PART_{part}__\n",encoding='utf8',newline='\n')
script=f'''set -e
root=/workspace/expert-profile-backfill-20261109-hidev
base64 -d "$root/randn-deploy.b64" > "$root/randn-deploy.tar.gz"
printf '%s  %s\\n' {digest} "$root/randn-deploy.tar.gz" | sha256sum -c
test ! -e "$root/extra-proxy-randn-harness"
tar -xzf "$root/randn-deploy.tar.gz" -C "$root"
bash -n "$root/run-hidev-extra-randn-detail.sh"
python3 -B -c 'import ast,pathlib;[ast.parse(pathlib.Path(p).read_text()) for p in ["/workspace/expert-profile-backfill-20261109-hidev/inspect-extra-randn.py","/workspace/expert-profile-backfill-20261109-hidev/extra-proxy-randn-harness/extra_randn.py"]]'
printf '%s\\n' __RANDN_DEPLOY_DONE__
'''
(p/'deploy-randn-finish.sh').write_text(script,encoding='utf8',newline='\n')
print('parts',(len(encoded)+5499)//5500,'sha256',digest)
