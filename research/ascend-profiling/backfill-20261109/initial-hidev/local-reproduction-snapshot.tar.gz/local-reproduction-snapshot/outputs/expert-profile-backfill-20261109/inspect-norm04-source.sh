#!/usr/bin/env bash
set -u
echo __INSPECT_NORM04_SOURCE_BEGIN__
r=/workspace/expert-profile-backfill-20261109-hidev/extra-proxy-runs/unified-extra3/quant_norm_forward-04/hidev-npu0/attempt-001/detail
python3 - "$r" <<'PY'
import json,sys
from pathlib import Path
p=Path(sys.argv[1]);m=json.loads((p/'provenance/cases.json').read_text())['cases']; print(next(x for x in m if x['target_id'].endswith('quant_norm_forward-04'))['params'])
print('\n'.join(x for x in (p/'generated-kernel.cpp').read_text().splitlines() if 'asc_copy_ub2gm_align(' in x))
PY
echo __INSPECT_NORM04_SOURCE_END__
