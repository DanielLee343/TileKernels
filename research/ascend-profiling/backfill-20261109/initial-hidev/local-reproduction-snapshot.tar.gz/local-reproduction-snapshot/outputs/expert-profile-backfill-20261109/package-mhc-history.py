"""Freeze historical application identities for remaining mHC cases."""
import csv,hashlib,json,tarfile
from collections import Counter
from pathlib import Path
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
families={'mhc_expand_bwd','mhc_expand_fwd','mhc_pre_apply_mix_fwd','mhc_post_fwd'}
with (HERE/'targets.csv').open(encoding='utf-8-sig',newline='') as f:rows=list(csv.DictReader(f))
items=[]
for r in rows:
 if r['batch']!='tilekernels-default' or r['case'].split('/')[0] not in families or r['per_core_requested_bytes_status']!='pending':continue
 batch,case_id=r['target_id'].split('/')
 if batch not in ('second','third','fifth'):continue  # retry adapters have a different input contract
 profile=ROOT/r['original_profile_paths'].split(';')[0]
 meta=profile.parent.parent/'default.json'
 assert meta.is_file(),meta
 j=json.loads(meta.read_text());assert j['runtime_kernel']==r['op_name'] and j['status']=='passed'
 basic=ROOT/r['original_opbasic_csv'].split(';')[0]
 with basic.open(encoding='utf-8-sig',newline='') as f:op,=csv.DictReader(f)
 items.append({'case':case_id,'batch':batch,'plan_case':r['case'],'target':r['target_id'],'kernel':r['op_name'],
               'metadata_sha256':hashlib.sha256(meta.read_bytes()).hexdigest(),
               'historical_block_dim':op['Block Dim'],'metadata_path':str(meta.relative_to(ROOT))})
assert len(items)==len({x['target'] for x in items})
out=HERE/'mhc-history.tar.gz'
with tarfile.open(out,'w:gz') as t:
 for item in items:
  t.add(ROOT/item['metadata_path'],arcname='mhc-history/'+item['batch']+'/'+item['case']+'/default.json')
(HERE/'mhc-history-sha256.txt').write_text(''.join(x['metadata_sha256']+'  mhc-history/'+x['batch']+'/'+x['case']+'/default.json\n' for x in items),encoding='utf-8')
(HERE/'mhc-pending.json').write_text(json.dumps(items,indent=2)+'\n',encoding='utf-8')
print('cases',len(items),'by family',dict(Counter(x['plan_case'].split('/')[0] for x in items)),
      'block dims',dict(Counter(x['historical_block_dim'] for x in items)))
