from pathlib import Path
p=Path(__file__).resolve().parent;s=(p/'hidev-extra-channel-queue.py').read_text()
for old,new in [('quant_per_channel_cast','quant_per_block_cast_lossless'),
                ('extra-channel-queue','extra-lossless-queue'),
                ('run-hidev-extra-proxy-detail.sh','run-hidev-extra-lossless-detail.sh'),
                ('inspect-extra-proxy.py','inspect-extra-lossless.py'),
                ('audit-extra-channel.py','audit-extra-lossless.py'),
                ('ALL_CHANNEL_SELECTED_AUDITED','ALL_LOSSLESS_SELECTED_AUDITED')]:
 assert old in s;s=s.replace(old,new)
(p/'hidev-extra-lossless-queue.py').write_text(s,encoding='utf8',newline='\n')
print('lossless batch queue prepared')
