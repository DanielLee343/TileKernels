from pathlib import Path
p=Path(__file__).resolve().parent;s=(p/'package-deepgemm-mgroup.py').read_text(encoding='utf-8')
for old,new in (
 ('deepgemm-mgroup-harness','deepgemm-paged-sparse-harness'),
 ('run-hidev-deepgemm-mgroup.sh','run-hidev-deepgemm-paged-sparse.sh'),
 ('inspect-deepgemm-mgroup.py','inspect-deepgemm-paged-sparse.py'),
 ('deploy-dg-mgroup','deploy-dg-paged-sparse'),
 ('dg-mgroup-deploy','dg-paged-sparse-deploy'),
 ('__DG_MGROUP_','__DG_PAGED_SPARSE_'),
):
 assert old in s,old;s=s.replace(old,new)
exec(compile(s,str(p/'package-deepgemm-mgroup.py'),'exec'))
