"""Stage an application-replay pilot with one evidence set per process."""
import hashlib,json,shutil
from pathlib import Path
p=Path(__file__).resolve().parent;src=p/'extra-proxy-harness';dst=p/'extra-proxy-accum-app-harness';dst.mkdir(exist_ok=True)
for name in ('cases.json','provenance.json'):shutil.copyfile(src/name,dst/name)
s=(src/'extra_norm_bwd.py').read_text()
needle='def run(group, params, stage, record_path):\n';assert s.count(needle)==1
s=s.replace(needle,needle+"    record_path = Path(record_path).with_name('application-' + str(os.getpid()) + '.json')\n")
for old,new in [("with_name('tensor-addresses.json')","with_name('tensor-addresses-' + str(os.getpid()) + '.json')"),
                ("with_name('generated-kernel.cpp')","with_name('generated-kernel-' + str(os.getpid()) + '.cpp')")]:
 assert old in s;s=s.replace(old,new)
(dst/'extra_norm_bwd.py').write_text(s,encoding='utf8',newline='\n')
(dst/'replay-instrumentation.json').write_text(json.dumps({'scope':'application replay; unique per-process evidence filenames; no changes to upstream kernel or input','source_adapter_sha256':hashlib.sha256((src/'extra_norm_bwd.py').read_bytes()).hexdigest(),'instrumented_adapter_sha256':hashlib.sha256((dst/'extra_norm_bwd.py').read_bytes()).hexdigest()},indent=2)+'\n')
r=(p/'run-hidev-extra-norm-backward-detail.sh').read_text().replace('extra-proxy-harness','extra-proxy-accum-app-harness')
r=r.replace('unified-extra3/quant_norm_backward-01','unified-extra3/quant_norm_backward-08')
r=r.replace('--replay-mode=kernel','--replay-mode=application')
r=r.replace('$root/run-hidev-extra-proxy-detail.sh','$root/run-hidev-extra-norm-accum-app.sh')
needle='"$root/extra-proxy-accum-app-harness/provenance.json"';assert needle in r;r=r.replace(needle,needle+' "$root/extra-proxy-accum-app-harness/replay-instrumentation.json"')
old='test -f "$out/application.json";test -f "$out/tensor-addresses.json";test -f "$out/generated-kernel.cpp"'
new='compgen -G "$out/application-*.json" >/dev/null;compgen -G "$out/tensor-addresses-*.json" >/dev/null;compgen -G "$out/generated-kernel-*.cpp" >/dev/null'
assert old in r;r=r.replace(old,new)
(p/'run-hidev-extra-norm-accum-app.sh').write_text(r,encoding='utf8',newline='\n')
print('prepared application replay pilot with per-process evidence')
