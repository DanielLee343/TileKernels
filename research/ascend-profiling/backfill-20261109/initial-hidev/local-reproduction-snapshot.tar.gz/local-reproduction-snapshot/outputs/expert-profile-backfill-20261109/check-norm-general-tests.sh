#!/usr/bin/env bash
echo __CHECK_NORM_GENERAL_TESTS_BEGIN__
root=/workspace/expert-profile-backfill-20261109-hidev
ps -p "$(cat "$root/norm-general-negative-tests.pid")" -o pid,stat,etime,args || true
tail -n 25 "$root/norm-general-negative-tests.log"
echo __CHECK_NORM_GENERAL_TESTS_END__
