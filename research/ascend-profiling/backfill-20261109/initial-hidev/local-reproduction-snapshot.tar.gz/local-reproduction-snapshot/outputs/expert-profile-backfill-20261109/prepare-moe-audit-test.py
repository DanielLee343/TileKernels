from pathlib import Path
p=Path(__file__).resolve().parent
s=(p/'test-swiglu-forward-audit.sh').read_text(encoding='utf-8')
for old,new in (
 ('__SWIGLU_FORWARD_AUDIT_TEST_', '__MOE_BACKWARD_AUDIT_TEST_'),
 ('quant-audit-test.', 'moe-backward-audit-test.'),
 ('unified-extra3/quant_swiglu_forward-01', 'unified-extra4/moe_topk_gate_backward-01'),
 ('audit-extra-swiglu-forward.py', 'audit-extra-moe-backward-candidate.py'),
 ('quant_swiglu_forward-01', 'moe_topk_gate_backward-01'),
 ("a[1]['address']=a[0]['address']", "a[6]['address']=a[0]['address']"),
):
 assert old in s,old;s=s.replace(old,new)
(p/'test-moe-backward-audit.sh').write_text(s,encoding='utf-8',newline='\n')
