from pathlib import Path
p=Path(__file__).resolve().parent;s=(p/'hidev-dg-transform-queue.py').read_text()
changes=[('deepgemm-transform-queue-hidev-npu0','deepgemm-mix-queue-hidev-npu0'),('deepgemm-transform-harness','deepgemm-mix-harness'),
 ("assert len(items)==14","assert len(items)==6"),("x['target']=='transform_sf'","x['target']=='fp8_gemm_impl'"),
 ('run-hidev-deepgemm-transform.sh','run-hidev-deepgemm-mix-batch.sh'),('inspect-deepgemm-transform.py','inspect-deepgemm-mix-batch.py'),
 ('audit-deepgemm-transform-general.py','audit-deepgemm-mix-general.py'),('ALL_DG_TRANSFORM_SELECTED_AUDITED','ALL_DG_MIX_SELECTED_AUDITED')]
for old,new in changes:assert old in s,old;s=s.replace(old,new)
(p/'hidev-dg-mix-queue.py').write_text(s,encoding='utf8',newline='\n')
s=(p/'start-hidev-dg-transform-queue.sh').read_text()
for old,new in [('transform-float32-k-g8-mn128-k7168','gemm-fp4fp4-nt-mn-m64-n576-k7168'),('attempt-002','attempt-001'),
 ('deepgemm-transform-queue-hidev-npu0','deepgemm-mix-queue-hidev-npu0'),('hidev-dg-transform-queue.py','hidev-dg-mix-queue.py'),
 ('DG_TRANSFORM_QUEUE','DG_MIX_QUEUE')]:assert old in s,old;s=s.replace(old,new)
(p/'start-hidev-dg-mix-queue.sh').write_text(s,encoding='utf8',newline='\n')
print('prepared mixed GEMM queue')
