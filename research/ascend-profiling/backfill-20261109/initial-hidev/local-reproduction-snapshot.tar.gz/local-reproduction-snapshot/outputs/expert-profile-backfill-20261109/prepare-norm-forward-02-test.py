from pathlib import Path
p=Path(__file__).resolve().parent;s=(p/'test-norm-forward-audit.sh').read_text()
for old,new in [('quant_norm_forward-01','quant_norm_forward-02'),
                ('audit-extra-norm-forward.py','audit-extra-norm-forward-02.py'),
                ("a[7]['address']","a[5]['address']"),
                ('NORM_FORWARD_AUDIT_TEST','NORM_FORWARD_02_AUDIT_TEST')]:
 assert old in s;s=s.replace(old,new)
(p/'test-norm-forward-02-audit.sh').write_text(s,encoding='utf8',newline='\n')
print('FP32/rstd negative tests prepared')
