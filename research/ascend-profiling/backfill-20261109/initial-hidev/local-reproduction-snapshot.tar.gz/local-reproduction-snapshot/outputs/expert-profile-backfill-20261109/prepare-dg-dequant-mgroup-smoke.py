from pathlib import Path
p=Path(__file__).resolve().parent
s=(p/'prepare-dg-bf16-mgroup-smoke.py').read_text()
for old,new in [('bf16-mgroup','dequant-mgroup'),('bf16bf16','fp8fp4'),
                ("startswith('campaign-13/mgroup-bf16')","startswith('campaign-13/mgroup-fp8fp4')"),('bf16_gemm_impl','fp8_dequant_gemm_impl'),
                ('BF16','FP8/FP4 dequant')]:
 assert old in s,old;s=s.replace(old,new)
exec(compile(s,str(p/'prepare-dg-bf16-mgroup-smoke.py'),'exec'))
