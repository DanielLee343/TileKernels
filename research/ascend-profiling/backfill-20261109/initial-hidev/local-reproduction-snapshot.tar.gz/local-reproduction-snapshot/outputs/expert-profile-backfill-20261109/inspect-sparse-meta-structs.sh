echo __SPARSE_META_STRUCTS_BEGIN__
f=/workspace/deepgemm-ascend-20261107/source/deep_gemm/include/deep_gemm/layout/sparse_mqa_logits.hpp
sed -n '1,125p' "$f"
f=/workspace/deepgemm-ascend-20261107/source/deep_gemm/include/deep_gemm/sparse_mqa_logits.hpp
grep -nE 'kv_split_outputs|q_block_headers|q_token_idx|output0|output1|schedule\[' "$f" | tail -n 35
echo __SPARSE_META_STRUCTS_END__
