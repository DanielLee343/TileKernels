echo __MOE_FORWARD_PARSER_BEGIN__
r=/workspace/expert-profile-backfill-20261109-hidev/extra-proxy-runs/unified-extra3/moe_topk_gate_forward-01/hidev-npu0
for n in attempt-001 attempt-002;do
 echo "$n"
 grep 'processedRecord:' "$r/$n/detail/profile.log" | tail -n 3 | cut -c1-600
done
echo __MOE_FORWARD_PARSER_END__
