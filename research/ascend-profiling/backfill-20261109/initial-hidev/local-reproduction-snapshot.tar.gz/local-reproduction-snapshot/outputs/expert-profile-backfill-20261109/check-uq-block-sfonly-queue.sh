#!/usr/bin/env bash
set -e
echo __CHECK_UQ_BLOCK_SFONLY_QUEUE_BEGIN__
q=/workspace/expert-profile-backfill-20261109-hidev/unified-quant-block-sfonly-queue-hidev-npu0
ps -p "$(cat "$q/queue.pid")" -o pid,stat,etime,args || true
tail -n 25 "$q/console.log"
echo __CHECK_UQ_BLOCK_SFONLY_QUEUE_END__
