"""Make a checksum-verified one-file transfer for the authenticated tmux pane."""
import base64,hashlib,sys
from pathlib import Path
HERE=Path(__file__).resolve().parent;name=sys.argv[1];p=HERE/name;data=p.read_bytes()
assert p.is_file() and p.name==name
marker='__HIDEV_SINGLE_'+''.join(c if c.isalnum() else '_' for c in name).upper()+'_DONE__'
script="""#!/usr/bin/env bash
set -Eeo pipefail
root=/workspace/expert-profile-backfill-20261109-hidev
printf '%s' 'PAYLOAD' | base64 -d > \"$root/NAME\"
printf '%s  %s\\n' HASH \"$root/NAME\" | sha256sum -c
printf '%s\\n' MARKER
""".replace('PAYLOAD',base64.b64encode(data).decode()).replace('NAME',name).replace('HASH',hashlib.sha256(data).hexdigest()).replace('MARKER',marker)
(HERE/'deploy-single.sh').write_text(script,encoding='utf-8',newline='\n')
print(marker,'bytes',len(script))
