echo __PAGED_SPARSE_META_BEGIN__
r=/workspace/expert-profile-backfill-20261109-hidev
python3 - "$r" <<'PY'
import hashlib,json,sys
from pathlib import Path
r=Path(sys.argv[1]);case='paged-sparse-fp8-q4-k256-h8-b8';p=r/'deepgemm-runs'/case/'hidev-npu0/attempt-001'
old=json.loads((r/'deepgemm-paged-sparse-harness/history'/case/'profile.json').read_text())['target_input']['kwargs']['metadata']
now=json.loads((p/'profile.json').read_text())['target_input']['kwargs']['metadata']
saved=json.loads((p/'paged-sparse-input-files.json').read_text());print('OLD',json.dumps(old));print('NEW',json.dumps(now));print('SAVED',json.dumps(saved))
print('AFTER',hashlib.sha256((p/'paged-sparse-metadata-after.bin').read_bytes()).hexdigest())
PY
echo __PAGED_SPARSE_META_END__
