import base64,hashlib,io,tarfile
from pathlib import Path
p=Path(__file__).resolve().parent;b=io.BytesIO()
with tarfile.open(fileobj=b,mode='w:gz') as t:
 for name in ('extra-proxy-harness','select-extra-proxy-case.py','run-hidev-extra-proxy-detail.sh','inspect-extra-proxy.py'):
  t.add(p/name,arcname=name,filter=lambda info:None if '__pycache__' in info.name else info)
data=b.getvalue();encoded=base64.b64encode(data).decode();digest=hashlib.sha256(data).hexdigest()
for i in range(0,len(encoded),5500):
 part=i//5500;mode='>' if part==0 else '>>'
 (p/f'deploy-extra-proxy-part-{part}.sh').write_text(f"printf '%s' '{encoded[i:i+5500]}' {mode} /workspace/expert-profile-backfill-20261109-hidev/extra-proxy-deploy.b64\nprintf '%s\\n' __EXTRA_PROXY_PART_{part}__\n",encoding='utf8',newline='\n')
script=f'''set -e
root=/workspace/expert-profile-backfill-20261109-hidev
base64 -d "$root/extra-proxy-deploy.b64" > "$root/extra-proxy-deploy.tar.gz"
printf '%s  %s\\n' {digest} "$root/extra-proxy-deploy.tar.gz" | sha256sum -c
test ! -e "$root/extra-proxy-harness"
tar -xzf "$root/extra-proxy-deploy.tar.gz" -C "$root"
bash -n "$root/run-hidev-extra-proxy-detail.sh"
python3 -B "$root/select-extra-proxy-case.py" "$root/extra-proxy-harness/cases.json" unified-extra2/quant_per_channel_cast-01 > /dev/null
printf '%s\\n' __EXTRA_PROXY_DEPLOY_DONE_{digest[:12].upper()}__
'''
(p/'deploy-extra-proxy-finish.sh').write_text(script,encoding='utf8',newline='\n')
print('parts',(len(encoded)+5499)//5500,'sha256',digest)
