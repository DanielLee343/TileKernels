echo __SPARSE_META_LAYOUT_BEGIN__
r=/workspace/deepgemm-ascend-20261107/source/deep_gemm/include
grep -RnE 'struct (MetadataHeader|QBlockHeader|QBlockSplitKVOutputInfo|ScheduleBoundary)|output_desc|kv_split_outputs_offset' "$r"/deep_gemm | head -n 45
echo __SPARSE_META_LAYOUT_END__
