echo __CHECK_PAGED_SPARSE_FIRST_BEGIN__
q=/workspace/expert-profile-backfill-20261109-hidev/deepgemm-paged-sparse-first-smoke-hidev-npu0
ps -p "$(cat "$q/pid")" -o pid,stat,etime,args || true
test ! -f "$q/attempt.txt" || cat "$q/attempt.txt"
test ! -f "$q/exit.txt" || cat "$q/exit.txt"
tail -n 15 "$q/console.log"
echo __CHECK_PAGED_SPARSE_FIRST_END__
