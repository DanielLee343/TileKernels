from pathlib import Path
p=Path(__file__).resolve().parent
s=(p/'test-dg-dequant-audit.sh').read_text().replace('gemm-fp8fp4-nt-k-m4096-n576-k7168','mgroup-fp8fp4-nt-g4-m128-n256-k512')
s=s.replace('audit-deepgemm-dequant.py','audit-dg-dequant-mgroup-candidate.py').replace('DG_DEQUANT_AUDIT_TEST','DG_DEQUANT_MGROUP_AUDIT_TEST')
(p/'test-dg-dequant-mgroup-audit.sh').write_text(s,encoding='utf8',newline='\n')
print('prepared dequant M-group negative checks')
