from pathlib import Path
p=Path(__file__).resolve().parent;s=(p/'test-dg-transform-audit.sh').read_text()
for old,new in [('transform-float32-k-g1-mn256-k2048','gemm-fp4fp4-nn-mn-m64-n576-k7168'),
                ('audit-deepgemm-transform-general.py','audit-deepgemm-mix-general.py'),('DG_TRANSFORM_AUDIT_TEST','DG_MIX_AUDIT_TEST')]:
 assert old in s;s=s.replace(old,new)
assert "rows[0]['UB_to_GM_datas(KB)']" in s
s=s.replace("rows[0]['UB_to_GM_datas(KB)']","rows[1]['UB_to_GM_datas(KB)']")
(p/'test-dg-mix-audit.sh').write_text(s,encoding='utf8',newline='\n')
print('prepared mixed GEMM audit negative tests')
