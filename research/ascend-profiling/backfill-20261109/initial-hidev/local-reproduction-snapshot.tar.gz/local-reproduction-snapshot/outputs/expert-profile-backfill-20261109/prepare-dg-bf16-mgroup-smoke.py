"""Stage original BF16 M-group inputs and kernel; no GEMM source changes."""
import csv,hashlib,json,shutil
from pathlib import Path
p=Path(__file__).resolve().parent; repo=p.parents[1]/'TileKernels-private'
base=repo/'research/ascend-profiling/deepgemm-ascend/campaign-13'
out=p/'deepgemm-bf16-mgroup-harness';campaign=out/'campaign-13';campaign.mkdir(parents=True,exist_ok=True)
src=p/'deepgemm-profile-harness/campaign-13/collect.py';shutil.copyfile(src,campaign/'collect.py')
pilot=out/'pilot-bf16';pilot.mkdir(exist_ok=True);shutil.copyfile(p/'deepgemm-profile-harness/pilot-bf16/collect.py',pilot/'collect.py')
with (p/'targets.csv').open(encoding='utf-8-sig',newline='') as f:rows=list(csv.DictReader(f))
ids={r['case'].split('/')[-1] for r in rows if r['batch']=='deepgemm-original' and r['case'].startswith('campaign-13/mgroup-bf16') and r['op_type']=='mix' and 'bf16_gemm_impl' in r['op_name']}
manifest=json.loads((base/'cases-last.json').read_text(encoding='utf-8-sig'));manifest['cases']=[x for x in manifest['cases'] if x['id'] in ids];assert len(manifest['cases'])==len(ids)==3
(campaign/'cases.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf8')
for case in manifest['cases']:
 matches=list((base/'runs').glob('*/'+case['id']+'/profile.json'));assert len(matches)==1,case['id']
 original=matches[0].parent;hist=out/'history'/case['id'];hist.mkdir(parents=True,exist_ok=True)
 for name in ('profile.json','result.json','jit/kernel.asc'):shutil.copyfile(original/name,hist/Path(name).name)
(out/'provenance.json').write_text(json.dumps({'source':'frozen campaign-13 collector with address-only additions','collector_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'source_commit':'3a35326271b069b8b5bf1a754435acd6cc91575b','case_count':3,'scope':'BF16 M-group smoke; identity and output prestate must be verified'},indent=2)+'\n',encoding='utf8')
runner=(p/'run-hidev-deepgemm-mgroup.sh').read_text().replace('deepgemm-mgroup-harness','deepgemm-bf16-mgroup-harness')
runner=runner.replace('^mgroup-fp(4|8)fp(4|8)-[a-z0-9-]+$','^mgroup-bf16bf16-[a-z0-9-]+$').replace('target=fp8_gemm_impl','target=bf16_gemm_impl')
(p/'run-hidev-deepgemm-bf16-mgroup.sh').write_text(runner,encoding='utf8',newline='\n')
inspector=(p/'inspect-deepgemm-mgroup.py').read_text().replace('deepgemm-mgroup-harness','deepgemm-bf16-mgroup-harness')
(p/'inspect-deepgemm-bf16-mgroup.py').write_text(inspector,encoding='utf8',newline='\n')
print('prepared BF16 M-group cases',sorted(ids))
