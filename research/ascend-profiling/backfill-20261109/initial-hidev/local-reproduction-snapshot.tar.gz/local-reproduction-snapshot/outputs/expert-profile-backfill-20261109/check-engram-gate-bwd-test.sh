#!/usr/bin/env bash
echo __CHECK_ENGRAM_GATE_BWD_TEST_BEGIN__
r=/workspace/expert-profile-backfill-20261109-hidev
ps -p "$(cat "$r/engram-gate-bwd-test.pid")" -o pid=,stat=,args= || true
tail -n 10 "$r/engram-gate-bwd-test.log"
echo __CHECK_ENGRAM_GATE_BWD_TEST_END__
