#!/usr/bin/env bash
set -e
echo __INSPECT_DG_SPARSE_META_CALLS_BEGIN__
repo=/workspace/tilekernels-env-20261101/src/TileKernels-private/research/ascend-profiling/deepgemm-ascend/campaign-13/runs
tool=/workspace/tilekernels-env-20261101/cann/cann-9.2.1/tools/bisheng_compiler/bin/llvm-objdump
bin=$(find "$repo" -path '*/sparse-meta-fp8-q4-k256-h8-b8/profile/OPPROF_*/dump/aicore_binary.o' -print -quit)
test -f "$bin"
"$tool" -r "$bin" | head -50
"$tool" -d "$bin" | grep -E -C 14 '\bCALL\b' | head -110
"$tool" -d "$bin" | grep -E '^\s*(600|6a0|700):|^0*[0-9a-f]+ <' | head -45
echo __INSPECT_DG_SPARSE_META_CALLS_END__
