"""Audit the exact four-block reduce-01 profile against addresses and compiled ISA."""
import csv,hashlib,json,re
from collections import Counter
from decimal import Decimal
from pathlib import Path
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
P=HERE/'tbe-evidence/reduce-01/tbe-npu3/attempt-001/detail'
H=ROOT/'TileKernels-private/research/ascend-profiling/runs/hidev-20261106-second/cases/reduce-01/default.json'
R=re.compile(r'DBI record core:(\d+);pc:0x([0-9a-f]+);dst:\(type:GM;addr:0x([0-9a-f]+);stride:(\d+);loop1Stride:(\d+);loop2Stride:(\d+)\);src:\(type:UB;addr:0x([0-9a-f]+);stride:(\d+);loop1Stride:(\d+);loop2Stride:(\d+)\);nBurst:(\d+);lenBurst:(\d+);dataType:([^;]+);loop1Size:(\d+);loop2Size:(\d+);leftPaddingNum:(\d+);rightPaddingNum:(\d+)',re.I)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):
 with p.open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def main():
 app=json.loads((P/'metadata/application.json').read_text());hist=json.loads(H.read_text());monitor=json.loads((P/'monitor-summary.json').read_text())
 assert app['status']=='passed' and app['visible_devices']=='3' and monitor['status']=='passed' and monitor['max_seconds_between_successful_queries']<=3
 for key in ('runtime_kernel','source_sha256','inputs','outputs'):assert app[key]==hist[key],key
 src=P/'metadata/default-kernel.cpp';assert sha(src)==app['source_sha256']
 code=src.read_text();assert 'col_sumsq[(((int32_t)block_idx) * 256)]' in code and 'asc_copy_ub2gm_align' in code
 op,=list((P/'capture').rglob('OpBasicInfo.csv'));basic,=read(op)
 assert basic['Op Name']==app['runtime_kernel'] and basic['Op Type']=='vector' and basic['Block Dim']=='4' and basic['Device Id']=='3'
 binary=op.parent/'dump/aicore_binary.o';binarysha=sha(binary)
 cache=(P/'cache-sha256.txt').read_text();assert any(x.startswith(binarysha+' ') and x.rstrip().endswith('/kernel.aibin') for x in cache.splitlines())
 isa=(P/'device-kernel.isa').read_text();assert any(re.match(r'^\s*174:',line) and 'MOV_UB_TO_OUT' in line for line in isa.splitlines())
 raw=(P/'profile.log').read_text();allstores=[line for line in raw.splitlines() if 'DBI record core:' in line and 'dst:(type:GM;' in line and 'src:(type:UB;' in line]
 rec=R.findall(raw);assert len(allstores)==len(rec)==4
 base=int(app['device_output_addresses'][0],16);blocks=Counter();segments=[]
 for core,pc,addr,stride,l1s,l2s,ub,us,ul1,ul2,burst,length,dtype,l1,l2,left,right in rec:
  core=int(core);block=2*(core//3)+core%3;addr=int(addr,16)
  assert core%3 in (0,1) and block in range(4)
  assert (int(pc,16),int(burst),int(length),int(l1),int(l2),int(left),int(right))==(0x174,1,1024,1,1,0,0)
  assert addr==base+block*1024
  blocks[block]+=int(length);segments.append((addr,addr+int(length)))
 assert set(blocks)==set(range(4)) and sorted(segments)==[(base+i*1024,base+(i+1)*1024) for i in range(4)]
 memory=read(op.with_name('Memory.csv'));assert len(memory)==4
 for i,row in enumerate(memory):
  assert int(row['block_id'])==i and row['sub_block_id']=='vector0'
  if i<2:assert Decimal(row['UB_to_GM_datas(KB)'])*1024==blocks[2*i]+blocks[2*i+1]
  else:assert row['UB_to_GM_datas(KB)']=='NA'
 result={'case':'engram_sinkhorn_step_reduce/01','device':'tbe NPU 3','runtime_kernel':basic['Op Name'],
   'historical_input_and_source_match':True,'correctness':'passed','output_logical_bytes':4096,
   'dbi_requested_bytes':sum(blocks.values()),'per_vector_block_requested_bytes':dict(blocks),
   'csv_two_pair_totals_match':True,'dbi_pc':'0x174 MOV_UB_TO_OUT_ALIGN_V2','capture_binary_sha256':binarysha,
   'scope':'one MemoryDetail window; requested UB to GM bytes, not DRAM transactions',
   'max_seconds_between_successful_device_queries':monitor['max_seconds_between_successful_queries']}
 (HERE/'reduce-01-audit.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
 print('PASS',json.dumps(result))
if __name__=='__main__':main()
