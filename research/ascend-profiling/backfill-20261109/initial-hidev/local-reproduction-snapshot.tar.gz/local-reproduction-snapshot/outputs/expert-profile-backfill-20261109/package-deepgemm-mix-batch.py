import base64,hashlib,io,tarfile
from pathlib import Path
p=Path(__file__).resolve().parent;b=io.BytesIO()
with tarfile.open(fileobj=b,mode='w:gz') as t:
 for name in ('deepgemm-mix-harness','run-hidev-deepgemm-mix-batch.sh','inspect-deepgemm-mix-batch.py'):
  t.add(p/name,arcname=name,filter=lambda info:None if '__pycache__' in info.name else info)
data=b.getvalue();encoded=base64.b64encode(data).decode();digest=hashlib.sha256(data).hexdigest()
for i in range(0,len(encoded),5500):
 part=i//5500;mode='>' if part==0 else '>>'
 (p/f'deploy-dg-mix-part-{part}.sh').write_text(f"printf '%s' '{encoded[i:i+5500]}' {mode} /workspace/expert-profile-backfill-20261109-hidev/dg-mix-deploy.b64\nprintf '%s\\n' __DG_MIX_PART_{part}__\n",encoding='utf8',newline='\n')
script=f'''set -e
root=/workspace/expert-profile-backfill-20261109-hidev
base64 -d "$root/dg-mix-deploy.b64" > "$root/dg-mix-deploy.tar.gz"
printf '%s  %s\\n' {digest} "$root/dg-mix-deploy.tar.gz" | sha256sum -c
test ! -e "$root/deepgemm-mix-harness"
tar -xzf "$root/dg-mix-deploy.tar.gz" -C "$root"
bash -n "$root/run-hidev-deepgemm-mix-batch.sh"
python3 -m py_compile "$root/inspect-deepgemm-mix-batch.py" "$root/deepgemm-mix-harness/campaign-13/collect.py"
printf '%s\\n' __DG_MIX_DEPLOY_DONE__
'''
(p/'deploy-dg-mix-finish.sh').write_text(script,encoding='utf8',newline='\n')
print('parts',(len(encoded)+5499)//5500,'sha256',digest)
