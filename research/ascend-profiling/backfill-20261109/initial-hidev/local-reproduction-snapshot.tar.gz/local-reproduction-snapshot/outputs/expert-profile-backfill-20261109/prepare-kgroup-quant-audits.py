from pathlib import Path
p=Path(__file__).resolve().parent
for src,dst,old_pat,new_pat in (
 ('audit-deepgemm-mgroup-batch.py','audit-dg-kgroup-fp8-candidate.py',"r'mgroup-fp(?:4|8)fp(?:4|8)-[a-z0-9-]+'", "r'kgroup-(?:fp8fp8|fp4fp4)-[a-z0-9-]+'"),
 ('audit-dg-dequant-mgroup-batch.py','audit-dg-kgroup-dequant-candidate.py',"r'mgroup-fp8fp4-[a-z0-9-]+'", "r'kgroup-fp8fp4-[a-z0-9-]+'"),
):
 s=(p/src).read_text(encoding='utf-8');assert old_pat in s;s=s.replace(old_pat,new_pat)
 needle="assert shape and len(shape)==len(stride) and all(x>0 for x in shape) and all(x>=0 for x in stride)"
 addition="""
manifest=json.loads((root/'deepgemm-kgroup-harness/campaign-13/cases.json').read_text())
case_doc,=(x for x in manifest['cases'] if x['id']==case)
assert shape==[case_doc['groups'],case_doc['m'],case_doc['n']] and out['dtype']=='torch.bfloat16'
def spans(t):
 lo=int(t['address'],16);return lo,lo+t['element_size']*(1+sum((n-1)*k for n,k in zip(t['shape'],t['stride'])))
lo,hi=spans(out)
for t in (*addr['args'][0],*addr['args'][1],addr['args'][4]):
 x,y=spans(t);assert hi<=x or y<=lo,'input/output overlap'
"""
 assert needle in s;s=s.replace(needle,needle+addition)
 needle="binary=op.parent/'dump/aicore_binary.o';assert sha(binary)==inspection['capture']['jit_binary_sha256']==sha(p/'jit/kernel.o')"
 assert needle in s;s=s.replace(needle,"assert 'GemmType::KGroupedContiguousWithPsumLayout' in (p/'jit/kernel.asc').read_text()\n"+needle)
 (p/dst).write_text(s,encoding='utf-8',newline='\n');compile(s,str(p/dst),'exec')
print('KGROUP_QUANT_AUDITS_PREPARED')
