#!/usr/bin/env bash
set -e
echo __INSPECT_DG_SPARSE_PREPARE_SOURCE_BEGIN__
repo=/workspace/tilekernels-env-20261101/src/TileKernels-private/research/ascend-profiling/deepgemm-ascend/campaign-13/runs
find "$repo" -path '*/paged-sparse-prepare-fp8-q4-k256-h8-b8/jit/kernel.asc' -type f -exec cat {} \;
src=/workspace/deepgemm-ascend-20261107/source/deep_gemm
grep -R -n 'paged_sparse_mqa_prepare_impl' "$src" --include='*.hpp' | head -20
sed -n '510,590p' "$src/include/deep_gemm/paged_sparse_mqa_logits_metadata.hpp"
grep -nE 'ub2gm|ub_to_gm|copy_ub|publish_kv_split_range' "$src/include/deep_gemm/paged_sparse_mqa_logits_metadata.hpp" || true
echo __INSPECT_DG_SPARSE_PREPARE_SOURCE_END__
