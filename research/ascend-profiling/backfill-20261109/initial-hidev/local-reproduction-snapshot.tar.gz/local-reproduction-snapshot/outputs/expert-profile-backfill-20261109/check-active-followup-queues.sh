#!/usr/bin/env bash
echo __CHECK_ACTIVE_FOLLOWUP_QUEUES_BEGIN__
root=/workspace/expert-profile-backfill-20261109-hidev
for stem in deepgemm-paged-meta classic-castback extra-block-castback;do
 q="$root/$stem-queue-hidev-npu0";echo "QUEUE=$stem"
 ps -p "$(cat "$q/followup.pid")" -o pid,stat,etime,args || true
 tail -n 12 "$q/console.log"
 if test -f "$q/followup-exit.txt";then cat "$q/followup-exit.txt";fi
done
echo __CHECK_ACTIVE_FOLLOWUP_QUEUES_END__
