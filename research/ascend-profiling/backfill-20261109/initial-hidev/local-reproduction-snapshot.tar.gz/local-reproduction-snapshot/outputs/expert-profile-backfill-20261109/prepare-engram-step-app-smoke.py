from pathlib import Path
p=Path(__file__).resolve().parent;s=(p/'prepare-engram-grad-app-smoke.py').read_text(encoding='utf-8')
for old,new in (
 ('extra-proxy-engram-grad-app-harness','extra-proxy-engram-step-app-harness'),
 ('extra_engram_grad.py','extra_engram_step.py'),
 ('run-hidev-extra-engram-grad-app.sh','run-hidev-extra-engram-step-app.sh'),
 ('engram_grad_w_reduce','engram_sinkhorn_step'),
 ('ENGRAM_GRAD_APPLICATION_REPLAY_STAGED','ENGRAM_STEP_APPLICATION_REPLAY_STAGED'),
):
 assert old in s,old;s=s.replace(old,new)
exec(compile(s,str(p/'prepare-engram-grad-app-smoke.py'),'exec'))
