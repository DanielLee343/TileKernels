#!/usr/bin/env bash
echo __INSPECT_NORM_ACCUM_APP_CAPTURE_BEGIN__
p=/workspace/expert-profile-backfill-20261109-hidev/extra-proxy-runs/unified-extra3/quant_norm_backward-08/hidev-npu0/attempt-001/detail
python3 - "$p" <<'PY'
from pathlib import Path
import csv,hashlib,json,re,sys
p=Path(sys.argv[1]);old=json.loads((p/'provenance/historical-default.json').read_text());files=sorted(p.glob('application-*.json'));print('application records',len(files))
for f in files:
 d=json.loads(f.read_text());pid=f.stem.split('-')[-1];a=p/('tensor-addresses-'+pid+'.json');s=p/('generated-kernel-'+pid+'.cpp')
 print('pid',pid,'status',d.get('status'),'matched',d.get('matched'),'historical inputs',d.get('inputs')==old.get('inputs'),'source hash',d.get('source_sha256')==old.get('source_sha256'),'files',a.is_file(),s.is_file(),'replay',d.get('profiler_replay_state'))
 if a.is_file():
  x=json.loads(a.read_text());print(' grad_output',x[4]['address'],'partial',x[5]['address'],'weight_grad',x[7]['address'])
ops=list((p/'capture').rglob('OpBasicInfo.csv'));print('opbasic files',len(ops))
for op in ops:
 with op.open(encoding='utf-8-sig',newline='') as f:
  for b in csv.DictReader(f):print('op',b['Op Name'],b['Op Type'],b['Block Dim'],b['Device Id'])
log=(p/'profile.log').read_text(errors='replace');print('DBI store events',sum('DBI record core:' in x and 'dst:(type:GM;' in x and 'src:(type:UB;' in x for x in log.splitlines()))
print('parser',re.findall(r'processedRecord: (\d+), droppedRecord: (\d+).*?memoryCorruption (\d+)',log))
PY
echo __INSPECT_NORM_ACCUM_APP_CAPTURE_END__
