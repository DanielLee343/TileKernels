from pathlib import Path
p=Path(__file__).resolve().parent
i=(p/'inspect-norm-accum-app.py').read_text();old="assert target=='unified-extra3/quant_norm_backward-08' and attempt=='attempt-001'"
assert old in i;i=i.replace(old,"assert re.fullmatch(r'unified-extra3/quant_norm_backward-(0[1-9]|1[0-9]|20)',target) and re.fullmatch(r'attempt-[0-9]+',attempt)")
(p/'inspect-norm-accum-app-batch.py').write_text(i,encoding='utf8',newline='\n')
a=(p/'audit-extra-norm-accum-app-08-candidate.py').read_text();old="assert case=='quant_norm_backward-08' and attempt=='attempt-001'"
assert old in a;a=a.replace(old,"assert re.fullmatch(r'quant_norm_backward-(0[1-9]|1[0-9]|20)',case) and re.fullmatch(r'attempt-[0-9]+',attempt)")
old="params['weight_grad_fmt']=='fp32'";assert old in a;a=a.replace(old,"params['weight_grad_fmt'] in ('fp32','bf16')")
needle="assert a[1]['shape']==a[7]['shape']==[hidden] and a[5]['shape']==[2*cores,hidden]"
assert needle in a;a=a.replace(needle,needle+"\nassert a[7]['dtype']==('torch.float32' if params['weight_grad_fmt']=='fp32' else 'torch.bfloat16')")
old="p/'candidate-audit-result.json'";assert old in a;a=a.replace(old,"p/'audit-result.json'")
(p/'audit-extra-norm-accum-app-batch.py').write_text(a,encoding='utf8',newline='\n')
r=(p/'run-hidev-extra-norm-accum-app.sh').read_text()
old='test "$group" = quant_norm_backward; test "$target" = unified-extra3/quant_norm_backward-08'
new='''test "$group" = quant_norm_backward
python3 - "$root/extra-proxy-accum-app-harness/cases.json" "$target" <<'PYCHECK'
import json,sys
with open(sys.argv[1]) as f:d=json.load(f)
selected,=(x for x in d['cases'] if x['target_id']==sys.argv[2]);p=selected['params']
assert selected['group']=='quant_norm_backward' and p['accumulate'] and p['use_weight'] and p['weight_grad_fmt'] in ('fp32','bf16')
PYCHECK'''
assert old in r;r=r.replace(old,new).replace('$root/run-hidev-extra-norm-accum-app.sh','$root/run-hidev-extra-norm-accum-app-batch.sh')
(p/'run-hidev-extra-norm-accum-app-batch.sh').write_text(r,encoding='utf8',newline='\n')
s=(p/'hidev-extra-norm-forward-queue.py').read_text()
for old,new in [('quant_norm_forward','quant_norm_backward'),('extra-norm-forward-queue','extra-norm-accum-app-queue'),
                ('extra-proxy-harness/cases.json','extra-proxy-accum-app-harness/cases.json'),
                ('run-hidev-extra-norm-forward-detail.sh','run-hidev-extra-norm-accum-app-batch.sh'),
                ('inspect-extra-norm-forward.py','inspect-norm-accum-app-batch.py'),
                ('audit-extra-norm-forward-general.py','audit-extra-norm-accum-app-batch.py'),
                ('ALL_NORM_FORWARD_SELECTED_AUDITED','ALL_NORM_ACCUM_APP_SELECTED_AUDITED')]:
 assert old in s,old;s=s.replace(old,new)
old="if x['group']=='quant_norm_backward'];assert len(items)==20"
new="if x['group']=='quant_norm_backward' and x['params']['accumulate'] and x['params']['use_weight'] and x['params']['weight_grad_fmt'] in ('fp32','bf16')];assert len(items)==9"
assert old in s;s=s.replace(old,new)
(p/'hidev-extra-norm-accum-app-queue.py').write_text(s,encoding='utf8',newline='\n')
print('prepared nine accumulation cases; application replay and kernel replay remain separate')
