#!/usr/bin/env bash
set -e
echo __INSPECT_DG_DEQUANT_DIRECT_ISA_BEGIN__
repo=/workspace/tilekernels-env-20261101/src/TileKernels-private/research/ascend-profiling/deepgemm-ascend/campaign-13/runs
tool=/workspace/tilekernels-env-20261101/cann/cann-9.2.1/tools/bisheng_compiler/bin/llvm-objdump
bin=$(find "$repo" -path '*/gemm-fp8fp4-nn-k-m128-n256-k512/profile/OPPROF_*/dump/aicore_binary.o' -print -quit)
test -f "$bin"
"$tool" -d "$bin" | grep -E 'MOV_UB_TO|MOV_L0C|STG' | sort | head -45 || true
echo __INSPECT_DG_DEQUANT_DIRECT_ISA_END__
