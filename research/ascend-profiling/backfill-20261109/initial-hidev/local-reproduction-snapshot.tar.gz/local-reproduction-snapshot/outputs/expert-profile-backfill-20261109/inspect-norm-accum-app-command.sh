#!/usr/bin/env bash
echo __INSPECT_NORM_ACCUM_APP_COMMAND_BEGIN__
p=/workspace/expert-profile-backfill-20261109-hidev/extra-proxy-runs/unified-extra3/quant_norm_backward-08/hidev-npu0/attempt-001/detail
cat "$p/command.json"
echo __INSPECT_NORM_ACCUM_APP_COMMAND_END__
