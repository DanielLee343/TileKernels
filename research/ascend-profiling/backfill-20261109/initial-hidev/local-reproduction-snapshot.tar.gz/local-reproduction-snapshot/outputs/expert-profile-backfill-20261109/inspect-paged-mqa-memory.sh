echo __PAGED_MQA_MEMORY_BEGIN__
p=/workspace/expert-profile-backfill-20261109-hidev/deepgemm-runs/paged-mqa-fp8-b2-k256-h8-d128-p64/hidev-npu0/attempt-002
python3 - "$p" <<'PY'
import csv,sys
from pathlib import Path
p=Path(sys.argv[1]);f,=list(p.rglob('Memory.csv'))
with f.open(encoding='utf-8-sig',newline='') as fp:rows=list(csv.DictReader(fp))
for row in rows:
 if row['block_id'] in ('9','19'):
  print(row['block_id'],row['sub_block_id'],row['UB_to_GM_datas(KB)'])
PY
echo __PAGED_MQA_MEMORY_END__
