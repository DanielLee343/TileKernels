from pathlib import Path
p=Path(__file__).resolve().parent
s=(p/'run-hidev-extra-engram-gate-bwd.sh').read_text()
assert 'unified-extra5/engram_gate_bwd-01' in s
s=s.replace('unified-extra5/engram_gate_bwd-01','unified-extra5/engram_gate_bwd-15')
s=s.replace('$root/run-hidev-extra-engram-gate-bwd.sh','$root/run-hidev-extra-engram-gate-bwd-mask.sh')
(p/'run-hidev-extra-engram-gate-bwd-mask.sh').write_text(s,encoding='utf8',newline='\n')
print('prepared masked Engram backward pilot using original test and input')
