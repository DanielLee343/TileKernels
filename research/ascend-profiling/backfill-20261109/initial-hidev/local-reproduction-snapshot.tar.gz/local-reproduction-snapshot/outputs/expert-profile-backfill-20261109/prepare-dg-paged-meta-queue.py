from pathlib import Path
p=Path(__file__).resolve().parent;s=(p/'hidev-dg-transform-queue.py').read_text()
for old,new in [('deepgemm-transform-queue','deepgemm-paged-meta-queue'),
                ('deepgemm-transform-harness','deepgemm-paged-meta-harness'),
                ("assert len(items)==14","assert len(items)==8"),
                ("x['target']=='transform_sf'","x['target']=='paged_mqa_logits_metadata_simt_impl'"),
                ('run-hidev-deepgemm-transform.sh','run-hidev-deepgemm-paged-meta.sh'),
                ('inspect-deepgemm-transform.py','inspect-deepgemm-paged-meta.py'),
                ('audit-deepgemm-transform-general.py','audit-deepgemm-paged-meta.py'),
                ('ALL_DG_TRANSFORM_SELECTED_AUDITED','ALL_DG_PAGED_META_SELECTED_AUDITED')]:
 assert old in s,old;s=s.replace(old,new)
(p/'hidev-dg-paged-meta-queue.py').write_text(s,encoding='utf8',newline='\n')
print('paged metadata queue prepared for 8 cases')
