import base64,hashlib,io,tarfile
from pathlib import Path
p=Path(__file__).resolve().parent
s=(p/'run-hidev-extra-moe-backward-detail.sh').read_text(encoding='utf-8')
for old,new in (('run-hidev-extra-moe-backward-detail.sh','run-hidev-extra-moe-forward-detail.sh'),('test "$group" = moe_topk_gate_backward','test "$group" = moe_topk_gate_forward')):
 assert old in s;s=s.replace(old,new)
(p/'run-hidev-extra-moe-forward-detail.sh').write_text(s,encoding='utf-8',newline='\n')
s=(p/'inspect-extra-moe-backward.py').read_text(encoding='utf-8')
old="for key in ('group','params','seed','captured_fix_routing','routed_scaling_factor','routing_fixture_inputs'):assert a[key]==old[key],key\nassert a['correctness']=='passed_upstream_full_moe_backward_test'"
new="for key in ('group','params','seed','route_counts','scalar_inputs','requested_fix_routing'):assert a[key]==old[key],key\nassert a['correctness']=='passed_upstream_full_moe_forward_test'"
assert old in s;s=s.replace(old,new).replace('MoE backward overwrites grad_logits; completeness and replay behavior require separate audit','MoE forward input/output routing semantics and address coverage require separate audit')
(p/'inspect-extra-moe-forward.py').write_text(s,encoding='utf-8',newline='\n')
buf=io.BytesIO()
with tarfile.open(fileobj=buf,mode='w:gz') as t:
 for n in ('run-hidev-extra-moe-forward-detail.sh','inspect-extra-moe-forward.py'):t.add(p/n,arcname=n)
data=buf.getvalue();enc=base64.b64encode(data).decode();sha=hashlib.sha256(data).hexdigest()
for i in range(0,len(enc),5500):
 part=i//5500;mode='>' if part==0 else '>>'
 (p/f'deploy-moe-forward-part-{part}.sh').write_text(f"printf '%s' '{enc[i:i+5500]}' {mode} /workspace/expert-profile-backfill-20261109-hidev/moe-forward-deploy.b64\necho __MOE_FORWARD_PART_{part}__\n",encoding='utf-8',newline='\n')
script=f'''set -e
echo __DEPLOY_MOE_FORWARD_BEGIN__
r=/workspace/expert-profile-backfill-20261109-hidev
base64 -d "$r/moe-forward-deploy.b64" > "$r/moe-forward-deploy.tar.gz"
printf '%s  %s\\n' {sha} "$r/moe-forward-deploy.tar.gz" | sha256sum -c
test ! -e "$r/run-hidev-extra-moe-forward-detail.sh"
tar -xzf "$r/moe-forward-deploy.tar.gz" -C "$r"
echo __DEPLOY_MOE_FORWARD_END__
'''
(p/'deploy-moe-forward-finish.sh').write_text(script,encoding='utf-8',newline='\n')
print('parts',(len(enc)+5499)//5500)
