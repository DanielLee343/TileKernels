echo __CHECK_NORM_ARCHIVE_BEGIN__
r=/workspace/expert-profile-backfill-20261109-hidev
ps -p "$(cat "$r/norm-backward-archive.pid")" -o pid,stat,etime,args || true
tail -n 8 "$r/norm-backward-archive.log"
test ! -f "$r/norm-backward-snapshot-archive-bundle.tar.gz" || stat -c '%s bytes' "$r/norm-backward-snapshot-archive-bundle.tar.gz"
echo __CHECK_NORM_ARCHIVE_END__
