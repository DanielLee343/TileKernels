import base64,hashlib,io,tarfile
from pathlib import Path
p=Path(__file__).resolve().parent;b=io.BytesIO()
names=['run-hidev-mega28-detail.sh','mega28-profile-harness/campaign-13/mega_port_run.py','mega28-profile-harness/provenance.json']
with tarfile.open(fileobj=b,mode='w:gz') as t:
 for n in names:t.add(p/n,arcname=n,recursive=False)
data=b.getvalue();payload=base64.b64encode(data).decode();digest=hashlib.sha256(data).hexdigest()
for i in range(0,len(payload),6000):
 part=i//6000;mode='>' if part==0 else '>>'
 (p/f'deploy-mega28-update-part-{part}.sh').write_text(f"printf '%s' '{payload[i:i+6000]}' {mode} /workspace/expert-profile-backfill-20261109-hidev/mega28-update.b64\nprintf '%s\\n' __HIDEV_MEGA28_UPDATE_PART_{part}__\n",encoding='utf8',newline='\n')
script=f'''set -e
root=/workspace/expert-profile-backfill-20261109-hidev
base64 -d "$root/mega28-update.b64" > "$root/mega28-update.tar.gz"
echo '{digest}  '"$root/mega28-update.tar.gz" | sha256sum -c
tar -xzf "$root/mega28-update.tar.gz" -C "$root"
printf '%s\\n' __HIDEV_MEGA28_UPDATE_DONE__
'''
(p/'deploy-mega28-update-finish.sh').write_text(script,encoding='utf8',newline='\n')
print('bytes',len(data),'parts',(len(payload)+5999)//6000)
