from pathlib import Path
p=Path(__file__).resolve().parent
s=(p/'summarize-dg-bf16-mgroup.py').read_text()
s=s.replace('deepgemm-bf16-mgroup-harness','deepgemm-mqa-ranges-harness').replace('deepgemm-bf16-mgroup-index.json','deepgemm-mqa-index.json')
s=s.replace('assert len(items)==3','assert len(items)==10').replace("assert len(cases)==3 and len({x['case'] for x in cases})==3","assert len(cases)==10 and len({x['case'] for x in cases})==10")
s=s.replace("a['dbi_requested_bytes']==a['output_bytes']","a['dbi_requested_bytes']==a['expected_written_bytes']")
needle="p/'jit/kernel.asc',p/'jit/kernel.o',p/'detail/profile.log'"
assert needle in s;s=s.replace(needle,"p/'jit/kernel.asc',p/'jit/kernel.o',p/'mqa-range-start.bin',p/'mqa-range-end.bin',p/'detail/profile.log'")
(p/'summarize-dg-mqa.py').write_text(s,encoding='utf8',newline='\n')
s=(p/'index-dg-bf16-mgroup.py').read_text().replace('deepgemm-bf16-mgroup-index.json','deepgemm-mqa-index.json').replace('deepgemm-bf16-mgroup-audits','deepgemm-mqa-audits')
s=s.replace('==3','==10').replace("a['dbi_requested_bytes']==a['output_bytes']","a['dbi_requested_bytes']==a['expected_written_bytes']")
(p/'index-dg-mqa.py').write_text(s,encoding='utf8',newline='\n')
print('prepared MQA index including bound input ranges')
