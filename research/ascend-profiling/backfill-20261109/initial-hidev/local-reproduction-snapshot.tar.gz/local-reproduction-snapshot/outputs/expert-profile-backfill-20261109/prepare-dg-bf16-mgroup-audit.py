from pathlib import Path
p=Path(__file__).resolve().parent
s=(p/'audit-deepgemm-mgroup-batch.py').read_text()
s=s.replace("r'mgroup-fp(?:4|8)fp(?:4|8)-[a-z0-9-]+'", "r'mgroup-bf16bf16-[a-z0-9-]+'").replace('fp8_gemm_impl','bf16_gemm_impl').replace('fp8_gemm.hpp','bf16_gemm.hpp')
s=s.replace("str(p/'address-audit.json')", "str(p/'candidate-address-audit.json')")
(p/'audit-dg-bf16-mgroup-candidate.py').write_text(s,encoding='utf8',newline='\n')
print('prepared BF16 candidate audit; source, ISA, captured addresses and CSV checked per case')
