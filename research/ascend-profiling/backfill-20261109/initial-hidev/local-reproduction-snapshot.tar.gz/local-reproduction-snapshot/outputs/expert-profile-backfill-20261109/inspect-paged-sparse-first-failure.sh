echo __PAGED_SPARSE_FIRST_FAILURE_BEGIN__
p=/workspace/expert-profile-backfill-20261109-hidev/deepgemm-runs/paged-sparse-first-0-q4-k256-h8-b8-p64/hidev-npu0/attempt-001
test ! -f "$p/detail/monitor-summary.json" || cat "$p/detail/monitor-summary.json"
test ! -f "$p/profile.json" || cat "$p/profile.json" | head -n 15
grep -iE 'error|fail|exception|replay|finish|profiling' "$p/detail/profile.log" | tail -n 30 | cut -c1-500 || true
echo __PAGED_SPARSE_FIRST_FAILURE_END__
