import base64,hashlib
from pathlib import Path
p=Path(__file__).resolve().parent;data=(p/'run-hidev-classic-detail.sh').read_bytes();digest=hashlib.sha256(data).hexdigest();payload=base64.b64encode(data).decode()
script=f'''set -e
root=/workspace/expert-profile-backfill-20261109-hidev
printf '%s' '{payload}' | base64 -d > "$root/run-hidev-classic-detail.sh.new"
echo '{digest}  '"$root/run-hidev-classic-detail.sh.new" | sha256sum -c
test -f "$root/guard-v4.py"
mv "$root/run-hidev-classic-detail.sh.new" "$root/run-hidev-classic-detail.sh"
printf '%s\\n' __HIDEV_CLASSIC_ATOMIC_DONE__
'''
(p/'deploy-classic-runner-atomic.sh').write_text(script,encoding='utf8',newline='\n')
print('prepared',digest)
