"""Prepare frozen historical contracts and isolated hash capture scaffolding."""
import csv,hashlib,json,tarfile
from pathlib import Path
p=Path(__file__).resolve().parent;root=p.parents[1]
with (p/'targets.csv').open(encoding='utf-8-sig',newline='') as f:rows=list(csv.DictReader(f))
items=[]
for r in rows:
 if r['batch']!='tilekernels-default' or not r['case'].startswith('engram_hash/'):continue
 batch,case=r['target_id'].split('/');assert batch=='starter'
 meta=(root/r['original_profile_paths'].split(';')[0]).parent.parent/'default.json';j=json.loads(meta.read_text())
 assert j['runtime_kernel']==r['op_name'] and j['status']=='passed'
 items.append({'case':case,'batch':batch,'plan_case':r['case'],'target':r['target_id'],'kernel':r['op_name'],
               'metadata_sha256':hashlib.sha256(meta.read_bytes()).hexdigest(),'metadata_path':str(meta.relative_to(root))})
assert len(items)==20 and len({x['case'] for x in items})==20
with tarfile.open(p/'hash-history.tar.gz','w:gz') as t:
 for x in items:
  m=root/x['metadata_path'];t.add(m,arcname='hash-history/'+x['case']+'/default.json')
  t.add(m.parent/'default-kernel.cpp',arcname='hash-history/'+x['case']+'/default-kernel.cpp')
(p/'hash-pending.json').write_text(json.dumps(items,indent=2)+'\n',encoding='utf8')
runner=(p/'run-hidev-fused-detail.sh').read_text()
for a,b in [('fused-runs','hash-runs'),('fused-cache','hash-cache'),('run-hidev-fused-detail.sh','run-hidev-hash-detail.sh'),
            ('engram_fused_weight_kernel_asc_kernel','engram_hash_kernel_asc_kernel'),('fused-','hash-')]:
 assert a in runner,a;runner=runner.replace(a,b)
(p/'run-hidev-hash-detail.sh').write_text(runner,encoding='utf8',newline='\n')
queue=(p/'hidev-topk-queue.py').read_text()
for a,b in [('topk-runs','hash-runs'),('TopK','hash'),('topk-queue','hash-queue'),('topk-pending','hash-pending'),
            ('run-hidev-topk-detail.sh','run-hidev-hash-detail.sh'),('audit-topk-detail.py','audit-hash-detail.py'),
            ('ALL_TOPK_CASES_CAPTURED_OR_AUDITED','ALL_HASH_CASES_CAPTURED_OR_AUDITED')]:
 assert a in queue,a;queue=queue.replace(a,b)
(p/'hidev-hash-queue.py').write_text(queue,encoding='utf8',newline='\n')
print('prepared',len(items),'hash cases')
