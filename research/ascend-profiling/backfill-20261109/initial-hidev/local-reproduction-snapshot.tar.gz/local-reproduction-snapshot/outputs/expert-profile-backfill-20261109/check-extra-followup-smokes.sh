#!/usr/bin/env bash
echo __CHECK_EXTRA_FOLLOWUP_SMOKES_BEGIN__
root=/workspace/expert-profile-backfill-20261109-hidev
for kind in lossless castback;do
 q="$root/extra-$kind-smoke-hidev-npu0";echo "SMOKE=$kind"
 ps -p "$(cat "$q/pid")" -o pid,stat,etime,args || true
 tail -n 18 "$q/console.log"
 if test -f "$q/exit.txt";then cat "$q/exit.txt";fi
done
echo __CHECK_EXTRA_FOLLOWUP_SMOKES_END__
