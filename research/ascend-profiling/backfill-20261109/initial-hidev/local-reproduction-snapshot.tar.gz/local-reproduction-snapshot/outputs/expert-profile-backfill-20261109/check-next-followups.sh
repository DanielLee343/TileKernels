echo __CHECK_NEXT_FOLLOWUPS_BEGIN__
r=/workspace/expert-profile-backfill-20261109-hidev
for stem in deepgemm-kgroup-smoke extra-randn-small-smoke deepgemm-sparse-mqa-smoke;do
 q="$r/$stem-hidev-npu0";echo "JOB=$stem"
 ps -p "$(cat "$q/pid")" -o pid,stat,etime,args || true
 test ! -f "$q/attempt.txt" || cat "$q/attempt.txt"
 test ! -f "$q/exit.txt" || cat "$q/exit.txt"
 tail -n 5 "$q/console.log"
done
echo ARCHIVE
ps -p "$(cat "$r/moe-backward-archive.pid")" -o pid,stat,etime,args || true
tail -n 4 "$r/moe-backward-archive.log"
echo __CHECK_NEXT_FOLLOWUPS_END__
