import base64,hashlib,io,tarfile
from pathlib import Path
p=Path(__file__).resolve().parent;b=io.BytesIO()
with tarfile.open(fileobj=b,mode='w:gz') as t:
 for name in ('unified-quant-extra-harness','run-hidev-unified-quant-extra-detail.sh','inspect-unified-quant-extra.py'):
  t.add(p/name,arcname=name,filter=lambda info:None if '__pycache__' in info.name else info)
data=b.getvalue();encoded=base64.b64encode(data).decode();digest=hashlib.sha256(data).hexdigest()
for i in range(0,len(encoded),5500):
 part=i//5500;mode='>' if part==0 else '>>'
 (p/f'deploy-uq-extra-part-{part}.sh').write_text(f"printf '%s' '{encoded[i:i+5500]}' {mode} /workspace/expert-profile-backfill-20261109-hidev/uq-extra-deploy.b64\nprintf '%s\\n' __UQ_EXTRA_PART_{part}__\n",encoding='utf8',newline='\n')
script=f'''set -e
root=/workspace/expert-profile-backfill-20261109-hidev
base64 -d "$root/uq-extra-deploy.b64" > "$root/uq-extra-deploy.tar.gz"
printf '%s  %s\\n' {digest} "$root/uq-extra-deploy.tar.gz" | sha256sum -c
test ! -e "$root/unified-quant-extra-harness"
tar -xzf "$root/uq-extra-deploy.tar.gz" -C "$root"
bash -n "$root/run-hidev-unified-quant-extra-detail.sh"
python3 -m py_compile "$root/inspect-unified-quant-extra.py" "$root/unified-quant-extra-harness/quant_hook.py"
printf '%s\\n' __UQ_EXTRA_DEPLOY_DONE__
'''
(p/'deploy-uq-extra-finish.sh').write_text(script,encoding='utf8',newline='\n')
print('parts',(len(encoded)+5499)//5500,'sha256',digest)
