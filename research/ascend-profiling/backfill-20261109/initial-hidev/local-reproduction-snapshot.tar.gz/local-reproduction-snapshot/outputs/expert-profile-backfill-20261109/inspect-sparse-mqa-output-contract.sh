echo __SPARSE_MQA_OUTPUT_BEGIN__
f=/workspace/deepgemm-ascend-20261107/source/deep_gemm/include/deep_gemm/sparse_mqa_logits.hpp
sed -n '90,145p;365,410p' "$f"
echo __SPARSE_MQA_OUTPUT_END__
