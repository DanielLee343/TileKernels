#!/usr/bin/env bash
echo __CHECK_ENGRAM_BWD_MASK_TEST_BEGIN__
r=/workspace/expert-profile-backfill-20261109-hidev
ps -p "$(cat "$r/engram-gate-bwd-mask-test.pid")" -o pid=,stat=,args= || true
tail -n 9 "$r/engram-gate-bwd-mask-test.log"
echo __CHECK_ENGRAM_BWD_MASK_TEST_END__
