"""Verify transferred index and register separate validated transform windows."""
import base64,gzip,hashlib,json,re
from pathlib import Path
p=Path(__file__).resolve().parent;root=p.parents[1]
s=(p/'deepgemm-transform-index-capture.txt').read_text(encoding='utf-8-sig')
body=s.split('__DG_TRANSFORM_INDEX_BEGIN__',1)[1].split('__DG_TRANSFORM_INDEX_END__',1)[0].strip()
lines=body.splitlines();expected=lines[0].split()[0];assert re.fullmatch('[0-9a-f]{64}',expected)
data=base64.b64decode(''.join(lines[1:]).replace(' ',''),validate=True);assert hashlib.sha256(data).hexdigest()==expected
doc=json.loads(gzip.decompress(data));assert doc['count']==len(doc['cases'])
(p/'deepgemm-transform-index.json').write_text(json.dumps(doc,indent=2)+'\n',encoding='utf8')
index=p/'deepgemm-new-captures.json';captures=json.loads(index.read_text(encoding='utf8'))
out=p/'deepgemm-transform-audits';out.mkdir(exist_ok=True)
for x in doc['cases']:
 a=x['audit'];assert x['case']==a['case'] and a['status']=='passed' and a['correctness']=='passed'
 assert a['historical_target_input_and_jit_source_match'] and a['dbi_requested_bytes']==a['output_bytes'] and x['health']=='Alarm 8C4BA00C'
 f=out/(x['case'].replace('/','__')+'.json');f.write_text(json.dumps(a,indent=2)+'\n',encoding='utf8')
 captures[x['case']]={'audit':f.relative_to(root).as_posix(),'remote_detail':x['raw_dir']+'/detail',
 'device':'hidev NPU 0','health':x['health'],'files_sha256':x['files_sha256']}
index.write_text(json.dumps(captures,indent=2)+'\n',encoding='utf8')
print('PASS index sha256',expected,'transform cases',doc['count'])
