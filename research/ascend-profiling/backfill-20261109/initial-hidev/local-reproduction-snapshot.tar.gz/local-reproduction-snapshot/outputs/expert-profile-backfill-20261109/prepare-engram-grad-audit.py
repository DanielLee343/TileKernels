from pathlib import Path
p=Path(__file__).resolve().parent;s=(p/'audit-extra-norm-accum-app-batch.py').read_text(encoding='utf-8')
for old,new in (
 ("r'quant_norm_backward-(0[1-9]|1[0-9]|20)'", "r'engram_grad_w_reduce-(0[1-9]|1[0-9]|20)'"),
 ("/'unified-extra3'/case", "/'unified-extra'/case"),
 ("assert len(a)==8 and all(a[i] is not None for i in (0,1,2,3,4,5,7))", "assert len(a)==5 and all(a)"),
 ("app['source_sha256']==old['source_sha256']", "app['source_sha256']==records[0]['source_sha256']"),
 ("'unified-extra3/'+case", "'unified-extra/'+case"),
):
 assert old in s,old;s=s.replace(old,new)
start=s.index("params=selected['params'];");end=s.index('def span(t):',start)
s=s[:start]+'''params=selected['params'];hidden=params['hidden'];cores=28
assert a[0]['shape']==[14,4,hidden] and all(a[i]['shape']==[4,hidden] for i in (1,2,3,4))
assert all(a[i]['dtype']=='torch.float32' for i in (0,3,4))
outputs=[a[3],a[4]];names=['grad_weight_hidden','grad_weight_embed']
''' +s[end:]
s=s.replace("inputs=[z for z in (a[0],a[1],a[2],a[3],a[6]) if z is not None]", "inputs=a[:3]")
s=s.replace("assert len(lines)==3 and 'block_idx' in source", "assert len(lines)==2 and 'block_idx' in source")
s=s.replace('the accumulated weight gradient is intentionally read and written in place','the two gradient outputs are intentionally read and written in place')
s=s.replace("(p/'audit-result.json').write_text", "(p/'candidate-audit-result.json').write_text")
(p/'audit-engram-grad-app-candidate.py').write_text(s,encoding='utf-8',newline='\n')
compile(s,str(p/'audit-engram-grad-app-candidate.py'),'exec')
print('ENGRAM_GRAD_AUDIT_PREPARED')
