echo __PILOT_M1_DETAIL_BEGIN__
r=/workspace/expert-profile-backfill-20261109-hidev/deepgemm-pilot-runs
python3 - "$r" <<'PY'
import csv,json,sys
from pathlib import Path
r=Path(sys.argv[1])
for case in ('bf16-m1-n32768-k512','fp8fp8-m1-n32768-k512','fp4fp4-m1-n32768-k512','fp8fp4-m1-n32768-k512'):
 p=r/case/'hidev-npu0/attempt-001'
 if not (p/'capture-inspection.json').exists():continue
 d=json.loads((p/'capture-inspection.json').read_text());a=d['addresses'];f,=list((p/'detail/capture').rglob('OpBasicInfo.csv'))
 with f.open(encoding='utf-8-sig',newline='') as fp:op,=csv.DictReader(fp)
 print('CASE',case,'op',op['Op Type'],'blocks',op['Block Dim'],op['Mix Block Dim'],'address',a['output'])
 log=(p/'detail/profile.log').read_text(errors='replace');print('stores',sum('DBI record core:' in s and 'dst:(type:GM;' in s and 'src:(type:UB;' in s for s in log.splitlines()))
 print('JIT', (p/'jit/kernel.asc').read_text()[:300])
PY
echo __PILOT_M1_DETAIL_END__
