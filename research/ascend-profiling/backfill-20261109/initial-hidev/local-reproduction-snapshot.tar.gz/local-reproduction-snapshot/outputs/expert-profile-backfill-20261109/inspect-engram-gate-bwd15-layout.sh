#!/usr/bin/env bash
echo __INSPECT_ENGRAM_GATE_BWD15_LAYOUT_BEGIN__
p=/workspace/expert-profile-backfill-20261109-hidev/extra-proxy-runs/unified-extra5/engram_gate_bwd-15/hidev-npu0/attempt-001/detail
python3 - "$p" <<'PY'
import json,csv,re,sys
from pathlib import Path
p=Path(sys.argv[1]);print('app',json.loads((p/'application.json').read_text())['params'])
for i,a in enumerate(json.loads((p/'tensor-addresses.json').read_text())):print('arg',i,a)
op,=p.rglob('OpBasicInfo.csv')
with op.open(encoding='utf-8-sig',newline='') as f:b,=csv.DictReader(f)
print('blockdim',b['Block Dim'],'optype',b['Op Type'])
for x in (p/'generated-kernel.cpp').read_text().splitlines():
 if 'asc_copy_ub2gm_align(' in x:
  dst=x.split('(__ubuf__',1)[0];m=re.search(r'\(&\((?:\(\([^)]*\)\s*)?([a-zA-Z_]\w*)\s*\)?\[',dst);print('store',m.group(1) if m else dst[:150])
PY
echo __INSPECT_ENGRAM_GATE_BWD15_LAYOUT_END__
