from pathlib import Path
p=Path(__file__).resolve().parent
a=(p/'audit-dg-mqa-candidate.py').read_text();old="assert case=='mqa-0-q16-k512-h8-random' and attempt=='attempt-002'"
assert old in a;a=a.replace(old,"assert re.fullmatch(r'mqa-[a-z0-9-]+',case) and re.fullmatch(r'attempt-[0-9]+',attempt)")
old="str(p/'candidate-address-audit.json')";assert old in a;a=a.replace(old,"str(p/'address-audit.json')")
(p/'audit-dg-mqa-batch.py').write_text(a,encoding='utf8',newline='\n')
s=(p/'hidev-dg-bf16-mgroup-queue.py').read_text()
for old,new in [('deepgemm-bf16-mgroup-queue','deepgemm-mqa-queue'),('deepgemm-bf16-mgroup-harness','deepgemm-mqa-ranges-harness'),
                ('assert len(items)==3','assert len(items)==10'),('bf16_gemm_impl','mqa_logits_impl'),
                ('run-hidev-deepgemm-bf16-mgroup.sh','run-hidev-deepgemm-mqa-ranges.sh'),
                ('inspect-deepgemm-bf16-mgroup.py','inspect-deepgemm-mqa-ranges.py'),
                ('audit-dg-bf16-mgroup-batch.py','audit-dg-mqa-batch.py'),
                ('ALL_DG_BF16_MGROUP_SELECTED_AUDITED','ALL_DG_MQA_SELECTED_AUDITED')]:
 assert old in s,old;s=s.replace(old,new)
(p/'hidev-dg-mqa-queue.py').write_text(s,encoding='utf8',newline='\n')
print('prepared ten MQA cases with bound ranges and per-row expected coverage')
