echo __INSPECT_SPARSE_CONTRACT_BEGIN__
sed -n '686,775p;805,830p' /workspace/deepgemm-ascend-20261107/source/tests/test_attention.py
echo __INSPECT_SPARSE_CONTRACT_END__
