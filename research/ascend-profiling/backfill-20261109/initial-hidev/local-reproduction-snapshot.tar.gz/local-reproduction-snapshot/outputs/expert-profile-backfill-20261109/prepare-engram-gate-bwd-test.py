from pathlib import Path
p=Path(__file__).resolve().parent
s=(p/'test-engram-gate-fwd-unmasked.sh').read_text()
for old,new in [('engram_gate_fwd-01','engram_gate_bwd-01'),
                ('audit-extra-engram-gate-fwd-unmasked-candidate.py','audit-extra-engram-gate-bwd-unmasked-candidate.py'),
                ('for index in 4 5 6 7 8','for index in 9 10 11'),
                ("a[4]['address']=a[0]['address']","a[9]['address']=a[0]['address']"),
                ("a[5]['shape'][-1]//=2","a[11]['shape'][-1]//=2"),
                ('ENGRAM_GATE_FWD_UNMASKED_TEST','ENGRAM_GATE_BWD_UNMASKED_TEST'),('all five outputs','all three outputs')]:
 assert old in s,old;s=s.replace(old,new)
(p/'test-engram-gate-bwd-unmasked.sh').write_text(s,encoding='utf8',newline='\n')
print('prepared tests for all three unmasked gradient outputs')
