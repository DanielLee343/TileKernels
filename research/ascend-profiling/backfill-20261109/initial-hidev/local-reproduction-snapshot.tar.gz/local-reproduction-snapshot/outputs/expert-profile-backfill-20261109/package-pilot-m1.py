import base64,hashlib,io,tarfile
from pathlib import Path
p=Path(__file__).resolve().parent;b=io.BytesIO()
with tarfile.open(fileobj=b,mode='w:gz') as t:
 for n in ('deepgemm-pilot-m1-harness','run-hidev-deepgemm-pilot-m1.sh','inspect-pilot-m1.py'):
  t.add(p/n,arcname=n,filter=lambda x:None if '__pycache__' in x.name else x)
data=b.getvalue();encoded=base64.b64encode(data).decode();sha=hashlib.sha256(data).hexdigest()
for i in range(0,len(encoded),5500):
 part=i//5500;mode='>' if part==0 else '>>'
 (p/f'deploy-pilot-m1-part-{part}.sh').write_text(f"printf '%s' '{encoded[i:i+5500]}' {mode} /workspace/expert-profile-backfill-20261109-hidev/pilot-m1-deploy.b64\necho __PILOT_M1_PART_{part}__\n",encoding='utf-8',newline='\n')
script=f'''set -e
echo __DEPLOY_PILOT_M1_BEGIN__
r=/workspace/expert-profile-backfill-20261109-hidev
base64 -d "$r/pilot-m1-deploy.b64" > "$r/pilot-m1-deploy.tar.gz"
printf '%s  %s\\n' {sha} "$r/pilot-m1-deploy.tar.gz" | sha256sum -c
test ! -e "$r/deepgemm-pilot-m1-harness"
tar -xzf "$r/pilot-m1-deploy.tar.gz" -C "$r"
bash -n "$r/run-hidev-deepgemm-pilot-m1.sh"
python3 -m py_compile "$r/inspect-pilot-m1.py" "$r/deepgemm-pilot-m1-harness/pilot-bf16/collect.py" "$r/deepgemm-pilot-m1-harness/pilot-quant/collect.py"
echo __DEPLOY_PILOT_M1_END__
'''
(p/'deploy-pilot-m1-finish.sh').write_text(script,encoding='utf-8',newline='\n')
print('parts',(len(encoded)+5499)//5500)
