#!/usr/bin/env bash
echo __CHECK_FINAL_QUEUES_SNAPSHOT_BEGIN__
r=/workspace/expert-profile-backfill-20261109-hidev
for x in extra-engram-gate-fwd-unmasked-queue-hidev-npu0 extra-norm-backward-noweight-queue-hidev-npu0 deepgemm-dequant-mgroup-queue-hidev-npu0;do
 q="$r/$x";echo "--- $x ---";ps -p "$(cat "$q/pid")" -o pid=,stat=,args= || true;test ! -f "$q/exit.txt" || cat "$q/exit.txt";tail -n 8 "$q/console.log" 2>/dev/null || true
done
echo '--- selected archives ---'
ps -p "$(cat "$r/selected-snapshot-archives.pid")" -o pid=,stat=,args= || true
grep -E 'SELECTED_SNAPSHOT_VERIFIED|ALL_SELECTED_SNAPSHOTS_VERIFIED|snapshot-archive-bundle.tar.gz$|Traceback|AssertionError' "$r/selected-snapshot-archives.log" | tail -n 10 || true
echo __CHECK_FINAL_QUEUES_SNAPSHOT_END__
