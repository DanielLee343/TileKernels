echo __CHECK_NORMAL_BF16_SMOKE_BEGIN__
q=/workspace/expert-profile-backfill-20261109-hidev/deepgemm-normal-bf16-smoke-hidev-npu0
ps -p "$(cat "$q/pid")" -o pid,stat,etime,args || true
test ! -f "$q/attempt.txt" || cat "$q/attempt.txt"
test ! -f "$q/exit.txt" || cat "$q/exit.txt"
tail -n 12 "$q/console.log"
echo __CHECK_NORMAL_BF16_SMOKE_END__
