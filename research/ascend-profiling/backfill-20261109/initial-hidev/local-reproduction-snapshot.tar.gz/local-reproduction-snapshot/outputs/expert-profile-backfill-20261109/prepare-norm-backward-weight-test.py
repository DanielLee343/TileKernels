from pathlib import Path
p=Path(__file__).resolve().parent
s=(p/'test-engram-gate-fwd-unmasked.sh').read_text()
for old,new in [('engram_gate_fwd-01','quant_norm_backward-03'),('unified-extra5','unified-extra3'),
                ('audit-extra-engram-gate-fwd-unmasked-candidate.py','audit-extra-norm-backward-weight-candidate.py'),
                ('for index in 4 5 6 7 8','for index in 4 5 7'),
                ('ENGRAM_GATE_FWD_UNMASKED_TEST','NORM_BACKWARD_WEIGHT_TEST'),
                ('all five outputs','all three outputs')]:
 assert old in s,old;s=s.replace(old,new)
(p/'test-norm-backward-weight.sh').write_text(s,encoding='utf8',newline='\n')
print('prepared negative checks for gradient, partial and final weight gradient')
