from pathlib import Path
p=Path(__file__).resolve().parent;orig=(p/'test-dg-kgroup-audit.sh').read_text(encoding='utf-8')
for tag,auditor in (('fp8fp8','audit-dg-kgroup-fp8-candidate.py'),('fp4fp4','audit-dg-kgroup-fp8-candidate.py'),('fp8fp4','audit-dg-kgroup-dequant-candidate.py')):
 s=orig.replace('kgroup-bf16bf16-tn-g4-m64-n256-k512',f'kgroup-{tag}-tn-g4-m64-n256-k512')
 s=s.replace('audit-dg-kgroup-bf16-candidate.py',auditor).replace('__DG_KGROUP_AUDIT_TEST_',f'__DG_KGROUP_{tag.upper()}_AUDIT_TEST_')
 s=s.replace("d[0]['args'][0]['address']", "d[0]['args'][0][0]['address']")
 if tag=='fp8fp4':s=s.replace("x['sub_block_id']=='vector0'", "x['sub_block_id']=='vector1'")
 (p/f'test-dg-kgroup-{tag}-audit.sh').write_text(s,encoding='utf-8',newline='\n')
