echo __CHECK_FINAL_DEEPGEMM_ARCHIVE_BEGIN__
r=/workspace/expert-profile-backfill-20261109-hidev
ps -p "$(cat "$r/final-deepgemm-archive.pid")" -o pid,stat,etime,args || true
tail -n 8 "$r/final-deepgemm-archive.log"
test ! -f "$r/final-deepgemm-smokes-snapshot-archive-bundle.tar.gz" || stat -c '%s bytes' "$r/final-deepgemm-smokes-snapshot-archive-bundle.tar.gz"
echo __CHECK_FINAL_DEEPGEMM_ARCHIVE_END__
