#!/usr/bin/env bash
echo __CHECK_CURRENT_WORKERS_BEGIN__
root=/workspace/expert-profile-backfill-20261109-hidev
for n in extra-norm-accum-app-queue dg-paged-mqa-smoke extra-randn-smoke; do
  q="$root/$n-hidev-npu0"
  echo "QUEUE=$n"
  for f in pid followup.pid exit.txt followup-exit.txt; do
    if test -f "$q/$f"; then printf '%s=' "$f"; cat "$q/$f"; fi
  done
  if test -f "$q/console.log"; then tail -n 5 "$q/console.log"; fi
done
ps -eo pid,ppid,stat,etime,args | grep -E '[m]sprof|[n]orm-accum-app|[p]aged-mqa|[r]andn-smoke' | tail -n 15
echo __CHECK_CURRENT_WORKERS_END__
