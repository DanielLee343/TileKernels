echo __MOE_FORWARD_BINARY_BEGIN__
r=/workspace/expert-profile-backfill-20261109-hidev
old=/workspace/tilekernels-env-20261101/src/TileKernels-private/research/ascend-profiling/runs/hidev-20261106-unified-extra3/cases/moe_topk_gate_forward-01
new="$r/extra-proxy-runs/unified-extra3/moe_topk_gate_forward-01/hidev-npu0/attempt-001/detail"
find "$old"/capture "$new"/capture -name aicore_binary.o -exec sha256sum {} \;
echo __MOE_FORWARD_BINARY_END__
