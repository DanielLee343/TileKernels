#!/usr/bin/env bash
echo __INSPECT_DG_MQA_STORE_SOURCE_BEGIN__
r=/workspace/deepgemm-ascend-20261107/source/deep_gemm/include/deep_gemm
grep -n -E 'copy_ub_to_gm|seq_ke|seq_ks|logits|kv_len' "$r/mqa_logits.hpp" | head -n 85
echo __INSPECT_DG_MQA_STORE_SOURCE_END__
