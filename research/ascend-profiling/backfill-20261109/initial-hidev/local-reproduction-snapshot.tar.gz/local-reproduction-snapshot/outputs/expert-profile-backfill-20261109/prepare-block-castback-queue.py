from pathlib import Path
p=Path(__file__).resolve().parent
audit=(p/'audit-extra-castback.py').read_text();assert 'quant_cast_back_per_token-' in audit
audit=audit.replace('quant_cast_back_per_token-','quant_cast_back_block-')
(p/'audit-extra-block-castback-batch.py').write_text(audit,encoding='utf8',newline='\n')
s=(p/'hidev-extra-channel-queue.py').read_text()
for old,new in [('quant_per_channel_cast','quant_cast_back_block'),
                ('extra-channel-queue','extra-block-castback-queue'),
                ('run-hidev-extra-proxy-detail.sh','run-hidev-extra-block-castback-detail.sh'),
                ('inspect-extra-proxy.py','inspect-extra-block-castback.py'),
                ('audit-extra-channel.py','audit-extra-block-castback-batch.py'),
                ('ALL_CHANNEL_SELECTED_AUDITED','ALL_BLOCK_CASTBACK_SELECTED_AUDITED')]:
 assert old in s;s=s.replace(old,new)
(p/'hidev-extra-block-castback-queue.py').write_text(s,encoding='utf8',newline='\n')
print('block cast-back 20-case queue prepared after negative test')
