echo __ENGRAM_GRAD_PROGRESS_BEGIN__
p=/workspace/expert-profile-backfill-20261109-hidev/extra-proxy-runs/unified-extra/engram_grad_w_reduce-01/hidev-npu0/attempt-001/detail
ls "$p"/application-*.json 2>/dev/null | wc -l
tail -n 8 "$p/profile.log" 2>/dev/null | cut -c1-250
ps -eo pid,ppid,stat,etime,args | grep -E '[m]sprof op.*engram_grad|[e]xtra_engram_grad.py' | cut -c1-230
echo __ENGRAM_GRAD_PROGRESS_END__
