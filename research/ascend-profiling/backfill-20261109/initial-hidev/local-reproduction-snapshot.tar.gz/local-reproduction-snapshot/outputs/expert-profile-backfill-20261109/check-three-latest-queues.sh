#!/usr/bin/env bash
echo __CHECK_THREE_LATEST_QUEUES_BEGIN__
r=/workspace/expert-profile-backfill-20261109-hidev
for x in extra-norm-forward-queue-hidev-npu0 extra-swiglu-forward-queue-hidev-npu0 extra-swiglu-backward-smoke-hidev-npu0;do
 q="$r/$x";echo "--- $x ---";ps -p "$(cat "$q/pid")" -o pid=,stat=,args= || true;test ! -f "$q/exit.txt" || cat "$q/exit.txt";tail -n 8 "$q/console.log" 2>/dev/null || true
done
echo __CHECK_THREE_LATEST_QUEUES_END__
