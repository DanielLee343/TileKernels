from pathlib import Path
p=Path(__file__).resolve().parent
s=(p/'run-hidev-extra-norm-backward-detail.sh').read_text()
old='test "$group" = quant_norm_backward; test "$target" = unified-extra3/quant_norm_backward-01'
new='test "$group" = quant_norm_backward; [[ "$target" =~ ^unified-extra3/quant_norm_backward-(03|06|07)$ ]]'
assert old in s;s=s.replace(old,new)
s=s.replace('$root/run-hidev-extra-proxy-detail.sh','$root/run-hidev-extra-norm-backward-variants.sh')
(p/'run-hidev-extra-norm-backward-variants.sh').write_text(s,encoding='utf8',newline='\n')
print('prepared only explicitly non-accumulating variant cases 03, 06, 07')
