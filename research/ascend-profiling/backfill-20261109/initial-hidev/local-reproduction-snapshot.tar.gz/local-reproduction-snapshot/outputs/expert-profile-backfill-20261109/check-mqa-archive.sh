echo __CHECK_MQA_ARCHIVE_BEGIN__
r=/workspace/expert-profile-backfill-20261109-hidev
ps -p "$(cat "$r/mqa-completed-archive.pid")" -o pid,stat,etime,args || true
tail -n 6 "$r/mqa-completed-archive.log"
test ! -f "$r/mqa-completed-snapshot-archive-bundle.tar.gz" || stat -c '%s bytes' "$r/mqa-completed-snapshot-archive-bundle.tar.gz"
echo __CHECK_MQA_ARCHIVE_END__
