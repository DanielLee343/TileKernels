"""Retain verified child PID history to distinguish stale process reports."""
from pathlib import Path
p=Path(__file__).resolve().parent;s=(p/'guard-v4.py').read_text()
needle="def main():\n"
insert="""def unexpected_processes(reported,current,seen,exists=lambda pid:Path(f'/proc/{pid}').exists()):
    unexpected=reported-current
    stale={pid for pid in unexpected if pid in seen and not exists(pid)}
    return unexpected-stale,stale

"""
assert s.count(needle)==1;s=s.replace(needle,insert+needle)
s=s.replace("state={'last_success':None,'max_gap':0.,'queries':0,'query_failures':0,'timeouts':0};proc=None;error=None",
            "state={'last_success':None,'max_gap':0.,'queries':0,'query_failures':0,'timeouts':0};proc=None;error=None;seen_owned=set();stale_owned=set()")
old="""                    unexpected=processes(device,log,state)-family(proc.pid)
                    if unexpected:raise RuntimeError(f'unexpected device PIDs: {sorted(unexpected)}')
"""
new="""                    reported=processes(device,log,state);current=family(proc.pid);seen_owned.update(current)
                    unexpected,stale=unexpected_processes(reported,current,seen_owned);stale_owned.update(stale)
                    if stale:log.write(f'confirmed exited previously-owned PIDs: {sorted(stale)}\\n');log.flush()
                    if unexpected:raise RuntimeError(f'unexpected device PIDs: {sorted(unexpected)}')
"""
assert s.count(old)==1;s=s.replace(old,new)
old="            if processes(device,log,state):raise RuntimeError('device busy after capture')\n"
new="""            reported=processes(device,log,state);unexpected,stale=unexpected_processes(reported,set(),seen_owned);stale_owned.update(stale)
            if unexpected:raise RuntimeError(f'device busy after capture: {sorted(unexpected)}')
"""
assert s.count(old)==1;s=s.replace(old,new)
old="             'status':'failed' if error else 'passed','profiler_returncode':None if proc is None else proc.returncode,\n"
new="             'status':'failed' if error else 'passed','profiler_returncode':None if proc is None else proc.returncode,\n             'exited_previously_owned_pids':sorted(stale_owned),\n"
assert s.count(old)==1;s=s.replace(old,new)
compile(s,str(p/'guard-v5.py'),'exec');(p/'guard-v5.py').write_text(s,encoding='utf8',newline='\n')
print('prepared guard v5 with exited-owned PID handling; unknown/live processes still rejected')
