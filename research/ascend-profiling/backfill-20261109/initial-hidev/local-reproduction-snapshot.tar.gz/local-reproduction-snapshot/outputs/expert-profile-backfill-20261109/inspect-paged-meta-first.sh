#!/usr/bin/env bash
set -e
echo __INSPECT_PAGED_META_FIRST_BEGIN__
p=/workspace/expert-profile-backfill-20261109-hidev/deepgemm-runs/paged-meta-b2-k256-h8-d128-p64/hidev-npu0/attempt-001
grep 'DBI record core:' "$p/detail/profile.log" | head -20
find "$p/detail/capture" -name Memory.csv -exec cat {} \;
grep -nE 'paged_mqa_logits_metadata_simt_impl|copy_ub|ub_to_gm|__gm__|asc_copy' /workspace/deepgemm-ascend-20261107/source/deep_gemm/include/deep_gemm/paged_mqa_logits_metadata.hpp | tail -40
sed -n '140,172p' /workspace/deepgemm-ascend-20261107/source/deep_gemm/include/deep_gemm/paged_mqa_logits_metadata.hpp
echo __INSPECT_PAGED_META_FIRST_END__
