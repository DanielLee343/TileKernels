#!/usr/bin/env bash
echo __INSPECT_CAST_NORM_BWD_LAYOUTS_BEGIN__
root=/workspace/expert-profile-backfill-20261109-hidev
python3 - "$root" <<'PY'
import json,sys
from pathlib import Path
r=Path(sys.argv[1])/'extra-proxy-runs'
for target in ('unified-extra/quant_cast-01','unified-extra3/quant_norm_backward-01'):
 p=r/target/'hidev-npu0/attempt-001/detail';print('\n###',target)
 for i,a in enumerate(json.loads((p/'tensor-addresses.json').read_text())):print('arg',i,a)
 print('\n'.join(x.strip() for x in (p/'generated-kernel.cpp').read_text().splitlines() if 'asc_copy_ub2gm_align(' in x))
PY
echo __INSPECT_CAST_NORM_BWD_LAYOUTS_END__
