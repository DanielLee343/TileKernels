#!/usr/bin/env bash
echo __INSPECT_SWIGLU_BWD01_LAYOUT_BEGIN__
r=/workspace/expert-profile-backfill-20261109-hidev/extra-proxy-runs/unified-extra4/quant_swiglu_backward-01/hidev-npu0/attempt-001/detail
python3 - "$r" <<'PY'
import json,sys
from pathlib import Path
p=Path(sys.argv[1]);print('params',json.loads((p/'application.json').read_text())['params'])
for i,a in enumerate(json.loads((p/'tensor-addresses.json').read_text())):print('arg',i,a)
print('\n'.join(x.strip() for x in (p/'generated-kernel.cpp').read_text().splitlines() if 'asc_copy_ub2gm_align(' in x))
PY
echo __INSPECT_SWIGLU_BWD01_LAYOUT_END__
