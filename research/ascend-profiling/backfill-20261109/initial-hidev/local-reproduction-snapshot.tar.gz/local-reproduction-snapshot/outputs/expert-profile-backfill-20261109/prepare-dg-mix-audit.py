"""Prepare general mixed-GEMM output audit for ordinary overwritten outputs."""
from pathlib import Path
p=Path(__file__).resolve().parent;s=(p/'audit-deepgemm-transform-general.py').read_text()
s=s.replace('Audit a transform_sf output; reject layouts or traffic not independently covered.',
            'Audit an ordinary mixed GEMM output; reject unverified traffic or layouts.')
s=s.replace("r'transform-[a-z0-9-]+'","r'gemm-fp(?:4|8)fp(?:4|8)-[a-z0-9-]+'");s=s.replace("out=addr['returned']","out=addr['args'][2]")
old="assert basic['Op Type']=='vector' and basic['Block Dim']=='56' and basic['Device Id']=='0' and 'transform_sf' in basic['Op Name']"
new="assert (basic['Op Type'],basic['Block Dim'],basic['Mix Block Dim'],basic['Device Id'])==('mix','28','56','0') and 'fp8_gemm_impl' in basic['Op Name']"
assert s.count(old)==1;s=s.replace(old,new)
start=s.index("header=Path('/workspace/deepgemm-ascend-20261107/source/deep_gemm/include/deep_gemm/transform_sf.hpp')")
end=s.index("\nbinary=op.parent/'dump/aicore_binary.o'",start)
s=s[:start]+'''repo=Path('/workspace/deepgemm-ascend-20261107/source');headers=[]
for rel in ['deep_gemm/include/deep_gemm/fp8_gemm.hpp','deep_gemm/include/deep_gemm/epilogue.hpp']:
 f=repo/rel;headers.append(f.read_text());assert subprocess.check_output(['git','-C',str(repo),'hash-object',str(f)],text=True).strip()==subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD:'+rel],text=True).strip()
assert '__mix__(1, kDirectStore ? 0 : 2)' in headers[0] and 'kNumEpilogueStages, 2,' in headers[0]
assert 'aiv_id != 2 - kNumAIVs + s_epi % kNumAIVs' in headers[1] and 'copy_ub_to_gm(d.index(block.m_idx, block.n_idx)' in headers[1]
'''+s[end:]
start=s.index("mem=read(op.with_name('Memory.csv'));assert len(mem)==56")
end=s.index("\nresult={",start)
s=s[:start]+'''mem=read(op.with_name('Memory.csv'));assert len(mem)==84
for j,row in enumerate(mem):
 group,role=divmod(j,3);assert int(row['block_id'])==group and row['sub_block_id']==('cube0','vector0','vector1')[role]
 value=row['UB_to_GM_datas(KB)']
 if role:
  total=rounded[3*group+role-1]
  if value not in ('NA',''):assert abs(Decimal(value)*1024-total)<=Decimal('0.000512'),(j,value,total)
  else:assert total==0
 else:assert value in ('NA','') or Decimal(value)==0
'''+s[end:]
s=s.replace("'target':'transform_sf'","'target':'fp8_gemm_impl'")
s=s.replace("'historical_target_input_and_jit_source_match':True","'historical_true_inputs_and_jit_source_match':True")
s=s.replace(" 'cpp_header_sha256':sha(header),", " ")
s=s.replace("'scope':'one MemoryDetail window; requested UB to GM bytes, not physical DRAM transactions'", "'scope':'one mixed-kernel MemoryDetail window; AIV UB to GM requests, not Cube traffic or physical DRAM transactions'")
assert 'sha(header)' not in s and "'target':'fp8_gemm_impl'" in s
compile(s,str(p/'audit-deepgemm-mix-general.py'),'exec')
(p/'audit-deepgemm-mix-general.py').write_text(s,encoding='utf8',newline='\n')
print('prepared mixed GEMM general audit; requires same-case and new-shape validation')
