#!/usr/bin/env bash
echo __CHECK_STATIC_OTHER_ARCHIVES_BEGIN__
r=/workspace/expert-profile-backfill-20261109-hidev
ps -p "$(cat "$r/static-other-archives.pid")" -o pid=,stat=,args= || true
grep -E 'FILES_SCANNED|STATIC_GROUP_ARCHIVE_VERIFIED|ALL_STATIC_GROUP_ARCHIVES_VERIFIED|Traceback|AssertionError|Error' "$r/static-other-archives.log" | tail -n 30 || true
ls -lh "$r"/*-runs-static-archive-bundle.tar.gz 2>/dev/null || true
echo __CHECK_STATIC_OTHER_ARCHIVES_END__
