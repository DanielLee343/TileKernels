import base64,hashlib,io,tarfile
from pathlib import Path
p=Path(__file__).resolve().parent;b=io.BytesIO()
with tarfile.open(fileobj=b,mode='w:gz') as t:
 for name in ('extra-proxy-mask-harness','run-hidev-extra-engram-gate-fwd-mask.sh','inspect-extra-engram-gate-fwd-mask.py'):
  t.add(p/name,arcname=name,filter=lambda info:None if '__pycache__' in info.name else info)
data=b.getvalue();encoded=base64.b64encode(data).decode();digest=hashlib.sha256(data).hexdigest()
for i in range(0,len(encoded),5500):
 part=i//5500;mode='>' if part==0 else '>>'
 (p/f'deploy-engram-mask-part-{part}.sh').write_text(f"printf '%s' '{encoded[i:i+5500]}' {mode} /workspace/expert-profile-backfill-20261109-hidev/engram-mask-deploy.b64\nprintf '%s\\n' __ENGRAM_MASK_PART_{part}__\n",encoding='utf8',newline='\n')
script=f'''set -e
root=/workspace/expert-profile-backfill-20261109-hidev
base64 -d "$root/engram-mask-deploy.b64" > "$root/engram-mask-deploy.tar.gz"
printf '%s  %s\\n' {digest} "$root/engram-mask-deploy.tar.gz" | sha256sum -c
test ! -e "$root/extra-proxy-mask-harness"
tar -xzf "$root/engram-mask-deploy.tar.gz" -C "$root"
bash -n "$root/run-hidev-extra-engram-gate-fwd-mask.sh"
python3 -B -c 'import ast,pathlib;[ast.parse(pathlib.Path(p).read_text()) for p in ["/workspace/expert-profile-backfill-20261109-hidev/inspect-extra-engram-gate-fwd-mask.py","/workspace/expert-profile-backfill-20261109-hidev/extra-proxy-mask-harness/extra_engram_gate_fwd.py"]]'
printf '%s\\n' __ENGRAM_MASK_DEPLOY_DONE__
'''
(p/'deploy-engram-mask-finish.sh').write_text(script,encoding='utf8',newline='\n')
print('parts',(len(encoded)+5499)//5500,'sha256',digest)
