import base64,hashlib,io,tarfile
from pathlib import Path
p=Path(__file__).resolve().parent
s=(p/'run-hidev-extra-randn-detail.sh').read_text(encoding='utf-8')
for old,new in (
 ('extra-proxy-randn-harness','extra-proxy-harness'),
 ('run-hidev-extra-randn-detail.sh','run-hidev-extra-moe-backward-detail.sh'),
 ('test "$group" = randn','test "$group" = moe_topk_gate_backward'),
):
 assert old in s,old;s=s.replace(old,new)
(p/'run-hidev-extra-moe-backward-detail.sh').write_text(s,encoding='utf-8',newline='\n')
s=(p/'inspect-extra-randn.py').read_text(encoding='utf-8')
old="for key in ('group','params','native_config','user_seed','launch_seed'):assert a[key]==old[key],key\nassert a['finite']==a['seed_repeatability']=='passed' and a['distribution']['status'] in ('passed','not_applicable')"
new="for key in ('group','params','seed','captured_fix_routing','routed_scaling_factor','routing_fixture_inputs'):assert a[key]==old[key],key\nassert a['correctness']=='passed_upstream_full_moe_backward_test'"
assert old in s;s=s.replace(old,new).replace('initially restricted to the randn with fixed native launch seed; no claim of fresh random samples across profiler replay; source-aware audit pending','MoE backward overwrites grad_logits; completeness and replay behavior require separate audit')
(p/'inspect-extra-moe-backward.py').write_text(s,encoding='utf-8',newline='\n')
for name in ('inspect-extra-moe-backward.py',):compile((p/name).read_text(),str(p/name),'exec')
buf=io.BytesIO()
with tarfile.open(fileobj=buf,mode='w:gz') as tar:
 for name in ('run-hidev-extra-moe-backward-detail.sh','inspect-extra-moe-backward.py'):tar.add(p/name,arcname=name)
data=buf.getvalue();encoded=base64.b64encode(data).decode();sha=hashlib.sha256(data).hexdigest()
for i in range(0,len(encoded),5500):
 part=i//5500;mode='>' if part==0 else '>>'
 (p/f'deploy-moe-backward-part-{part}.sh').write_text(f"printf '%s' '{encoded[i:i+5500]}' {mode} /workspace/expert-profile-backfill-20261109-hidev/moe-backward-deploy.b64\necho __MOE_BACKWARD_PART_{part}__\n",encoding='utf-8',newline='\n')
script=f'''set -e
echo __DEPLOY_MOE_BACKWARD_BEGIN__
r=/workspace/expert-profile-backfill-20261109-hidev
base64 -d "$r/moe-backward-deploy.b64" > "$r/moe-backward-deploy.tar.gz"
printf '%s  %s\\n' {sha} "$r/moe-backward-deploy.tar.gz" | sha256sum -c
test ! -e "$r/run-hidev-extra-moe-backward-detail.sh"
test ! -e "$r/inspect-extra-moe-backward.py"
tar -xzf "$r/moe-backward-deploy.tar.gz" -C "$r"
echo __DEPLOY_MOE_BACKWARD_END__
'''
(p/'deploy-moe-backward-finish.sh').write_text(script,encoding='utf-8',newline='\n')
print('parts',(len(encoded)+5499)//5500)
