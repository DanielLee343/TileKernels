from pathlib import Path
p=Path(__file__).resolve().parent;s=(p/'package-deepgemm-mgroup.py').read_text(encoding='utf-8')
for old,new in (
 ('deepgemm-mgroup-harness','deepgemm-kgroup-harness'),
 ('run-hidev-deepgemm-mgroup.sh','run-hidev-deepgemm-kgroup-bf16.sh'),
 ('inspect-deepgemm-mgroup.py','inspect-deepgemm-kgroup.py'),
 ('deploy-dg-mgroup','deploy-dg-kgroup'),
 ('dg-mgroup-deploy','dg-kgroup-deploy'),
 ('__DG_MGROUP_','__DG_KGROUP_'),
):
 assert old in s,old;s=s.replace(old,new)
exec(compile(s,str(p/'package-deepgemm-mgroup.py'),'exec'))
