#!/usr/bin/env bash
echo __CHECK_BWD_MASK_ACCUM_MQA_TEST_BEGIN__
r=/workspace/expert-profile-backfill-20261109-hidev
for x in extra-engram-gate-bwd-mask-smoke-hidev-npu0 extra-norm-accum-app-smoke-hidev-npu0;do
 q="$r/$x";echo "--- $x ---";ps -p "$(cat "$q/pid")" -o pid=,stat=,args= || true;test ! -f "$q/exit.txt" || cat "$q/exit.txt";tail -n 9 "$q/console.log" 2>/dev/null || true
done
echo '--- MQA test ---';ps -p "$(cat "$r/dg-mqa-test.pid")" -o pid=,stat=,args= || true;tail -n 10 "$r/dg-mqa-test.log"
echo __CHECK_BWD_MASK_ACCUM_MQA_TEST_END__
