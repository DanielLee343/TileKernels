import base64,hashlib,io,tarfile
from pathlib import Path
p=Path(__file__).resolve().parent;mem=io.BytesIO()
files=['hash-history.tar.gz','hash-pending.json','run-hidev-hash-detail.sh','hidev-hash-queue.py','audit-hash-detail.py']
with tarfile.open(fileobj=mem,mode='w:gz') as t:
 for name in files:t.add(p/name,arcname=name,recursive=False)
data=mem.getvalue();encoded=base64.b64encode(data).decode();digest=hashlib.sha256(data).hexdigest()
for i in range(0,len(encoded),6000):
 part=i//6000;mode='>' if part==0 else '>>'
 (p/f'deploy-hash-part-{part}.sh').write_text(f"printf '%s' '{encoded[i:i+6000]}' {mode} /workspace/expert-profile-backfill-20261109-hidev/hash-deploy.b64\nprintf '%s\\n' __HIDEV_HASH_PART_{part}__\n",encoding='utf8',newline='\n')
finish=f'''set -e
root=/workspace/expert-profile-backfill-20261109-hidev
base64 -d "$root/hash-deploy.b64" > "$root/hash-deploy.tar.gz"
echo '{digest}  '"$root/hash-deploy.tar.gz" | sha256sum -c
tar -xzf "$root/hash-deploy.tar.gz" -C "$root"
tar -xzf "$root/hash-history.tar.gz" -C "$root"
printf '%s\\n' __HIDEV_HASH_DEPLOY_DONE__
'''
(p/'deploy-hash-finish.sh').write_text(finish,encoding='utf8',newline='\n')
print('archive',len(data),'parts',(len(encoded)+5999)//6000,'sha256',digest)
