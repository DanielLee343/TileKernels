import base64,hashlib,io,tarfile
from pathlib import Path
p=Path(__file__).resolve().parent;b=io.BytesIO()
with tarfile.open(fileobj=b,mode='w:gz') as t:
 for n in ('audit-dg-kgroup-fp8-candidate.py','audit-dg-kgroup-dequant-candidate.py'):t.add(p/n,arcname=n)
data=b.getvalue();encoded=base64.b64encode(data).decode();sha=hashlib.sha256(data).hexdigest()
for i in range(0,len(encoded),5500):
 part=i//5500;mode='>' if part==0 else '>>'
 (p/f'deploy-kgroup-quant-audit-part-{part}.sh').write_text(f"printf '%s' '{encoded[i:i+5500]}' {mode} /workspace/expert-profile-backfill-20261109-hidev/kgroup-quant-audit-deploy.b64\necho __KGROUP_QUANT_AUDIT_PART_{part}__\n",encoding='utf-8',newline='\n')
script=f'''set -e
echo __DEPLOY_KGROUP_QUANT_AUDIT_BEGIN__
r=/workspace/expert-profile-backfill-20261109-hidev
base64 -d "$r/kgroup-quant-audit-deploy.b64" > "$r/kgroup-quant-audit-deploy.tar.gz"
printf '%s  %s\\n' {sha} "$r/kgroup-quant-audit-deploy.tar.gz" | sha256sum -c
test ! -e "$r/audit-dg-kgroup-fp8-candidate.py"
test ! -e "$r/audit-dg-kgroup-dequant-candidate.py"
tar -xzf "$r/kgroup-quant-audit-deploy.tar.gz" -C "$r"
python3 -B "$r/audit-dg-kgroup-fp8-candidate.py" kgroup-fp8fp8-tn-g4-m64-n256-k512 attempt-001
python3 -B "$r/audit-dg-kgroup-fp8-candidate.py" kgroup-fp4fp4-tn-g4-m64-n256-k512 attempt-001
python3 -B "$r/audit-dg-kgroup-dequant-candidate.py" kgroup-fp8fp4-tn-g4-m64-n256-k512 attempt-001
echo __DEPLOY_KGROUP_QUANT_AUDIT_END__
'''
(p/'deploy-kgroup-quant-audit-finish.sh').write_text(script,encoding='utf-8',newline='\n')
print('parts',(len(encoded)+5499)//5500)
