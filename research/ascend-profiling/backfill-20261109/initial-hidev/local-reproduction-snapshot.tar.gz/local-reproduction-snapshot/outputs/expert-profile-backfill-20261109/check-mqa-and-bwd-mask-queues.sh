#!/usr/bin/env bash
echo __CHECK_MQA_AND_BWD_MASK_QUEUES_BEGIN__
r=/workspace/expert-profile-backfill-20261109-hidev
for x in deepgemm-mqa-queue-hidev-npu0 extra-engram-gate-bwd-mask-queue-hidev-npu0;do
 q="$r/$x";echo "--- $x ---";ps -p "$(cat "$q/pid")" -o pid=,stat=,args= || true;test ! -f "$q/exit.txt" || cat "$q/exit.txt";tail -n 10 "$q/console.log" 2>/dev/null || true
done
echo __CHECK_MQA_AND_BWD_MASK_QUEUES_END__
