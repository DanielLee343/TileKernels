import base64,hashlib,io,tarfile
from pathlib import Path
p=Path(__file__).resolve().parent;b=io.BytesIO();name='audit-extra-moe-backward-candidate.py'
with tarfile.open(fileobj=b,mode='w:gz') as t:t.add(p/name,arcname=name)
data=b.getvalue();encoded=base64.b64encode(data).decode();sha=hashlib.sha256(data).hexdigest()
for i in range(0,len(encoded),5500):
 part=i//5500;mode='>' if part==0 else '>>'
 (p/f'deploy-moe-audit-part-{part}.sh').write_text(f"printf '%s' '{encoded[i:i+5500]}' {mode} /workspace/expert-profile-backfill-20261109-hidev/moe-audit-deploy.b64\necho __MOE_AUDIT_PART_{part}__\n",encoding='utf-8',newline='\n')
script=f'''set -e
echo __DEPLOY_MOE_AUDIT_BEGIN__
r=/workspace/expert-profile-backfill-20261109-hidev
base64 -d "$r/moe-audit-deploy.b64" > "$r/moe-audit-deploy.tar.gz"
printf '%s  %s\\n' {sha} "$r/moe-audit-deploy.tar.gz" | sha256sum -c
test ! -e "$r/{name}"
tar -xzf "$r/moe-audit-deploy.tar.gz" -C "$r"
python3 -B "$r/{name}" moe_topk_gate_backward-01 attempt-001
echo __DEPLOY_MOE_AUDIT_END__
'''
(p/'deploy-moe-audit-finish.sh').write_text(script,encoding='utf-8',newline='\n')
print('parts',(len(encoded)+5499)//5500)
