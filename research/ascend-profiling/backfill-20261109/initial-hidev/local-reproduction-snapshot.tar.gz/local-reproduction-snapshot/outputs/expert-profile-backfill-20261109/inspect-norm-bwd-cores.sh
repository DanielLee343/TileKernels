#!/usr/bin/env bash
echo __INSPECT_NORM_BWD_CORES_BEGIN__
p=/workspace/expert-profile-backfill-20261109-hidev/extra-proxy-runs/unified-extra3/quant_norm_backward-01/hidev-npu0/attempt-001/detail
python3 - "$p" <<'PY'
import csv,re,sys
from pathlib import Path
p=Path(sys.argv[1]);op,=p.rglob('OpBasicInfo.csv')
cores=sorted({int(x) for x in re.findall(r'DBI record core:(\d+).*?dst:\(type:GM;.*?src:\(type:UB;', (p/'profile.log').read_text(errors='replace'))});print('raw cores',cores)
with op.with_name('Memory.csv').open(encoding='utf-8-sig',newline='') as f:
 for x in csv.DictReader(f):print(x['block_id'],x['sub_block_id'],x['UB_to_GM_datas(KB)'])
PY
echo __INSPECT_NORM_BWD_CORES_END__
