from pathlib import Path
p=Path(__file__).resolve().parent
a=(p/'audit-extra-engram-gate-fwd-unmasked-candidate.py').read_text();old="p/'candidate-audit-result.json'";assert old in a
(p/'audit-extra-engram-gate-fwd-unmasked.py').write_text(a.replace(old,"p/'audit-result.json'"),encoding='utf8',newline='\n')
r=(p/'run-hidev-extra-engram-gate-fwd.sh').read_text()
old='test "$group" = engram_gate_fwd; test "$target" = unified-extra5/engram_gate_fwd-01'
new='''test "$group" = engram_gate_fwd
python3 - "$root/extra-proxy-harness/cases.json" "$target" <<'PYCHECK'
import json,sys
with open(sys.argv[1]) as f:d=json.load(f)
selected,=(x for x in d['cases'] if x['target_id']==sys.argv[2]);assert selected['group']=='engram_gate_fwd' and not selected['params']['with_mask']
PYCHECK'''
assert old in r;r=r.replace(old,new).replace('$root/run-hidev-extra-engram-gate-fwd.sh','$root/run-hidev-extra-engram-gate-fwd-unmasked.sh')
(p/'run-hidev-extra-engram-gate-fwd-unmasked.sh').write_text(r,encoding='utf8',newline='\n')
s=(p/'hidev-extra-norm-forward-queue.py').read_text()
for old,new in [('quant_norm_forward','engram_gate_fwd'),('extra-norm-forward-queue','extra-engram-gate-fwd-unmasked-queue'),
                ("'unified-extra3/'+case", "'unified-extra5/'+case"),
                ('run-hidev-extra-norm-forward-detail.sh','run-hidev-extra-engram-gate-fwd-unmasked.sh'),
                ('inspect-extra-norm-forward.py','inspect-extra-engram-gate-fwd.py'),
                ('audit-extra-norm-forward-general.py','audit-extra-engram-gate-fwd-unmasked.py'),
                ('ALL_NORM_FORWARD_SELECTED_AUDITED','ALL_ENGRAM_GATE_FWD_UNMASKED_SELECTED_AUDITED')]:
 assert old in s,old;s=s.replace(old,new)
old="if x['group']=='engram_gate_fwd'];assert len(items)==20"
new="if x['group']=='engram_gate_fwd' and not x['params']['with_mask']];assert len(items)==10"
assert old in s;s=s.replace(old,new)
(p/'hidev-extra-engram-gate-fwd-unmasked-queue.py').write_text(s,encoding='utf8',newline='\n')
print('prepared 10 unmasked cases; masked cases require separate expected-output handling')
