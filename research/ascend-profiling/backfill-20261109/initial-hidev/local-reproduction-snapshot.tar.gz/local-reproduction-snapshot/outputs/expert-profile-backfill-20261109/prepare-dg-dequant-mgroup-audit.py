from pathlib import Path
p=Path(__file__).resolve().parent
s=(p/'audit-deepgemm-dequant.py').read_text()
old='gemm-fp8fp4-nt-k-m4096-n576-k7168';new='mgroup-fp8fp4-nt-g4-m128-n256-k512';assert old in s;s=s.replace(old,new)
old="str(p/'address-audit.json')";assert old in s;s=s.replace(old,"str(p/'candidate-address-audit.json')")
(p/'audit-dg-dequant-mgroup-candidate.py').write_text(s,encoding='utf8',newline='\n')
print('prepared dequant M-group candidate audit')
