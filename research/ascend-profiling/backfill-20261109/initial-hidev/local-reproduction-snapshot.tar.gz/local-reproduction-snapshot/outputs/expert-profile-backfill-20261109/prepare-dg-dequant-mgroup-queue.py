from pathlib import Path
p=Path(__file__).resolve().parent
a=(p/'audit-dg-dequant-mgroup-candidate.py').read_text()
old="assert case=='mgroup-fp8fp4-nt-g4-m128-n256-k512'";assert old in a
a=a.replace(old,"assert re.fullmatch(r'mgroup-fp8fp4-[a-z0-9-]+',case)")
old="str(p/'candidate-address-audit.json')";assert old in a;a=a.replace(old,"str(p/'address-audit.json')")
(p/'audit-dg-dequant-mgroup-batch.py').write_text(a,encoding='utf8',newline='\n')
s=(p/'hidev-dg-bf16-mgroup-queue.py').read_text()
for old,new in [('bf16-mgroup','dequant-mgroup'),('bf16_gemm_impl','fp8_dequant_gemm_impl'),
                ('BF16_MGROUP','DEQUANT_MGROUP')]:
 assert old in s,old;s=s.replace(old,new)
(p/'hidev-dg-dequant-mgroup-queue.py').write_text(s,encoding='utf8',newline='\n')
print('prepared dequant grouped batch from audited representative')
