"""Produce a candidate audit for the one non-direct ordinary dequant GEMM."""
from pathlib import Path
p=Path(__file__).resolve().parent;s=(p/'audit-deepgemm-mix-general.py').read_text()
assert s.count('fp8_gemm_impl')==2
s=s.replace('fp8_gemm_impl','fp8_dequant_gemm_impl')
assert s.count('fp8_gemm.hpp')==1;s=s.replace('fp8_gemm.hpp','fp8_dequant_gemm.hpp')
old="assert '__mix__(1, kDirectStore ? 0 : 2)' in headers[0] and 'kNumEpilogueStages, 2,' in headers[0]"
new="assert '__mix__(1, 2)' in headers[0] and 'kNumEpilogueStages, 1,' in headers[0] and 'if constexpr (kDirectStore) return;' in headers[0]"
assert old in s;s=s.replace(old,new)
s=s.replace("assert re.fullmatch(r'gemm-fp(?:4|8)fp(?:4|8)-[a-z0-9-]+',case)","assert case=='gemm-fp8fp4-nt-k-m4096-n576-k7168'")
(p/'audit-deepgemm-dequant.py').write_text(s,encoding='utf8',newline='\n')
print('candidate generated; requires real capture and independent negative tests')
