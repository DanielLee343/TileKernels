from pathlib import Path
p=Path(__file__).resolve().parent
a=(p/'audit-extra-engram-gate-bwd-mask-candidate.py').read_text();old="p/'candidate-audit-result.json'";assert old in a
(p/'audit-extra-engram-gate-bwd-mask.py').write_text(a.replace(old,"p/'audit-result.json'"),encoding='utf8',newline='\n')
r=(p/'run-hidev-extra-engram-gate-bwd-unmasked.sh').read_text()
old="and not selected['params']['with_mask']";assert old in r;r=r.replace(old,"and selected['params']['with_mask']")
r=r.replace('$root/run-hidev-extra-engram-gate-bwd-unmasked.sh','$root/run-hidev-extra-engram-gate-bwd-mask-batch.sh')
(p/'run-hidev-extra-engram-gate-bwd-mask-batch.sh').write_text(r,encoding='utf8',newline='\n')
s=(p/'hidev-extra-engram-gate-bwd-unmasked-queue.py').read_text()
for old,new in [('extra-engram-gate-bwd-unmasked-queue','extra-engram-gate-bwd-mask-queue'),
                ("and not x['params']['with_mask']","and x['params']['with_mask']"),
                ('run-hidev-extra-engram-gate-bwd-unmasked.sh','run-hidev-extra-engram-gate-bwd-mask-batch.sh'),
                ('audit-extra-engram-gate-bwd-unmasked.py','audit-extra-engram-gate-bwd-mask.py'),
                ('ALL_ENGRAM_GATE_BWD_UNMASKED_SELECTED_AUDITED','ALL_ENGRAM_GATE_BWD_MASK_SELECTED_AUDITED')]:
 assert old in s,old;s=s.replace(old,new)
(p/'hidev-extra-engram-gate-bwd-mask-queue.py').write_text(s,encoding='utf8',newline='\n')
print('prepared ten masked backward cases with full output coverage')
