#!/usr/bin/env bash
echo __CHECK_SUPPORT_SNAPSHOT_BEGIN__
r=/workspace/expert-profile-backfill-20261109-hidev
ps -p "$(cat "$r/support-snapshot.pid")" -o pid=,stat=,args= || true
tail -n 12 "$r/support-snapshot.log"
test ! -f "$r/support-snapshot.tar.gz" || ls -lh "$r/support-snapshot.tar.gz"
echo __CHECK_SUPPORT_SNAPSHOT_END__
