#!/usr/bin/env bash
echo __INSPECT_DG_MQA01_TARGET_INPUT_BEGIN__
p=/workspace/expert-profile-backfill-20261109-hidev/deepgemm-runs/mqa-0-q16-k512-h8-random/hidev-npu0/attempt-001/profile.json
python3 - "$p" <<'PY'
import json,sys
from pathlib import Path
d=json.loads(Path(sys.argv[1]).read_text());print(json.dumps(d['target_input'],indent=2))
PY
echo __INSPECT_DG_MQA01_TARGET_INPUT_END__
