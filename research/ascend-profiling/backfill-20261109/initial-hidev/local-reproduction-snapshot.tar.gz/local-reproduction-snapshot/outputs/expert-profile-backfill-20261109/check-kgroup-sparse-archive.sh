echo __CHECK_KGROUP_SPARSE_ARCHIVE_BEGIN__
r=/workspace/expert-profile-backfill-20261109-hidev
ps -p "$(cat "$r/kgroup-sparse-archive.pid")" -o pid,stat,etime,args || true
tail -n 6 "$r/kgroup-sparse-archive.log"
test ! -f "$r/kgroup-sparse-randn-snapshot-archive-bundle.tar.gz" || stat -c '%s bytes' "$r/kgroup-sparse-randn-snapshot-archive-bundle.tar.gz"
echo __CHECK_KGROUP_SPARSE_ARCHIVE_END__
