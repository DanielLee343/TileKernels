echo __MOE_FORWARD_OLD_CACHE_BEGIN__
for d in /workspace/tilekernels-expert-unified-extra3-20261106 /workspace/tilekernels-env-20261101 /root/.tilelang;do
 if test -d "$d";then echo "EXISTS $d";find "$d" -maxdepth 3 -type d \( -name '*cache*' -o -name '*tilelang*' \) -print | head -n 25;fi
done
echo __MOE_FORWARD_OLD_CACHE_END__
