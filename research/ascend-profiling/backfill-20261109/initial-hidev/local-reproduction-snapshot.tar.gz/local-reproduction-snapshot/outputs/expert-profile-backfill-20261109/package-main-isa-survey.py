import base64,hashlib,io,tarfile
from pathlib import Path
p=Path(__file__).resolve().parent;b=io.BytesIO()
with tarfile.open(fileobj=b,mode='w:gz') as t:
 for name in ('main-pending-isa-survey-input.json','survey-main-historical-isa.py'):t.add(p/name,arcname=name)
data=b.getvalue();encoded=base64.b64encode(data).decode();digest=hashlib.sha256(data).hexdigest()
for i in range(0,len(encoded),5500):
 part=i//5500;mode='>' if part==0 else '>>'
 (p/f'deploy-main-isa-survey-part-{part}.sh').write_text(f"printf '%s' '{encoded[i:i+5500]}' {mode} /workspace/expert-profile-backfill-20261109-hidev/main-isa-deploy.b64\nprintf '%s\\n' __MAIN_ISA_PART_{part}__\n",encoding='utf8',newline='\n')
script=f'''set -e
root=/workspace/expert-profile-backfill-20261109-hidev
base64 -d "$root/main-isa-deploy.b64" > "$root/main-isa-deploy.tar.gz"
printf '%s  %s\\n' {digest} "$root/main-isa-deploy.tar.gz" | sha256sum -c
tar -xzf "$root/main-isa-deploy.tar.gz" -C "$root"
printf '%s\\n' __MAIN_ISA_DEPLOY_DONE_{digest[:12].upper()}__
'''
(p/'deploy-main-isa-survey-finish.sh').write_text(script,encoding='utf8',newline='\n')
print('parts',(len(encoded)+5499)//5500,'sha256',digest)
