echo __CHECK_CLOCK_UNIQUE_BEGIN__
date -u
ps -p 1238104 -o pid,stat,etime,args
echo __CHECK_CLOCK_UNIQUE_END__
