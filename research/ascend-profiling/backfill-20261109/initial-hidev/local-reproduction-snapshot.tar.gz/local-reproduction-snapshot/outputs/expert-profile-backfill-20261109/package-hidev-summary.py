import base64,hashlib
from pathlib import Path
HERE=Path(__file__).resolve().parent;data=(HERE/'summarize-hidev.py').read_bytes()
payload=base64.b64encode(data).decode()
script="""#!/usr/bin/env bash
set -Eeo pipefail
root=/workspace/expert-profile-backfill-20261109-hidev
printf '%s' 'PAYLOAD' | base64 -d > \"$root/summarize-hidev.py\"
printf '%s  %s\\n' HASH \"$root/summarize-hidev.py\" | sha256sum -c
python3 -B \"$root/summarize-hidev.py\"
gzip -n -c \"$root/hidev-capture-index.json\" > \"$root/hidev-capture-index.json.gz\"
printf '%s\\n' __HIDEV_INDEX_EXPORT_BEGIN__
sha256sum \"$root/hidev-capture-index.json.gz\"
base64 -w 128 \"$root/hidev-capture-index.json.gz\"
printf '%s\\n' __HIDEV_INDEX_EXPORT_END__
""".replace('PAYLOAD',payload).replace('HASH',hashlib.sha256(data).hexdigest())
(HERE/'export-hidev-index.sh').write_text(script,encoding='utf-8',newline='\n')
print('prepared',len(script),'bytes')
