"""Stage ordinary mixed GEMMs with pinned histories; grouped GEMMs stay separate."""
import csv,hashlib,json,shutil
from pathlib import Path
p=Path(__file__).resolve().parent;repo=p.parents[1]/'TileKernels-private'
base=repo/'research/ascend-profiling/deepgemm-ascend/campaign-13'
out=p/'deepgemm-mix-harness';campaign=out/'campaign-13';campaign.mkdir(parents=True,exist_ok=True)
src=p/'deepgemm-profile-harness/campaign-13/collect.py';shutil.copyfile(src,campaign/'collect.py')
pilot=out/'pilot-bf16';pilot.mkdir(exist_ok=True);shutil.copyfile(p/'deepgemm-profile-harness/pilot-bf16/collect.py',pilot/'collect.py')
with (p/'targets.csv').open(encoding='utf-8-sig',newline='') as f:rows=list(csv.DictReader(f))
ids={r['case'].split('/')[-1] for r in rows if r['batch']=='deepgemm-original' and r['case'].startswith('campaign-13/gemm-') and r['op_type']=='mix' and 'fp8_gemm_impl' in r['op_name']}
manifest=json.loads((base/'cases-last.json').read_text(encoding='utf-8-sig'))
manifest['cases']=[x for x in manifest['cases'] if x['id'] in ids];assert len(manifest['cases'])==len(ids)==6
(campaign/'cases.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf8')
for case in manifest['cases']:
 matches=list((base/'runs').glob('*/'+case['id']+'/profile.json'));assert len(matches)==1,case['id']
 original=matches[0].parent;hist=out/'history'/case['id'];hist.mkdir(parents=True,exist_ok=True)
 for name in ('profile.json','result.json','jit/kernel.asc'):shutil.copyfile(original/name,hist/Path(name).name)
(out/'provenance.json').write_text(json.dumps({'source':'frozen campaign-13 collector with address-only additions',
 'collector_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'source_commit':'3a35326271b069b8b5bf1a754435acd6cc91575b',
 'case_count':len(ids),'scope':'ordinary mixed GEMMs only; grouped GEMMs excluded'},indent=2)+'\n',encoding='utf8')
runner=(p/'run-hidev-deepgemm-smoke-v3.sh').read_text();start=runner.index('case "$case_id" in\n');end=runner.index('\nunset LD_LIBRARY_PATH',start)
runner=runner[:start]+'''[[ "$case_id" =~ ^gemm-fp(4|8)fp(4|8)-[a-z0-9-]+$ ]] || exit 2
target=fp8_gemm_impl'''+runner[end:];runner=runner.replace('deepgemm-profile-harness','deepgemm-mix-harness')
runner=runner.replace('guard-v4.py','guard-v6.py')
(p/'run-hidev-deepgemm-mix-batch.sh').write_text(runner,encoding='utf8',newline='\n')
inspector=(p/'inspect-deepgemm-capture.py').read_text().replace("harness=root/'deepgemm-profile-harness'","harness=root/'deepgemm-mix-harness'")
start=inspector.index("if case=='gemm-fp4fp4-nn-mn-m64-n576-k7168':");end=inspector.index('\ncapture=mod.inspect_profile',start)
inspector=inspector[:start]+'''assert selected[0]['family']=='gemm' and 'gemm_type' not in selected[0]
assert len(current['args'])==len(previous['args'])==3
assert current['args'][:2]==previous['args'][:2] and current['kwargs']==previous['kwargs']
assert 'c' not in current['kwargs'] and 'accumulate' not in current['kwargs'] and current['kwargs'].get('epilogue') is None
if current!=previous:
 now_out=dict(current['args'][2]);old_out=dict(previous['args'][2]);now_hash=now_out.pop('sha256');old_hash=old_out.pop('sha256')
 assert now_out==old_out and old_out['dtype']=='torch.bfloat16' and len(old_out['shape'])==2
 assert old_hash==hashlib.sha256(bytes(old_out['shape'][0]*old_out['shape'][1]*2)).hexdigest()
 output_prestate={'historical_sha256':old_hash,'current_sha256':now_hash,
  'reason':'historical snapshot before warmups; current snapshot after warmups; output is overwritten, no accumulation'}
'''+inspector[end:]
(p/'inspect-deepgemm-mix-batch.py').write_text(inspector,encoding='utf8',newline='\n')
print('prepared',len(ids),'ordinary mixed GEMMs; not run')
