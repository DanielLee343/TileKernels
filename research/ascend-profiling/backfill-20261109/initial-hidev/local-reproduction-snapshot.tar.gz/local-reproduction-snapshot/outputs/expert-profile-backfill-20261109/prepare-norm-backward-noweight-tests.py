from pathlib import Path
p=Path(__file__).resolve().parent
base=(p/'test-norm-backward-01-audit.sh').read_text().replace('audit-extra-norm-backward-01.py','audit-extra-norm-backward-noweight-candidate.py')
for n in ('01','06'):
 s=base.replace('quant_norm_backward-01','quant_norm_backward-'+n).replace('NORM_BACKWARD_01_AUDIT_TEST','NORM_BACKWARD_'+n+'_NOWEIGHT_AUDIT_TEST')
 (p/f'test-norm-backward-noweight-{n}.sh').write_text(s,encoding='utf8',newline='\n')
print('prepared negative tests for small and padded/residual inputs')
