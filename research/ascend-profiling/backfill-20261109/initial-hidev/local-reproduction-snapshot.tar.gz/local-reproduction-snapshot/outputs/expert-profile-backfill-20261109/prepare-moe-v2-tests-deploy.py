import base64,hashlib,io,tarfile
from pathlib import Path
p=Path(__file__).resolve().parent;b=io.BytesIO()
with tarfile.open(fileobj=b,mode='w:gz') as t:
 for name in ('test-moe-backward-v2-01.sh','test-moe-backward-v2-02.sh'):t.add(p/name,arcname=name)
data=b.getvalue();encoded=base64.b64encode(data).decode();sha=hashlib.sha256(data).hexdigest()
for i in range(0,len(encoded),5500):
 part=i//5500;mode='>' if part==0 else '>>'
 (p/f'deploy-moe-v2-tests-part-{part}.sh').write_text(f"printf '%s' '{encoded[i:i+5500]}' {mode} /workspace/expert-profile-backfill-20261109-hidev/moe-v2-tests-deploy.b64\necho __MOE_V2_TESTS_PART_{part}__\n",encoding='utf-8',newline='\n')
script=f'''set -e
echo __DEPLOY_MOE_V2_TESTS_BEGIN__
r=/workspace/expert-profile-backfill-20261109-hidev
base64 -d "$r/moe-v2-tests-deploy.b64" > "$r/moe-v2-tests-deploy.tar.gz"
printf '%s  %s\\n' {sha} "$r/moe-v2-tests-deploy.tar.gz" | sha256sum -c
test ! -e "$r/test-moe-backward-v2-01.sh"
tar -xzf "$r/moe-v2-tests-deploy.tar.gz" -C "$r"
for n in 01 02; do
 bash "$r/test-moe-backward-v2-$n.sh" > "$r/moe-backward-v2-$n-test.log" 2>&1
 grep -q 'PASS rejects missing store, altered per-core CSV and input/output alias' "$r/moe-backward-v2-$n-test.log"
done
echo __DEPLOY_MOE_V2_TESTS_END__
'''
(p/'deploy-moe-v2-tests-finish.sh').write_text(script,encoding='utf-8',newline='\n')
print('parts',(len(encoded)+5499)//5500)
