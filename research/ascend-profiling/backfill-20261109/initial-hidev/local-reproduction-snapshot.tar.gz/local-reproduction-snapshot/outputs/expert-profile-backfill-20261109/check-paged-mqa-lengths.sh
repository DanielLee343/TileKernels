echo __CHECK_PAGED_MQA_LENGTHS_BEGIN__
q=/workspace/expert-profile-backfill-20261109-hidev/dg-paged-mqa-lengths-smoke-hidev-npu0
ps -p "$(cat "$q/pid")" -o pid,stat,etime,args || true
test ! -f "$q/exit.txt" || cat "$q/exit.txt"
tail -n 8 "$q/console.log"
echo __CHECK_PAGED_MQA_LENGTHS_END__
