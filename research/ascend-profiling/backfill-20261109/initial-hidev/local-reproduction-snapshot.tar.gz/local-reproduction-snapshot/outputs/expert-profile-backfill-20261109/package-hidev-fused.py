"""Prepare chunked checksum-verified fused-weight collection package."""
import base64,hashlib,io,tarfile
from pathlib import Path
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
starter=ROOT/'TileKernels-private/research/ascend-profiling/collector/starter'
names=('audit-fused-detail.py','run-hidev-fused-detail.sh','hidev-fused-queue.py','fused-pending.json','fused-history.tar.gz','fused-history-sha256.txt')
files={name:HERE/name for name in names}
files.update({'collector_starter.py':starter/'collect.py','cases_starter.json':starter/'cases.json'})
buf=io.BytesIO()
with tarfile.open(fileobj=buf,mode='w:gz') as tar:
 for name,path in files.items():tar.add(path,arcname=name,recursive=False)
payload=base64.b64encode(buf.getvalue()).decode('ascii')
for idx in range(0,len(payload),5000):
 part=idx//5000
 body=('mkdir -p /workspace/expert-profile-backfill-20261109-hidev\n'
       +(': > /workspace/expert-profile-backfill-20261109-hidev/fused-package.b64\n' if part==0 else '')
       +"printf '%s' '"+payload[idx:idx+5000]+"' >> /workspace/expert-profile-backfill-20261109-hidev/fused-package.b64\n"
       +f"printf '%s\\n' __HIDEV_FUSED_PART_{part:02d}_DONE__\n")
 (HERE/f'deploy-hidev-fused-part-{part:02d}.sh').write_text(body,encoding='utf-8',newline='\n')
hashes='\n'.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+name for name,p in files.items())
script="""#!/usr/bin/env bash
set -Eeo pipefail
cd /workspace/expert-profile-backfill-20261109-hidev
test ! -e fused-package.done
printf '%s  %s\\n' PACKAGE_HASH fused-package.b64 | sha256sum -c
base64 -d fused-package.b64 | tar -xz
cat > fused-package-sha256.txt <<'EOF'
HASHES
EOF
sha256sum -c fused-package-sha256.txt
test ! -e fused-history
tar -xzf fused-history.tar.gz
sha256sum -c fused-history-sha256.txt
touch fused-package.done
printf '%s\\n' __HIDEV_FUSED_DEPLOY_DONE__
""".replace('PACKAGE_HASH',hashlib.sha256(payload.encode()).hexdigest()).replace('HASHES',hashes)
(HERE/'deploy-hidev-fused-final.sh').write_text(script,encoding='utf-8',newline='\n')
print('bytes',len(buf.getvalue()),'parts',(len(payload)+4999)//5000)
