from pathlib import Path
p=Path(__file__).resolve().parent;s=(p/'prepare-moe-audit-deploy.py').read_text(encoding='utf-8')
for old,new in (
 ('audit-extra-moe-backward-candidate.py','audit-engram-grad-app-candidate.py'),
 ('moe-audit-deploy','engram-grad-audit-deploy'),
 ('deploy-moe-audit-','deploy-engram-grad-audit-'),
 ('__MOE_AUDIT_PART_', '__ENGRAM_GRAD_AUDIT_PART_'),
 ('__DEPLOY_MOE_AUDIT_', '__DEPLOY_ENGRAM_GRAD_AUDIT_'),
 ('moe_topk_gate_backward-01','engram_grad_w_reduce-01'),
):
 assert old in s,old;s=s.replace(old,new)
exec(compile(s,str(p/'prepare-moe-audit-deploy.py'),'exec'))
