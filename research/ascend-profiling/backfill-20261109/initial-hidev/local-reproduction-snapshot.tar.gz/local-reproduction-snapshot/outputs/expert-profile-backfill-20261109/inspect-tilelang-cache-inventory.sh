echo __TILELANG_CACHE_INVENTORY_BEGIN__
for d in /workspace/tilekernels-env-20261101/cache/tilelang /root/.tilelang/cache;do
 du -sh "$d" 2>/dev/null;find "$d" -type f \( -name '*.cpp' -o -name '*.cc' -o -name '*.cu' \) | wc -l
done
find /workspace/tilekernels-env-20261101/cache/tilelang -type f | head -n 8
echo __TILELANG_CACHE_INVENTORY_END__
