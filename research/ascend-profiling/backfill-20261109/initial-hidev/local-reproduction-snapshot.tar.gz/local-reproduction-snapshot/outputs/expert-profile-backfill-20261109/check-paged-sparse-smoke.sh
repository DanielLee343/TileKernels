echo __CHECK_PAGED_SPARSE_SMOKE_BEGIN__
q=/workspace/expert-profile-backfill-20261109-hidev/deepgemm-paged-sparse-smoke-hidev-npu0
ps -p "$(cat "$q/pid")" -o pid,stat,etime,args || true
test ! -f "$q/exit.txt" || cat "$q/exit.txt"
grep -E 'case=|PAGED_SPARSE_IDENTITY|ALL_PAGED|Traceback|Error|AssertionError' "$q/console.log" | tail -n 15 || true
tail -n 5 "$q/console.log"
echo __CHECK_PAGED_SPARSE_SMOKE_END__
