#!/usr/bin/env bash
printf '%s\n' __HIDEV_UQ_AUDIT_BEGIN__
root=/workspace/expert-profile-backfill-20261109-hidev
python3 -B "$root/audit-unified-quant.py" quant_per_token_cast-01 attempt-002
printf '%s\n' __HIDEV_UQ_AUDIT_END__
