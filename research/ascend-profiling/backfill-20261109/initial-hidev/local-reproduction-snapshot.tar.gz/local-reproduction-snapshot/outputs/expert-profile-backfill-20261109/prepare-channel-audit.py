"""Prepare first per-channel candidate audit; no pass until run and challenged."""
from pathlib import Path
p=Path(__file__).resolve().parent;s=(p/'audit-uq-sfonly.py').read_text()
replacements=[
 ('quant_per_token_cast_with_sf_only-','quant_per_channel_cast-'),
 ("p=root/'unified-quant-runs'/case/", "p=root/'extra-proxy-runs'/'unified-extra2'/case/"),
 ("assert len(a)==4 and a[3]", "assert len(a)==4 and a[1] and a[2]"),
 ("source.count('asc_copy_ub2gm_align(')==1", "source.count('asc_copy_ub2gm_align(')==2"),
 ("assert ('out_sf[' in source or 'out_sf)[' in source) and 'block_idx' in source", "assert ('out_sf[' in source or 'out_sf)[' in source) and ('out[' in source or 'out)[' in source) and 'block_idx' in source"),
 ('a[3:]', 'a[1:3]'),
 ('actual=[[]];percore', 'actual=[[],[]];percore'),
 ('for i in (0,)', 'for i in (0,1)'),
 ("'target':'unified-quant/'+case", "'target':'unified-extra2/'+case"),
]
for old,new in replacements:
 assert old in s,old;s=s.replace(old,new)
(p/'audit-extra-channel.py').write_text(s,encoding='utf8',newline='\n')
print('per-channel candidate prepared; requires address and negative tests')
