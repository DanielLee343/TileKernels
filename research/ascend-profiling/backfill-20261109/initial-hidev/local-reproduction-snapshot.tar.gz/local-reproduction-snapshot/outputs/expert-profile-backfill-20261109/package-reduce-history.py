"""Package exact historical application metadata for live case identity checks."""
import hashlib,tarfile
from pathlib import Path
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
old=ROOT/'TileKernels-private/research/ascend-profiling/runs/hidev-20261106-second/cases'
files=[old/f'reduce-{i:02d}'/'default.json' for i in range(1,21)]
assert all(p.is_file() for p in files)
with tarfile.open(HERE/'reduce-history.tar.gz','w:gz') as tar:
 for p in files:tar.add(p,arcname='history/'+p.parent.name+'/default.json')
lines=[hashlib.sha256(p.read_bytes()).hexdigest()+'  history/'+p.parent.name+'/default.json' for p in files]
(HERE/'reduce-history-sha256.txt').write_text('\n'.join(lines)+'\n',encoding='utf-8')
print('packaged',len(files),'historical metadata files')
