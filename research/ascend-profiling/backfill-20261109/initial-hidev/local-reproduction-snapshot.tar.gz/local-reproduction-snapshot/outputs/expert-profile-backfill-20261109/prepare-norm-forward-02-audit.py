"""Prepare FP32 norm+rstd case with exact two-output coverage."""
from pathlib import Path
p=Path(__file__).resolve().parent;s=(p/'audit-extra-norm-forward.py').read_text()
old="assert len(a)==8 and a[0] and a[1] and a[6] and a[7] and all(a[i] is None for i in (2,3,4,5))"
new="assert len(a)==8 and a[0] and a[1] and a[4] and a[5] and all(a[i] is None for i in (2,3,6,7))"
edits=[("assert case=='quant_norm_forward-01'", "assert case=='quant_norm_forward-02'"),
 (old,new),
 ("((a[0],a[1]),(a[0],a[7]),(a[6],a[1]),(a[6],a[7]),(a[1],a[7]))", "((a[0],a[1]),(a[0],a[5]),(a[4],a[1]),(a[4],a[5]),(a[1],a[5]))"),
 ("('residual_out[' in source or 'residual_out)[' in source)", "('rstd[' in source or 'rstd)[' in source)"),
 ('[a[1],a[7]]','[a[1],a[5]]')]
for old,new in edits:assert old in s,old;s=s.replace(old,new)
(p/'audit-extra-norm-forward-02.py').write_text(s,encoding='utf8',newline='\n')
print('FP32/rstd audit candidate prepared; no status admitted')
