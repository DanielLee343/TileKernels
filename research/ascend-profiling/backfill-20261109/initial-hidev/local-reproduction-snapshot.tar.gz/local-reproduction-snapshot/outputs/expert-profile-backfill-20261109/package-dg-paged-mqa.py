from pathlib import Path
p=Path(__file__).resolve().parent;s=(p/'package-deepgemm-mgroup.py').read_text()
s=s.replace('deepgemm-mgroup-harness','deepgemm-paged-mqa-harness')
s=s.replace('run-hidev-deepgemm-mgroup.sh','run-hidev-deepgemm-paged-mqa.sh')
s=s.replace('inspect-deepgemm-mgroup.py','inspect-deepgemm-paged-mqa.py')
s=s.replace('deploy-dg-mgroup','deploy-dg-paged-mqa').replace('dg-mgroup-deploy','dg-paged-mqa-deploy').replace('__DG_MGROUP_','__DG_PAGED_MQA_')
exec(compile(s,str(p/'package-deepgemm-mgroup.py'),'exec'))
