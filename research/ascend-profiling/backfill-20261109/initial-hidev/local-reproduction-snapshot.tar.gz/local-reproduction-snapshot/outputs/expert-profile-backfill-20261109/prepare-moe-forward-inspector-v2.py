import base64,hashlib
from pathlib import Path
p=Path(__file__).resolve().parent;data=(p/'inspect-extra-moe-forward.py').read_bytes();enc=base64.b64encode(data).decode();sha=hashlib.sha256(data).hexdigest()
script=f'''set -e
echo __MOE_FORWARD_INSPECTOR_V2_BEGIN__
r=/workspace/expert-profile-backfill-20261109-hidev
test ! -e "$r/inspect-extra-moe-forward-v2.py"
printf %s {enc} | base64 -d > "$r/inspect-extra-moe-forward-v2.py"
printf '%s  %s\\n' {sha} "$r/inspect-extra-moe-forward-v2.py" | sha256sum -c
python3 -B "$r/inspect-extra-moe-forward-v2.py" unified-extra3/moe_topk_gate_forward-01 attempt-001
echo __MOE_FORWARD_INSPECTOR_V2_END__
'''
(p/'deploy-moe-forward-inspector-v2.sh').write_text(script,encoding='utf-8',newline='\n')
