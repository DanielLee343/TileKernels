from pathlib import Path
p=Path(__file__).resolve().parent
s=(p/'package-deepgemm-mgroup.py').read_text()
s=s.replace('deepgemm-mgroup-harness','deepgemm-mqa-harness')
s=s.replace('run-hidev-deepgemm-mgroup.sh','run-hidev-deepgemm-mqa.sh')
s=s.replace('inspect-deepgemm-mgroup.py','inspect-deepgemm-mqa.py')
s=s.replace('deploy-dg-mgroup','deploy-dg-mqa').replace('dg-mgroup-deploy','dg-mqa-deploy').replace('__DG_MGROUP_','__DG_MQA_')
exec(compile(s,str(p/'package-deepgemm-mgroup.py'),'exec'))
