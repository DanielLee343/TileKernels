#!/usr/bin/env bash
echo __CHECK_SWIGLU_GENERAL_TESTS_BEGIN__
r=/workspace/expert-profile-backfill-20261109-hidev
ps -p "$(cat "$r/swiglu-general-negative-tests.pid")" -o pid=,stat=,args= || true
tail -n 25 "$r/swiglu-general-negative-tests.log"
echo __CHECK_SWIGLU_GENERAL_TESTS_END__
