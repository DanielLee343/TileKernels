import base64,gzip,hashlib,sys
from pathlib import Path
p=Path(__file__).resolve().parent;name=sys.argv[1];raw=(p/name).read_bytes()
assert Path(name).name==name
payload=base64.b64encode(gzip.compress(raw,mtime=0)).decode()
digest=hashlib.sha256(raw).hexdigest()
script='#!/usr/bin/env bash\nset -e\nroot=/workspace/expert-profile-backfill-20261109-hidev\n'
script+=f"printf '%s' '{payload}' | base64 -d | gzip -dc > \"$root/{name}\"\n"
script+=f"printf '%s  %s\\n' {digest} \"$root/{name}\" | sha256sum -c\n"
marker='__COMPRESSED_SINGLE_'+''.join(c if c.isalnum() else '_' for c in name).upper()+'_'+digest[:12].upper()+'_DONE__'
script+=f"printf '%s\\n' {marker}\n"
(p/'deploy-compressed-single.sh').write_text(script,encoding='utf8',newline='\n')
print('bytes',len(script),marker)
