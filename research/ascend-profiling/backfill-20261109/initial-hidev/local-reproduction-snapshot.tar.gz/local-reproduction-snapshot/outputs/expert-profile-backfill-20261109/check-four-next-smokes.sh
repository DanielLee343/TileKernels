#!/usr/bin/env bash
echo __CHECK_FOUR_NEXT_SMOKES_BEGIN__
r=/workspace/expert-profile-backfill-20261109-hidev
for x in extra-swiglu-backward-smoke-hidev-npu0 extra-quant-cast-smoke-hidev-npu0 extra-norm-backward-smoke-hidev-npu0 dg-bf16-mgroup-smoke-hidev-npu0;do
 q="$r/$x";echo "--- $x ---";ps -p "$(cat "$q/pid")" -o pid=,stat=,args= || true;test ! -f "$q/exit.txt" || cat "$q/exit.txt";tail -n 10 "$q/console.log" 2>/dev/null || true
done
echo __CHECK_FOUR_NEXT_SMOKES_END__
