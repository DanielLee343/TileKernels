from pathlib import Path
p=Path(__file__).resolve().parent
s=(p/'package-deepgemm-mgroup.py').read_text()
s=s.replace('deepgemm-mgroup-harness','deepgemm-mqa-ranges-harness')
s=s.replace('run-hidev-deepgemm-mgroup.sh','run-hidev-deepgemm-mqa-ranges.sh')
s=s.replace('inspect-deepgemm-mgroup.py','inspect-deepgemm-mqa-ranges.py')
s=s.replace('deploy-dg-mgroup','deploy-dg-mqa-ranges').replace('dg-mgroup-deploy','dg-mqa-ranges-deploy').replace('__DG_MGROUP_','__DG_MQA_RANGES_')
exec(compile(s,str(p/'package-deepgemm-mgroup.py'),'exec'))
