#!/usr/bin/env bash
echo __CHECK_CURRENT_SWIGLU_CANDIDATES_BEGIN__
r=/workspace/expert-profile-backfill-20261109-hidev
ps -p "$(cat "$r/swiglu-general-candidates.pid")" -o pid=,stat=,args= || true
tail -n 20 "$r/swiglu-general-candidates.log"
echo NORM_QUEUE
tail -n 15 "$r/extra-norm-forward-queue-hidev-npu0/console.log"
echo __CHECK_CURRENT_SWIGLU_CANDIDATES_END__
