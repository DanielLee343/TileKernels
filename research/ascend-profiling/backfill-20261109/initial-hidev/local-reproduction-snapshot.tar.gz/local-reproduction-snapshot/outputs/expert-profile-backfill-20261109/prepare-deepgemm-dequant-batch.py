"""Stage ordinary fp8/fp4 dequant GEMM histories; no capture or approval implied."""
import csv,hashlib,json,shutil
from pathlib import Path
p=Path(__file__).resolve().parent;repo=p.parents[1]/'TileKernels-private'
base=repo/'research/ascend-profiling/deepgemm-ascend/campaign-13'
out=p/'deepgemm-dequant-harness';campaign=out/'campaign-13';campaign.mkdir(parents=True,exist_ok=True)
src=p/'deepgemm-profile-harness/campaign-13/collect.py';shutil.copyfile(src,campaign/'collect.py')
pilot=out/'pilot-bf16';pilot.mkdir(exist_ok=True);shutil.copyfile(p/'deepgemm-profile-harness/pilot-bf16/collect.py',pilot/'collect.py')
with (p/'targets.csv').open(encoding='utf-8-sig',newline='') as f:rows=list(csv.DictReader(f))
ids={r['case'].split('/')[-1] for r in rows if r['batch']=='deepgemm-original' and r['case'].startswith('campaign-13/gemm-') and r['op_type']=='mix' and 'fp8_dequant_gemm_impl' in r['op_name']}
manifest=json.loads((base/'cases-last.json').read_text(encoding='utf-8-sig'))
manifest['cases']=[x for x in manifest['cases'] if x['id'] in ids];assert len(manifest['cases'])==len(ids)==10
(campaign/'cases.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf8')
for case in manifest['cases']:
 matches=list((base/'runs').glob('*/'+case['id']+'/profile.json'));assert len(matches)==1,case['id']
 original=matches[0].parent;hist=out/'history'/case['id'];hist.mkdir(parents=True,exist_ok=True)
 for name in ('profile.json','result.json','jit/kernel.asc'):shutil.copyfile(original/name,hist/Path(name).name)
(out/'provenance.json').write_text(json.dumps({'source':'frozen campaign-13 collector with address-only additions',
 'collector_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'source_commit':'3a35326271b069b8b5bf1a754435acd6cc91575b',
 'case_count':len(ids),'scope':'ordinary fp8/fp4 dequant GEMMs; no capture or completeness audit yet'},indent=2)+'\n',encoding='utf8')
runner=(p/'run-hidev-deepgemm-mix-batch.sh').read_text().replace('target=fp8_gemm_impl','target=fp8_dequant_gemm_impl').replace('deepgemm-mix-harness','deepgemm-dequant-harness')
(p/'run-hidev-deepgemm-dequant-batch.sh').write_text(runner,encoding='utf8',newline='\n')
inspector=(p/'inspect-deepgemm-mix-batch.py').read_text().replace('deepgemm-mix-harness','deepgemm-dequant-harness')
(p/'inspect-deepgemm-dequant.py').write_text(inspector,encoding='utf8',newline='\n')
print('prepared',len(ids),'dequant GEMMs; identity and source-specific store audit still needed')
