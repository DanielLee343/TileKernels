#!/usr/bin/env bash
set -e
echo __INSPECT_DG_SLEEP_BINARY_BEGIN__
repo=/workspace/tilekernels-env-20261101/src/TileKernels-private/research/ascend-profiling/deepgemm-ascend/campaign-13/runs
tool=/workspace/tilekernels-env-20261101/cann/cann-9.2.1/tools/bisheng_compiler/bin/llvm-objdump
bin=$(find "$repo/campaign-rest/sleep-cycles100000-marker1/profile" -name aicore_binary.o -print -quit)
test -f "$bin";sha256sum "$bin";"$tool" -d "$bin"
echo __INSPECT_DG_SLEEP_BINARY_END__
