import base64,hashlib,io,tarfile
from pathlib import Path
p=Path(__file__).resolve().parent;b=io.BytesIO()
with tarfile.open(fileobj=b,mode='w:gz') as t:
 for name in ('extra-proxy-accum-app-harness','run-hidev-extra-norm-accum-app.sh'):
  t.add(p/name,arcname=name,filter=lambda info:None if '__pycache__' in info.name else info)
data=b.getvalue();encoded=base64.b64encode(data).decode();digest=hashlib.sha256(data).hexdigest()
for i in range(0,len(encoded),5500):
 part=i//5500;mode='>' if part==0 else '>>'
 (p/f'deploy-norm-accum-app-part-{part}.sh').write_text(f"printf '%s' '{encoded[i:i+5500]}' {mode} /workspace/expert-profile-backfill-20261109-hidev/norm-accum-app-deploy.b64\nprintf '%s\\n' __NORM_ACCUM_APP_PART_{part}__\n",encoding='utf8',newline='\n')
script=f'''set -e
root=/workspace/expert-profile-backfill-20261109-hidev
base64 -d "$root/norm-accum-app-deploy.b64" > "$root/norm-accum-app-deploy.tar.gz"
printf '%s  %s\\n' {digest} "$root/norm-accum-app-deploy.tar.gz" | sha256sum -c
test ! -e "$root/extra-proxy-accum-app-harness"
tar -xzf "$root/norm-accum-app-deploy.tar.gz" -C "$root"
bash -n "$root/run-hidev-extra-norm-accum-app.sh"
python3 -B -c 'import ast,pathlib;ast.parse(pathlib.Path("/workspace/expert-profile-backfill-20261109-hidev/extra-proxy-accum-app-harness/extra_norm_bwd.py").read_text())'
printf '%s\\n' __NORM_ACCUM_APP_DEPLOY_DONE__
'''
(p/'deploy-norm-accum-app-finish.sh').write_text(script,encoding='utf8',newline='\n')
print('parts',(len(encoded)+5499)//5500,'sha256',digest)
