#!/usr/bin/env bash
echo __INSPECT_NORM05_SOURCE_BEGIN__
p=/workspace/expert-profile-backfill-20261109-hidev/extra-proxy-runs/unified-extra3/quant_norm_forward-05/hidev-npu0/attempt-001/detail/generated-kernel.cpp
grep 'asc_copy_ub2gm_align(' "$p"
echo __INSPECT_NORM05_SOURCE_END__
