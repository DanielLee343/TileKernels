"""Prepare an audit for the three original collector cast-back cases."""
from pathlib import Path
p=Path(__file__).resolve().parent;s=(p/'audit-extra-castback.py').read_text()
edits=[
 ("assert re.fullmatch(r'quant_cast_back_per_token-(0[1-9]|1[0-9]|20)',case)","assert case in ('castback-05','castback-09','castback-15')"),
 ("p=root/'extra-proxy-runs'/'unified-extra2'/case/", "p=root/'classic-runs'/'second'/case/"),
 ("ident['historical_input_and_source_match']", "ident['historical_true_inputs_and_source_match']"),
 ("a=json.loads((p/'tensor-addresses.json').read_text());assert len(a)==3 and a[2]", """meta=json.loads((p/'metadata/application.json').read_text());assert len(meta['outputs'])==len(meta['device_output_addresses'])==1
out=dict(meta['outputs'][0]);n=__import__('math').prod(out['shape']);assert n>0 and out['bytes']%n==0
out['address']=meta['device_output_addresses'][0];out['logical_bytes']=out['bytes'];out['element_size']=out['bytes']//n
a=[None,None,out]"""),
 ("p/'generated-kernel.cpp'", "p/'metadata/default-kernel.cpp'"),
 ("'target':'unified-extra2/'+case", "'target':'second/'+case")]
for old,new in edits:
 assert old in s,old;s=s.replace(old,new)
(p/'audit-classic-castback.py').write_text(s,encoding='utf8',newline='\n')
print('classic cast-back candidate prepared; must pass representative and negative tests')
