"""Index five address-audited captures, preserving alarm and distinct window."""
import csv,hashlib,json
from pathlib import Path
HERE=Path(__file__).resolve().parent
base=HERE/'hidev-evidence/runs';rows=[]
for i in range(1,6):
 case=f'reduce-{i:02d}';d=base/case/'hidev-npu0/attempt-001/detail'
 a=json.loads((d/'audit-result.json').read_text());m=json.loads((d/'monitor-summary.json').read_text())
 assert a['status']=='passed' and a['historical_input_and_source_match'] and a['correctness']=='passed' and m['status']=='passed'
 before=(d/'provenance/health-before.txt').read_text();after=(d/'provenance/health-after.txt').read_text()
 assert '8C4BA00C' in before and '8C4BA00C' in after
 rows.append({'target':'second/'+case,'profile_device':'hidev NPU 0','health':'Alarm 8C4BA00C before and after',
   'status':'address-audited; device-fault qualification pending','logical_output_bytes':a['output_logical_bytes'],
   'requested_bytes':a['dbi_requested_bytes'],'block_dim':a['block_dim'],
   'audit_file':str((d/'audit-result.json').relative_to(HERE)),
   'audit_sha256':hashlib.sha256((d/'audit-result.json').read_bytes()).hexdigest(),
   'remote_directory':'/workspace/expert-profile-backfill-20261109-hidev/runs/'+case+'/hidev-npu0/attempt-001/detail'})
with (HERE/'hidev-alarm-observations.csv').open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
print('indexed',len(rows),'fault-state captures; not admitted as healthy-device samples')
