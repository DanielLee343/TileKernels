#!/usr/bin/env bash
echo __INSPECT_ARCHIVE_CANDIDATE_SIZES_BEGIN__
r=/workspace/expert-profile-backfill-20261109-hidev
for n in runs mhc-runs fused-runs topk-runs hash-runs classic-runs deepgemm-runs mega28-runs unified-quant-runs extra-proxy-runs;do test ! -d "$r/$n" || du -sh "$r/$n";done
echo __INSPECT_ARCHIVE_CANDIDATE_SIZES_END__
