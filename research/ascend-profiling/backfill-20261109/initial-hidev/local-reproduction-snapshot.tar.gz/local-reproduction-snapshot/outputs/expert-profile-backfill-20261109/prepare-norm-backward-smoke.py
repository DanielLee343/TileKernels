from pathlib import Path
p=Path(__file__).resolve().parent
s=(p/'run-hidev-extra-proxy-detail.sh').read_text()
assert 'quant_per_channel_cast' in s
s=s.replace('quant_per_channel_cast','quant_norm_backward')
s=s.replace('test "$group" = quant_norm_backward','test "$group" = quant_norm_backward; test "$target" = unified-extra3/quant_norm_backward-01')
(p/'run-hidev-extra-norm-backward-detail.sh').write_text(s,encoding='utf8',newline='\n')
s=(p/'inspect-extra-proxy.py').read_text()
needle="assert a['status']==old['status']=='passed' and a['matched']==old['matched']==1"
assert needle in s
s=s.replace(needle,needle+"\nassert a['profiler_replay_state']=='not_mutating_input'")
s=s.replace('stateless per-channel quantization representative','non-accumulating Norm backward representative')
(p/'inspect-extra-norm-backward.py').write_text(s,encoding='utf8',newline='\n')
print('prepared only the non-accumulating backward smoke')
