import base64,hashlib
from pathlib import Path
p=Path(__file__).resolve().parent
s=(p/'hidev-moe-backward-queue.py').read_text(encoding='utf-8')
assert 'audit-extra-moe-backward-candidate.py' in s
s=s.replace('audit-extra-moe-backward-candidate.py','audit-extra-moe-backward-v2.py')
(p/'hidev-moe-backward-queue-v2.py').write_text(s,encoding='utf-8',newline='\n')
data=s.encode();encoded=base64.b64encode(data).decode();sha=hashlib.sha256(data).hexdigest()
script=f'''set -e
echo __DEPLOY_MOE_QUEUE_V2_BEGIN__
r=/workspace/expert-profile-backfill-20261109-hidev
test ! -e "$r/hidev-moe-backward-queue-v2.py"
printf %s {encoded} | base64 -d > "$r/hidev-moe-backward-queue-v2.py"
printf '%s  %s\\n' {sha} "$r/hidev-moe-backward-queue-v2.py" | sha256sum -c
echo __DEPLOY_MOE_QUEUE_V2_END__
'''
(p/'deploy-moe-queue-v2.sh').write_text(script,encoding='utf-8',newline='\n')
