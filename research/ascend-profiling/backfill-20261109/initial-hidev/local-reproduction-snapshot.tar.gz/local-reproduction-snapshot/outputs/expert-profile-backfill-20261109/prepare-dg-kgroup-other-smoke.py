import base64,hashlib,io,tarfile
from pathlib import Path
p=Path(__file__).resolve().parent
s=(p/'run-hidev-deepgemm-kgroup-bf16.sh').read_text(encoding='utf-8')
s=s.replace('^kgroup-bf16bf16-[a-z0-9-]+$','^kgroup-fp(4|8)fp(4|8)-[a-z0-9-]+$')
old='target=bf16_gemm_impl'
new='case "$case_id" in kgroup-fp8fp4-*) target=fp8_dequant_gemm_impl;; kgroup-fp8fp8-*|kgroup-fp4fp4-*) target=fp8_gemm_impl;; *) exit 2;; esac'
assert old in s;s=s.replace(old,new)
(p/'run-hidev-deepgemm-kgroup-quant.sh').write_text(s,encoding='utf-8',newline='\n')
buf=io.BytesIO()
with tarfile.open(fileobj=buf,mode='w:gz') as tar:tar.add(p/'run-hidev-deepgemm-kgroup-quant.sh',arcname='run-hidev-deepgemm-kgroup-quant.sh')
data=buf.getvalue();encoded=base64.b64encode(data).decode();sha=hashlib.sha256(data).hexdigest()
for i in range(0,len(encoded),5500):
 part=i//5500;mode='>' if part==0 else '>>'
 (p/f'deploy-kgroup-quant-part-{part}.sh').write_text(f"printf '%s' '{encoded[i:i+5500]}' {mode} /workspace/expert-profile-backfill-20261109-hidev/kgroup-quant-deploy.b64\necho __KGROUP_QUANT_PART_{part}__\n",encoding='utf-8',newline='\n')
script=f'''set -e
echo __DEPLOY_KGROUP_QUANT_BEGIN__
r=/workspace/expert-profile-backfill-20261109-hidev
base64 -d "$r/kgroup-quant-deploy.b64" > "$r/kgroup-quant-deploy.tar.gz"
printf '%s  %s\\n' {sha} "$r/kgroup-quant-deploy.tar.gz" | sha256sum -c
test ! -e "$r/run-hidev-deepgemm-kgroup-quant.sh"
tar -xzf "$r/kgroup-quant-deploy.tar.gz" -C "$r"
bash -n "$r/run-hidev-deepgemm-kgroup-quant.sh"
echo __DEPLOY_KGROUP_QUANT_END__
'''
(p/'deploy-kgroup-quant-finish.sh').write_text(script,encoding='utf-8',newline='\n')
print('parts',(len(encoded)+5499)//5500)
