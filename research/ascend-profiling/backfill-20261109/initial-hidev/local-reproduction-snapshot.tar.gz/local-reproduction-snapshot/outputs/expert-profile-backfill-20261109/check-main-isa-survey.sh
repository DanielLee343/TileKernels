#!/usr/bin/env bash
echo __CHECK_MAIN_ISA_SURVEY_BEGIN__
root=/workspace/expert-profile-backfill-20261109-hidev
ps -p "$(cat "$root/main-isa-survey.pid")" -o pid,stat,etime,args || true
tail -n 8 "$root/main-isa-survey.log"
echo __CHECK_MAIN_ISA_SURVEY_END__
