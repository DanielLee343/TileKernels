"""Build a small self-contained, checksum-verified hidev deployment script."""
import base64,hashlib,io,tarfile
from pathlib import Path
HERE=Path(__file__).resolve().parent
OLD=HERE.parent/'gcm-profile-screen-20261108/mte3-x1-x3/tbe-recapture'
files={name:HERE/name for name in ('guard-v2.py','audit-reduce-family.py','run-hidev-reduce.sh','reduce-history.tar.gz','reduce-history-sha256.txt')}
files.update({name:OLD/name for name in ('application.py','collector.py','cases.json')})
buf=io.BytesIO()
with tarfile.open(fileobj=buf,mode='w:gz') as t:
 for name,path in files.items():t.add(path,arcname=name,recursive=False)
payload=base64.b64encode(buf.getvalue()).decode('ascii')
lines=[hashlib.sha256(p.read_bytes()).hexdigest()+'  '+name for name,p in files.items()]
script="""#!/usr/bin/env bash
set -Eeo pipefail
root=/workspace/expert-profile-backfill-20261109-hidev
printf '%s\\n' __HIDEV_BACKFILL_DEPLOY_BEGIN__
test ! -e \"$root/package-v1.done\"
mkdir -p \"$root\"
cd \"$root\"
printf '%s' 'PAYLOAD' | base64 -d | tar -xz
cat > package-sha256.txt <<'EOF'
HASHES
EOF
sha256sum -c package-sha256.txt
tar -xzf reduce-history.tar.gz
sha256sum -c reduce-history-sha256.txt
touch package-v1.done
printf '%s\\n' __HIDEV_BACKFILL_DEPLOY_END__
""".replace('PAYLOAD',payload).replace('HASHES','\n'.join(lines))
(HERE/'deploy-hidev.sh').write_text(script,encoding='utf-8',newline='\n')
for idx in range(0,len(payload),5000):
 part=idx//5000
 command=('mkdir -p /workspace/expert-profile-backfill-20261109-hidev\n'
          +(': > /workspace/expert-profile-backfill-20261109-hidev/package-v1.b64\n' if part==0 else '')
          +"printf '%s' '"+payload[idx:idx+5000]+"' >> /workspace/expert-profile-backfill-20261109-hidev/package-v1.b64\n"
          +f"printf '%s\\n' __HIDEV_PACKAGE_PART_{part:02d}_DONE__\n")
 (HERE/f'deploy-hidev-part-{part:02d}.sh').write_text(command,encoding='utf-8',newline='\n')
final="""#!/usr/bin/env bash
set -Eeo pipefail
root=/workspace/expert-profile-backfill-20261109-hidev
printf '%s\\n' __HIDEV_BACKFILL_DEPLOY_BEGIN__
test ! -e \"$root/package-v1.done\"
cd \"$root\"
printf '%s  %s\\n' ARCHIVE_HASH package-v1.b64 | sha256sum -c
base64 -d package-v1.b64 | tar -xz
cat > package-sha256.txt <<'EOF'
HASHES
EOF
sha256sum -c package-sha256.txt
tar -xzf reduce-history.tar.gz
sha256sum -c reduce-history-sha256.txt
touch package-v1.done
printf '%s\\n' __HIDEV_BACKFILL_DEPLOY_END__
""".replace('ARCHIVE_HASH',hashlib.sha256(payload.encode()).hexdigest()).replace('HASHES','\n'.join(lines))
(HERE/'deploy-hidev-final.sh').write_text(final,encoding='utf-8',newline='\n')
print('package bytes',len(buf.getvalue()),'script bytes',len(script))
