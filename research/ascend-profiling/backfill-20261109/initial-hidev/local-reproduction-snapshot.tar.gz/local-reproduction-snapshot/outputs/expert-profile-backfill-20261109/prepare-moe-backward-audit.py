from pathlib import Path
p=Path(__file__).resolve().parent
s=(p/'audit-extra-randn-candidate.py').read_text(encoding='utf-8')
changes=(
 ("r'randn-(0[1-9]|1[0-9]|20)'", "r'moe_topk_gate_backward-(0[1-9]|1[0-9]|20)'"),
 ("/'unified-extra2'/case", "/'unified-extra4'/case"),
 ("assert len(a)==1 and a[0]", "assert len(a)==8 and a[6]"),
 ("'unified-extra2/'+case", "'unified-extra4/'+case"),
 ("params=selected['params'];numel=__import__('math').prod(params['shape']);assert a[0]['shape']==[numel]\nassert a[0]['dtype']==('torch.bfloat16' if params['dtype']=='bf16' else 'torch.float32')", "params=selected['params'];rows=params['num_seqs']*(params['num_tokens']+params['num_padded_tokens'])\nassert a[0]['shape']==a[6]['shape']==[rows,params['num_routed_experts']]\nassert a[6]['dtype']=='torch.float32'"),
 ("# Native randn input is a scalar seed; the tensor argument is the sole output.", "# MoE backward overwrites grad_logits; its inputs must not alias the output.\nlo,hi=span(a[6])\nfor item in a[:6]:\n if item is not None:\n  x,y=span(item);assert hi<=x or y<=lo,'input/output overlap'"),
 ("all('output[' in x.split('(__ubuf__',1)[0] for x in lines)", "all('grad_logits[' in x.split('(__ubuf__',1)[0] for x in lines)"),
 ('a[0:1]', 'a[6:7]'),
 ('one MemoryDetail window using fixed launch seed; requested UB to GM bytes, not physical DRAM transactions or independent random sampling','one MemoryDetail window; requested UB to GM bytes, not physical DRAM transactions'),
)
for old,new in changes:
 assert old in s,old;s=s.replace(old,new)
(p/'audit-extra-moe-backward-v2.py').write_text(s,encoding='utf-8',newline='\n')
compile(s,str(p/'audit-extra-moe-backward-v2.py'),'exec')
print('MOE_BACKWARD_AUDIT_PREPARED')
