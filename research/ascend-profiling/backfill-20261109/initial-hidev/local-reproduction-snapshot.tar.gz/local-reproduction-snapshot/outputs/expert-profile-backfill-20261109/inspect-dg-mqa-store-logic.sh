#!/usr/bin/env bash
echo __INSPECT_DG_MQA_STORE_LOGIC_BEGIN__
r=/workspace/deepgemm-ascend-20261107/source/deep_gemm/include/deep_gemm/mqa_logits.hpp
sed -n '46,72p;581,603p' "$r"
echo __INSPECT_DG_MQA_STORE_LOGIC_END__
