"""Stage application replay for the in-place Engram gradient update."""
import hashlib,json,shutil
from pathlib import Path
p=Path(__file__).resolve().parent;src=p/'extra-proxy-harness';dst=p/'extra-proxy-engram-grad-app-harness';dst.mkdir(exist_ok=False)
for n in ('cases.json','provenance.json'):shutil.copyfile(src/n,dst/n)
s=(src/'extra_engram_grad.py').read_text(encoding='utf-8')
needle='def run(group, params, stage, record_path):\n';assert s.count(needle)==1
s=s.replace(needle,needle+"    record_path = Path(record_path).with_name('application-' + str(os.getpid()) + '.json')\n")
for old,new in (("with_name('tensor-addresses.json')","with_name('tensor-addresses-' + str(os.getpid()) + '.json')"),("with_name('generated-kernel.cpp')","with_name('generated-kernel-' + str(os.getpid()) + '.cpp')")):
 assert old in s;s=s.replace(old,new)
(dst/'extra_engram_grad.py').write_text(s,encoding='utf-8',newline='\n')
(dst/'replay-instrumentation.json').write_text(json.dumps({'scope':'application replay, unique per-process evidence; upstream kernel unchanged','source_adapter_sha256':hashlib.sha256((src/'extra_engram_grad.py').read_bytes()).hexdigest(),'instrumented_adapter_sha256':hashlib.sha256((dst/'extra_engram_grad.py').read_bytes()).hexdigest()},indent=2)+'\n')
r=(p/'run-hidev-extra-norm-accum-app-batch.sh').read_text(encoding='utf-8').replace('extra-proxy-accum-app-harness','extra-proxy-engram-grad-app-harness').replace('run-hidev-extra-norm-accum-app-batch.sh','run-hidev-extra-engram-grad-app.sh')
start=r.index('# Only this stateless group');end=r.index('test -f "$old"',start)
r=r[:start]+'test "$group" = engram_grad_w_reduce\n'+r[end:]
(p/'run-hidev-extra-engram-grad-app.sh').write_text(r,encoding='utf-8',newline='\n')
print('ENGRAM_GRAD_APPLICATION_REPLAY_STAGED')
