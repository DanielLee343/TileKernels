#!/usr/bin/env bash
set -e
echo __CHECK_UQ_BLOCK_SMOKES_BEGIN__
root=/workspace/expert-profile-backfill-20261109-hidev
for group in sfonly castonly; do
 q="$root/unified-quant-block-$group-queue-hidev-npu0"
 if test -f "$q/smoke.pid"; then ps -p "$(cat "$q/smoke.pid")" -o pid,stat,etime,args || true; tail -n 16 "$q/smoke.log"; fi
done
echo __CHECK_UQ_BLOCK_SMOKES_END__
