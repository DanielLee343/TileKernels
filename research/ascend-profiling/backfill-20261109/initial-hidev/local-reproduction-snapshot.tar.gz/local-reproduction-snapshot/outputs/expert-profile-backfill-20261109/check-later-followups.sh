#!/usr/bin/env bash
echo __CHECK_LATER_FOLLOWUPS_BEGIN__
root=/workspace/expert-profile-backfill-20261109-hidev
for stem in extra-norm-forward-variants deepgemm-mgroup-queue extra-swiglu-forward;do
 if [[ "$stem" == *-queue ]];then q="$root/$stem-hidev-npu0";pid="$q/followup.pid";exitfile="$q/followup-exit.txt"
 else q="$root/$stem-smoke-hidev-npu0";pid="$q/pid";exitfile="$q/exit.txt";fi
 echo "FOLLOWUP=$stem";ps -p "$(cat "$pid")" -o pid,stat,etime,args || true
 tail -n 12 "$q/console.log";if test -f "$exitfile";then cat "$exitfile";fi
done
echo __CHECK_LATER_FOLLOWUPS_END__
