"""Handle a child disappearing while its proc status file is being read."""
from pathlib import Path
import base64, hashlib
p=Path(__file__).resolve().parent
old=(p/'guard-v5.py').read_text(encoding='utf8')
needle='        except FileNotFoundError:pass\n'
assert old.count(needle)==1
new=old.replace(needle,'        except (FileNotFoundError, ProcessLookupError):pass\n')
(p/'guard-v6.py').write_text(new,encoding='utf8',newline='\n')
runner=(p/'run-hidev-mega28-detail.sh').read_text(encoding='utf8')
assert runner.count('guard-v5.py')==3
runner=runner.replace('guard-v5.py','guard-v6.py')
(p/'run-hidev-mega28-detail-v6.sh').write_text(runner,encoding='utf8',newline='\n')
lines=['#!/usr/bin/env bash','set -e','root=/workspace/expert-profile-backfill-20261109-hidev']
for filename,target in [('guard-v6.py','guard-v6.py'),('run-hidev-mega28-detail-v6.sh','run-hidev-mega28-detail.sh')]:
 data=(p/filename).read_bytes();enc=base64.b64encode(data).decode();digest=hashlib.sha256(data).hexdigest()
 lines += [f"printf '%s' '{enc}' | base64 -d > \"$root/{target}\"",f"echo '{digest}  '"+'"$root/'+target+'" | sha256sum -c']
lines+=['python3 -m py_compile "$root/guard-v6.py"','printf \'%s\\n\' __GUARD_V6_DEPLOYED__']
(p/'deploy-guard-v6.sh').write_text('\n'.join(lines)+'\n',encoding='utf8',newline='\n')
print('prepared')
