#!/usr/bin/env bash
echo __INSPECT_SWIGLU_BWD_BLOCKDIMS_BEGIN__
r=/workspace/expert-profile-backfill-20261109-hidev
python3 - "$r" <<'PY'
import csv,sys
from pathlib import Path
r=Path(sys.argv[1])/'extra-proxy-runs/unified-extra4'
for n in ('01','13','12','07','08'):
 p=r/('quant_swiglu_backward-'+n)/'hidev-npu0/attempt-001/detail';op,=p.rglob('OpBasicInfo.csv')
 with op.open(encoding='utf-8-sig',newline='') as f:b,=csv.DictReader(f)
 print(n,b['Op Type'],b['Block Dim'],b['Device Id'])
PY
echo __INSPECT_SWIGLU_BWD_BLOCKDIMS_END__
