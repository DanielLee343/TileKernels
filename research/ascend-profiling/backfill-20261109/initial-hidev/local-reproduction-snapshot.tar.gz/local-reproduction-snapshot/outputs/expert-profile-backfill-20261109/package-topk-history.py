import csv,hashlib,json,tarfile
from pathlib import Path
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
with (HERE/'targets.csv').open(encoding='utf-8-sig',newline='') as f:rows=list(csv.DictReader(f))
items=[]
for r in rows:
 if r['batch']!='tilekernels-default' or not r['case'].startswith('moe_topk_gate/'):continue
 batch,case=r['target_id'].split('/');assert batch=='second'
 meta=(ROOT/r['original_profile_paths'].split(';')[0]).parent.parent/'default.json';j=json.loads(meta.read_text())
 assert j['runtime_kernel']==r['op_name'] and j['status']=='passed'
 items.append({'case':case,'target':r['target_id'],'plan_case':r['case'],
  'metadata_sha256':hashlib.sha256(meta.read_bytes()).hexdigest(),'metadata_path':str(meta.relative_to(ROOT))})
assert len(items)==20 and len({x['case'] for x in items})==20
with tarfile.open(HERE/'topk-history.tar.gz','w:gz') as t:
 for x in items:t.add(ROOT/x['metadata_path'],arcname='topk-history/'+x['case']+'/default.json')
(HERE/'topk-history-sha256.txt').write_text(''.join(x['metadata_sha256']+'  topk-history/'+x['case']+'/default.json\n' for x in items),encoding='utf-8')
(HERE/'topk-pending.json').write_text(json.dumps(items,indent=2)+'\n',encoding='utf-8')
print('cases',len(items))
