#!/usr/bin/env bash
set -Eeuo pipefail
echo __ARCHIVE_RUNNER_EVIDENCE_BEGIN__
r=/workspace/expert-profile-backfill-20261109-hidev
python3 -B "$r/scan-public-archive.py" "$r/runner-version-evidence"
test ! -e "$r/runner-version-evidence.tar.gz"
tar -C "$r" -czf "$r/runner-version-evidence.tar.gz" runner-version-evidence
sha256sum "$r/runner-version-evidence.tar.gz"
echo __ARCHIVE_RUNNER_EVIDENCE_END__
