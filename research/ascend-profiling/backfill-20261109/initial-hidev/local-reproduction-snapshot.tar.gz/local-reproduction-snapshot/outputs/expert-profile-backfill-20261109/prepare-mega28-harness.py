"""Isolate the 28-core MegaMoE worker, adding tensor address metadata only."""
import hashlib,json
from pathlib import Path
p=Path(__file__).resolve().parent;root=p.parents[1]
base=root/'TileKernels-private/research/ascend-profiling/deepgemm-ascend';out=p/'mega28-profile-harness';campaign=out/'campaign-13';pilot=out/'pilot-bf16'
campaign.mkdir(parents=True,exist_ok=True);pilot.mkdir(parents=True,exist_ok=True)
source=base/'campaign-13/mega_port_run.py';s=source.read_text(encoding='utf8')
old="        if stage=='profile':\n            lib=ctypes.CDLL"
new="""        if stage=='profile':
            def tensor_address(t):
                if t is None:return None
                if isinstance(t,torch.Tensor):
                    return {'device':str(t.device),'address':hex(t.data_ptr()),'dtype':str(t.dtype),
                            'shape':list(t.shape),'stride':list(t.stride()),'bytes':t.numel()*t.element_size()}
                if isinstance(t,(tuple,list)):return [tensor_address(x) for x in t]
                return None
            views={k:tensor_address(v) for k,v in vars(obj.buffer).items() if isinstance(v,torch.Tensor)}
            record={'output':tensor_address(obj.y),'weights_l1':tensor_address(obj.transformed_l1_weights),
                    'weights_l2':tensor_address(obj.transformed_l2_weights),'symmetric_buffer_views':views,
                    'buffer_pointers':[hex(int(x)) for x in obj.buffer.handle.buffer_ptrs]}
            record['pid']=os.getpid()
            Path(output).with_name(f'profile-addresses-{os.getpid()}.json').write_text(json.dumps(record,indent=2)+'\\n')
            lib=ctypes.CDLL"""
assert s.count(old)==1;s=s.replace(old,new)
old="            'threshold':5e-6,'max_abs_error':float((af-ef).abs().max())},indent=2)+'\\n')\n"
new=old+"        if stage=='profile':Path(output).with_name(f'profile-result-{os.getpid()}.json').write_bytes(Path(output).read_bytes())\n"
assert s.count(old)==1;s=s.replace(old,new)
compile(s,str(campaign/'mega_port_run.py'),'exec');(campaign/'mega_port_run.py').write_text(s,encoding='utf8',newline='\n')
(campaign/'mega_reference.py').write_bytes((base/'campaign-13/mega_reference.py').read_bytes())
(pilot/'collect.py').write_bytes((base/'pilot-bf16/collect.py').read_bytes())
cases=json.loads((base/'campaign-13/cases.json').read_text(encoding='utf-8-sig'))
ids={'mega-h256-i512-e4-top2-t16','mega-h256-i512-e4-top2-t64','mega-h512-i1024-e8-top4-t64','mega-h512-i512-e8-top2-t32'}
cases['cases']=[x for x in cases['cases'] if x['id'] in ids];assert {x['id'] for x in cases['cases']}==ids
(campaign/'cases.json').write_text(json.dumps(cases,indent=2)+'\n',encoding='utf8')
history=base/'campaign-13/runs/mega-port28-experiment'
for case in sorted(ids):
 old=history/('smoke-range0' if case=='mega-h256-i512-e4-top2-t16' else 'cases/'+case)
 dest=out/'history'/case;dest.mkdir(parents=True,exist_ok=True)
 for name in ('prepare.json','profile.json','result.json'):(dest/name).write_bytes((old/name).read_bytes())
 (dest/'kernel.asc').write_bytes((old/'jit/kernel.asc').read_bytes())
(out/'provenance.json').write_text(json.dumps({'runner_original_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),
 'change':'additional address-only metadata before profiled range; original reference and numeric checks unchanged',
 'source_commit':'3a35326271b069b8b5bf1a754435acd6cc91575b','port_header_change':'kNumAICores 32 to 28',
 'historical_replay_mode':'range','diagnostic_replay_modes':['application','kernel'],'profiler_warmup':0,'application_warmup':5},indent=2)+'\n')
print('prepared',len(ids),'isolated MegaMoE address-recording workers')
