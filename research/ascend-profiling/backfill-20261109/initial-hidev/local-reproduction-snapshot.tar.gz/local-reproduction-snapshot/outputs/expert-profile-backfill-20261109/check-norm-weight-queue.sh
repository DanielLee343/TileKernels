#!/usr/bin/env bash
echo __CHECK_NORM_WEIGHT_QUEUE_BEGIN__
q=/workspace/expert-profile-backfill-20261109-hidev/extra-norm-backward-weight-queue-hidev-npu0
ps -p "$(cat "$q/pid")" -o pid=,stat=,args= || true
test ! -f "$q/exit.txt" || cat "$q/exit.txt"
tail -n 12 "$q/console.log"
echo __CHECK_NORM_WEIGHT_QUEUE_END__
