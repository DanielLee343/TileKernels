from pathlib import Path
p=Path(__file__).resolve().parent;s=(p/'prepare-engram-grad-inspector-deploy.py').read_text(encoding='utf-8')
for old,new in (
 ('inspect-engram-grad-app.py','inspect-engram-step-app.py'),
 ('deploy-engram-grad-inspector','deploy-engram-step-inspector'),
 ('engram-grad-inspector-deploy','engram-step-inspector-deploy'),
 ('__ENGRAM_GRAD_INSPECTOR_','__ENGRAM_STEP_INSPECTOR_'),
 ('__DEPLOY_ENGRAM_GRAD_INSPECTOR_','__DEPLOY_ENGRAM_STEP_INSPECTOR_'),
):
 assert old in s,old;s=s.replace(old,new)
exec(compile(s,str(p/'prepare-engram-grad-inspector-deploy.py'),'exec'))
