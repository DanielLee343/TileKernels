#!/usr/bin/env bash
echo __INSPECT_SMOKE_DIMENSIONS_BEGIN__
r=/workspace/expert-profile-backfill-20261109-hidev
python3 - "$r" <<'PY'
import csv,sys
from pathlib import Path
r=Path(sys.argv[1])/'extra-proxy-runs'
for target in ('unified-extra/quant_cast-01','unified-extra3/quant_norm_backward-01'):
 p=r/target/'hidev-npu0/attempt-001/detail'; op,=p.rglob('OpBasicInfo.csv')
 with op.open(encoding='utf-8-sig',newline='') as f:b,=csv.DictReader(f)
 with op.with_name('Memory.csv').open(encoding='utf-8-sig',newline='') as f:m=list(csv.DictReader(f))
 print(target,'blockdim',b['Block Dim'],'optype',b['Op Type'],'memory_rows',len(m));print('first/last',[(x['block_id'],x['sub_block_id']) for x in (m[:2]+m[-2:])])
PY
echo __INSPECT_SMOKE_DIMENSIONS_END__
