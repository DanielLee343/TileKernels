from pathlib import Path
p=Path(__file__).resolve().parent;s=(p/'prepare-moe-audit-deploy.py').read_text(encoding='utf-8')
for old,new in (
 ('audit-extra-moe-backward-candidate.py','audit-dg-kgroup-bf16-candidate.py'),
 ('moe-audit-deploy','dg-kgroup-audit-deploy'),
 ('deploy-moe-audit-','deploy-dg-kgroup-audit-'),
 ('__MOE_AUDIT_PART_', '__DG_KGROUP_AUDIT_PART_'),
 ('__DEPLOY_MOE_AUDIT_', '__DEPLOY_DG_KGROUP_AUDIT_'),
 ('moe_topk_gate_backward-01','kgroup-bf16bf16-tn-g4-m64-n256-k512'),
):
 assert old in s,old;s=s.replace(old,new)
exec(compile(s,str(p/'prepare-moe-audit-deploy.py'),'exec'))
