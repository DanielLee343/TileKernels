import base64,hashlib,io,tarfile
from pathlib import Path
p=Path(__file__).resolve().parent;b=io.BytesIO()
names=('summarize-dg-kgroup-quant.py','summarize-dg-sparse-mqa.py','test-dg-kgroup-fp8fp8-audit.sh','test-dg-kgroup-fp4fp4-audit.sh','test-dg-kgroup-fp8fp4-audit.sh')
with tarfile.open(fileobj=b,mode='w:gz') as t:
 for n in names:t.add(p/n,arcname=n)
data=b.getvalue();encoded=base64.b64encode(data).decode();sha=hashlib.sha256(data).hexdigest()
for i in range(0,len(encoded),5500):
 part=i//5500;mode='>' if part==0 else '>>'
 (p/f'deploy-kgroup-sparse-index-part-{part}.sh').write_text(f"printf '%s' '{encoded[i:i+5500]}' {mode} /workspace/expert-profile-backfill-20261109-hidev/kgroup-sparse-index-deploy.b64\necho __KGROUP_SPARSE_INDEX_PART_{part}__\n",encoding='utf-8',newline='\n')
script=f'''set -e
echo __KGROUP_SPARSE_INDEX_BEGIN__
r=/workspace/expert-profile-backfill-20261109-hidev
base64 -d "$r/kgroup-sparse-index-deploy.b64" > "$r/kgroup-sparse-index-deploy.tar.gz"
printf '%s  %s\\n' {sha} "$r/kgroup-sparse-index-deploy.tar.gz" | sha256sum -c
test ! -e "$r/summarize-dg-kgroup-quant.py"
test ! -e "$r/summarize-dg-sparse-mqa.py"
tar -xzf "$r/kgroup-sparse-index-deploy.tar.gz" -C "$r"
for tag in fp8fp8 fp4fp4 fp8fp4;do
 bash "$r/test-dg-kgroup-$tag-audit.sh" > "$r/kgroup-$tag-audit-test.log" 2>&1
 grep -q 'PASS rejects missing store, altered CSV and input/output alias' "$r/kgroup-$tag-audit-test.log"
done
grep -q 'ALL_DG_SPARSE_MQA_SELECTED_AUDITED' "$r/deepgemm-sparse-mqa-queue-hidev-npu0/console.log"
python3 -B "$r/summarize-dg-kgroup-quant.py"
python3 -B "$r/summarize-dg-sparse-mqa.py"
for x in kgroup-quant sparse-mqa;do gzip -n -c "$r/deepgemm-$x-index.json" > "$r/deepgemm-$x-index.json.gz";sha256sum "$r/deepgemm-$x-index.json.gz";done
echo __KGROUP_SPARSE_INDEX_END__
'''
(p/'deploy-kgroup-sparse-index-finish.sh').write_text(script,encoding='utf-8',newline='\n')
print('parts',(len(encoded)+5499)//5500)
