from pathlib import Path
p=Path(__file__).resolve().parent;s=(p/'test-engram-gate-bwd-unmasked.sh').read_text()
s=s.replace('engram_gate_bwd-01','engram_gate_bwd-15').replace('audit-extra-engram-gate-bwd-unmasked-candidate.py','audit-extra-engram-gate-bwd-mask-candidate.py').replace('ENGRAM_GATE_BWD_UNMASKED_TEST','ENGRAM_GATE_BWD_MASK_TEST')
(p/'test-engram-gate-bwd-mask.sh').write_text(s,encoding='utf8',newline='\n')
print('prepared masked backward output, CSV, alias and shape tests')
