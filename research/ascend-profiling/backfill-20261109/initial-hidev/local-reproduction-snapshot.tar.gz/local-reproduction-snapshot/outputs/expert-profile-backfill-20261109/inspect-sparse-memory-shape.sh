echo __SPARSE_MEMORY_SHAPE_BEGIN__
p=/workspace/expert-profile-backfill-20261109-hidev/deepgemm-runs/sparse-fp8-q4-k256-h8-b8/hidev-npu0/attempt-001
python3 - "$p" <<'PY'
import csv,sys
from pathlib import Path
f,=list(Path(sys.argv[1]).rglob('Memory.csv'))
with f.open(encoding='utf-8-sig',newline='') as fp:rows=list(csv.DictReader(fp))
print('rows',len(rows));print('blocks',sorted({r['block_id'] for r in rows},key=int))
for r in rows:
 if r['UB_to_GM_datas(KB)'] not in ('NA','','0.000000'):
  print(r['block_id'],r['sub_block_id'],r['UB_to_GM_datas(KB)'])
PY
echo __SPARSE_MEMORY_SHAPE_END__
