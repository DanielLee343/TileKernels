"""Prepare packed quantized norm with residual and batched tail."""
from pathlib import Path
p=Path(__file__).resolve().parent;s=(p/'audit-extra-norm-forward-05.py').read_text()
edits=[
 ("assert case=='quant_norm_forward-05'", "assert case=='quant_norm_forward-06'"),
 ("assert len(a)==8 and a[0] and a[1] and a[2] and a[3] and a[5] and all(a[i] is None for i in (4,6,7))", "assert len(a)==8 and a[0] and a[1] and a[2] and a[4] and a[6] and a[7] and all(a[i] is None for i in (3,5))"),
 ("sf['shape'][0]==1", "sf['shape'][0]==2"),
 ('outputs=[a[1],sf,a[3],a[5]]','outputs=[a[1],sf,a[7]]'),
 ('all_tensors=[a[0]]+outputs','all_tensors=[a[0],a[4],a[6]]+outputs'),
 ("source.count('asc_copy_ub2gm_align(')==4", "source.count('asc_copy_ub2gm_align(')==3"),
 ("('out[','out_bf16[','out_sf_words','rstd[')", "('out[','residual_out[','out_sf_words')"),
 ('actual=[[],[],[],[]];percore','actual=[[],[],[]];percore'),
 ('for i in (0,1,2,3)','for i in (0,1,2)')]
for old,new in edits:assert old in s,old;s=s.replace(old,new)
(p/'audit-extra-norm-forward-06.py').write_text(s,encoding='utf8',newline='\n')
print('batched quantized norm/residual audit candidate prepared')
