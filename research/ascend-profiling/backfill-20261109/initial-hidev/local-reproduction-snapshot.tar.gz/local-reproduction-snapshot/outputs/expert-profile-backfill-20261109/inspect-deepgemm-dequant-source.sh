#!/usr/bin/env bash
set -e
echo __INSPECT_DG_DEQUANT_SOURCE_BEGIN__
src=/workspace/deepgemm-ascend-20261107/source/deep_gemm/include/deep_gemm
grep -R -n 'fp8_dequant_gemm_impl\|copy_ub_to_gm' "$src" --include='*dequant*' | head -80 || true
grep -n -E 'epilogue|Epilogue|write|Store|store|AIV|aiv' "$src/fp8_dequant_gemm.hpp" | tail -80
sed -n '318,337p' "$src/fp8_dequant_gemm.hpp"
echo __INSPECT_DG_DEQUANT_SOURCE_END__
