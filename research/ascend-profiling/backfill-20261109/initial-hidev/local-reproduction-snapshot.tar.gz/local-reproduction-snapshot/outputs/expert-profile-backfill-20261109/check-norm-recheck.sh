#!/usr/bin/env bash
echo __CHECK_NORM_RECHECK_BEGIN__
r=/workspace/expert-profile-backfill-20261109-hidev
ps -p "$(cat "$r/norm-recheck-20261110.pid")" -o pid=,stat=,args= || true
tail -n 25 "$r/norm-recheck-20261110.log"
echo __CHECK_NORM_RECHECK_END__
