import base64,hashlib
from pathlib import Path
p=Path(__file__).resolve().parent
data=(p/'archive-norm-backward.py').read_bytes()
encoded=base64.b64encode(data).decode();digest=hashlib.sha256(data).hexdigest()
script=f'''set -e
echo __DEPLOY_NORM_ARCHIVE_BEGIN__
p=/workspace/expert-profile-backfill-20261109-hidev/archive-norm-backward.py
test ! -e "$p"
printf %s {encoded} | base64 -d > "$p"
printf '%s  %s\\n' {digest} "$p" | sha256sum -c
echo __DEPLOY_NORM_ARCHIVE_END__
'''
(p/'deploy-norm-archive.sh').write_text(script,encoding='utf-8',newline='\n')
