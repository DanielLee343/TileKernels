from pathlib import Path
p=Path(__file__).resolve().parent;s=(p/'test-dg-bf16-mgroup-audit.sh').read_text(encoding='utf-8')
for old,new in (
 ('__DG_BF16_MGROUP_AUDIT_TEST_', '__DG_KGROUP_AUDIT_TEST_'),
 ('mgroup-bf16bf16-nt-g4-m128-n256-k512','kgroup-bf16bf16-tn-g4-m64-n256-k512'),
 ('audit-dg-bf16-mgroup-candidate.py','audit-dg-kgroup-bf16-candidate.py'),
 ("cp \"$root/audit-reduce-family.py\" \"$tmp/\";export BACKFILL_ROOT=\"$tmp\"", "cp \"$root/audit-reduce-family.py\" \"$tmp/\";cp -a \"$root/deepgemm-kgroup-harness\" \"$tmp/\";export BACKFILL_ROOT=\"$tmp\""),
 ("rows[2]['UB_to_GM_datas(KB)']=str(float(rows[2]['UB_to_GM_datas(KB)'])+1)", "row=next(x for x in rows if x['sub_block_id']=='vector0' and x['UB_to_GM_datas(KB)'] not in ('NA',''));row['UB_to_GM_datas(KB)']=str(float(row['UB_to_GM_datas(KB)'])+1)"),
):
 assert old in s,old;s=s.replace(old,new)
needle='mem=$(find "$detail/capture" -name Memory.csv -print -quit)'
assert needle in s;s=s.replace(needle,needle+'\ncp "$mem" "$tmp/original-memory.csv"')
marker="echo 'PASS rejects missing store and altered CSV'"
extra="""cp \"$tmp/original-memory.csv\" \"$mem\"
python3 - \"$tmp/$base/profile-addresses.json\" <<'PY'
import json,sys
from pathlib import Path
p=Path(sys.argv[1]);d=json.loads(p.read_text());d[0]['args'][2]['address']=d[0]['args'][0]['address'];p.write_text(json.dumps(d))
PY
if python3 -B \"$root/audit-dg-kgroup-bf16-candidate.py\" \"$case_id\" attempt-001 > \"$tmp/alias.out\" 2>&1;then echo INPUT_ALIAS_UNDETECTED;exit 1;fi
echo 'PASS rejects missing store, altered CSV and input/output alias'
"""
assert marker in s;s=s.replace(marker,extra)
(p/'test-dg-kgroup-audit.sh').write_text(s,encoding='utf-8',newline='\n')
