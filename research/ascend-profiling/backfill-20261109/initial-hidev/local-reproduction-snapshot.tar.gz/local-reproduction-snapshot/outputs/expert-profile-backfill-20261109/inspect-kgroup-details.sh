echo __KGROUP_DETAILS_BEGIN__
p=/workspace/expert-profile-backfill-20261109-hidev/deepgemm-runs/kgroup-bf16bf16-tn-g4-m64-n256-k512/hidev-npu0/attempt-001
python3 - "$p" <<'PY'
import json,sys
from pathlib import Path
p=Path(sys.argv[1]);d=json.loads((p/'capture-inspection.json').read_text())
print('identity',d['correctness'],d.get('historical_true_inputs_match'),d['historical_jit_source_sha256_match'],'stores',d['ub_to_gm_records'],'cores',d['raw_store_core_labels'])
a=json.loads((p/'profile-addresses.json').read_text());print('addresses',json.dumps(a,indent=2))
for line in (p/'detail/profile.log').read_text(errors='replace').splitlines():
 if 'processedRecord:' in line:print(line)
PY
echo __KGROUP_DETAILS_END__
