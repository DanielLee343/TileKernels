#!/usr/bin/env bash
echo __CHECK_NORM_ACCUM_APP08_TEST_BEGIN__
r=/workspace/expert-profile-backfill-20261109-hidev
ps -p "$(cat "$r/norm-accum-app08-test.pid")" -o pid=,stat=,args= || true
tail -n 12 "$r/norm-accum-app08-test.log"
echo __CHECK_NORM_ACCUM_APP08_TEST_END__
