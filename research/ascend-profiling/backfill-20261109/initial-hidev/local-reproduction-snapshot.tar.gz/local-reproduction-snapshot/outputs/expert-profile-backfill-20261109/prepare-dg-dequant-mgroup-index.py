from pathlib import Path
p=Path(__file__).resolve().parent
for old,new in [('summarize-dg-bf16-mgroup.py','summarize-dg-dequant-mgroup.py'),('index-dg-bf16-mgroup.py','index-dg-dequant-mgroup.py')]:
 s=(p/old).read_text();assert 'bf16-mgroup' in s;s=s.replace('bf16-mgroup','dequant-mgroup')
 (p/new).write_text(s,encoding='utf8',newline='\n')
print('prepared independent dequant grouped index')
