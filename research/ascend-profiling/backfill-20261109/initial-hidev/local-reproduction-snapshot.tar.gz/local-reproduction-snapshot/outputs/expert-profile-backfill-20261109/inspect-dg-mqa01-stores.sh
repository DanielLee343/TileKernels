#!/usr/bin/env bash
echo __INSPECT_DG_MQA01_STORES_BEGIN__
p=/workspace/expert-profile-backfill-20261109-hidev/deepgemm-runs/mqa-0-q16-k512-h8-random/hidev-npu0/attempt-001
python3 - "$p" <<'PY'
import importlib.machinery,json,sys
from pathlib import Path
p=Path(sys.argv[1]);m=importlib.machinery.SourceFileLoader('r','/workspace/expert-profile-backfill-20261109-hidev/audit-reduce-family.py').load_module()
out=json.loads((p/'profile-addresses.json').read_text())[0]['returned'];base=int(out['address'],16)
for c,pc,addr,stride,l1s,l2s,srcaddr,srcstride,srcl1s,srcl2s,burst,length,dtype,l1,l2,left,right in m.REGEX.findall((p/'detail/profile.log').read_text(errors='replace')):
 print('core',c,'pc',pc,'offset',int(addr,16)-base,'n',burst,'len',length,'stride',stride,'l1',l1,'l2',l2)
PY
echo __INSPECT_DG_MQA01_STORES_END__
