#!/usr/bin/env bash
echo __CHECK_DG_DEQUANT_SMOKE_BEGIN__
q=/workspace/expert-profile-backfill-20261109-hidev/deepgemm-dequant-smoke-hidev-npu0
ps -p "$(cat "$q/pid")" -o pid,stat,etime,args || true
tail -n 28 "$q/console.log"
if test -f "$q/exit.txt";then cat "$q/exit.txt";fi
echo __CHECK_DG_DEQUANT_SMOKE_END__
