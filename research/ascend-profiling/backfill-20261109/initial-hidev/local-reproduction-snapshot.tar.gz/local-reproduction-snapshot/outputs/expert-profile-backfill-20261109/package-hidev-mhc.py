"""Prepare chunked checksum-verified deployment to the existing hidev session."""
import base64,hashlib,io,tarfile
from pathlib import Path
HERE=Path(__file__).resolve().parent
OLD=HERE.parent/'gcm-profile-screen-20261108/mte3-x1-x3/tbe-recapture'
names=('audit-mhc-detail.py','run-hidev-mhc-detail.sh','mhc-queue.py','mhc-pending.json','mhc-history.tar.gz','mhc-history-sha256.txt')
files={name:HERE/name for name in names}
files.update({name:OLD/name for name in ('collector_third.py','collector_fifth.py','cases_third.json','cases_fifth.json')})
buf=io.BytesIO()
with tarfile.open(fileobj=buf,mode='w:gz') as tar:
 for name,path in files.items():tar.add(path,arcname=name,recursive=False)
payload=base64.b64encode(buf.getvalue()).decode('ascii')
for idx in range(0,len(payload),5000):
 part=idx//5000
 body=('mkdir -p /workspace/expert-profile-backfill-20261109-hidev\n'
       +(': > /workspace/expert-profile-backfill-20261109-hidev/mhc-package.b64\n' if part==0 else '')
       +"printf '%s' '"+payload[idx:idx+5000]+"' >> /workspace/expert-profile-backfill-20261109-hidev/mhc-package.b64\n"
       +f"printf '%s\\n' __HIDEV_MHC_PART_{part:02d}_DONE__\n")
 (HERE/f'deploy-hidev-mhc-part-{part:02d}.sh').write_text(body,encoding='utf-8',newline='\n')
hashes='\n'.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+name for name,p in files.items())
script="""#!/usr/bin/env bash
set -Eeo pipefail
cd /workspace/expert-profile-backfill-20261109-hidev
test ! -e mhc-package.done
printf '%s  %s\\n' PACKAGE_HASH mhc-package.b64 | sha256sum -c
base64 -d mhc-package.b64 | tar -xz
cat > mhc-package-sha256.txt <<'EOF'
HASHES
EOF
sha256sum -c mhc-package-sha256.txt
test ! -e mhc-history
tar -xzf mhc-history.tar.gz
sha256sum -c mhc-history-sha256.txt
touch mhc-package.done
printf '%s\\n' __HIDEV_MHC_DEPLOY_DONE__
""".replace('PACKAGE_HASH',hashlib.sha256(payload.encode()).hexdigest()).replace('HASHES',hashes)
(HERE/'deploy-hidev-mhc-final.sh').write_text(script,encoding='utf-8',newline='\n')
print('bytes',len(buf.getvalue()),'parts',(len(payload)+4999)//5000)
