#!/usr/bin/env bash
echo __INSPECT_DG_MQA01_LAYOUT_BEGIN__
p=/workspace/expert-profile-backfill-20261109-hidev/deepgemm-runs/mqa-0-q16-k512-h8-random/hidev-npu0/attempt-001
python3 - "$p" <<'PY'
import json,sys
from pathlib import Path
p=Path(sys.argv[1]);a=json.loads((p/'profile-addresses.json').read_text());print(json.dumps(a,indent=2))
PY
grep -n 'copy_ub_to_gm\|mqa_logits_impl\|out\[' "$p/jit/kernel.asc" | head -30 || true
echo __INSPECT_DG_MQA01_LAYOUT_END__
