from pathlib import Path
p=Path(__file__).resolve().parent;s=(p/'package-deepgemm-mgroup.py').read_text(encoding='utf-8')
for old,new in (
 ('deepgemm-mgroup-harness','deepgemm-normal-bf16-harness'),
 ('run-hidev-deepgemm-mgroup.sh','run-hidev-deepgemm-normal-bf16.sh'),
 ('inspect-deepgemm-mgroup.py','inspect-deepgemm-normal-bf16.py'),
 ('deploy-dg-mgroup','deploy-dg-normal-bf16'),
 ('dg-mgroup-deploy','dg-normal-bf16-deploy'),
 ('__DG_MGROUP_','__DG_NORMAL_BF16_'),
):
 assert old in s,old;s=s.replace(old,new)
exec(compile(s,str(p/'package-deepgemm-mgroup.py'),'exec'))
