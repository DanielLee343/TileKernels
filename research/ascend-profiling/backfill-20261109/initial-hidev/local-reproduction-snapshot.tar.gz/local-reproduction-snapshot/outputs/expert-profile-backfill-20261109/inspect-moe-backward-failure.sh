echo __MOE_BACKWARD_FAILURE_BEGIN__
p=/workspace/expert-profile-backfill-20261109-hidev/extra-proxy-runs/unified-extra4/moe_topk_gate_backward-02/hidev-npu0/attempt-001
cat "$p/queue-status.json"
tail -n 25 "$p/audit-console.log"
python3 - "$p/detail" <<'PY'
import json,sys
from pathlib import Path
p=Path(sys.argv[1]);a=json.loads((p/'tensor-addresses.json').read_text());app=json.loads((p/'application.json').read_text())
print('params',json.dumps(app['params']))
for i,t in enumerate(a):print(i,json.dumps(t))
PY
echo __MOE_BACKWARD_FAILURE_END__
