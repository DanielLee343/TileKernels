from pathlib import Path
p=Path(__file__).resolve().parent;s=(p/'package-engram-grad-app.py').read_text(encoding='utf-8')
for old,new in (
 ('extra-proxy-engram-grad-app-harness','extra-proxy-engram-step-app-harness'),
 ('run-hidev-extra-engram-grad-app.sh','run-hidev-extra-engram-step-app.sh'),
 ('extra_engram_grad.py','extra_engram_step.py'),
 ('deploy-engram-grad-app','deploy-engram-step-app'),
 ('engram-grad-app-deploy','engram-step-app-deploy'),
 ('__ENGRAM_GRAD_APP_','__ENGRAM_STEP_APP_'),
):
 assert old in s,old;s=s.replace(old,new)
exec(compile(s,str(p/'package-engram-grad-app.py'),'exec'))
