echo __SPARSE_META_WRITE_DETAIL_BEGIN__
sed -n '145,190p;300,335p' /workspace/deepgemm-ascend-20261107/source/deep_gemm/include/deep_gemm/sparse_mqa_logits_metadata.hpp
echo __SPARSE_META_WRITE_DETAIL_END__
