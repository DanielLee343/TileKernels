"""Compare early/main candidates without merging separate capture windows."""
import csv,hashlib,json
from collections import Counter
from pathlib import Path

HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(p):return json.loads(p.read_text(encoding='utf-8-sig'))
with (HERE/'early-overlap-candidates.csv').open(encoding='utf-8-sig',newline='') as f:rows=list(csv.DictReader(f))
out=[]
for r in rows:
 main=ROOT/r['main_metadata'].replace('\\','/');m=load(main)
 for raw in r['early_original'].split(';'):
  op=ROOT/raw;meta=None
  for parent in list(op.parents)[:6]:
   for candidate in (parent/'default.json',parent/'metadata/default.json'):
    if candidate.is_file():meta=candidate;break
   if meta:break
  rec={'early_target':r['early_target'],'main_target':r['main_target'],
    'early_opbasic':raw,'early_metadata':str(meta.relative_to(ROOT)) if meta else None,
    'main_metadata':r['main_metadata'],'status':'insufficient_evidence'}
  if meta is None:out.append(rec);continue
  e=load(meta)
  prepare=meta.parent/'prepare.json';prepared=load(prepare) if prepare.is_file() else {}
  separate=e.get('correctness',{}).get('status')=='checked_in_separate_prepare_process'
  early_correct=prepared.get('correctness',{}).get('status')=='passed' if separate else e.get('status')=='passed'
  rec['both_correct']=early_correct and m.get('status')=='passed'
  for field in ('runtime_kernel','native_symbol','source_sha256','inputs','outputs'):
   rec[field+'_equal']=field in e and field in m and e[field]==m[field]
  def specs(x):
   return [{k:a.get(k) for k in ('shape','dtype','stride','bytes')} if isinstance(a,dict) else a for a in x] if isinstance(x,list) else None
  rec['input_layout_equal']=specs(e.get('inputs'))==specs(m.get('inputs')) and specs(e.get('inputs')) is not None
  eh=e.get('input_sha256') or [x.get('sha256') if isinstance(x,dict) else None for x in e.get('inputs',[])]
  mh=[x.get('sha256') if isinstance(x,dict) else None for x in m.get('inputs',[])]
  rec['input_hash_comparable']=bool(eh) and len(eh)==len(mh) and all(isinstance(x,str) and len(x)==64 for x in eh+mh)
  rec['input_hash_equal']=rec['input_hash_comparable'] and eh==mh
  es=(meta.parent/'launch-kernel.cpp') if separate else (meta.parent/'default-kernel.cpp');ms=main.parent/'default-kernel.cpp'
  rec['source_file_sha_match']=es.is_file() and ms.is_file() and sha(es)==sha(ms)
  rec['old_sinkhorn_reference_only']=separate and '/sinkhorn-mhc-profile-40cases-20261101/' in raw
  rec['early_application_warmups']=e.get('application_warmup_launches')
  rec['status']='matched_inputs_and_generated_source_scalar_contract_unverified' if all(rec.get(k) for k in ('both_correct','runtime_kernel_equal','inputs_equal','outputs_equal','source_file_sha_match')) else 'not_identical_or_missing_evidence'
  out.append(rec)
summary={'candidate_pairs':len(rows),'early_capture_windows':len(out),'statuses':dict(Counter(x['status'] for x in out)),
 'both_correct':sum(x.get('both_correct',False) for x in out),'exact_input_metadata_matches':sum(x.get('inputs_equal',False) for x in out),
 'input_hash_comparable':sum(x.get('input_hash_comparable',False) for x in out),'same_input_hashes':sum(x.get('input_hash_equal',False) for x in out),'same_generated_source':sum(x.get('source_file_sha_match',False) for x in out),
 'old_sinkhorn_reference_only':sum(x.get('old_sinkhorn_reference_only',False) for x in out),
 'note':'Early/main raw windows remain separate; output is an evidence comparison, not an equivalence or deduplication decision.'}
(HERE/'early-overlap-evidence.json').write_text(json.dumps({'summary':summary,'comparisons':out},indent=2)+'\n',encoding='utf8')
print(json.dumps(summary,indent=2))
