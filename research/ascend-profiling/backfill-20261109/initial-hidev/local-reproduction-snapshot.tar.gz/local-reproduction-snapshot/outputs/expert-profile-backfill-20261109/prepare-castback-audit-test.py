from pathlib import Path
p=Path(__file__).resolve().parent;s=(p/'test-channel-audit.sh').read_text()
for old,new in [('quant_per_channel_cast','quant_cast_back_per_token'),
                ('audit-extra-channel.py','audit-extra-castback.py'),
                ('CHANNEL_AUDIT_TEST','CASTBACK_AUDIT_TEST')]:
 assert old in s;s=s.replace(old,new)
(p/'test-castback-audit.sh').write_text(s,encoding='utf8',newline='\n')
print('prepared per-token cast-back negative tests')
