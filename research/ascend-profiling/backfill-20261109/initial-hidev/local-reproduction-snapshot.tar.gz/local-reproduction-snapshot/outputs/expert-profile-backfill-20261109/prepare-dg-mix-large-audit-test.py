from pathlib import Path
p=Path(__file__).resolve().parent;s=(p/'test-dg-mix-audit.sh').read_text()
for old,new in [('gemm-fp4fp4-nn-mn-m64-n576-k7168','gemm-fp8fp8-nt-k-m4096-n576-k7168'),
                ('DG_MIX_AUDIT_TEST','DG_MIX_LARGE_AUDIT_TEST'),
                ("rows[1]['UB_to_GM_datas(KB)']","rows[2]['UB_to_GM_datas(KB)']")]:
 assert old in s;s=s.replace(old,new)
(p/'test-dg-mix-large-audit.sh').write_text(s,encoding='utf8',newline='\n')
print('prepared large mixed GEMM vector1 negative test')
