#!/usr/bin/env bash
echo __INSPECT_NORM_ACCUM_APP_LAYOUT_BEGIN__
p=/workspace/expert-profile-backfill-20261109-hidev/extra-proxy-runs/unified-extra3/quant_norm_backward-08/hidev-npu0/attempt-001/detail
python3 - "$p" <<'PY'
import json,re,sys
from pathlib import Path
p=Path(sys.argv[1]);a=sorted(p.glob('application-*.json'))[0];pid=a.stem.split('-')[-1]
for i,x in enumerate(json.loads((p/('tensor-addresses-'+pid+'.json')).read_text())):print('arg',i,x)
for x in (p/('generated-kernel-'+pid+'.cpp')).read_text().splitlines():
 if 'asc_copy_ub2gm_align(' in x:
  dst=x.split('(__ubuf__',1)[0];m=re.search(r'\(&\((?:\(\([^)]*\)\s*)?([a-zA-Z_]\w*)\s*\)?\[',dst);print('store',m.group(1) if m else dst[:180])
PY
echo __INSPECT_NORM_ACCUM_APP_LAYOUT_END__
