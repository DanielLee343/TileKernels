#!/usr/bin/env bash
echo __CHECK_NORM_ROWMAJOR_SMOKES_BEGIN__
q=/workspace/expert-profile-backfill-20261109-hidev/extra-norm-rowmajor-smoke-hidev-npu0
ps -p "$(cat "$q/pid")" -o pid,stat,etime,args || true
tail -n 20 "$q/console.log"
if test -f "$q/exit.txt";then cat "$q/exit.txt";fi
echo __CHECK_NORM_ROWMAJOR_SMOKES_END__
