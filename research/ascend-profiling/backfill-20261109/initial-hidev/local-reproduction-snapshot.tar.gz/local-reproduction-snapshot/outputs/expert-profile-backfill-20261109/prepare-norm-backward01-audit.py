from pathlib import Path
p=Path(__file__).resolve().parent
s=(p/'audit-extra-swiglu-backward-01.py').read_text()
s=s.replace('quant_swiglu_backward-01','quant_norm_backward-01').replace('unified-extra4','unified-extra3')
old="a=json.loads((p/'tensor-addresses.json').read_text());assert len(a)==12 and a[0] and a[2] and a[9] and all(a[i] is None for i in (1,3,4,5,6,7,8,10,11))\nassert a[0]['shape']==a[9]['shape']==[128,256] and a[2]['shape']==[128,128]"
new="a=json.loads((p/'tensor-addresses.json').read_text());assert len(a)==8 and a[0] and a[2] and a[3] and a[4] and all(a[i] is None for i in (1,5,6,7))\nassert a[0]['shape']==a[2]['shape']==a[4]['shape']==[512,128] and a[3]['shape']==[512]"
assert old in s;s=s.replace(old,new)
s=s.replace('for x in (a[0],a[2]):','for x in (a[0],a[2],a[3]):').replace('span(a[9])','span(a[4])')
s=s.replace("assert len(lines)==2 and all('x_grad['", "assert len(lines)==1 and all('x_grad['")
s=s.replace("basic['Block Dim']=='56'", "basic['Block Dim']=='18'").replace('c//3<28','c//3<9')
s=s.replace('for item in a[9:10]:','for item in a[4:5]:').replace('for item in a[9:10])','for item in a[4:5])')
s=s.replace("mem=read(op.with_name('Memory.csv'));assert len(mem)==56", "mem=read(op.with_name('Memory.csv'));assert len(mem)==18")
s=s.replace('if j<28 else None','if j<9 else None').replace("if j<28 and value", "if j<9 and value").replace('elif j<28:', 'elif j<9:')
s=s.replace('for i in range(56)', 'for i in range(18)')
(p/'audit-extra-norm-backward-01.py').write_text(s,encoding='utf8',newline='\n')
test=(p/'test-swiglu-forward-audit.sh').read_text().replace('quant_swiglu_forward-01','quant_norm_backward-01')
test=test.replace('audit-extra-swiglu-forward.py','audit-extra-norm-backward-01.py').replace("a[1]['address']=a[0]['address']","a[4]['address']=a[0]['address']").replace('SWIGLU_FORWARD_AUDIT_TEST','NORM_BACKWARD_01_AUDIT_TEST')
(p/'test-norm-backward-01-audit.sh').write_text(test,encoding='utf8',newline='\n')
print('prepared non-accumulating 18-vector-block case audit and negative tests')
