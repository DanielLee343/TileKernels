import base64,hashlib,io,tarfile
from pathlib import Path
p=Path(__file__).resolve().parent;b=io.BytesIO()
with tarfile.open(fileobj=b,mode='w:gz') as t:
 for name in ('deepgemm-transform-harness','run-hidev-deepgemm-transform.sh','inspect-deepgemm-transform.py'):
  t.add(p/name,arcname=name,filter=lambda info:None if '__pycache__' in info.name else info)
data=b.getvalue();encoded=base64.b64encode(data).decode();digest=hashlib.sha256(data).hexdigest()
for i in range(0,len(encoded),5500):
 part=i//5500;mode='>' if part==0 else '>>'
 (p/f'deploy-dg-transform-part-{part}.sh').write_text(f"printf '%s' '{encoded[i:i+5500]}' {mode} /workspace/expert-profile-backfill-20261109-hidev/dg-transform-deploy.b64\nprintf '%s\\n' __DG_TRANSFORM_PART_{part}__\n",encoding='utf8',newline='\n')
script=f'''set -e
root=/workspace/expert-profile-backfill-20261109-hidev
base64 -d "$root/dg-transform-deploy.b64" > "$root/dg-transform-deploy.tar.gz"
printf '%s  %s\\n' {digest} "$root/dg-transform-deploy.tar.gz" | sha256sum -c
test ! -e "$root/deepgemm-transform-harness"
tar -xzf "$root/dg-transform-deploy.tar.gz" -C "$root"
bash -n "$root/run-hidev-deepgemm-transform.sh"
python3 -m py_compile "$root/inspect-deepgemm-transform.py" "$root/deepgemm-transform-harness/campaign-13/collect.py"
printf '%s\\n' __DG_TRANSFORM_DEPLOY_DONE__
'''
(p/'deploy-dg-transform-finish.sh').write_text(script,encoding='utf8',newline='\n')
print('parts',(len(encoded)+5499)//5500,'sha256',digest)
