#!/usr/bin/env bash
echo __CHECK_BLOCK_CASTONLY_FOLLOWUP_BEGIN__
q=/workspace/expert-profile-backfill-20261109-hidev/unified-quant-block-castonly-queue-hidev-npu0
ps -p "$(cat "$q/followup.pid")" -o pid,stat,etime,args || true
tail -n 25 "$q/followup.log"
if test -f "$q/followup-exit.txt";then cat "$q/followup-exit.txt";fi
echo __CHECK_BLOCK_CASTONLY_FOLLOWUP_END__
