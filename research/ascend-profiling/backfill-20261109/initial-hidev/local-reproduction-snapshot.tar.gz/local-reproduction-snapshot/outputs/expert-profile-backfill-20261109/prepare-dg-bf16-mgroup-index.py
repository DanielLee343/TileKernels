from pathlib import Path
p=Path(__file__).resolve().parent
s=(p/'summarize-dg-mgroup.py').read_text()
s=s.replace('deepgemm-mgroup-harness','deepgemm-bf16-mgroup-harness').replace('deepgemm-mgroup-index.json','deepgemm-bf16-mgroup-index.json')
s=s.replace('assert len(items)==6','assert len(items)==3').replace('assert len(cases)==6 and len({x[\'case\'] for x in cases})==6','assert len(cases)==3 and len({x[\'case\'] for x in cases})==3')
(p/'summarize-dg-bf16-mgroup.py').write_text(s,encoding='utf8',newline='\n')
s=(p/'index-dg-mgroup.py').read_text().replace('deepgemm-mgroup-index.json','deepgemm-bf16-mgroup-index.json').replace('deepgemm-mgroup-audits','deepgemm-bf16-mgroup-audits').replace("==6", "==3")
(p/'index-dg-bf16-mgroup.py').write_text(s,encoding='utf8',newline='\n')
print('prepared independent BF16 grouped index')
