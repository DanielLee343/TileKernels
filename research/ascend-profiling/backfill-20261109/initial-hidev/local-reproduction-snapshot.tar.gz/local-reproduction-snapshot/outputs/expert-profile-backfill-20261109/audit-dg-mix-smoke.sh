#!/usr/bin/env bash
printf '%s\n' __DG_MIX_SMOKE_AUDIT_BEGIN__
root=/workspace/expert-profile-backfill-20261109-hidev
python3 -B "$root/audit-deepgemm-mix-general.py" gemm-fp4fp4-nt-mn-m64-n576-k7168 attempt-001
printf '%s\n' __DG_MIX_SMOKE_AUDIT_END__
