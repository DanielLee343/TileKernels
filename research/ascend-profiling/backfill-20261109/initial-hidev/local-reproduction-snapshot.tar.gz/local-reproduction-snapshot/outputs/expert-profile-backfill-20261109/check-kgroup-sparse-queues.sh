echo __CHECK_KGROUP_SPARSE_QUEUES_BEGIN__
r=/workspace/expert-profile-backfill-20261109-hidev
for name in deepgemm-kgroup-quant-smoke deepgemm-sparse-mqa-queue;do
 q="$r/$name-hidev-npu0";echo "JOB=$name"
 ps -p "$(cat "$q/pid")" -o pid,stat,etime,args || true
 test ! -f "$q/exit.txt" || cat "$q/exit.txt"
 grep -E 'IDENTITY_CHECKED_ADDRESS_AUDIT_PENDING|case=|ALL_|passed|failed|Traceback|Error|AssertionError' "$q/console.log" | tail -n 12 || true
done
echo __CHECK_KGROUP_SPARSE_QUEUES_END__
