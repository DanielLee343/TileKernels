echo __CHECK_HIDEV_DISK_WORKERS_BEGIN__
df -h /workspace | tail -n 2
r=/workspace/expert-profile-backfill-20261109-hidev
du -sh "$r" 2>/dev/null
ps -eo pid,ppid,stat,etime,args | grep -E '[m]sprof op|[h]idev-moe-backward-queue-v2|[k]group-smoke-hidev|[r]andn-small-smoke-hidev' | cut -c1-220
echo __CHECK_HIDEV_DISK_WORKERS_END__
