import base64,hashlib
from pathlib import Path
HERE=Path(__file__).resolve().parent
names=('guard-v4.py','run-hidev-deepgemm-smoke-v3.sh')
lines=['#!/usr/bin/env bash','set -Eeo pipefail','root=/workspace/expert-profile-backfill-20261109-hidev']
for name in names:
 data=(HERE/name).read_bytes();payload=base64.b64encode(data).decode();digest=hashlib.sha256(data).hexdigest()
 lines += [f'test ! -e "$root/{name}"',f"printf '%s' '{payload}' | base64 -d > \"$root/{name}\"",
           f"printf '%s  %s\\n' {digest} \"$root/{name}\" | sha256sum -c"]
lines.append("printf '%s\\n' __HIDEV_DEEPGEMM_V3_DONE__")
(HERE/'deploy-deepgemm-v3.sh').write_text('\n'.join(lines)+'\n',encoding='utf-8',newline='\n')
print('prepared bytes',sum(len(x) for x in lines))
