import base64,hashlib,io,tarfile
from pathlib import Path
p=Path(__file__).resolve().parent;s=(p/'hidev-extra-norm-accum-app-queue.py').read_text(encoding='utf-8')
start=s.index('items=[');end=s.index('\nfor x in items:',start)
s=s[:start]+"items=[x for x in json.loads((root/'extra-proxy-engram-grad-app-harness/cases.json').read_text())['cases'] if x['group']=='engram_grad_w_reduce'];assert len(items)==20"+s[end:]
for old,new in (
 ('extra-norm-accum-app-queue-hidev-npu0','extra-engram-grad-app-queue-hidev-npu0'),
 ("target=='unified-extra3/'+case", "target=='unified-extra/'+case"),
 ('run-hidev-extra-norm-accum-app-batch.sh','run-hidev-extra-engram-grad-app.sh'),
 ('inspect-norm-accum-app-batch.py','inspect-engram-grad-app.py'),
 ('audit-extra-norm-accum-app-batch.py','audit-engram-grad-app-candidate.py'),
 ('ALL_NORM_ACCUM_APP_SELECTED_AUDITED','ALL_ENGRAM_GRAD_APP_SELECTED_AUDITED'),
):
 assert old in s,old;s=s.replace(old,new)
old=" else:status['status']='passed'"
new=""" else:
  candidate=out/'detail/candidate-audit-result.json';final=out/'detail/audit-result.json'
  data=json.loads(candidate.read_text());assert data['target']==target and data['status']=='passed' and not final.exists()
  final.write_bytes(candidate.read_bytes());status['status']='passed'"""
assert old in s;s=s.replace(old,new)
(p/'hidev-engram-grad-app-queue.py').write_text(s,encoding='utf-8',newline='\n');compile(s,str(p/'hidev-engram-grad-app-queue.py'),'exec')
b=io.BytesIO()
with tarfile.open(fileobj=b,mode='w:gz') as t:
 for n in ('hidev-engram-grad-app-queue.py','test-engram-grad-app-audit.sh'):t.add(p/n,arcname=n)
data=b.getvalue();enc=base64.b64encode(data).decode();sha=hashlib.sha256(data).hexdigest()
for i in range(0,len(enc),5500):
 part=i//5500;mode='>' if part==0 else '>>'
 (p/f'deploy-engram-grad-queue-part-{part}.sh').write_text(f"printf '%s' '{enc[i:i+5500]}' {mode} /workspace/expert-profile-backfill-20261109-hidev/engram-grad-queue-deploy.b64\necho __ENGRAM_GRAD_QUEUE_PART_{part}__\n",encoding='utf-8',newline='\n')
script=f'''set -e
echo __DEPLOY_ENGRAM_GRAD_QUEUE_BEGIN__
r=/workspace/expert-profile-backfill-20261109-hidev
base64 -d "$r/engram-grad-queue-deploy.b64" > "$r/engram-grad-queue-deploy.tar.gz"
printf '%s  %s\\n' {sha} "$r/engram-grad-queue-deploy.tar.gz" | sha256sum -c
test ! -e "$r/hidev-engram-grad-app-queue.py"
tar -xzf "$r/engram-grad-queue-deploy.tar.gz" -C "$r"
bash "$r/test-engram-grad-app-audit.sh" > "$r/engram-grad-app-audit-test.log" 2>&1
grep -q 'PASS rejects missing outputs, duplicate record, wrong CSV and unauthorized input/output alias' "$r/engram-grad-app-audit-test.log"
echo __DEPLOY_ENGRAM_GRAD_QUEUE_END__
'''
(p/'deploy-engram-grad-queue-finish.sh').write_text(script,encoding='utf-8',newline='\n')
print('parts',(len(enc)+5499)//5500)
