#!/usr/bin/env bash
echo __CHECK_ENGRAM_GATE_BWD_SMOKE_BEGIN__
q=/workspace/expert-profile-backfill-20261109-hidev/extra-engram-gate-bwd-smoke-hidev-npu0
ps -p "$(cat "$q/pid")" -o pid=,stat=,args= || true
test ! -f "$q/exit.txt" || cat "$q/exit.txt"
tail -n 15 "$q/console.log"
echo __CHECK_ENGRAM_GATE_BWD_SMOKE_END__
