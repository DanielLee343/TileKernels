"""Prepare source-aware audit for the first grouped GEMM representative."""
from pathlib import Path
p=Path(__file__).resolve().parent;s=(p/'audit-deepgemm-mix-general.py').read_text()
old="assert re.fullmatch(r'gemm-fp(?:4|8)fp(?:4|8)-[a-z0-9-]+',case)"
assert old in s;s=s.replace(old,"assert case=='mgroup-fp8fp8-nt-g4-m128-n256-k512'")
(p/'audit-deepgemm-mgroup.py').write_text(s,encoding='utf8',newline='\n')
print('grouped GEMM audit candidate prepared; negative tests remain required')
