#!/usr/bin/env bash
echo __INSPECT_DG_BF16_MGROUP_SOURCE_BEGIN__
r=/workspace/deepgemm-ascend-20261107/source/deep_gemm/include/deep_gemm
grep -n -E '__mix__|kDirectStore|Epilogue|epilogue' "$r/bf16_gemm.hpp" | head -n 40
echo __INSPECT_DG_BF16_MGROUP_SOURCE_END__
