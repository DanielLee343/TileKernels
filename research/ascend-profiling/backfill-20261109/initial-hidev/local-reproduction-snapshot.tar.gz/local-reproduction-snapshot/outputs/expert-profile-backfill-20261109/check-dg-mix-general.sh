#!/usr/bin/env bash
set -Eeo pipefail
printf '%s\n' __DG_MIX_GENERAL_CHECK_BEGIN__
root=/workspace/expert-profile-backfill-20261109-hidev
tmp=$(mktemp -d "$root/dg-mix-audit-test.XXXXXXXX")
trap 'rm -rf -- "$tmp"' EXIT
export AUDIT_OUTPUT="$tmp/result.json" AUDIT_ISA="$tmp/device.isa"
case_id=gemm-fp4fp4-nn-mn-m64-n576-k7168
nice -n 15 python3 -B "$root/audit-deepgemm-mix-general.py" "$case_id" attempt-001
python3 - "$root" "$tmp/result.json" "$case_id" <<'PY'
from pathlib import Path
import json,sys
root=Path(sys.argv[1]);new=json.loads(Path(sys.argv[2]).read_text())
old=json.loads((root/'deepgemm-runs'/sys.argv[3]/'hidev-npu0/attempt-001/address-audit.json').read_text())
for k in ('dbi_requested_bytes','output_bytes','per_vector_block_requested_bytes','capture_binary_sha256','dbi_pc'):
 assert old[k]==new[k],k
print('PASS general mixed audit matches prior exact-case audit')
PY
printf '%s\n' __DG_MIX_GENERAL_CHECK_END__
