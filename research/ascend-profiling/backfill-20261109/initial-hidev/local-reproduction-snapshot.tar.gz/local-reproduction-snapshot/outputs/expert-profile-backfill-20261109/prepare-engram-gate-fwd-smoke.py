from pathlib import Path
p=Path(__file__).resolve().parent
s=(p/'run-hidev-extra-proxy-detail.sh').read_text().replace('quant_per_channel_cast','engram_gate_fwd')
assert 'test "$group" = engram_gate_fwd' in s
s=s.replace('test "$group" = engram_gate_fwd','test "$group" = engram_gate_fwd; test "$target" = unified-extra5/engram_gate_fwd-01')
s=s.replace('$root/run-hidev-extra-proxy-detail.sh','$root/run-hidev-extra-engram-gate-fwd.sh')
(p/'run-hidev-extra-engram-gate-fwd.sh').write_text(s,encoding='utf8',newline='\n')
s=(p/'inspect-extra-proxy.py').read_text()
needle="for key in ('runtime_kernel','inputs','source_sha256'):assert a[key]==old[key],key"
assert needle in s
s=s.replace(needle,needle+"\nfor key in ('group','params','seed','native_config','capture_mode'):assert a[key]==old[key],key\nassert a['application_warmup_native_calls']==5 and a['target_native_calls']==1 and a['correctness']=='passed_upstream_full_engram_gate_fwd_test'")
s=s.replace('stateless per-channel quantization representative','Engram gate forward, save-for-backward non-inplace mode; replay and output audit pending')
(p/'inspect-extra-engram-gate-fwd.py').write_text(s,encoding='utf8',newline='\n')
print('prepared non-inplace Engram forward pilot')
