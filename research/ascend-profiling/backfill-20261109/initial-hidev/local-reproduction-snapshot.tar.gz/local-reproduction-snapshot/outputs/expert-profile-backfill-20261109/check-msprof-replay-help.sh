#!/usr/bin/env bash
echo __CHECK_MSPROF_REPLAY_HELP_BEGIN__
source /workspace/tilekernels-env-20261101/activate.sh
msprof op --help 2>&1 | grep -A 8 -B 3 -i replay | head -n 35
echo __CHECK_MSPROF_REPLAY_HELP_END__
