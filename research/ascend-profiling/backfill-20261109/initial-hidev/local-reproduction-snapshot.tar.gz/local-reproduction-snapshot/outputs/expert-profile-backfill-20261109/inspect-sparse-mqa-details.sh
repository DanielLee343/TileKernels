echo __SPARSE_MQA_DETAILS_BEGIN__
p=/workspace/expert-profile-backfill-20261109-hidev/deepgemm-runs/sparse-fp8-q4-k256-h8-b8/hidev-npu0/attempt-001
python3 - "$p" <<'PY'
import hashlib,json,struct,sys
from pathlib import Path
p=Path(sys.argv[1]);d=json.loads((p/'capture-inspection.json').read_text());print('identity',d['correctness'],d.get('historical_true_inputs_match'),d['historical_jit_source_sha256_match'],'stores',d['ub_to_gm_records'],'cores',d['raw_store_core_labels'])
a,=json.loads((p/'profile-addresses.json').read_text());print('addresses',json.dumps(a,indent=2))
b=(p/'sparse-mqa-metadata.bin').read_bytes();record=json.loads((p/'profile.json').read_text())['target_input']['kwargs']['metadata'];print('metadata',len(b),hashlib.sha256(b).hexdigest(),record)
print('header',struct.unpack_from('<I4xQQQ',b))
print('qheaders',[struct.unpack_from('<II',b,512+i*8) for i in range(4)])
for line in (p/'detail/profile.log').read_text(errors='replace').splitlines():
 if 'processedRecord:' in line:print(line)
PY
echo __SPARSE_MQA_DETAILS_END__
