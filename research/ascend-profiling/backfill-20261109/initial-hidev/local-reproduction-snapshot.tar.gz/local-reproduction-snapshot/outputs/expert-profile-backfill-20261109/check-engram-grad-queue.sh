echo __CHECK_ENGRAM_GRAD_QUEUE_BEGIN__
q=/workspace/expert-profile-backfill-20261109-hidev/extra-engram-grad-app-queue-hidev-npu0
ps -p "$(cat "$q/pid")" -o pid,stat,etime,args || true
tail -n 12 "$q/console.log"
echo __CHECK_ENGRAM_GRAD_QUEUE_END__
