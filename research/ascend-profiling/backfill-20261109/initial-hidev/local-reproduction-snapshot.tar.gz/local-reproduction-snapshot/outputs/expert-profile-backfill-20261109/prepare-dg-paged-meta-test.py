from pathlib import Path
p=Path(__file__).resolve().parent;s=(p/'test-dg-mix-audit.sh').read_text()
for old,new in [('gemm-fp4fp4-nn-mn-m64-n576-k7168','paged-meta-b2-k256-h8-d128-p64'),
                ('audit-deepgemm-mix-general.py','audit-deepgemm-paged-meta.py'),
                ('DG_MIX_AUDIT_TEST','DG_PAGED_META_AUDIT_TEST'),
                ("rows[1]['UB_to_GM_datas(KB)']","rows[0]['UB_to_GM_datas(KB)']")]:
 assert old in s;s=s.replace(old,new)
(p/'test-dg-paged-meta-audit.sh').write_text(s,encoding='utf8',newline='\n')
print('prepared paged metadata negative tests')
