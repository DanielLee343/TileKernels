import base64,hashlib
from pathlib import Path
HERE=Path(__file__).resolve().parent
p=HERE/'run-hidev-deepgemm-smoke-v2.sh';data=p.read_bytes()
script="""#!/usr/bin/env bash
set -Eeo pipefail
root=/workspace/expert-profile-backfill-20261109-hidev
test ! -e \"$root/run-hidev-deepgemm-smoke-v2.sh\"
printf '%s' 'PAYLOAD' | base64 -d > \"$root/run-hidev-deepgemm-smoke-v2.sh\"
printf '%s  %s\\n' HASH \"$root/run-hidev-deepgemm-smoke-v2.sh\" | sha256sum -c
printf '%s\\n' __HIDEV_DEEPGEMM_V2_DONE__
""".replace('PAYLOAD',base64.b64encode(data).decode()).replace('HASH',hashlib.sha256(data).hexdigest())
(HERE/'deploy-deepgemm-v2.sh').write_text(script,encoding='utf-8',newline='\n')
