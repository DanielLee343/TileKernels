echo __RANDN_SMALL_FAILURE_BEGIN__
p=/workspace/expert-profile-backfill-20261109-hidev/extra-proxy-runs/unified-extra2/randn-01/hidev-npu0/attempt-001/detail
python3 - "$p" <<'PY'
import json,sys
from pathlib import Path
p=Path(sys.argv[1]);a=json.loads((p/'application.json').read_text());print('application',a['status'],'shape',a['shape'],'dtype',a['dtype'])
for line in (p/'profile.log').read_text(errors='replace').splitlines():
 if 'processedRecord:' in line:print(line)
PY
echo __RANDN_SMALL_FAILURE_END__
