from pathlib import Path
p=Path(__file__).resolve().parent;s=(p/'summarize-dg-bf16-mgroup.py').read_text(encoding='utf-8')
old="items=json.loads((root/'deepgemm-bf16-mgroup-harness/campaign-13/cases.json').read_text())['cases'];assert len(items)==3"
new="items=[x for x in json.loads((root/'deepgemm-kgroup-harness/campaign-13/cases.json').read_text())['cases'] if x['id'].startswith('kgroup-fp')];assert len(items)==3"
assert old in s;s=s.replace(old,new).replace('deepgemm-bf16-mgroup-index.json','deepgemm-kgroup-quant-index.json')
(p/'summarize-dg-kgroup-quant.py').write_text(s,encoding='utf-8',newline='\n')
s=(p/'index-dg-bf16-mgroup.py').read_text(encoding='utf-8').replace('deepgemm-bf16-mgroup-index.json','deepgemm-kgroup-quant-index.json').replace('deepgemm-bf16-mgroup-audits','deepgemm-kgroup-quant-audits')
(p/'index-dg-kgroup-quant.py').write_text(s,encoding='utf-8',newline='\n')
