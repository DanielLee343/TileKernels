echo __SPARSE_MQA_STORE_BEGIN__
r=/workspace/deepgemm-ascend-20261107/source/deep_gemm/include/deep_gemm
grep -nE 'sparse_mqa_logits_impl|ub2gm|ub_to_gm|logits.index|gm_ptr.*logits' "$r"/*sparse*mqa* 2>/dev/null | tail -n 50
echo __SPARSE_MQA_STORE_END__
