#!/usr/bin/env bash
set -e
echo __INSPECT_DG_MGROUP_SMOKE_BEGIN__
p=/workspace/expert-profile-backfill-20261109-hidev/deepgemm-runs/mgroup-fp8fp8-nt-g4-m128-n256-k512/hidev-npu0/attempt-001
grep 'DBI record core:.*dst:(type:GM;.*src:(type:UB;' "$p/detail/profile.log" | head -15
cat "$p/profile.json" | head -100
echo __INSPECT_DG_MGROUP_SMOKE_END__
