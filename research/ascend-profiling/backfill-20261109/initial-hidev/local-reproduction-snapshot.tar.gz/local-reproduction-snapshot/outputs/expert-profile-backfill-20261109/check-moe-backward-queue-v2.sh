echo __CHECK_MOE_BACKWARD_QUEUE_V2_BEGIN__
q=/workspace/expert-profile-backfill-20261109-hidev/extra-moe-backward-queue-hidev-npu0
ps -p "$(cat "$q/pid-v2")" -o pid,stat,etime,args || true
tail -n 12 "$q/console-v2.log"
echo __CHECK_MOE_BACKWARD_QUEUE_V2_END__
