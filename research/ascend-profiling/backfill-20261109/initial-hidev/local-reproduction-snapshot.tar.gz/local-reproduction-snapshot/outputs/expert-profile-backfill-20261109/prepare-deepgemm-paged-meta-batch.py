"""Stage original paged MQA metadata cases for a first independent smoke."""
import hashlib,json,shutil
from pathlib import Path
p=Path(__file__).resolve().parent;repo=p.parents[1]/'TileKernels-private'
base=repo/'research/ascend-profiling/deepgemm-ascend/campaign-13'
out=p/'deepgemm-paged-meta-harness';campaign=out/'campaign-13';campaign.mkdir(parents=True,exist_ok=True)
src=p/'deepgemm-profile-harness/campaign-13/collect.py';shutil.copyfile(src,campaign/'collect.py')
pilot=out/'pilot-bf16';pilot.mkdir(exist_ok=True);shutil.copyfile(p/'deepgemm-profile-harness/pilot-bf16/collect.py',pilot/'collect.py')
manifest=json.loads((base/'cases-last.json').read_text(encoding='utf-8-sig'))
manifest['cases']=[x for x in manifest['cases'] if x.get('target')=='paged_mqa_logits_metadata_simt_impl'];assert len(manifest['cases'])==8
(campaign/'cases.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf8')
for case in manifest['cases']:
 matches=list((base/'runs').glob('*/'+case['id']+'/profile.json'));assert len(matches)==1,case['id']
 original=matches[0].parent;hist=out/'history'/case['id'];hist.mkdir(parents=True,exist_ok=True)
 for name in ('profile.json','result.json','jit/kernel.asc'):shutil.copyfile(original/name,hist/Path(name).name)
(out/'provenance.json').write_text(json.dumps({'source':'pinned campaign-13 collector with address-only additions',
 'collector_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'source_commit':'3a35326271b069b8b5bf1a754435acd6cc91575b',
 'case_count':8,'scope':'paged MQA metadata only; no collection or address audit yet'},indent=2)+'\n',encoding='utf8')
runner=(p/'run-hidev-deepgemm-transform.sh').read_text()
runner=runner.replace('deepgemm-transform-harness','deepgemm-paged-meta-harness').replace('target=transform_sf','target=paged_mqa_logits_metadata_simt_impl')
old='[[ "$case_id" =~ ^transform-[a-z0-9-]+$ ]] || exit 2'
new='[[ "$case_id" =~ ^paged[-_a-zA-Z0-9]+$ ]] || exit 2'
assert old in runner;runner=runner.replace(old,new)
(p/'run-hidev-deepgemm-paged-meta.sh').write_text(runner,encoding='utf8',newline='\n')
inspector=(p/'inspect-deepgemm-transform.py').read_text().replace('deepgemm-transform-harness','deepgemm-paged-meta-harness')
(p/'inspect-deepgemm-paged-meta.py').write_text(inspector,encoding='utf8',newline='\n')
print('prepared 8 paged metadata cases; no acceptance without actual capture and output audit')
