import base64,hashlib,io,tarfile
from pathlib import Path
p=Path(__file__).resolve().parent
source=Path('D:/puma_v2/TileKernels-private/research/ascend-profiling/runs/hidev-20261106-second/cases')
b=io.BytesIO()
with tarfile.open(fileobj=b,mode='w:gz') as t:
 for i in range(1,21):
  name=f'topk-{i:02d}'
  t.add(source/name/'default-kernel.cpp',arcname=f'{name}/default-kernel.cpp',recursive=False)
data=b.getvalue();encoded=base64.b64encode(data).decode();digest=hashlib.sha256(data).hexdigest()
script=f'''#!/usr/bin/env bash
set -e
root=/workspace/expert-profile-backfill-20261109-hidev
printf '%s' '{encoded}' | base64 -d > "$root/topk-historical-code.tar.gz"
echo '{digest}  '"$root/topk-historical-code.tar.gz" | sha256sum -c
tar -xzf "$root/topk-historical-code.tar.gz" -C "$root/topk-history"
printf '%s\\n' __HIDEV_TOPK_SOURCE_HISTORY_DONE__
'''
(p/'deploy-topk-source-history.sh').write_text(script,encoding='utf8',newline='\n')
for i in range(0,len(encoded),6000):
 chunk=encoded[i:i+6000];part=i//6000
 mode='>' if part==0 else '>>'
 text=f"printf '%s' '{chunk}' {mode} /workspace/expert-profile-backfill-20261109-hidev/topk-history.b64\nprintf '%s\\n' __HIDEV_TOPK_HISTORY_PART_{part}__\n"
 (p/f'deploy-topk-history-part-{part}.sh').write_text(text,encoding='utf8',newline='\n')
finish=f'''set -e
root=/workspace/expert-profile-backfill-20261109-hidev
base64 -d "$root/topk-history.b64" > "$root/topk-historical-code.tar.gz"
echo '{digest}  '"$root/topk-historical-code.tar.gz" | sha256sum -c
tar -xzf "$root/topk-historical-code.tar.gz" -C "$root/topk-history"
printf '%s\\n' __HIDEV_TOPK_SOURCE_HISTORY_DONE__
'''
(p/'deploy-topk-history-finish.sh').write_text(finish,encoding='utf8',newline='\n')
print('archive sha256',digest,'bytes',len(data))
