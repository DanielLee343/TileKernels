from pathlib import Path
p=Path(__file__).resolve().parent;s=(p/'test-castback-audit.sh').read_text()
for old,new in [('quant_cast_back_per_token','quant_cast_back_block'),
                ('audit-extra-castback.py','audit-extra-block-castback.py'),
                ('CASTBACK_AUDIT_TEST','BLOCK_CASTBACK_AUDIT_TEST')]:
 assert old in s;s=s.replace(old,new)
(p/'test-block-castback-audit.sh').write_text(s,encoding='utf8',newline='\n')
print('block cast-back negative tests prepared')
