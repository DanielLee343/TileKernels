from pathlib import Path
p=Path(__file__).resolve().parent
s=(p/'test-engram-gate-fwd-unmasked.sh').read_text()
for old,new in [('engram_gate_fwd-01','engram_gate_fwd-03'),
                ('audit-extra-engram-gate-fwd-unmasked-candidate.py','audit-extra-engram-gate-fwd-mask-candidate.py'),
                ('ENGRAM_GATE_FWD_UNMASKED_TEST','ENGRAM_GATE_FWD_MASK_TEST')]:
 assert old in s,old;s=s.replace(old,new)
needle="echo 'PASS rejects missing records for all five outputs, altered CSV, input/output alias and wrong output shape'"
assert needle in s
replacement='''cp "$tmp/original-addresses.json" "$d/tensor-addresses.json"
python3 - "$d/mask-uint8.bin" <<'PYMASK'
import sys
from pathlib import Path
p=Path(sys.argv[1]);b=bytearray(p.read_bytes());b[0]^=1;p.write_bytes(b)
PYMASK
if run_audit > "$tmp/mask.out" 2>&1;then echo WRONG_MASK_UNDETECTED;exit 1;fi
echo 'PASS rejects missing records for all five outputs, altered CSV, alias, wrong output shape and altered mask' '''
s=s.replace(needle,replacement)
(p/'test-engram-gate-fwd-mask.sh').write_text(s,encoding='utf8',newline='\n')
print('prepared masked-output and mask-hash negative checks')
