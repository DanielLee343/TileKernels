#!/usr/bin/env bash
echo __CHECK_NORM_ROWMAJOR_TESTS_BEGIN__
root=/workspace/expert-profile-backfill-20261109-hidev
ps -p "$(cat "$root/norm-rowmajor-negative-tests.pid")" -o pid,stat,etime,args || true
tail -n 18 "$root/norm-rowmajor-negative-tests.log"
echo __CHECK_NORM_ROWMAJOR_TESTS_END__
