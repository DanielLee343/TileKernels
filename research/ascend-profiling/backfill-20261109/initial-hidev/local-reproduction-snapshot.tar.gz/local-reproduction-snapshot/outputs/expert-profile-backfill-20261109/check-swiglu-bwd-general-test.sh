#!/usr/bin/env bash
echo __CHECK_SWIGLU_BWD_GENERAL_TEST_BEGIN__
r=/workspace/expert-profile-backfill-20261109-hidev
ps -p "$(cat "$r/swiglu-backward-general-test.pid")" -o pid=,stat=,args= || true
tail -n 20 "$r/swiglu-backward-general-test.log"
echo __CHECK_SWIGLU_BWD_GENERAL_TEST_END__
