"""Stage a stateless lossless quant smoke; source-aware audit remains separate."""
from pathlib import Path
p=Path(__file__).resolve().parent
runner=(p/'run-hidev-extra-proxy-detail.sh').read_text()
assert 'test "$group" = quant_per_channel_cast' in runner
runner=runner.replace('test "$group" = quant_per_channel_cast','test "$group" = quant_per_block_cast_lossless')
runner=runner.replace('run-hidev-extra-proxy-detail.sh','run-hidev-extra-lossless-detail.sh')
(p/'run-hidev-extra-lossless-detail.sh').write_text(runner,encoding='utf8',newline='\n')
inspect=(p/'inspect-extra-proxy.py').read_text().replace('stateless per-channel quantization representative','stateless lossless block quantization representative')
old="for key in ('runtime_kernel','inputs','source_sha256'):assert a[key]==old[key],key"
assert old in inspect;inspect=inspect.replace(old,"for key in ('runtime_kernel','inputs'):assert a[key]==old[key],key")
anchor="assert sha(p/'generated-kernel.cpp')==a['source_sha256']"
check=r'''
source=(p/'generated-kernel.cpp').read_bytes();source_comparison='exact'
if a['source_sha256']!=old['source_sha256']:
 current=br'\/workspace\/tilekernels-env-20261101\/src\/TileKernels-private\/tile_kernels\/quant\/per_block_cast_lossless_asc.py:243'
 historical=br'\/workspace\/tilekernels-env-20261101\/src\/TileKernels\/tile_kernels\/quant\/per_block_cast_lossless_asc.py:243'
 assert source.count(current)==1 and historical not in source
 assert hashlib.sha256(source.replace(current,historical)).hexdigest()==old['source_sha256']
 selected=(p/'provenance/selected.txt').read_text().splitlines();assert len(selected)==6
 repo=Path('/workspace/tilekernels-env-20261101/src/TileKernels-private')
 old_log=(repo/selected[4]).parent/'default.log'
 assert '/workspace/tilekernels-env-20261101/src/TileKernels/' in old_log.read_text(errors='replace')
 source_comparison='exact after replacing the single embedded assertion path with the historical checkout path'
'''.strip('\n')
assert anchor in inspect;inspect=inspect.replace(anchor,anchor+'\n'+check)
anchor=" 'replay_note':'initially restricted to the stateless lossless block quantization representative; source-aware audit pending'}"
assert anchor in inspect;inspect=inspect.replace(anchor," 'source_comparison':source_comparison,'historical_source_sha256':old['source_sha256'],\n"+anchor)
(p/'inspect-extra-lossless.py').write_text(inspect,encoding='utf8',newline='\n')
print('prepared lossless smoke; does not assert address coverage')
