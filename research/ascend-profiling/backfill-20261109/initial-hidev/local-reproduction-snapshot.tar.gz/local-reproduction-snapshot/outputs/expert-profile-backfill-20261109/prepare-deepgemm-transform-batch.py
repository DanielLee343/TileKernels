"""Stage frozen transform cases and histories for isolated follow-up captures."""
import hashlib,json,shutil
from pathlib import Path
p=Path(__file__).resolve().parent;repo=p.parents[1]/'TileKernels-private'
base=repo/'research/ascend-profiling/deepgemm-ascend/campaign-13'
out=p/'deepgemm-transform-harness';campaign=out/'campaign-13';campaign.mkdir(parents=True,exist_ok=True)
src=p/'deepgemm-profile-harness/campaign-13/collect.py';shutil.copyfile(src,campaign/'collect.py')
pilot=out/'pilot-bf16';pilot.mkdir(exist_ok=True);shutil.copyfile(p/'deepgemm-profile-harness/pilot-bf16/collect.py',pilot/'collect.py')
manifest=json.loads((base/'cases-last.json').read_text(encoding='utf-8-sig'))
manifest['cases']=[x for x in manifest['cases'] if x.get('target')=='transform_sf'];assert len(manifest['cases'])==14
(campaign/'cases.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf8')
for case in manifest['cases']:
 matches=list((base/'runs').glob('*/'+case['id']+'/profile.json'));assert len(matches)==1,case['id']
 original=matches[0].parent;hist=out/'history'/case['id'];hist.mkdir(parents=True,exist_ok=True)
 for name in ('profile.json','result.json','jit/kernel.asc'):
  target=hist/Path(name).name;shutil.copyfile(original/name,target)
(out/'provenance.json').write_text(json.dumps({'source':'frozen campaign-13 collector with address-only additions',
 'collector_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'source_commit':'3a35326271b069b8b5bf1a754435acd6cc91575b',
 'case_count':len(manifest['cases'])},indent=2)+'\n',encoding='utf8')
runner=(p/'run-hidev-deepgemm-smoke-v3.sh').read_text()
start=runner.index('case "$case_id" in\n');end=runner.index('\nunset LD_LIBRARY_PATH',start)
runner=runner[:start]+'''[[ "$case_id" =~ ^transform-[a-z0-9-]+$ ]] || exit 2
target=transform_sf'''+runner[end:]
runner=runner.replace('deepgemm-profile-harness','deepgemm-transform-harness')
runner=runner.replace('guard-v4.py','guard-v6.py')
(p/'run-hidev-deepgemm-transform.sh').write_text(runner,encoding='utf8',newline='\n')
inspector=(p/'inspect-deepgemm-capture.py').read_text().replace("harness=root/'deepgemm-profile-harness'","harness=root/'deepgemm-transform-harness'")
(p/'inspect-deepgemm-transform.py').write_text(inspector,encoding='utf8',newline='\n')
print('prepared',len(manifest['cases']),'pinned transform cases, not run')
