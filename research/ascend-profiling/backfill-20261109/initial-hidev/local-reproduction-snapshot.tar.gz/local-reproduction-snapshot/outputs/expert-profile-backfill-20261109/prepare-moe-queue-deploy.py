import base64,hashlib,io,tarfile
from pathlib import Path
p=Path(__file__).resolve().parent;b=io.BytesIO()
with tarfile.open(fileobj=b,mode='w:gz') as t:
 for name in ('hidev-moe-backward-queue.py','test-moe-backward-audit.sh'):t.add(p/name,arcname=name)
data=b.getvalue();encoded=base64.b64encode(data).decode();sha=hashlib.sha256(data).hexdigest()
for i in range(0,len(encoded),5500):
 part=i//5500;mode='>' if part==0 else '>>'
 (p/f'deploy-moe-queue-part-{part}.sh').write_text(f"printf '%s' '{encoded[i:i+5500]}' {mode} /workspace/expert-profile-backfill-20261109-hidev/moe-queue-deploy.b64\necho __MOE_QUEUE_PART_{part}__\n",encoding='utf-8',newline='\n')
script=f'''set -e
echo __DEPLOY_MOE_QUEUE_BEGIN__
r=/workspace/expert-profile-backfill-20261109-hidev
base64 -d "$r/moe-queue-deploy.b64" > "$r/moe-queue-deploy.tar.gz"
printf '%s  %s\\n' {sha} "$r/moe-queue-deploy.tar.gz" | sha256sum -c
test ! -e "$r/hidev-moe-backward-queue.py"
test ! -e "$r/test-moe-backward-audit.sh"
tar -xzf "$r/moe-queue-deploy.tar.gz" -C "$r"
bash "$r/test-moe-backward-audit.sh" > "$r/moe-backward-audit-test.log" 2>&1
grep -q 'PASS rejects missing store, altered per-core CSV and input/output alias' "$r/moe-backward-audit-test.log"
echo __DEPLOY_MOE_QUEUE_END__
'''
(p/'deploy-moe-queue-finish.sh').write_text(script,encoding='utf-8',newline='\n')
print('parts',(len(encoded)+5499)//5500)
