#!/usr/bin/env bash
set -e
echo __INSPECT_DG_SLEEP_SOURCE_BEGIN__
src=/workspace/deepgemm-ascend-20261107/source
git -C "$src" rev-parse HEAD
find "$src" -path '*/deep_gemm/sleep.hpp' -type f -print -exec cat {} \;
echo __INSPECT_DG_SLEEP_SOURCE_END__
