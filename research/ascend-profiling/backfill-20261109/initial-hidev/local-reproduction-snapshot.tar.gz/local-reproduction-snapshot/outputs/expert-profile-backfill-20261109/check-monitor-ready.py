"""Read-only NPU 4 monitor gate, using the same 3-second safety bound."""
import json,re,subprocess,sys,time
from datetime import datetime,timezone
records=[];last=None
for i in range(30):
    start=time.monotonic()
    try:
        p=subprocess.run(['npu-smi','info','-t','proc-mem','-i','4'],capture_output=True,text=True,timeout=3)
        end=time.monotonic(); pids=re.findall(r'Process id:\s*(\d+)',p.stdout,re.I)
        rec={'i':i,'utc':datetime.now(timezone.utc).isoformat(),'elapsed':end-start,'gap':None if last is None else end-last,
             'returncode':p.returncode,'pids':pids,'stdout':p.stdout,'stderr':p.stderr}
        records.append(rec)
        if p.returncode or pids or (not pids and 'No process in device.' not in p.stdout) or (last is not None and end-last>3):break
        last=end;time.sleep(.5)
    except subprocess.TimeoutExpired:
        records.append({'i':i,'utc':datetime.now(timezone.utc).isoformat(),'error':'query timeout after 3 s'});break
result={'passed':len(records)==30 and all(r.get('returncode')==0 and not r.get('pids') and (r.get('gap') is None or r['gap']<=3) for r in records),'records':records,
        'limitation':'sampled checks only; does not establish exclusive use'}
print(json.dumps(result,indent=2));sys.exit(not result['passed'])
