#!/usr/bin/env bash
echo __MOE_BACKWARD_DETAIL_BEGIN__
p=/workspace/expert-profile-backfill-20261109-hidev/extra-proxy-runs/unified-extra4/moe_topk_gate_backward-01/hidev-npu0/attempt-001/detail
python3 - "$p" <<'PY'
import json,sys
from pathlib import Path
p=Path(sys.argv[1]);a=json.loads((p/'tensor-addresses.json').read_text())
for i,t in enumerate(a):print(i,json.dumps(t))
print('SOURCE STORES')
s=(p/'generated-kernel.cpp').read_text()
for n,line in enumerate(s.splitlines(),1):
 if 'asc_copy_ub2gm' in line or 'out_base' in line:print(n,line)
print('STORE SAMPLES')
count=0
for line in (p/'profile.log').read_text(errors='replace').splitlines():
 if 'DBI record core:' in line and 'dst:(type:GM;' in line and 'src:(type:UB;' in line:
  print(line);count+=1
  if count==3:break
PY
echo __MOE_BACKWARD_DETAIL_END__
