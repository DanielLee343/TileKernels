from pathlib import Path
p=Path(__file__).resolve().parent
a=(p/'audit-dg-bf16-mgroup-candidate.py').read_text();old="str(p/'candidate-address-audit.json')";assert old in a
(p/'audit-dg-bf16-mgroup-batch.py').write_text(a.replace(old,"str(p/'address-audit.json')"),encoding='utf8',newline='\n')
s=(p/'hidev-dg-mgroup-queue.py').read_text()
for old,new in [('deepgemm-mgroup-queue','deepgemm-bf16-mgroup-queue'),('deepgemm-mgroup-harness','deepgemm-bf16-mgroup-harness'),
                ('assert len(items)==6','assert len(items)==3'),('fp8_gemm_impl','bf16_gemm_impl'),
                ('run-hidev-deepgemm-mgroup.sh','run-hidev-deepgemm-bf16-mgroup.sh'),
                ('inspect-deepgemm-mgroup.py','inspect-deepgemm-bf16-mgroup.py'),
                ('audit-deepgemm-mgroup-batch.py','audit-dg-bf16-mgroup-batch.py'),
                ('ALL_DG_MGROUP_SELECTED_AUDITED','ALL_DG_BF16_MGROUP_SELECTED_AUDITED')]:
 assert old in s,old;s=s.replace(old,new)
(p/'hidev-dg-bf16-mgroup-queue.py').write_text(s,encoding='utf8',newline='\n')
print('prepared remaining BF16 grouped cases with independent gates')
