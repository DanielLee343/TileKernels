echo __SPARSE_STRIDE_CONTRACT_BEGIN__
sed -n '245,265p' /workspace/deepgemm-ascend-20261107/source/deep_gemm/include/deep_gemm/sparse_mqa_logits.hpp
sed -n '335,375p' /workspace/deepgemm-ascend-20261107/source/deep_gemm/include/deep_gemm/sparse_mqa_logits_metadata.hpp
echo __SPARSE_STRIDE_CONTRACT_END__
