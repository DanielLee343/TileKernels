#!/usr/bin/env bash
echo __CHECK_NORM_BACKWARD_NOWEIGHT_CANDIDATES_BEGIN__
r=/workspace/expert-profile-backfill-20261109-hidev
ps -p "$(cat "$r/norm-backward-noweight-candidates.pid")" -o pid=,stat=,args= || true
tail -n 15 "$r/norm-backward-noweight-candidates.log"
echo __CHECK_NORM_BACKWARD_NOWEIGHT_CANDIDATES_END__
