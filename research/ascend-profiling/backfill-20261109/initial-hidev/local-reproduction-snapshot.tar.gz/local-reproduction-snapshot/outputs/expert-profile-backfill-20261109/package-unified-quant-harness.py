import base64,hashlib,io,tarfile
from pathlib import Path
p=Path(__file__).resolve().parent;b=io.BytesIO()
with tarfile.open(fileobj=b,mode='w:gz') as t:
 t.add(p/'unified-quant-harness',arcname='unified-quant-harness')
 t.add(p/'run-hidev-unified-quant-detail.sh',arcname='run-hidev-unified-quant-detail.sh')
data=b.getvalue();encoded=base64.b64encode(data).decode();digest=hashlib.sha256(data).hexdigest()
for i in range(0,len(encoded),6000):
 part=i//6000;mode='>' if part==0 else '>>'
 (p/f'deploy-unified-quant-part-{part}.sh').write_text(f"printf '%s' '{encoded[i:i+6000]}' {mode} /workspace/expert-profile-backfill-20261109-hidev/unified-quant-deploy.b64\nprintf '%s\\n' __HIDEV_UQ_PART_{part}__\n",encoding='utf8',newline='\n')
script=f'''set -e
root=/workspace/expert-profile-backfill-20261109-hidev
base64 -d "$root/unified-quant-deploy.b64" > "$root/unified-quant-deploy.tar.gz"
echo '{digest}  '"$root/unified-quant-deploy.tar.gz" | sha256sum -c
test -d "$root/unified-quant-harness"
test ! -e "$root/unified-quant-harness-before-root-fix"
cp -a "$root/unified-quant-harness" "$root/unified-quant-harness-before-root-fix"
cp "$root/run-hidev-unified-quant-detail.sh" "$root/run-hidev-unified-quant-detail-before-root-fix.sh"
tar -xzf "$root/unified-quant-deploy.tar.gz" -C "$root"
printf '%s\\n' __HIDEV_UQ_DEPLOY_DONE__
'''
(p/'deploy-unified-quant-finish.sh').write_text(script,encoding='utf8',newline='\n')
print('archive',len(data),'parts',(len(encoded)+5999)//6000,'sha256',digest)
