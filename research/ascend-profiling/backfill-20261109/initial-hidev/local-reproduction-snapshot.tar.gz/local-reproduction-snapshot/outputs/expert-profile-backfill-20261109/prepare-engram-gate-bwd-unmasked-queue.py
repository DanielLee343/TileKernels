from pathlib import Path
p=Path(__file__).resolve().parent
s=(p/'prepare-engram-gate-fwd-unmasked-queue.py').read_text()
s=s.replace('engram-gate-fwd','engram-gate-bwd').replace('engram_gate_fwd','engram_gate_bwd').replace('ENGRAM_GATE_FWD','ENGRAM_GATE_BWD')
exec(compile(s,str(p/'prepare-engram-gate-fwd-unmasked-queue.py'),'exec'))
