"""Prepare lossless block output-address candidate; verify on device evidence."""
from pathlib import Path
p=Path(__file__).resolve().parent;s=(p/'audit-extra-channel.py').read_text()
for old,new in [('quant_per_channel_cast-', 'quant_per_block_cast_lossless-'),
                ('assert len(a)==4 and a[1] and a[2]', 'assert len(a)==4 and a[2] and a[3]'),
                ('a[1:3]', 'a[2:4]')]:
 assert old in s;s=s.replace(old,new)
(p/'audit-extra-lossless.py').write_text(s,encoding='utf8',newline='\n')
print('lossless candidate prepared; requires negative tests')
