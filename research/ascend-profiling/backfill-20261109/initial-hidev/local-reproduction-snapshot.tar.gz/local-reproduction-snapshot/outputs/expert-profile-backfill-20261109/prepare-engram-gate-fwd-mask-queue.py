from pathlib import Path
p=Path(__file__).resolve().parent
a=(p/'audit-extra-engram-gate-fwd-mask-candidate.py').read_text();old="p/'candidate-audit-result.json'";assert old in a
(p/'audit-extra-engram-gate-fwd-mask.py').write_text(a.replace(old,"p/'audit-result.json'"),encoding='utf8',newline='\n')
r=(p/'run-hidev-extra-engram-gate-fwd-mask.sh').read_text()
old='test "$group" = engram_gate_fwd; test "$target" = unified-extra5/engram_gate_fwd-03'
new='''test "$group" = engram_gate_fwd
python3 - "$root/extra-proxy-mask-harness/cases.json" "$target" <<'PYCHECK'
import json,sys
with open(sys.argv[1]) as f:d=json.load(f)
selected,=(x for x in d['cases'] if x['target_id']==sys.argv[2]);assert selected['group']=='engram_gate_fwd' and selected['params']['with_mask']
PYCHECK'''
assert old in r;r=r.replace(old,new)
r=r.replace('$root/run-hidev-extra-engram-gate-fwd-mask.sh','$root/run-hidev-extra-engram-gate-fwd-mask-batch.sh')
needle='"$root/extra-proxy-mask-harness/provenance.json"';assert needle in r;r=r.replace(needle,needle+' "$root/extra-proxy-mask-harness/mask-instrumentation.json"')
(p/'run-hidev-extra-engram-gate-fwd-mask-batch.sh').write_text(r,encoding='utf8',newline='\n')
i=(p/'inspect-extra-engram-gate-fwd-mask.py').read_text();old="assert target=='unified-extra5/engram_gate_fwd-03'"
assert old in i;i=i.replace(old,"assert target.startswith('unified-extra5/engram_gate_fwd-')")
(p/'inspect-extra-engram-gate-fwd-mask-batch.py').write_text(i,encoding='utf8',newline='\n')
s=(p/'hidev-extra-engram-gate-fwd-unmasked-queue.py').read_text()
for old,new in [('extra-engram-gate-fwd-unmasked-queue','extra-engram-gate-fwd-mask-queue'),
                ("and not x['params']['with_mask']","and x['params']['with_mask']"),
                ('run-hidev-extra-engram-gate-fwd-unmasked.sh','run-hidev-extra-engram-gate-fwd-mask-batch.sh'),
                ('inspect-extra-engram-gate-fwd.py','inspect-extra-engram-gate-fwd-mask-batch.py'),
                ('audit-extra-engram-gate-fwd-unmasked.py','audit-extra-engram-gate-fwd-mask.py'),
                ('ALL_ENGRAM_GATE_FWD_UNMASKED_SELECTED_AUDITED','ALL_ENGRAM_GATE_FWD_MASK_SELECTED_AUDITED')]:
 assert old in s,old;s=s.replace(old,new)
(p/'hidev-extra-engram-gate-fwd-mask-queue.py').write_text(s,encoding='utf8',newline='\n')
print('prepared ten masked cases with bound input masks and conditional output coverage')
