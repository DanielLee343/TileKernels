from pathlib import Path
p=Path(__file__).resolve().parent;s=(p/'test-norm-accum-app08-audit.sh').read_text(encoding='utf-8')
for old,new in (
 ('__NORM_ACCUM_APP08_AUDIT_TEST_','__ENGRAM_GRAD_AUDIT_TEST_'),
 ('norm-accum-app-audit-test.','engram-grad-audit-test.'),
 ('unified-extra3/quant_norm_backward-08','unified-extra/engram_grad_w_reduce-01'),
 ('audit-extra-norm-accum-app-08-candidate.py','audit-engram-grad-app-candidate.py'),
 ('quant_norm_backward-08','engram_grad_w_reduce-01'),
 ('for index in 4 5 7;do','for index in 3 4;do'),
 ("a[4]['address']=a[0]['address']", "a[3]['address']=a[0]['address']"),
):
 assert old in s,old;s=s.replace(old,new)
(p/'test-engram-grad-app-audit.sh').write_text(s,encoding='utf-8',newline='\n')
