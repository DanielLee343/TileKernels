from pathlib import Path
p=Path(__file__).resolve().parent
s=(p/'test-swiglu-backward-general.sh').read_text()
for old,new in [('quant_swiglu_backward-07','engram_gate_fwd-01'),('unified-extra4','unified-extra5'),
                ('audit-extra-swiglu-backward-general-candidate.py','audit-extra-engram-gate-fwd-unmasked-candidate.py'),
                ('for index in 6 7 8 9 10','for index in 4 5 6 7 8'),
                ("a[9]['address']=a[0]['address']","a[4]['address']=a[0]['address']"),
                ("a[8]['shape'][-1]//=2","a[5]['shape'][-1]//=2"),
                ('SWIGLU_BACKWARD_GENERAL_TEST','ENGRAM_GATE_FWD_UNMASKED_TEST'),
                ('WRONG_SCALE_SHAPE','WRONG_OUTPUT_SHAPE'),('wrong scale shape','wrong output shape')]:
 assert old in s,old;s=s.replace(old,new)
(p/'test-engram-gate-fwd-unmasked.sh').write_text(s,encoding='utf8',newline='\n')
print('prepared tests for all five unmasked outputs')
