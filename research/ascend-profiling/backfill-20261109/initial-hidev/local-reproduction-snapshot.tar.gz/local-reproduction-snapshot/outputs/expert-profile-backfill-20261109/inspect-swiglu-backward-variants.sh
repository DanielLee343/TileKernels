#!/usr/bin/env bash
echo __INSPECT_SWIGLU_BACKWARD_VARIANTS_BEGIN__
r=/workspace/expert-profile-backfill-20261109-hidev
python3 - "$r" <<'PY'
import json,sys,re
from pathlib import Path
r=Path(sys.argv[1])/'extra-proxy-runs/unified-extra4'
for n in ('13','12','07','08'):
 p=r/('quant_swiglu_backward-'+n)/'hidev-npu0/attempt-001/detail';print('\n###',n)
 print('params',json.loads((p/'application.json').read_text())['params'])
 for i,a in enumerate(json.loads((p/'tensor-addresses.json').read_text())):print('arg',i,a)
 for x in (p/'generated-kernel.cpp').read_text().splitlines():
  if 'asc_copy_ub2gm_align(' in x:
   dst=x.split('(__ubuf__',1)[0]; m=re.search(r'\(&\((?:\(\([^)]*\)\s*)?([a-zA-Z_]\w*)\s*\)?\[',dst);print('store',m.group(1) if m else dst[:180])
PY
echo __INSPECT_SWIGLU_BACKWARD_VARIANTS_END__
