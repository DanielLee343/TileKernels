# 专家 profiling 缺口补采

目标是补齐已登记专家 case 缺失的采集或数值。执行人为「GCM筛查」，主会话核对原始数据、回填状态和剩余缺口。本轮只处理 profiling。规则卡、阈值和 GCM 仍冻结。 [数据盘点](专家profiling数据盘点-20261109.md)

当前采集现场为 HiDev 950PR，28 Cube / 56 Vector。4 个 MegaMoE case 采用用户授权的 28 核适配实现，固定上游版本另存历史。用户确认采集后归档到公开仓 `DanielLee343/TileKernels`，再按 Vector、Cube、CV融合三张工作表汇总到一个 Excel。 [实时台账](../outputs/expert-profile-backfill-20261109/PROGRESS.md) · [工作簿验收](../outputs/expert-profiling-workbook-20261110/plan.md)

## 已知缺口

| 数据集 | 缺整份 Default | 缺可核验的逐核 AIV 搬出字节 |
|---|---|---|
| TileKernels 主归档 | 0。50 个计划组各有 20 个 case，RoPE 的 Q/K 均在。13 个有精度标签，保留原状态。 | 最近一次台账：1,020 个目标中 622 个已对账，40 个不适用，358 个待核（含 13 个原精度标签）。采集中会继续变化；应用重放采集窗口单独标注。 |
| DeepGEMM-Ascend 原版 | **4 个 `mega_moe_impl`**，ID 见下。 | 120 个含 AIV 的目标中 76 个已对账、12 个待核，32 个经二进制核查该字段不适用（其中 16 个有 SIMT／标量主存写入，12 个由 Cube 搬出结果）；另 34 个纯 Cube 目标不适用。 |
| 早期 TileKernels | 140 份已有 Default。 | 逐目标拆分后 1 个已对账、118 个待核；旧 Sinkhorn 批只作参考，正式验证须用同口径新数据。 |
| DeepGEMM MegaMoE 28 核适配 | 4 个 case 已有 Default，按适配实现单独归档。 | 4 个独立 DBI 采集窗口的预期地址覆盖已核，重复写入总量是否完整仍未证实；其他 PMU 重放失败。 |

`mega_moe_impl` 的四个计划 case 为 `mega-h256-i512-e4-top2-t16`、`mega-h256-i512-e4-top2-t64`、`mega-h512-i1024-e8-top4-t64`、`mega-h512-i512-e8-top2-t32`。DeepGEMM-Ascend 固定上游提交 `3a35326` 的入口要求 32 个 Cube 核，采集以当前 HiDev 能运行的 28 核适配版为准。FP4 FIRST 已有通过校验的 range replay 数据，单列采集口径。 [DeepGEMM 采集状态](../TileKernels-private/research/ascend-profiling/deepgemm-ascend/campaign-13/STATUS.md)

[主归档逐 case 缺口](../outputs/expert-profile-backfill-20261109/main-baseline-gaps.csv)包含 1,121 个目标。1,117 个需要核对逐核搬出字段，4 个缺原版采集。名单逐项列出 kernel 名、case、历史标签和原 profile 路径。是否可采和是否适用以现场回填为准。

## 给执行人的任务

1. **离线生成逐项清单。** 以 [采集索引](../outputs/expert-profile-inventory-20261109/captures.csv)、TileKernels 计划及 DeepGEMM 的 `cases*.json` 为输入。按 case 与目标 kernel 去重，核对现有日志能否补列。逐项标记已有、待补、只缺字段、不适用、正确性未过、无法复现。原始 CSV 和补采日志证据分列。核对 23 个 mHC 已完成的日志对账，复用其结果。
2. **先实测采集链。** 使用 `ssh tbe` 和已有环境，用户已允许 NPU 3 或 4。优先检查卡 3，按实时空闲状态选择。核对卡映射、空闲、空间、CANN、工具构建、源码提交。卡号、设备锁、可见设备和进程保护须一致。选尚缺字段的普通 TileKernels Vector、与 mHC 不同的访问方式、DeepGEMM 纯 Vector 和混合各代表一个。先用原用例参数和固定输入做正确性检查。采集 `--aic-metrics=MemoryDetail,Default`，保留 `MSOPT_LOG_LEVEL=0` 日志。状态型 kernel 延用已验证的 replay 模式。仅缺字段时保留历史 Default，并单独保存本次采集窗口。确需本机同窗口的基准或对账，再另采 Default。
3. **按已跑通的类型分批补齐。** 覆盖全部可复现的待补项。先测耗时和日志量，限制单次运行与磁盘占用，按批保留可恢复进度。失败按根因归类。代表 case 出现同一采集缺陷时，先验证通用修复再恢复该类。原实现与正确性要求固定，失败或待验证的样本保留标签。现场不具备运行条件的，记录 case、具体原因和可复现证据。确认有搬出且采集器无法测到的标「缺失」。有证据确认该侧没有目标操作的标「不适用」或有依据的零。
4. **逐字段验收。** 对齐目标 kernel、输入规格及可用哈希、生成代码或二进制、核角色和逐核行。保留原始表、日志、工具及板卡信息、命令、采集方式和哈希。若 `Memory.csv` 只给两核合计，按动态请求及地址归属复算逐核 UB→GM 请求字节，并与合法输出或已知请求对账。对 4 个相关带宽或利用率字段，只有能核对工具公式、分子、同窗口分母与逐核归属，才另列为可复算值。保留原始字段状态，缺值和不适用分别计数。
5. **交付与汇报。** 本地输出放到 `outputs/expert-profile-backfill-20261109/`，当前远端原始采集放 hidev 的独立任务目录。提交逐项缺口和状态 CSV、原始采集索引、字段覆盖变化、日志恢复脚本和复算结果。先回报首批代表 case 和预计余量。其后按实际成功、失败、阻塞或不适用更新，直至可执行项跑完。长批次用可恢复队列和持久化状态，主会话以逐项结果验收。既有归档及原 CSV 保持原样。

## TODO

- [x] 主会话核对已登记计划和初始缺口。
- [x] 向「GCM筛查」下发采集任务和验收口径。
- [x] 执行人生成[逐项清单](../outputs/expert-profile-backfill-20261109/targets.csv)，共 1,301 行。早期 20 个 RoPE case 按两次调用拆成 40 行。主会话复核这 40 行，以及 1,121 个主归档缺口的目标键和状态。
- [x] 在 tbe 卡 3 完成首例 `engram_sinkhorn_step_reduce/01`。主会话从原始日志复算 4 个向量 block 各 1,024 B，合计 4,096 B，与两行 CSV 合计及输出地址覆盖一致。 [首例审计](../outputs/expert-profile-backfill-20261109/reduce-01-audit.json)
- [ ] 核对早期记录可复用项，完成现场采集链试测。 [现场进度](../outputs/expert-profile-backfill-20261109/PROGRESS.md)
- [ ] 分批补采，逐项登记终态及证据。
- [ ] 在 28 Cube / 56 Vector 适配实现上补采 MegaMoE 4 个计划 case；与原版 32 Cube 要求、历史 range replay 分开。四例独立 DBI 轮的正确性、工作区与最终输出预期地址覆盖均通过；是否遗漏对已覆盖地址的重复写入仍未证明，其他 PMU 重放失败，尚不标完整对账。 [进度](../outputs/expert-profile-backfill-20261109/PROGRESS.md)
- [ ] 主会话复核新增采集、实际字段覆盖和剩余阻塞，回填数据盘点。
- [ ] 归档本轮原始 CSV、日志、环境、源码绑定、正确性、对账及失败／不适用证据，逐份校验恢复，推送到用户确认的公开 `DanielLee343/TileKernels`，记录分支、提交和索引；不覆盖原归档。
  - 已推阶段性快照至 `expert-profile-backfill-20261109` 分支，最新提交 `d45c862111fd6de39d0477b75757cbee4de1916d`；包含 `runs`、`mhc-runs`、`fused-runs`、`topk-runs`、`hash-runs`、`classic-runs`、`mega28-runs`、`unified-quant-runs`、`deepgemm-runs` 及 `extra-proxy-runs` 下 `unified-extra`、`extra2`、`extra3`、`extra4`、`extra5` 当时存在的采集目录，Norm／MoE backward、MQA、K-group、非分页 sparse MQA、普通及 pilot GEMM 后续快照，分页 sparse 失败试采、实际运行脚本版本证据、1,089 份脚本／适配器等支持文件、复验工具和台账快照；其余原始数据尚未全部上传。

## 当前进度与待处理问题

按用户最新要求，采集已切到 hidev，并先完成旧 case 的同口径对照。当前逐项状态以 [清单](../outputs/expert-profile-backfill-20261109/targets.csv) 和 [进度](../outputs/expert-profile-backfill-20261109/PROGRESS.md) 为准；不以历史 tbe 状态代替当前运行状态。Hash 的部分大输入遇到工具地址记录丢失，暂缓同类大输入，保留日志并待定位；其他已验证的算子类型继续分批采集。规则卡、阈值和 GCM 仍冻结。

## 历史 tbe 现场记录

`engram_sinkhorn_step_reduce/01` 在 tbe 卡 4 试采 3 次，均在设备进程查询超过 3 秒后由保护程序中止。第三次试采前的 30 次空闲查询通过，但采集过程中仍复现超时。三次均无可验收的新 profile，批量待首例通过后启动。DeepGEMM 主机扩展已隔离构建并成功导入，设备端试采待验证。 [现场进度](../outputs/expert-profile-backfill-20261109/PROGRESS.md) · [试采记录](../outputs/expert-profile-backfill-20261109/attempts.csv)

21:03 复查。三次现场命令均通过 `ssh tbe` 启动。板卡记录均为 NPU 4、PCIe `0000:D3:00.0`。三次原始异常均为保护脚本运行 `npu-smi info -t proc-mem -i 4` 时抛出 `subprocess.TimeoutExpired`。3 秒是保护脚本设的单次查询时限。这个异常只说明查询未按时返回，无法判断当时设备占用或 kernel 执行结果。主会话直接 SSH 检查时，卡 3 和卡 4 均为 `Health OK`。21:03:23 卡 3 无进程，卡 4 有 Python 进程，查询分别用时 0.10 秒和 0.08 秒。此状态只代表检查时刻。 [现场保护脚本](../outputs/expert-profile-backfill-20261109/tbe-evidence/reduce-01/attempt-003/detail/provenance/guard.py)

复核时两个旧验证脚本重写了各自的 `verification.json`。原始采集未改，重写前后没有哈希对照。 [操作记录](../outputs/expert-profile-backfill-20261109/PROGRESS.md)

用户允许使用 tbe 卡 3 或 4 后，「GCM筛查」已在卡 3 恢复试采。首例采集及逐核字节对账通过，已登记到 `targets.csv`。同一类剩余 19 个 case 的队列已在本地准备。上传时 SSH 连接中断，主会话复查仍被拒绝，队列尚未在远端启动。恢复连接后先确认远端状态，再部署队列。 [现场进度](../outputs/expert-profile-backfill-20261109/PROGRESS.md)
