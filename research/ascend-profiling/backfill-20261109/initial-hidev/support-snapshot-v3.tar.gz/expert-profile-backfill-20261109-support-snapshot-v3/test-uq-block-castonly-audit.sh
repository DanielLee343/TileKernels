#!/usr/bin/env bash
set -Eeuo pipefail
printf '%s\n' __UQ_BLOCK_CASTONLY_AUDIT_TEST_BEGIN__
root=/workspace/expert-profile-backfill-20261109-hidev
tmp=$(mktemp -d "$root/quant-audit-test.XXXXXXXX")
trap 'rm -rf -- "$tmp"' EXIT
base=unified-quant-runs/quant_per_block_cast_with_precomputed_sf-01/hidev-npu0/attempt-001
mkdir -p "$tmp/$(dirname "$base")"
cp -a "$root/$base" "$tmp/$base"
cp "$root/audit-reduce-family.py" "$tmp/"
export BACKFILL_ROOT="$tmp"
python3 -B "$root/audit-uq-block-castonly.py" quant_per_block_cast_with_precomputed_sf-01 attempt-001
detail="$tmp/$base/detail";cp "$detail/profile.log" "$tmp/original-profile.log"
python3 - "$detail/profile.log" <<'PY'
from pathlib import Path
import sys
p=Path(sys.argv[1]);lines=p.read_text().splitlines(keepends=True)
i=next(i for i,s in enumerate(lines) if 'DBI record core:' in s and 'dst:(type:GM;' in s and 'src:(type:UB;' in s)
del lines[i];p.write_text(''.join(lines))
PY
if python3 -B "$root/audit-uq-block-castonly.py" quant_per_block_cast_with_precomputed_sf-01 attempt-001 > "$tmp/missing.out" 2>&1;then echo MISSING_RECORD_UNDETECTED;exit 1;fi
cp "$tmp/original-profile.log" "$detail/profile.log"
mem=$(find "$detail/capture" -name Memory.csv -print -quit)
python3 - "$mem" <<'PY'
from pathlib import Path
import csv,io,sys
p=Path(sys.argv[1]);text=p.read_text(encoding='utf-8-sig');r=csv.DictReader(io.StringIO(text));rows=list(r)
rows[0]['UB_to_GM_datas(KB)']=str(float(rows[0]['UB_to_GM_datas(KB)'])+1)
with p.open('w',encoding='utf8',newline='') as f:
 w=csv.DictWriter(f,fieldnames=r.fieldnames);w.writeheader();w.writerows(rows)
PY
if python3 -B "$root/audit-uq-block-castonly.py" quant_per_block_cast_with_precomputed_sf-01 attempt-001 > "$tmp/csv.out" 2>&1;then echo WRONG_CSV_UNDETECTED;exit 1;fi
echo 'PASS rejects missing store and altered per-core CSV'
printf '%s\n' __UQ_BLOCK_CASTONLY_AUDIT_TEST_END__
