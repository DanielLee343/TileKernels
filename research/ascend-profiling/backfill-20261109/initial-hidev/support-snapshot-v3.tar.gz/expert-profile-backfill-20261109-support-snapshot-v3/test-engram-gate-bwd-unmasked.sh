#!/usr/bin/env bash
set -Eeuo pipefail
echo __ENGRAM_GATE_BWD_UNMASKED_TEST_BEGIN__
root=/workspace/expert-profile-backfill-20261109-hidev
tmp=$(mktemp -d "$root/swiglu-bwd-general-audit-test.XXXXXXXX")
trap 'rm -rf -- "$tmp"' EXIT
base=extra-proxy-runs/unified-extra5/engram_gate_bwd-01/hidev-npu0/attempt-001
mkdir -p "$tmp/$(dirname "$base")";cp -a "$root/$base" "$tmp/$base"
cp "$root/audit-reduce-family.py" "$tmp/";export BACKFILL_ROOT="$tmp"
audit="$root/audit-extra-engram-gate-bwd-unmasked-candidate.py"
run_audit(){ python3 -B "$audit" engram_gate_bwd-01 attempt-001; }
run_audit
d="$tmp/$base/detail";cp "$d/profile.log" "$tmp/original.log";cp "$d/tensor-addresses.json" "$tmp/original-addresses.json"
mem=$(find "$d/capture" -name Memory.csv -print -quit);cp "$mem" "$tmp/original-memory.csv"
for index in 9 10 11;do
 cp "$tmp/original.log" "$d/profile.log"
 python3 - "$d/profile.log" "$d/tensor-addresses.json" "$index" <<'PY'
from pathlib import Path
import json,re,sys
p=Path(sys.argv[1]);a=json.loads(Path(sys.argv[2]).read_text());t=a[int(sys.argv[3])];lo=int(t['address'],16);hi=lo+t['logical_bytes'];lines=p.read_text().splitlines(keepends=True)
for i,s in enumerate(lines):
 m=re.search(r'DBI record core:.*dst:\(type:GM;addr:(0x[0-9a-f]+)',s)
 if m and lo<=int(m.group(1),16)<hi:del lines[i];break
else:raise RuntimeError('no output store for arg '+sys.argv[3])
p.write_text(''.join(lines))
PY
 if run_audit > "$tmp/missing-$index.out" 2>&1;then echo "MISSING_OUTPUT_${index}_UNDETECTED";exit 1;fi
done
cp "$tmp/original.log" "$d/profile.log"
python3 - "$mem" <<'PY'
import csv,io,sys
from pathlib import Path
p=Path(sys.argv[1]);r=csv.DictReader(io.StringIO(p.read_text(encoding='utf-8-sig')));rows=list(r)
row=next(x for x in rows if x['UB_to_GM_datas(KB)'] not in ('NA',''));row['UB_to_GM_datas(KB)']=str(float(row['UB_to_GM_datas(KB)'])+1)
with p.open('w',encoding='utf8',newline='') as f:w=csv.DictWriter(f,fieldnames=r.fieldnames);w.writeheader();w.writerows(rows)
PY
if run_audit > "$tmp/csv.out" 2>&1;then echo WRONG_CSV_UNDETECTED;exit 1;fi
cp "$tmp/original-memory.csv" "$mem"
python3 - "$d/tensor-addresses.json" <<'PY'
import json,sys
from pathlib import Path
p=Path(sys.argv[1]);a=json.loads(p.read_text());a[9]['address']=a[0]['address'];p.write_text(json.dumps(a))
PY
if run_audit > "$tmp/alias.out" 2>&1;then echo INPUT_ALIAS_UNDETECTED;exit 1;fi
cp "$tmp/original-addresses.json" "$d/tensor-addresses.json"
python3 - "$d/tensor-addresses.json" <<'PY'
import json,sys
from pathlib import Path
p=Path(sys.argv[1]);a=json.loads(p.read_text());a[11]['shape'][-1]//=2;p.write_text(json.dumps(a))
PY
if run_audit > "$tmp/scale.out" 2>&1;then echo WRONG_OUTPUT_SHAPE_UNDETECTED;exit 1;fi
echo 'PASS rejects missing records for all three outputs, altered CSV, input/output alias and wrong output shape'
echo __ENGRAM_GATE_BWD_UNMASKED_TEST_END__
