#!/usr/bin/env bash
set -Eeuo pipefail
echo __NORM_FORWARD_11_ROWMAJOR_AUDIT_TEST_BEGIN__
root=/workspace/expert-profile-backfill-20261109-hidev
tmp=$(mktemp -d "$root/norm05-audit-test.XXXXXXXX")
trap 'rm -rf -- "$tmp"' EXIT
base=extra-proxy-runs/unified-extra3/quant_norm_forward-11/hidev-npu0/attempt-001
mkdir -p "$tmp/$(dirname "$base")";cp -a "$root/$base" "$tmp/$base"
cp "$root/audit-reduce-family.py" "$tmp/";export BACKFILL_ROOT="$tmp"
python3 -B "$root/audit-extra-norm-forward-general-candidate.py" quant_norm_forward-11 attempt-001
detail="$tmp/$base/detail";cp "$detail/profile.log" "$tmp/original.log";cp "$detail/tensor-addresses.json" "$tmp/original-addresses.json"
mem=$(find "$detail/capture" -name Memory.csv -print -quit);cp "$mem" "$tmp/original-memory.csv"
python3 - "$detail/profile.log" "$detail/tensor-addresses.json" <<'PY'
from pathlib import Path
import json,re,sys
p=Path(sys.argv[1]);a=json.loads(Path(sys.argv[2]).read_text());lo=int(a[2]['address'],16);hi=lo+a[2]['logical_bytes'];lines=p.read_text().splitlines(keepends=True)
for i,s in enumerate(lines):
 m=re.search(r'DBI record core:.*dst:\(type:GM;addr:(0x[0-9a-f]+)',s)
 if m and lo<=int(m.group(1),16)<hi:del lines[i];break
else:raise RuntimeError('no scale store found')
p.write_text(''.join(lines))
PY
if python3 -B "$root/audit-extra-norm-forward-general-candidate.py" quant_norm_forward-11 attempt-001 > "$tmp/missing.out" 2>&1;then echo MISSING_SCALE_STORE_UNDETECTED;exit 1;fi
cp "$tmp/original.log" "$detail/profile.log"
python3 - "$mem" <<'PY'
from pathlib import Path
import csv,io,sys
p=Path(sys.argv[1]);r=csv.DictReader(io.StringIO(p.read_text(encoding='utf-8-sig')));rows=list(r)
rows[0]['UB_to_GM_datas(KB)']=str(float(rows[0]['UB_to_GM_datas(KB)'])+1)
with p.open('w',encoding='utf8',newline='') as f:w=csv.DictWriter(f,fieldnames=r.fieldnames);w.writeheader();w.writerows(rows)
PY
if python3 -B "$root/audit-extra-norm-forward-general-candidate.py" quant_norm_forward-11 attempt-001 > "$tmp/csv.out" 2>&1;then echo WRONG_CSV_UNDETECTED;exit 1;fi
cp "$tmp/original-memory.csv" "$mem"
python3 - "$detail/tensor-addresses.json" <<'PY'
import json,sys
from pathlib import Path
p=Path(sys.argv[1]);a=json.loads(p.read_text());a[3]['address']=a[0]['address'];p.write_text(json.dumps(a))
PY
if python3 -B "$root/audit-extra-norm-forward-general-candidate.py" quant_norm_forward-11 attempt-001 > "$tmp/alias.out" 2>&1;then echo INPUT_ALIAS_UNDETECTED;exit 1;fi
cp "$tmp/original-addresses.json" "$detail/tensor-addresses.json"
python3 - "$detail/tensor-addresses.json" <<'PY'
import json,sys
from pathlib import Path
p=Path(sys.argv[1]);a=json.loads(p.read_text());a[2]['shape'][-1]//=2;p.write_text(json.dumps(a))
PY
if python3 -B "$root/audit-extra-norm-forward-general-candidate.py" quant_norm_forward-11 attempt-001 > "$tmp/scale.out" 2>&1;then echo WRONG_SCALE_SHAPE_UNDETECTED;exit 1;fi
echo 'PASS rejects missing scale store, altered CSV, input/output alias and wrong row-major scale shape'
echo __NORM_FORWARD_11_ROWMAJOR_AUDIT_TEST_END__
