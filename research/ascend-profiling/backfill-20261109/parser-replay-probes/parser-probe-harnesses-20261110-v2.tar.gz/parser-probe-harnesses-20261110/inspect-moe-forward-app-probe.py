"""Inspect MoE forward application replay as a parser-health experiment."""
import csv,hashlib,json,re,sys
from pathlib import Path
root=Path('/workspace/expert-profile-backfill-20261109-hidev');target,attempt=sys.argv[1:]
assert target=='unified-extra3/moe_topk_gate_forward-01' and re.fullmatch(r'attempt-\d+',attempt)
p=root/'extra-proxy-runs'/target/'hidev-npu0'/attempt/'detail';old=json.loads((p/'provenance/historical-default.json').read_text());command=json.loads((p/'command.json').read_text());assert '--replay-mode=application' in command and '--warm-up=5' in command
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();apps=sorted(p.glob('application-*.json'));assert len(apps)>=2
records=[];first=None
for f in apps:
 pid=f.stem.removeprefix('application-');a=json.loads(f.read_text());sf=p/('generated-kernel-'+pid+'.cpp');af=p/('tensor-addresses-'+pid+'.json');assert sf.is_file() and af.is_file()
 assert a['status']==old['status']=='passed' and a['matched']==old['matched']==1
 for k in ('runtime_kernel','inputs','group','params','seed','route_counts','scalar_inputs','requested_fix_routing'):assert a[k]==old[k],k
 assert a['correctness']=='passed_upstream_full_moe_forward_test' and sha(sf)==a['source_sha256']
 source=sf.read_text();new=r'\/workspace\/tilekernels-env-20261101\/src\/TileKernels-private\/';previous=r'\/workspace\/tilekernels-env-20261101\/src\/TileKernels\/'
 assert sha(sf)==old['source_sha256'] or (new in source and hashlib.sha256(source.replace(new,previous).encode()).hexdigest()==old['source_sha256'])
 addresses=json.loads(af.read_text());assert len(addresses)==16 and all(x is None or x['device'].startswith('npu') for x in addresses)
 if first is None:first=addresses
 else:assert addresses==first,'address differs across processes'
 records.append({'pid':pid,'application':f.name,'application_sha256':sha(f),'source':sf.name,'source_sha256':sha(sf),'addresses':af.name,'addresses_sha256':sha(af)})
mon=json.loads((p/'monitor-summary.json').read_text());assert mon['status']=='passed' and mon['max_seconds_between_successful_queries']<=3
op,=list((p/'capture').rglob('OpBasicInfo.csv'))
with op.open(encoding='utf-8-sig',newline='') as f:basic,=csv.DictReader(f)
assert basic['Op Name']==old['runtime_kernel'] and basic['Device Id']=='0' and basic['Op Type']=='vector'
binary=op.parent/'dump/aicore_binary.o';bsha=sha(binary);assert any(x.startswith(bsha+' ') and x.rstrip().endswith('/kernel.aibin') for x in (p/'cache-sha256.txt').read_text().splitlines())
log=(p/'profile.log').read_text(errors='replace');lines=[x for x in log.splitlines() if 'processedRecord:' in x];assert lines
flags={};fields=('droppedRecord','memoryCopyFailed','invalidParam','overflow','invalidDataCount','memoryCorruption','invalidRecordType','outOfBoundsRead')
for k in fields:
 vals=[int(m.group(1)) for line in lines if (m:=re.search(r'\b'+k+r'\s*:?\s*(\d+)',line))];assert len(vals)==len(lines),k;flags[k]=sum(vals)
stores=[x for x in log.splitlines() if 'DBI record core:' in x and 'dst:(type:GM;' in x and 'src:(type:UB;' in x]
out={'target':target,'status':'identity_passed_parser_health_probe_only','historical_input_and_source_match':True,'correctness':'passed','capture_binary_sha256':bsha,'application_records':records,'parser_error_fields':flags,'raw_ub_to_gm_event_count':len(stores),'scope':'application replay; no byte completeness or historical kernel replay equivalence claimed'}
(p/'capture-inspection.json').write_text(json.dumps(out,indent=2)+'\n');print('MOE_FORWARD_APP_PROBE',len(records),'processes',len(stores),'events',json.dumps(flags))
