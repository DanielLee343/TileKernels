#!/usr/bin/env bash
set -Eeo pipefail
out=/workspace/expert-profile-backfill-20261109-hidev/moe-topk-original-store-20261111
obj=/workspace/tilekernels-env-20261101/cann/cann-9.2.1/tools/bisheng_compiler/bin/llvm-objdump
for i in $(seq -w 1 20); do
 case_id="moe_topk_gate_forward-$i"
 for j in $(seq 1 90); do
  compgen -G "$out/$case_id/application-*.json" >/dev/null && break
  test ! -f "$out/exit.txt" || break
  sleep 2
 done
 if python3 -B "$out/audit-v2.py" "$out" /workspace/tilekernels-expert-unified-extra3-20261106/cases "$obj" "$case_id" > "$out/$case_id/audit.log" 2>&1; then
  echo "$case_id passed"
 else
  echo "$case_id failed"
 fi
done
