#include <tl_templates/ascend/common.h>
#include <tl_templates/ascend/debug.h>
#include <tl_templates/ascend/philox_rng.h>
#include <tl_templates/ascend/simd_inst.h>
__simd_vf__ inline void moe_topk_gate_forward_kernel_asc_kernel_simd_vf_0(__ubuf__ uint8_t* buf_dyn_shmem) {
  vector_bool v = asc_create_mask_b32(PAT_ALL);
  simd_inst::vsts_norm(simd_inst::vdup<float>(float(0x0p+0f/*0.000000e+00*/), v, MODE_ZEROING), (__ubuf__ float*)(&(((__ubuf__ float*)buf_dyn_shmem)[18944])), 0, v);
  vector_bool v_1 = asc_create_mask_b32(PAT_ALL);
  simd_inst::vsts_norm(simd_inst::vdup<float>(float(0x0p+0f/*0.000000e+00*/), v_1, MODE_ZEROING), (__ubuf__ float*)(&(((__ubuf__ float*)buf_dyn_shmem)[19008])), 0, v_1);
}

__simd_vf__ inline void moe_topk_gate_forward_kernel_asc_kernel_simd_vf_1(__ubuf__ uint8_t* buf_dyn_shmem) {
  vector_bool mask = asc_create_mask_b32(PAT_ALL);
  auto vreg_0 = simd_inst::vdup<int32_t>(0, mask, MODE_ZEROING);
  simd_inst::vsts_norm(vreg_0, (__ubuf__ int32_t*)(&(((__ubuf__ int32_t*)buf_dyn_shmem)[19200])), 0, mask);
}

__simd_vf__ inline void moe_topk_gate_forward_kernel_asc_kernel_simd_vf_2(__ubuf__ uint8_t* buf_dyn_shmem, int32_t num_tokens, int32_t w, int32_t block_idx, int32_t force_random_ub_version_counter_1) {
  vector_s32 invalid;
  int8_t active = (int8_t)0;
  int32_t bias_kind = 0;
  vector_f32 logit;
  vector_f32 t;
  vector_f32 poly;
  vector_f32 s;
  vector_f32 root1;
  vector_f32 resid;
  vector_f32 root2;
  vector_f32 score;
  auto lanes = simd_inst::vci<int32_t>(0, INC_ORDER);
  vector_bool v = asc_create_mask_b32(PAT_ALL);
  auto zero = simd_inst::vdup<float>(float(0x0p+0f/*0.000000e+00*/), v, MODE_ZEROING);
  auto zeros = simd_inst::vdup<int32_t>(0, v, MODE_ZEROING);
  invalid = simd_inst::vlds_norm<int32_t>((__ubuf__ int32_t*)(&(((__ubuf__ int32_t*)buf_dyn_shmem)[19200])), 0);
  auto topk_lanes = simd_inst::vcmps_lt(lanes, 6, v);
  for (int32_t row = 0; row < min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31)))); ++row) {
    active = ((int8_t)((((((((w * 56) + ((int32_t)block_idx)) / max(1, min(8, ((((num_tokens - 1) / min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) + (((num_tokens - 1) % min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) >> 31)) + 1)))) * max(1, min(8, ((((num_tokens - 1) / min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) + (((num_tokens - 1) % min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) >> 31)) + 1)))) + (((w * 56) + ((int32_t)block_idx)) % max(1, min(8, ((((num_tokens - 1) / min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) + (((num_tokens - 1) % min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) >> 31)) + 1))))) * min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) + row) < num_tokens));
    active = ((int8_t)(((bool)active) && !((bool)((__ubuf__ int8_t*)buf_dyn_shmem)[((((force_random_ub_version_counter_1 & 1) * 32) + row) + 77056)])));
    bias_kind = 0;
    int32_t condval;
    if (((bool)((__ubuf__ int8_t*)buf_dyn_shmem)[((((force_random_ub_version_counter_1 & 1) * 32) + row) + 77184)])) {
      condval = 1;
    } else {
      condval = 0;
    }
    bias_kind = condval;
    if (((bool)active) && ((bool)((__ubuf__ int8_t*)buf_dyn_shmem)[((((force_random_ub_version_counter_1 & 1) * 32) + row) + 77120)])) {
        vector_s32 v_ = simd_inst::vmuls(lanes, 2, v, MODE_ZEROING);
      auto fixed_idx = simd_inst::vgather2((&(((__ubuf__ int32_t*)buf_dyn_shmem)[((((force_random_ub_version_counter_1 & 1) * 512) + (row * 16)) + 16384)])), (*(vector_u32 *)(&(v_))), topk_lanes);
      auto invalid_idx = simd_inst::vcmps_lt(fixed_idx, 0, topk_lanes);
      invalid = simd_inst::vmax(invalid, simd_inst::vsel(simd_inst::vdup<int32_t>(1, v, MODE_ZEROING), zeros, invalid_idx), v, MODE_ZEROING);
    }
    auto active_lanes = simd_inst::vcmps_ne(simd_inst::vdup<int32_t>(((int32_t)((bool)active)), v, MODE_ZEROING), 0, v);
    for (int32_t j = 0; j < 2; ++j) {
      auto valid = simd_inst::vcmps_lt(simd_inst::vadds(lanes, (j * 64), v, MODE_ZEROING), 72, v);
      logit = simd_inst::vlds_norm<float>((__ubuf__ float*)(&(((__ubuf__ float*)buf_dyn_shmem)[((((force_random_ub_version_counter_1 & 1) * 4096) + (row * 128)) + (j * 64))])), 0);
      logit = simd_inst::vsel(logit, zero, valid);
      logit = simd_inst::vsel(logit, zero, active_lanes);
      auto nonfinite = simd_inst::vcmps_ne(simd_inst::vsub(logit, logit, v, MODE_ZEROING), float(0x0p+0f/*0.000000e+00*/), v);
      invalid = simd_inst::vmax(invalid, simd_inst::vsel(simd_inst::vdup<int32_t>(1, v, MODE_ZEROING), zeros, nonfinite), v, MODE_ZEROING);
      auto x = logit;
      auto neg_half_abs = simd_inst::vmuls(simd_inst::vabs(x, v, MODE_ZEROING), float(-0x1p-1f/*-5.000000e-01*/), v, MODE_ZEROING);
      auto a = simd_inst::vexp_1ulp_ftz_false(neg_half_abs, v, MODE_ZEROING);
      t = simd_inst::vsub(simd_inst::vdup<float>(float(0x1p+0f/*1.000000e+00*/), v, MODE_ZEROING), simd_inst::vmul(a, a, v, MODE_ZEROING), v, MODE_ZEROING);
      auto t_1 = t;
      poly = simd_inst::vdup<float>(float(0x1.eeb88ap-12f/*4.718026e-04*/), v, MODE_ZEROING);
      simd_inst::vmadd((&(poly)), t_1, simd_inst::vdup<float>(float(-0x1.bb39ap-12f/*-4.226924e-04*/), v, MODE_ZEROING), v, MODE_ZEROING);
      simd_inst::vmadd((&(poly)), t_1, simd_inst::vdup<float>(float(-0x1.660b34p-14f/*-8.536429e-05*/), v, MODE_ZEROING), v, MODE_ZEROING);
      simd_inst::vmadd((&(poly)), t_1, simd_inst::vdup<float>(float(0x1.1f51dep-9f/*2.192076e-03*/), v, MODE_ZEROING), v, MODE_ZEROING);
      simd_inst::vmadd((&(poly)), t_1, simd_inst::vdup<float>(float(0x1.3321p-12f/*2.929009e-04*/), v, MODE_ZEROING), v, MODE_ZEROING);
      simd_inst::vmadd((&(poly)), t_1, simd_inst::vdup<float>(float(0x1.46c3dep-8f/*4.986040e-03*/), v, MODE_ZEROING), v, MODE_ZEROING);
      simd_inst::vmadd((&(poly)), t_1, simd_inst::vdup<float>(float(0x1.6d2fc4p-7f/*1.114461e-02*/), v, MODE_ZEROING), v, MODE_ZEROING);
      simd_inst::vmadd((&(poly)), t_1, simd_inst::vdup<float>(float(0x1.0d470cp-5f/*3.287079e-02*/), v, MODE_ZEROING), v, MODE_ZEROING);
      simd_inst::vmadd((&(poly)), t_1, simd_inst::vdup<float>(float(0x1.db1dc4p-4f/*1.159952e-01*/), v, MODE_ZEROING), v, MODE_ZEROING);
      auto p = poly;
      simd_inst::vmadd((&(t)), p, simd_inst::vdup<float>(float(0x1.aa449ap-1f/*8.325546e-01*/), v, MODE_ZEROING), v, MODE_ZEROING);
      auto l = simd_inst::vmul(a, t, v, MODE_ZEROING);
      s = simd_inst::vrelu(x, v, MODE_ZEROING);
      simd_inst::vmula((&(s)), l, l, v, MODE_ZEROING);
      auto x_1 = s;
      auto root0 = simd_inst::vsqrt(x_1, v, MODE_ZEROING);
      auto recip0 = simd_inst::vdiv(simd_inst::vdup<float>(float(0x1p+0f/*1.000000e+00*/), v, MODE_ZEROING), root0, v, MODE_ZEROING);
      root1 = simd_inst::vmuls(simd_inst::vadd(root0, simd_inst::vmul(x_1, recip0, v, MODE_ZEROING), v, MODE_ZEROING), float(0x1p-1f/*5.000000e-01*/), v, MODE_ZEROING);
      resid = simd_inst::vneg(x_1, v, MODE_ZEROING);
      simd_inst::vmula((&(resid)), root1, root1, v, MODE_ZEROING);
      auto corr = simd_inst::vmuls(recip0, float(-0x1p-1f/*-5.000000e-01*/), v, MODE_ZEROING);
      root2 = root1;
      simd_inst::vmula((&(root2)), resid, corr, v, MODE_ZEROING);
      auto y_pos = root2;
      score = simd_inst::vsel(y_pos, l, simd_inst::vcmps_gt(x, float(0x0p+0f/*0.000000e+00*/), v));
      score = simd_inst::vsel(score, zero, active_lanes);
      score = simd_inst::vsel(score, zero, valid);
      simd_inst::vsts_norm(score, (__ubuf__ float*)(&(((__ubuf__ float*)buf_dyn_shmem)[(((((force_random_ub_version_counter_1 & 1) * 4096) + (row * 128)) + (j * 64)) + 8192)])), 0, v);
      score = simd_inst::vadd(score, simd_inst::vlds_norm<float>((__ubuf__ float*)(&(((__ubuf__ float*)buf_dyn_shmem)[(((((int64_t)bias_kind) * (int64_t)128) + (((int64_t)j) * (int64_t)64)) + (int64_t)18944)])), 0), v, MODE_ZEROING);
      score = simd_inst::vsel(score, simd_inst::vdup<float>(tl::limits::kFloatNInf, v, MODE_ZEROING), valid);
      simd_inst::vsts_norm(score, (__ubuf__ float*)(&(((__ubuf__ float*)buf_dyn_shmem)[((((force_random_ub_version_counter_1 & 1) * 4096) + (row * 128)) + (j * 64))])), 0, v);
    }
  }
  simd_inst::vsts_norm(invalid, (__ubuf__ int32_t*)(&(((__ubuf__ int32_t*)buf_dyn_shmem)[19200])), 0, v);
}

__simt_vf__ __launch_bounds__(1024) inline void moe_topk_gate_forward_kernel_asc_kernel_simt_vf_0(int32_t num_tokens, int32_t w, __ubuf__ uint8_t* buf_dyn_shmem, int32_t force_random_ub_version_counter_1, int32_t ep_rank, int32_t num_physical_experts, float routed_scaling_factor) {
  int8_t active = (int8_t)0;
  int8_t is_force_random_token = (int8_t)0;
  int8_t use_fixed = (int8_t)0;
  int32_t topk_idx_var = 0;
  int32_t unmapped = 0;
  float weight = float(0x0p+0f/*0.000000e+00*/);
  int32_t rand_topk_idx_tmp_var = 0;
  float scores_local[4];
  float max_score = float(0x0p+0f/*0.000000e+00*/);
  int32_t local_winner = 0;
  float quotient = float(0x0p+0f/*0.000000e+00*/);
  active = ((int8_t)(((((int32_t)threadIdx.x) < 32) || ((((int32_t)threadIdx.x) >> 5) < (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31)))) && (((((int32_t)threadIdx.x) >> 5) + ((((((w * 56) + ((int32_t)block_idx)) / max(1, min(8, ((((num_tokens - 1) / min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) + (((num_tokens - 1) % min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) >> 31)) + 1)))) * max(1, min(8, ((((num_tokens - 1) / min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) + (((num_tokens - 1) % min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) >> 31)) + 1)))) + (((w * 56) + ((int32_t)block_idx)) % max(1, min(8, ((((num_tokens - 1) / min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) + (((num_tokens - 1) % min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) >> 31)) + 1))))) * min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31)))))) < num_tokens)));
  is_force_random_token = (int8_t)0;
  use_fixed = (int8_t)0;
  is_force_random_token = ((int8_t)((bool)((__ubuf__ int8_t*)buf_dyn_shmem)[((((force_random_ub_version_counter_1 & 1) * 32) + (((int32_t)threadIdx.x) >> 5)) + 77056)]));
  use_fixed = ((int8_t)((bool)((__ubuf__ int8_t*)buf_dyn_shmem)[((((force_random_ub_version_counter_1 & 1) * 32) + (((int32_t)threadIdx.x) >> 5)) + 77120)]));
  topk_idx_var = -1;
  unmapped = -1;
  weight = float(0x0p+0f/*0.000000e+00*/);
  if ((bool)active) {
    if ((bool)is_force_random_token) {
      tl::AscendPhiloxState __asc_rng_state;
      tl::philox_init(&__asc_rng_state, ep_rank, ((((((((w * 56) + ((int32_t)block_idx)) / max(1, min(8, ((((num_tokens - 1) / min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) + (((num_tokens - 1) % min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) >> 31)) + 1)))) * max(1, min(8, ((((num_tokens - 1) / min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) + (((num_tokens - 1) % min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) >> 31)) + 1)))) + (((w * 56) + ((int32_t)block_idx)) % max(1, min(8, ((((num_tokens - 1) / min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) + (((num_tokens - 1) % min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) >> 31)) + 1))))) * min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) * 32) + ((int32_t)threadIdx.x)), 0);
      weight = tl::philox_rand_uniform(&__asc_rng_state);
      rand_topk_idx_tmp_var = 2147483647;
      if ((((int32_t)threadIdx.x) & 31) < 6) {
        rand_topk_idx_tmp_var = ((int32_t)(tl::philox_rand(&__asc_rng_state) % ((uint32_t)(num_physical_experts - (((int32_t)threadIdx.x) & 31)))));
      } else {
        topk_idx_var = 2147483647;
      }
      for (int32_t j = 0; j < 6; ++j) {
        int32_t min_topk_idx = asc_reduce_min(rand_topk_idx_tmp_var);
        int32_t condval;
        if ((rand_topk_idx_tmp_var == min_topk_idx)) {
          condval = (((int32_t)threadIdx.x) & 31);
        } else {
          condval = 2147483647;
        }
        int32_t min_lane_idx = asc_reduce_min(condval);
        if (topk_idx_var == -1) {
          if ((min_topk_idx <= rand_topk_idx_tmp_var) && (min_lane_idx < (((int32_t)threadIdx.x) & 31))) {
            rand_topk_idx_tmp_var = (rand_topk_idx_tmp_var + 1);
          } else {
            if (min_lane_idx == (((int32_t)threadIdx.x) & 31)) {
              topk_idx_var = rand_topk_idx_tmp_var;
              rand_topk_idx_tmp_var = 2147483647;
            }
          }
        }
      }
    } else {
      if ((bool)use_fixed) {
        if ((((int32_t)threadIdx.x) & 31) < 6) {
          topk_idx_var = ((__ubuf__ int32_t*)buf_dyn_shmem)[(((((force_random_ub_version_counter_1 & 1) * 512) + ((((int32_t)threadIdx.x) >> 5) * 16)) + ((((int32_t)threadIdx.x) & 31) * 2)) + 16384)];
        }
      } else {
        scores_local[0] = ((__ubuf__ float*)buf_dyn_shmem)[((((force_random_ub_version_counter_1 & 1) * 4096) + ((((int32_t)threadIdx.x) >> 5) * 128)) + (((int32_t)threadIdx.x) & 31))];
        scores_local[1] = ((__ubuf__ float*)buf_dyn_shmem)[(((((force_random_ub_version_counter_1 & 1) * 4096) + ((((int32_t)threadIdx.x) >> 5) * 128)) + (((int32_t)threadIdx.x) & 31)) + 32)];
        scores_local[2] = ((__ubuf__ float*)buf_dyn_shmem)[(((((force_random_ub_version_counter_1 & 1) * 4096) + ((((int32_t)threadIdx.x) >> 5) * 128)) + (((int32_t)threadIdx.x) & 31)) + 64)];
        scores_local[3] = ((__ubuf__ float*)buf_dyn_shmem)[(((((force_random_ub_version_counter_1 & 1) * 4096) + ((((int32_t)threadIdx.x) >> 5) * 128)) + (((int32_t)threadIdx.x) & 31)) + 96)];
        for (int32_t j_1 = 0; j_1 < 6; ++j_1) {
          max_score = tl::limits::kFloatNInf;
          local_winner = 2147483647;
          int32_t condval_1;
          if ((max_score < scores_local[0])) {
            condval_1 = (((int32_t)threadIdx.x) & 31);
          } else {
            condval_1 = local_winner;
          }
          local_winner = condval_1;
          max_score = max(max_score, scores_local[0]);
          int32_t condval_2;
          if ((max_score < scores_local[1])) {
            condval_2 = ((((int32_t)threadIdx.x) & 31) + 32);
          } else {
            condval_2 = local_winner;
          }
          local_winner = condval_2;
          max_score = max(max_score, scores_local[1]);
          int32_t condval_3;
          if ((max_score < scores_local[2])) {
            condval_3 = ((((int32_t)threadIdx.x) & 31) + 64);
          } else {
            condval_3 = local_winner;
          }
          local_winner = condval_3;
          max_score = max(max_score, scores_local[2]);
          int32_t condval_4;
          if ((max_score < scores_local[3])) {
            condval_4 = ((((int32_t)threadIdx.x) & 31) + 96);
          } else {
            condval_4 = local_winner;
          }
          local_winner = condval_4;
          max_score = max(max_score, scores_local[3]);
          float global_max = asc_reduce_max(max_score);
          int32_t condval_5;
          if ((max_score == global_max)) {
            condval_5 = local_winner;
          } else {
            condval_5 = 2147483647;
          }
          int32_t winner_idx = asc_reduce_min(condval_5);
          if ((((int32_t)threadIdx.x) & 31) == j_1) {
            topk_idx_var = winner_idx;
          }
          float condval_6;
          if ((winner_idx == (((int32_t)threadIdx.x) & 31))) {
            condval_6 = tl::limits::kFloatNInf;
          } else {
            condval_6 = scores_local[0];
          }
          scores_local[0] = condval_6;
          float condval_7;
          if ((winner_idx == ((((int32_t)threadIdx.x) & 31) + 32))) {
            condval_7 = tl::limits::kFloatNInf;
          } else {
            condval_7 = scores_local[1];
          }
          scores_local[1] = condval_7;
          float condval_8;
          if ((winner_idx == ((((int32_t)threadIdx.x) & 31) + 64))) {
            condval_8 = tl::limits::kFloatNInf;
          } else {
            condval_8 = scores_local[2];
          }
          scores_local[2] = condval_8;
          float condval_9;
          if ((winner_idx == ((((int32_t)threadIdx.x) & 31) + 96))) {
            condval_9 = tl::limits::kFloatNInf;
          } else {
            condval_9 = scores_local[3];
          }
          scores_local[3] = condval_9;
        }
      }
      if ((((int32_t)threadIdx.x) & 31) < 6) {
        weight = ((__ubuf__ float*)buf_dyn_shmem)[(((((((int64_t)force_random_ub_version_counter_1) & (int64_t)1) * (int64_t)4096) + ((((int64_t)((int32_t)threadIdx.x)) >> (int64_t)5) * (int64_t)128)) + max(((int64_t)topk_idx_var), (int64_t)0)) + (int64_t)8192)];
        unmapped = topk_idx_var;
      }
      float weight_sum = asc_reduce_add(weight);
      quotient = (weight / (weight_sum + float(0x1.79ca10c924223p-67f/*1.000000e-20*/)));
        int32_t v_ = (*(int32_t *)(&(quotient))) - 1;
      float quotient_prev = (*(float *)(&(v_)));
        int32_t v__1 = (*(int32_t *)(&(quotient))) + 1;
      float quotient_next = (*(float *)(&(v__1)));
      float residual = fabsf(((quotient * ((weight_sum + float(0x1.79ca10c924223p-67f/*1.000000e-20*/)) * float(-0x1p+0f/*-1.000000e+00*/))) + weight));
      float residual_prev = fabsf(((quotient_prev * ((weight_sum + float(0x1.79ca10c924223p-67f/*1.000000e-20*/)) * float(-0x1p+0f/*-1.000000e+00*/))) + weight));
      float residual_next = fabsf(((quotient_next * ((weight_sum + float(0x1.79ca10c924223p-67f/*1.000000e-20*/)) * float(-0x1p+0f/*-1.000000e+00*/))) + weight));
      float condval_10;
      if ((residual < residual_prev)) {
        condval_10 = quotient;
      } else {
        condval_10 = quotient_prev;
      }
      float closest = condval_10;
      float condval_11;
      if ((quotient == float(0x0p+0f/*0.000000e+00*/))) {
        condval_11 = quotient;
      } else {
        float condval_12;
        if ((residual_next < min(residual, residual_prev))) {
          condval_12 = quotient_next;
        } else {
          condval_12 = closest;
        }
        condval_11 = condval_12;
      }
      quotient = condval_11;
      float condval_13;
      if (((((int32_t)threadIdx.x) & 31) < 6)) {
        condval_13 = (quotient * routed_scaling_factor);
      } else {
        condval_13 = float(0x1p+0f/*1.000000e+00*/);
      }
      weight = condval_13;
      if (6 <= (((int32_t)threadIdx.x) & 31)) {
        topk_idx_var = ((((int32_t)threadIdx.x) & 31) + 66);
      }
    }
  }
  asc_syncthreads();
  if ((((int32_t)threadIdx.x) & 31) < 6) {
    ((__ubuf__ int32_t*)buf_dyn_shmem)[(((((force_random_ub_version_counter_1 & 1) * 512) + ((((int32_t)threadIdx.x) >> 5) * 16)) + ((((int32_t)threadIdx.x) & 31) * 2)) + 17408)] = topk_idx_var;
    int32_t condval_14;
    if (((bool)active)) {
      condval_14 = 0;
    } else {
      condval_14 = -1;
    }
    ((__ubuf__ int32_t*)buf_dyn_shmem)[(((((force_random_ub_version_counter_1 & 1) * 512) + ((((int32_t)threadIdx.x) >> 5) * 16)) + ((((int32_t)threadIdx.x) & 31) * 2)) + 17409)] = condval_14;
    ((__ubuf__ float*)buf_dyn_shmem)[(((((force_random_ub_version_counter_1 & 1) * 256) + ((((int32_t)threadIdx.x) >> 5) * 8)) + (((int32_t)threadIdx.x) & 31)) + 18432)] = weight;
    ((__ubuf__ int32_t*)buf_dyn_shmem)[(((((force_random_ub_version_counter_1 & 1) * 512) + ((((int32_t)threadIdx.x) >> 5) * 16)) + ((((int32_t)threadIdx.x) & 31) * 2)) + 16384)] = unmapped;
    int32_t condval_15;
    if ((unmapped < 0)) {
      condval_15 = -1;
    } else {
      condval_15 = 0;
    }
    ((__ubuf__ int32_t*)buf_dyn_shmem)[(((((force_random_ub_version_counter_1 & 1) * 512) + ((((int32_t)threadIdx.x) >> 5) * 16)) + ((((int32_t)threadIdx.x) & 31) * 2)) + 16385)] = condval_15;
  }
}

__simd_vf__ inline void moe_topk_gate_forward_kernel_asc_kernel_simd_vf_3(__ubuf__ uint8_t* buf_dyn_shmem) {
  vector_bool v = asc_create_mask_b32(PAT_ALL);
  simd_inst::vsts_norm(simd_inst::vcmax(simd_inst::vlds_norm<int32_t>((__ubuf__ int32_t*)(&(((__ubuf__ int32_t*)buf_dyn_shmem)[19200])), 0), v, MODE_ZEROING), (__ubuf__ int32_t*)(&(((__ubuf__ int32_t*)buf_dyn_shmem)[19200])), 0, v);
}

extern "C" __global__ __vector__ void moe_topk_gate_forward_kernel_asc_kernel(__gm__ int8_t* fix_routing_mask, __gm__ int8_t* force_random, __gm__ float* image_bias, __gm__ int8_t* image_token_mask, __gm__ float* logits, __gm__ float* scores, __gm__ int64_t* topk_idx_view, __gm__ float* topk_weights, __gm__ int64_t* unmapped_idx_view, int32_t ep_rank, int32_t num_tokens, float routed_scaling_factor, int32_t unmapped_topk_idx_stride) {
  asc_init();
  __ubuf__ uint8_t *buf_dyn_shmem = (__ubuf__ uint8_t *)0;
  int32_t num_physical_experts = 0;
  int32_t force_random_ub_version_counter_1 = 0;
  asc_sync_notify(PIPE_MTE3, PIPE_MTE2, static_cast<event_t>(0));
  force_random_ub_version_counter_1 = 0;
  moe_topk_gate_forward_kernel_asc_kernel_simd_vf_0(buf_dyn_shmem);
  asc_copy_gm2ub_align((__ubuf__ uint8_t*)((&(((__ubuf__ float*)buf_dyn_shmem)[19072]))), (__gm__ uint8_t*)((&(image_bias[0]))), 1, 288, 0, 0, 0, static_cast<asc_load_l2_cache_mode>(0), 288, 288);
  asc_sync_notify(PIPE_MTE2, PIPE_V, static_cast<event_t>(1));
  moe_topk_gate_forward_kernel_asc_kernel_simd_vf_1(buf_dyn_shmem);
  num_physical_experts = 72;
  asc_sync_wait(PIPE_MTE2, PIPE_V, static_cast<event_t>(1));
  for (int32_t w = 0; w < ((((((((((num_tokens - 1) / min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) + (((num_tokens - 1) % min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) >> 31)) / max(1, min(8, ((((num_tokens - 1) / min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) + (((num_tokens - 1) % min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) >> 31)) + 1)))) + (((((num_tokens - 1) / min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) + (((num_tokens - 1) % min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) >> 31)) % max(1, min(8, ((((num_tokens - 1) / min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) + (((num_tokens - 1) % min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) >> 31)) + 1)))) >> 31)) + 1) * max(1, min(8, ((((num_tokens - 1) / min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) + (((num_tokens - 1) % min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) >> 31)) + 1)))) + 55) / 56) + ((((((((((num_tokens - 1) / min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) + (((num_tokens - 1) % min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) >> 31)) / max(1, min(8, ((((num_tokens - 1) / min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) + (((num_tokens - 1) % min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) >> 31)) + 1)))) + (((((num_tokens - 1) / min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) + (((num_tokens - 1) % min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) >> 31)) % max(1, min(8, ((((num_tokens - 1) / min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) + (((num_tokens - 1) % min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) >> 31)) + 1)))) >> 31)) + 1) * max(1, min(8, ((((num_tokens - 1) / min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) + (((num_tokens - 1) % min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) >> 31)) + 1)))) + 55) % 56) >> 31)); ++w) {
    if ((((((w * 56) + ((int32_t)block_idx)) / max(1, min(8, ((((num_tokens - 1) / min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) + (((num_tokens - 1) % min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) >> 31)) + 1)))) * max(1, min(8, ((((num_tokens - 1) / min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) + (((num_tokens - 1) % min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) >> 31)) + 1)))) + (((w * 56) + ((int32_t)block_idx)) % max(1, min(8, ((((num_tokens - 1) / min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) + (((num_tokens - 1) % min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) >> 31)) + 1))))) <= (((num_tokens - 1) / min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) + (((num_tokens - 1) % min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) >> 31))) {
      if (0 < (num_tokens - ((((((w * 56) + ((int32_t)block_idx)) / max(1, min(8, ((((num_tokens - 1) / min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) + (((num_tokens - 1) % min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) >> 31)) + 1)))) * max(1, min(8, ((((num_tokens - 1) / min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) + (((num_tokens - 1) % min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) >> 31)) + 1)))) + (((w * 56) + ((int32_t)block_idx)) % max(1, min(8, ((((num_tokens - 1) / min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) + (((num_tokens - 1) % min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) >> 31)) + 1))))) * min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))))) {
        asc_copy_gm2ub_align((__ubuf__ uint8_t*)((&(((__ubuf__ bool*)buf_dyn_shmem)[(((force_random_ub_version_counter_1 & 1) * 32) + 77120)]))), (__gm__ uint8_t*)((&(((__gm__ bool*)fix_routing_mask)[((((((((int64_t)w) * (int64_t)56) + ((int64_t)((int32_t)block_idx))) / max((int64_t)1, min((int64_t)8, ((((((int64_t)num_tokens) - (int64_t)1) / min((int64_t)32, max((int64_t)1, (((((int64_t)num_tokens) + (int64_t)55) / (int64_t)56) + (((((int64_t)num_tokens) + (int64_t)55) % (int64_t)56) >> (int64_t)63))))) + (((((int64_t)num_tokens) - (int64_t)1) % min((int64_t)32, max((int64_t)1, (((((int64_t)num_tokens) + (int64_t)55) / (int64_t)56) + (((((int64_t)num_tokens) + (int64_t)55) % (int64_t)56) >> (int64_t)63))))) >> (int64_t)63)) + (int64_t)1)))) * max((int64_t)1, min((int64_t)8, ((((((int64_t)num_tokens) - (int64_t)1) / min((int64_t)32, max((int64_t)1, (((((int64_t)num_tokens) + (int64_t)55) / (int64_t)56) + (((((int64_t)num_tokens) + (int64_t)55) % (int64_t)56) >> (int64_t)63))))) + (((((int64_t)num_tokens) - (int64_t)1) % min((int64_t)32, max((int64_t)1, (((((int64_t)num_tokens) + (int64_t)55) / (int64_t)56) + (((((int64_t)num_tokens) + (int64_t)55) % (int64_t)56) >> (int64_t)63))))) >> (int64_t)63)) + (int64_t)1)))) + (((((int64_t)w) * (int64_t)56) + ((int64_t)((int32_t)block_idx))) % max((int64_t)1, min((int64_t)8, ((((((int64_t)num_tokens) - (int64_t)1) / min((int64_t)32, max((int64_t)1, (((((int64_t)num_tokens) + (int64_t)55) / (int64_t)56) + (((((int64_t)num_tokens) + (int64_t)55) % (int64_t)56) >> (int64_t)63))))) + (((((int64_t)num_tokens) - (int64_t)1) % min((int64_t)32, max((int64_t)1, (((((int64_t)num_tokens) + (int64_t)55) / (int64_t)56) + (((((int64_t)num_tokens) + (int64_t)55) % (int64_t)56) >> (int64_t)63))))) >> (int64_t)63)) + (int64_t)1))))) * min((int64_t)32, max((int64_t)1, (((((int64_t)num_tokens) + (int64_t)55) / (int64_t)56) + (((((int64_t)num_tokens) + (int64_t)55) % (int64_t)56) >> (int64_t)63)))))]))), 1, min(min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31)))), (num_tokens - ((((((w * 56) + ((int32_t)block_idx)) / max(1, min(8, ((((num_tokens - 1) / min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) + (((num_tokens - 1) % min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) >> 31)) + 1)))) * max(1, min(8, ((((num_tokens - 1) / min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) + (((num_tokens - 1) % min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) >> 31)) + 1)))) + (((w * 56) + ((int32_t)block_idx)) % max(1, min(8, ((((num_tokens - 1) / min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) + (((num_tokens - 1) % min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) >> 31)) + 1))))) * min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))))), 0, 0, 0, static_cast<asc_load_l2_cache_mode>(0), min(min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31)))), (num_tokens - ((((((w * 56) + ((int32_t)block_idx)) / max(1, min(8, ((((num_tokens - 1) / min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) + (((num_tokens - 1) % min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) >> 31)) + 1)))) * max(1, min(8, ((((num_tokens - 1) / min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) + (((num_tokens - 1) % min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) >> 31)) + 1)))) + (((w * 56) + ((int32_t)block_idx)) % max(1, min(8, ((((num_tokens - 1) / min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) + (((num_tokens - 1) % min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) >> 31)) + 1))))) * min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))))), min(min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31)))), (num_tokens - ((((((w * 56) + ((int32_t)block_idx)) / max(1, min(8, ((((num_tokens - 1) / min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) + (((num_tokens - 1) % min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) >> 31)) + 1)))) * max(1, min(8, ((((num_tokens - 1) / min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) + (((num_tokens - 1) % min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) >> 31)) + 1)))) + (((w * 56) + ((int32_t)block_idx)) % max(1, min(8, ((((num_tokens - 1) / min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) + (((num_tokens - 1) % min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) >> 31)) + 1))))) * min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))))));
        asc_copy_gm2ub_align((__ubuf__ uint8_t*)((&(((__ubuf__ float*)buf_dyn_shmem)[((force_random_ub_version_counter_1 & 1) * 4096)]))), (__gm__ uint8_t*)((&(logits[(((((((((int64_t)w) * (int64_t)56) + ((int64_t)((int32_t)block_idx))) / max((int64_t)1, min((int64_t)8, ((((((int64_t)num_tokens) - (int64_t)1) / min((int64_t)32, max((int64_t)1, (((((int64_t)num_tokens) + (int64_t)55) / (int64_t)56) + (((((int64_t)num_tokens) + (int64_t)55) % (int64_t)56) >> (int64_t)63))))) + (((((int64_t)num_tokens) - (int64_t)1) % min((int64_t)32, max((int64_t)1, (((((int64_t)num_tokens) + (int64_t)55) / (int64_t)56) + (((((int64_t)num_tokens) + (int64_t)55) % (int64_t)56) >> (int64_t)63))))) >> (int64_t)63)) + (int64_t)1)))) * max((int64_t)1, min((int64_t)8, ((((((int64_t)num_tokens) - (int64_t)1) / min((int64_t)32, max((int64_t)1, (((((int64_t)num_tokens) + (int64_t)55) / (int64_t)56) + (((((int64_t)num_tokens) + (int64_t)55) % (int64_t)56) >> (int64_t)63))))) + (((((int64_t)num_tokens) - (int64_t)1) % min((int64_t)32, max((int64_t)1, (((((int64_t)num_tokens) + (int64_t)55) / (int64_t)56) + (((((int64_t)num_tokens) + (int64_t)55) % (int64_t)56) >> (int64_t)63))))) >> (int64_t)63)) + (int64_t)1)))) + (((((int64_t)w) * (int64_t)56) + ((int64_t)((int32_t)block_idx))) % max((int64_t)1, min((int64_t)8, ((((((int64_t)num_tokens) - (int64_t)1) / min((int64_t)32, max((int64_t)1, (((((int64_t)num_tokens) + (int64_t)55) / (int64_t)56) + (((((int64_t)num_tokens) + (int64_t)55) % (int64_t)56) >> (int64_t)63))))) + (((((int64_t)num_tokens) - (int64_t)1) % min((int64_t)32, max((int64_t)1, (((((int64_t)num_tokens) + (int64_t)55) / (int64_t)56) + (((((int64_t)num_tokens) + (int64_t)55) % (int64_t)56) >> (int64_t)63))))) >> (int64_t)63)) + (int64_t)1))))) * min((int64_t)32, max((int64_t)1, (((((int64_t)num_tokens) + (int64_t)55) / (int64_t)56) + (((((int64_t)num_tokens) + (int64_t)55) % (int64_t)56) >> (int64_t)63))))) * (int64_t)72)]))), min(min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31)))), (num_tokens - ((((((w * 56) + ((int32_t)block_idx)) / max(1, min(8, ((((num_tokens - 1) / min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) + (((num_tokens - 1) % min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) >> 31)) + 1)))) * max(1, min(8, ((((num_tokens - 1) / min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) + (((num_tokens - 1) % min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) >> 31)) + 1)))) + (((w * 56) + ((int32_t)block_idx)) % max(1, min(8, ((((num_tokens - 1) / min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) + (((num_tokens - 1) % min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) >> 31)) + 1))))) * min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))))), 288, 0, 0, 0, static_cast<asc_load_l2_cache_mode>(0), 288, 512);
        asc_copy_gm2ub_align((__ubuf__ uint8_t*)((&(((__ubuf__ bool*)buf_dyn_shmem)[(((force_random_ub_version_counter_1 & 1) * 32) + 77056)]))), (__gm__ uint8_t*)((&(((__gm__ bool*)force_random)[((((((((int64_t)w) * (int64_t)56) + ((int64_t)((int32_t)block_idx))) / max((int64_t)1, min((int64_t)8, ((((((int64_t)num_tokens) - (int64_t)1) / min((int64_t)32, max((int64_t)1, (((((int64_t)num_tokens) + (int64_t)55) / (int64_t)56) + (((((int64_t)num_tokens) + (int64_t)55) % (int64_t)56) >> (int64_t)63))))) + (((((int64_t)num_tokens) - (int64_t)1) % min((int64_t)32, max((int64_t)1, (((((int64_t)num_tokens) + (int64_t)55) / (int64_t)56) + (((((int64_t)num_tokens) + (int64_t)55) % (int64_t)56) >> (int64_t)63))))) >> (int64_t)63)) + (int64_t)1)))) * max((int64_t)1, min((int64_t)8, ((((((int64_t)num_tokens) - (int64_t)1) / min((int64_t)32, max((int64_t)1, (((((int64_t)num_tokens) + (int64_t)55) / (int64_t)56) + (((((int64_t)num_tokens) + (int64_t)55) % (int64_t)56) >> (int64_t)63))))) + (((((int64_t)num_tokens) - (int64_t)1) % min((int64_t)32, max((int64_t)1, (((((int64_t)num_tokens) + (int64_t)55) / (int64_t)56) + (((((int64_t)num_tokens) + (int64_t)55) % (int64_t)56) >> (int64_t)63))))) >> (int64_t)63)) + (int64_t)1)))) + (((((int64_t)w) * (int64_t)56) + ((int64_t)((int32_t)block_idx))) % max((int64_t)1, min((int64_t)8, ((((((int64_t)num_tokens) - (int64_t)1) / min((int64_t)32, max((int64_t)1, (((((int64_t)num_tokens) + (int64_t)55) / (int64_t)56) + (((((int64_t)num_tokens) + (int64_t)55) % (int64_t)56) >> (int64_t)63))))) + (((((int64_t)num_tokens) - (int64_t)1) % min((int64_t)32, max((int64_t)1, (((((int64_t)num_tokens) + (int64_t)55) / (int64_t)56) + (((((int64_t)num_tokens) + (int64_t)55) % (int64_t)56) >> (int64_t)63))))) >> (int64_t)63)) + (int64_t)1))))) * min((int64_t)32, max((int64_t)1, (((((int64_t)num_tokens) + (int64_t)55) / (int64_t)56) + (((((int64_t)num_tokens) + (int64_t)55) % (int64_t)56) >> (int64_t)63)))))]))), 1, min(min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31)))), (num_tokens - ((((((w * 56) + ((int32_t)block_idx)) / max(1, min(8, ((((num_tokens - 1) / min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) + (((num_tokens - 1) % min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) >> 31)) + 1)))) * max(1, min(8, ((((num_tokens - 1) / min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) + (((num_tokens - 1) % min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) >> 31)) + 1)))) + (((w * 56) + ((int32_t)block_idx)) % max(1, min(8, ((((num_tokens - 1) / min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) + (((num_tokens - 1) % min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) >> 31)) + 1))))) * min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))))), 0, 0, 0, static_cast<asc_load_l2_cache_mode>(0), min(min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31)))), (num_tokens - ((((((w * 56) + ((int32_t)block_idx)) / max(1, min(8, ((((num_tokens - 1) / min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) + (((num_tokens - 1) % min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) >> 31)) + 1)))) * max(1, min(8, ((((num_tokens - 1) / min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) + (((num_tokens - 1) % min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) >> 31)) + 1)))) + (((w * 56) + ((int32_t)block_idx)) % max(1, min(8, ((((num_tokens - 1) / min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) + (((num_tokens - 1) % min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) >> 31)) + 1))))) * min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))))), min(min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31)))), (num_tokens - ((((((w * 56) + ((int32_t)block_idx)) / max(1, min(8, ((((num_tokens - 1) / min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) + (((num_tokens - 1) % min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) >> 31)) + 1)))) * max(1, min(8, ((((num_tokens - 1) / min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) + (((num_tokens - 1) % min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) >> 31)) + 1)))) + (((w * 56) + ((int32_t)block_idx)) % max(1, min(8, ((((num_tokens - 1) / min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) + (((num_tokens - 1) % min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) >> 31)) + 1))))) * min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))))));
        asc_copy_gm2ub_align((__ubuf__ uint8_t*)((&(((__ubuf__ bool*)buf_dyn_shmem)[(((force_random_ub_version_counter_1 & 1) * 32) + 77184)]))), (__gm__ uint8_t*)((&(((__gm__ bool*)image_token_mask)[((((((((int64_t)w) * (int64_t)56) + ((int64_t)((int32_t)block_idx))) / max((int64_t)1, min((int64_t)8, ((((((int64_t)num_tokens) - (int64_t)1) / min((int64_t)32, max((int64_t)1, (((((int64_t)num_tokens) + (int64_t)55) / (int64_t)56) + (((((int64_t)num_tokens) + (int64_t)55) % (int64_t)56) >> (int64_t)63))))) + (((((int64_t)num_tokens) - (int64_t)1) % min((int64_t)32, max((int64_t)1, (((((int64_t)num_tokens) + (int64_t)55) / (int64_t)56) + (((((int64_t)num_tokens) + (int64_t)55) % (int64_t)56) >> (int64_t)63))))) >> (int64_t)63)) + (int64_t)1)))) * max((int64_t)1, min((int64_t)8, ((((((int64_t)num_tokens) - (int64_t)1) / min((int64_t)32, max((int64_t)1, (((((int64_t)num_tokens) + (int64_t)55) / (int64_t)56) + (((((int64_t)num_tokens) + (int64_t)55) % (int64_t)56) >> (int64_t)63))))) + (((((int64_t)num_tokens) - (int64_t)1) % min((int64_t)32, max((int64_t)1, (((((int64_t)num_tokens) + (int64_t)55) / (int64_t)56) + (((((int64_t)num_tokens) + (int64_t)55) % (int64_t)56) >> (int64_t)63))))) >> (int64_t)63)) + (int64_t)1)))) + (((((int64_t)w) * (int64_t)56) + ((int64_t)((int32_t)block_idx))) % max((int64_t)1, min((int64_t)8, ((((((int64_t)num_tokens) - (int64_t)1) / min((int64_t)32, max((int64_t)1, (((((int64_t)num_tokens) + (int64_t)55) / (int64_t)56) + (((((int64_t)num_tokens) + (int64_t)55) % (int64_t)56) >> (int64_t)63))))) + (((((int64_t)num_tokens) - (int64_t)1) % min((int64_t)32, max((int64_t)1, (((((int64_t)num_tokens) + (int64_t)55) / (int64_t)56) + (((((int64_t)num_tokens) + (int64_t)55) % (int64_t)56) >> (int64_t)63))))) >> (int64_t)63)) + (int64_t)1))))) * min((int64_t)32, max((int64_t)1, (((((int64_t)num_tokens) + (int64_t)55) / (int64_t)56) + (((((int64_t)num_tokens) + (int64_t)55) % (int64_t)56) >> (int64_t)63)))))]))), 1, min(min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31)))), (num_tokens - ((((((w * 56) + ((int32_t)block_idx)) / max(1, min(8, ((((num_tokens - 1) / min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) + (((num_tokens - 1) % min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) >> 31)) + 1)))) * max(1, min(8, ((((num_tokens - 1) / min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) + (((num_tokens - 1) % min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) >> 31)) + 1)))) + (((w * 56) + ((int32_t)block_idx)) % max(1, min(8, ((((num_tokens - 1) / min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) + (((num_tokens - 1) % min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) >> 31)) + 1))))) * min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))))), 0, 0, 0, static_cast<asc_load_l2_cache_mode>(0), min(min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31)))), (num_tokens - ((((((w * 56) + ((int32_t)block_idx)) / max(1, min(8, ((((num_tokens - 1) / min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) + (((num_tokens - 1) % min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) >> 31)) + 1)))) * max(1, min(8, ((((num_tokens - 1) / min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) + (((num_tokens - 1) % min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) >> 31)) + 1)))) + (((w * 56) + ((int32_t)block_idx)) % max(1, min(8, ((((num_tokens - 1) / min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) + (((num_tokens - 1) % min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) >> 31)) + 1))))) * min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))))), min(min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31)))), (num_tokens - ((((((w * 56) + ((int32_t)block_idx)) / max(1, min(8, ((((num_tokens - 1) / min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) + (((num_tokens - 1) % min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) >> 31)) + 1)))) * max(1, min(8, ((((num_tokens - 1) / min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) + (((num_tokens - 1) % min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) >> 31)) + 1)))) + (((w * 56) + ((int32_t)block_idx)) % max(1, min(8, ((((num_tokens - 1) / min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) + (((num_tokens - 1) % min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) >> 31)) + 1))))) * min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))))));
      }
      asc_sync_wait(PIPE_MTE3, PIPE_MTE2, static_cast<event_t>(0));
      if (0 < (num_tokens - ((((((w * 56) + ((int32_t)block_idx)) / max(1, min(8, ((((num_tokens - 1) / min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) + (((num_tokens - 1) % min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) >> 31)) + 1)))) * max(1, min(8, ((((num_tokens - 1) / min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) + (((num_tokens - 1) % min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) >> 31)) + 1)))) + (((w * 56) + ((int32_t)block_idx)) % max(1, min(8, ((((num_tokens - 1) / min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) + (((num_tokens - 1) % min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) >> 31)) + 1))))) * min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))))) {
        asc_copy_gm2ub_align((__ubuf__ uint8_t*)((&(((__ubuf__ int32_t*)buf_dyn_shmem)[(((force_random_ub_version_counter_1 & 1) * 512) + 16384)]))), (__gm__ uint8_t*)((&(((__gm__ int32_t*)unmapped_idx_view)[((((((((((int64_t)w) * (int64_t)56) + ((int64_t)((int32_t)block_idx))) / max((int64_t)1, min((int64_t)8, ((((((int64_t)num_tokens) - (int64_t)1) / min((int64_t)32, max((int64_t)1, (((((int64_t)num_tokens) + (int64_t)55) / (int64_t)56) + (((((int64_t)num_tokens) + (int64_t)55) % (int64_t)56) >> (int64_t)63))))) + (((((int64_t)num_tokens) - (int64_t)1) % min((int64_t)32, max((int64_t)1, (((((int64_t)num_tokens) + (int64_t)55) / (int64_t)56) + (((((int64_t)num_tokens) + (int64_t)55) % (int64_t)56) >> (int64_t)63))))) >> (int64_t)63)) + (int64_t)1)))) * max((int64_t)1, min((int64_t)8, ((((((int64_t)num_tokens) - (int64_t)1) / min((int64_t)32, max((int64_t)1, (((((int64_t)num_tokens) + (int64_t)55) / (int64_t)56) + (((((int64_t)num_tokens) + (int64_t)55) % (int64_t)56) >> (int64_t)63))))) + (((((int64_t)num_tokens) - (int64_t)1) % min((int64_t)32, max((int64_t)1, (((((int64_t)num_tokens) + (int64_t)55) / (int64_t)56) + (((((int64_t)num_tokens) + (int64_t)55) % (int64_t)56) >> (int64_t)63))))) >> (int64_t)63)) + (int64_t)1)))) + (((((int64_t)w) * (int64_t)56) + ((int64_t)((int32_t)block_idx))) % max((int64_t)1, min((int64_t)8, ((((((int64_t)num_tokens) - (int64_t)1) / min((int64_t)32, max((int64_t)1, (((((int64_t)num_tokens) + (int64_t)55) / (int64_t)56) + (((((int64_t)num_tokens) + (int64_t)55) % (int64_t)56) >> (int64_t)63))))) + (((((int64_t)num_tokens) - (int64_t)1) % min((int64_t)32, max((int64_t)1, (((((int64_t)num_tokens) + (int64_t)55) / (int64_t)56) + (((((int64_t)num_tokens) + (int64_t)55) % (int64_t)56) >> (int64_t)63))))) >> (int64_t)63)) + (int64_t)1))))) * min((int64_t)32, max((int64_t)1, (((((int64_t)num_tokens) + (int64_t)55) / (int64_t)56) + (((((int64_t)num_tokens) + (int64_t)55) % (int64_t)56) >> (int64_t)63))))) * ((int64_t)unmapped_topk_idx_stride)) * (int64_t)2)]))), min(min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31)))), (num_tokens - ((((((w * 56) + ((int32_t)block_idx)) / max(1, min(8, ((((num_tokens - 1) / min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) + (((num_tokens - 1) % min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) >> 31)) + 1)))) * max(1, min(8, ((((num_tokens - 1) / min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) + (((num_tokens - 1) % min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) >> 31)) + 1)))) + (((w * 56) + ((int32_t)block_idx)) % max(1, min(8, ((((num_tokens - 1) / min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) + (((num_tokens - 1) % min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) >> 31)) + 1))))) * min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))))), 48, 0, 0, 0, static_cast<asc_load_l2_cache_mode>(0), (unmapped_topk_idx_stride * 8), 64);
      }
      asc_sync_notify(PIPE_MTE2, PIPE_V, static_cast<event_t>(0));
      asc_sync_wait(PIPE_MTE2, PIPE_V, static_cast<event_t>(0));
      moe_topk_gate_forward_kernel_asc_kernel_simd_vf_2(buf_dyn_shmem, num_tokens, w, block_idx, force_random_ub_version_counter_1);
      asc_vf_call<moe_topk_gate_forward_kernel_asc_kernel_simt_vf_0>(cce::dim3(1024), num_tokens, w, buf_dyn_shmem, force_random_ub_version_counter_1, ep_rank, num_physical_experts, routed_scaling_factor);
      asc_sync_notify(PIPE_V, PIPE_MTE3, static_cast<event_t>(0));
      asc_sync_wait(PIPE_V, PIPE_MTE3, static_cast<event_t>(0));
      if (0 < (num_tokens - ((((((w * 56) + ((int32_t)block_idx)) / max(1, min(8, ((((num_tokens - 1) / min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) + (((num_tokens - 1) % min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) >> 31)) + 1)))) * max(1, min(8, ((((num_tokens - 1) / min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) + (((num_tokens - 1) % min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) >> 31)) + 1)))) + (((w * 56) + ((int32_t)block_idx)) % max(1, min(8, ((((num_tokens - 1) / min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) + (((num_tokens - 1) % min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) >> 31)) + 1))))) * min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))))) {
        asc_copy_ub2gm_align((__gm__ uint8_t*)((&(((__gm__ int32_t*)unmapped_idx_view)[((((((((((int64_t)w) * (int64_t)56) + ((int64_t)((int32_t)block_idx))) / max((int64_t)1, min((int64_t)8, ((((((int64_t)num_tokens) - (int64_t)1) / min((int64_t)32, max((int64_t)1, (((((int64_t)num_tokens) + (int64_t)55) / (int64_t)56) + (((((int64_t)num_tokens) + (int64_t)55) % (int64_t)56) >> (int64_t)63))))) + (((((int64_t)num_tokens) - (int64_t)1) % min((int64_t)32, max((int64_t)1, (((((int64_t)num_tokens) + (int64_t)55) / (int64_t)56) + (((((int64_t)num_tokens) + (int64_t)55) % (int64_t)56) >> (int64_t)63))))) >> (int64_t)63)) + (int64_t)1)))) * max((int64_t)1, min((int64_t)8, ((((((int64_t)num_tokens) - (int64_t)1) / min((int64_t)32, max((int64_t)1, (((((int64_t)num_tokens) + (int64_t)55) / (int64_t)56) + (((((int64_t)num_tokens) + (int64_t)55) % (int64_t)56) >> (int64_t)63))))) + (((((int64_t)num_tokens) - (int64_t)1) % min((int64_t)32, max((int64_t)1, (((((int64_t)num_tokens) + (int64_t)55) / (int64_t)56) + (((((int64_t)num_tokens) + (int64_t)55) % (int64_t)56) >> (int64_t)63))))) >> (int64_t)63)) + (int64_t)1)))) + (((((int64_t)w) * (int64_t)56) + ((int64_t)((int32_t)block_idx))) % max((int64_t)1, min((int64_t)8, ((((((int64_t)num_tokens) - (int64_t)1) / min((int64_t)32, max((int64_t)1, (((((int64_t)num_tokens) + (int64_t)55) / (int64_t)56) + (((((int64_t)num_tokens) + (int64_t)55) % (int64_t)56) >> (int64_t)63))))) + (((((int64_t)num_tokens) - (int64_t)1) % min((int64_t)32, max((int64_t)1, (((((int64_t)num_tokens) + (int64_t)55) / (int64_t)56) + (((((int64_t)num_tokens) + (int64_t)55) % (int64_t)56) >> (int64_t)63))))) >> (int64_t)63)) + (int64_t)1))))) * min((int64_t)32, max((int64_t)1, (((((int64_t)num_tokens) + (int64_t)55) / (int64_t)56) + (((((int64_t)num_tokens) + (int64_t)55) % (int64_t)56) >> (int64_t)63))))) * ((int64_t)unmapped_topk_idx_stride)) * (int64_t)2)]))), (__ubuf__ uint8_t*)((&(((__ubuf__ int32_t*)buf_dyn_shmem)[(((force_random_ub_version_counter_1 & 1) * 512) + 16384)]))), min(min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31)))), (num_tokens - ((((((w * 56) + ((int32_t)block_idx)) / max(1, min(8, ((((num_tokens - 1) / min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) + (((num_tokens - 1) % min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) >> 31)) + 1)))) * max(1, min(8, ((((num_tokens - 1) / min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) + (((num_tokens - 1) % min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) >> 31)) + 1)))) + (((w * 56) + ((int32_t)block_idx)) % max(1, min(8, ((((num_tokens - 1) / min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) + (((num_tokens - 1) % min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) >> 31)) + 1))))) * min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))))), 48, static_cast<asc_store_l2_cache_mode>(4), (unmapped_topk_idx_stride * 8), 64);
      }
      asc_sync_notify(PIPE_MTE3, PIPE_MTE2, static_cast<event_t>(0));
      asc_sync_pipe(PIPE_MTE3);
      if (0 < (num_tokens - ((((((w * 56) + ((int32_t)block_idx)) / max(1, min(8, ((((num_tokens - 1) / min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) + (((num_tokens - 1) % min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) >> 31)) + 1)))) * max(1, min(8, ((((num_tokens - 1) / min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) + (((num_tokens - 1) % min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) >> 31)) + 1)))) + (((w * 56) + ((int32_t)block_idx)) % max(1, min(8, ((((num_tokens - 1) / min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) + (((num_tokens - 1) % min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) >> 31)) + 1))))) * min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))))) {
        asc_copy_ub2gm_align((__gm__ uint8_t*)((&(topk_weights[(((((((((int64_t)w) * (int64_t)56) + ((int64_t)((int32_t)block_idx))) / max((int64_t)1, min((int64_t)8, ((((((int64_t)num_tokens) - (int64_t)1) / min((int64_t)32, max((int64_t)1, (((((int64_t)num_tokens) + (int64_t)55) / (int64_t)56) + (((((int64_t)num_tokens) + (int64_t)55) % (int64_t)56) >> (int64_t)63))))) + (((((int64_t)num_tokens) - (int64_t)1) % min((int64_t)32, max((int64_t)1, (((((int64_t)num_tokens) + (int64_t)55) / (int64_t)56) + (((((int64_t)num_tokens) + (int64_t)55) % (int64_t)56) >> (int64_t)63))))) >> (int64_t)63)) + (int64_t)1)))) * max((int64_t)1, min((int64_t)8, ((((((int64_t)num_tokens) - (int64_t)1) / min((int64_t)32, max((int64_t)1, (((((int64_t)num_tokens) + (int64_t)55) / (int64_t)56) + (((((int64_t)num_tokens) + (int64_t)55) % (int64_t)56) >> (int64_t)63))))) + (((((int64_t)num_tokens) - (int64_t)1) % min((int64_t)32, max((int64_t)1, (((((int64_t)num_tokens) + (int64_t)55) / (int64_t)56) + (((((int64_t)num_tokens) + (int64_t)55) % (int64_t)56) >> (int64_t)63))))) >> (int64_t)63)) + (int64_t)1)))) + (((((int64_t)w) * (int64_t)56) + ((int64_t)((int32_t)block_idx))) % max((int64_t)1, min((int64_t)8, ((((((int64_t)num_tokens) - (int64_t)1) / min((int64_t)32, max((int64_t)1, (((((int64_t)num_tokens) + (int64_t)55) / (int64_t)56) + (((((int64_t)num_tokens) + (int64_t)55) % (int64_t)56) >> (int64_t)63))))) + (((((int64_t)num_tokens) - (int64_t)1) % min((int64_t)32, max((int64_t)1, (((((int64_t)num_tokens) + (int64_t)55) / (int64_t)56) + (((((int64_t)num_tokens) + (int64_t)55) % (int64_t)56) >> (int64_t)63))))) >> (int64_t)63)) + (int64_t)1))))) * min((int64_t)32, max((int64_t)1, (((((int64_t)num_tokens) + (int64_t)55) / (int64_t)56) + (((((int64_t)num_tokens) + (int64_t)55) % (int64_t)56) >> (int64_t)63))))) * (int64_t)6)]))), (__ubuf__ uint8_t*)((&(((__ubuf__ float*)buf_dyn_shmem)[(((force_random_ub_version_counter_1 & 1) * 256) + 18432)]))), min(min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31)))), (num_tokens - ((((((w * 56) + ((int32_t)block_idx)) / max(1, min(8, ((((num_tokens - 1) / min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) + (((num_tokens - 1) % min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) >> 31)) + 1)))) * max(1, min(8, ((((num_tokens - 1) / min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) + (((num_tokens - 1) % min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) >> 31)) + 1)))) + (((w * 56) + ((int32_t)block_idx)) % max(1, min(8, ((((num_tokens - 1) / min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) + (((num_tokens - 1) % min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) >> 31)) + 1))))) * min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))))), 24, static_cast<asc_store_l2_cache_mode>(4), 24, 32);
      }
      asc_sync_pipe(PIPE_MTE3);
      if (0 < (num_tokens - ((((((w * 56) + ((int32_t)block_idx)) / max(1, min(8, ((((num_tokens - 1) / min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) + (((num_tokens - 1) % min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) >> 31)) + 1)))) * max(1, min(8, ((((num_tokens - 1) / min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) + (((num_tokens - 1) % min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) >> 31)) + 1)))) + (((w * 56) + ((int32_t)block_idx)) % max(1, min(8, ((((num_tokens - 1) / min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) + (((num_tokens - 1) % min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) >> 31)) + 1))))) * min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))))) {
        asc_copy_ub2gm_align((__gm__ uint8_t*)((&(((__gm__ int32_t*)topk_idx_view)[(((((((((int64_t)w) * (int64_t)56) + ((int64_t)((int32_t)block_idx))) / max((int64_t)1, min((int64_t)8, ((((((int64_t)num_tokens) - (int64_t)1) / min((int64_t)32, max((int64_t)1, (((((int64_t)num_tokens) + (int64_t)55) / (int64_t)56) + (((((int64_t)num_tokens) + (int64_t)55) % (int64_t)56) >> (int64_t)63))))) + (((((int64_t)num_tokens) - (int64_t)1) % min((int64_t)32, max((int64_t)1, (((((int64_t)num_tokens) + (int64_t)55) / (int64_t)56) + (((((int64_t)num_tokens) + (int64_t)55) % (int64_t)56) >> (int64_t)63))))) >> (int64_t)63)) + (int64_t)1)))) * max((int64_t)1, min((int64_t)8, ((((((int64_t)num_tokens) - (int64_t)1) / min((int64_t)32, max((int64_t)1, (((((int64_t)num_tokens) + (int64_t)55) / (int64_t)56) + (((((int64_t)num_tokens) + (int64_t)55) % (int64_t)56) >> (int64_t)63))))) + (((((int64_t)num_tokens) - (int64_t)1) % min((int64_t)32, max((int64_t)1, (((((int64_t)num_tokens) + (int64_t)55) / (int64_t)56) + (((((int64_t)num_tokens) + (int64_t)55) % (int64_t)56) >> (int64_t)63))))) >> (int64_t)63)) + (int64_t)1)))) + (((((int64_t)w) * (int64_t)56) + ((int64_t)((int32_t)block_idx))) % max((int64_t)1, min((int64_t)8, ((((((int64_t)num_tokens) - (int64_t)1) / min((int64_t)32, max((int64_t)1, (((((int64_t)num_tokens) + (int64_t)55) / (int64_t)56) + (((((int64_t)num_tokens) + (int64_t)55) % (int64_t)56) >> (int64_t)63))))) + (((((int64_t)num_tokens) - (int64_t)1) % min((int64_t)32, max((int64_t)1, (((((int64_t)num_tokens) + (int64_t)55) / (int64_t)56) + (((((int64_t)num_tokens) + (int64_t)55) % (int64_t)56) >> (int64_t)63))))) >> (int64_t)63)) + (int64_t)1))))) * min((int64_t)32, max((int64_t)1, (((((int64_t)num_tokens) + (int64_t)55) / (int64_t)56) + (((((int64_t)num_tokens) + (int64_t)55) % (int64_t)56) >> (int64_t)63))))) * (int64_t)12)]))), (__ubuf__ uint8_t*)((&(((__ubuf__ int32_t*)buf_dyn_shmem)[(((force_random_ub_version_counter_1 & 1) * 512) + 17408)]))), min(min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31)))), (num_tokens - ((((((w * 56) + ((int32_t)block_idx)) / max(1, min(8, ((((num_tokens - 1) / min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) + (((num_tokens - 1) % min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) >> 31)) + 1)))) * max(1, min(8, ((((num_tokens - 1) / min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) + (((num_tokens - 1) % min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) >> 31)) + 1)))) + (((w * 56) + ((int32_t)block_idx)) % max(1, min(8, ((((num_tokens - 1) / min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) + (((num_tokens - 1) % min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) >> 31)) + 1))))) * min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))))), 48, static_cast<asc_store_l2_cache_mode>(4), 48, 64);
      }
      asc_sync_pipe(PIPE_MTE3);
      if (0 < (num_tokens - ((((((w * 56) + ((int32_t)block_idx)) / max(1, min(8, ((((num_tokens - 1) / min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) + (((num_tokens - 1) % min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) >> 31)) + 1)))) * max(1, min(8, ((((num_tokens - 1) / min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) + (((num_tokens - 1) % min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) >> 31)) + 1)))) + (((w * 56) + ((int32_t)block_idx)) % max(1, min(8, ((((num_tokens - 1) / min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) + (((num_tokens - 1) % min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) >> 31)) + 1))))) * min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))))) {
        asc_copy_ub2gm_align((__gm__ uint8_t*)((&(scores[(((((((((int64_t)w) * (int64_t)56) + ((int64_t)((int32_t)block_idx))) / max((int64_t)1, min((int64_t)8, ((((((int64_t)num_tokens) - (int64_t)1) / min((int64_t)32, max((int64_t)1, (((((int64_t)num_tokens) + (int64_t)55) / (int64_t)56) + (((((int64_t)num_tokens) + (int64_t)55) % (int64_t)56) >> (int64_t)63))))) + (((((int64_t)num_tokens) - (int64_t)1) % min((int64_t)32, max((int64_t)1, (((((int64_t)num_tokens) + (int64_t)55) / (int64_t)56) + (((((int64_t)num_tokens) + (int64_t)55) % (int64_t)56) >> (int64_t)63))))) >> (int64_t)63)) + (int64_t)1)))) * max((int64_t)1, min((int64_t)8, ((((((int64_t)num_tokens) - (int64_t)1) / min((int64_t)32, max((int64_t)1, (((((int64_t)num_tokens) + (int64_t)55) / (int64_t)56) + (((((int64_t)num_tokens) + (int64_t)55) % (int64_t)56) >> (int64_t)63))))) + (((((int64_t)num_tokens) - (int64_t)1) % min((int64_t)32, max((int64_t)1, (((((int64_t)num_tokens) + (int64_t)55) / (int64_t)56) + (((((int64_t)num_tokens) + (int64_t)55) % (int64_t)56) >> (int64_t)63))))) >> (int64_t)63)) + (int64_t)1)))) + (((((int64_t)w) * (int64_t)56) + ((int64_t)((int32_t)block_idx))) % max((int64_t)1, min((int64_t)8, ((((((int64_t)num_tokens) - (int64_t)1) / min((int64_t)32, max((int64_t)1, (((((int64_t)num_tokens) + (int64_t)55) / (int64_t)56) + (((((int64_t)num_tokens) + (int64_t)55) % (int64_t)56) >> (int64_t)63))))) + (((((int64_t)num_tokens) - (int64_t)1) % min((int64_t)32, max((int64_t)1, (((((int64_t)num_tokens) + (int64_t)55) / (int64_t)56) + (((((int64_t)num_tokens) + (int64_t)55) % (int64_t)56) >> (int64_t)63))))) >> (int64_t)63)) + (int64_t)1))))) * min((int64_t)32, max((int64_t)1, (((((int64_t)num_tokens) + (int64_t)55) / (int64_t)56) + (((((int64_t)num_tokens) + (int64_t)55) % (int64_t)56) >> (int64_t)63))))) * (int64_t)72)]))), (__ubuf__ uint8_t*)((&(((__ubuf__ float*)buf_dyn_shmem)[(((force_random_ub_version_counter_1 & 1) * 4096) + 8192)]))), min(min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31)))), (num_tokens - ((((((w * 56) + ((int32_t)block_idx)) / max(1, min(8, ((((num_tokens - 1) / min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) + (((num_tokens - 1) % min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) >> 31)) + 1)))) * max(1, min(8, ((((num_tokens - 1) / min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) + (((num_tokens - 1) % min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) >> 31)) + 1)))) + (((w * 56) + ((int32_t)block_idx)) % max(1, min(8, ((((num_tokens - 1) / min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) + (((num_tokens - 1) % min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))) >> 31)) + 1))))) * min(32, max(1, (((num_tokens + 55) / 56) + (((num_tokens + 55) % 56) >> 31))))))), 288, static_cast<asc_store_l2_cache_mode>(4), 288, 512);
      }
      force_random_ub_version_counter_1 = (force_random_ub_version_counter_1 + 1);
    }
  }
  moe_topk_gate_forward_kernel_asc_kernel_simd_vf_3(buf_dyn_shmem);
  asc_sync_notify(PIPE_V, PIPE_S, static_cast<event_t>(0));
  asc_sync_wait(PIPE_V, PIPE_S, static_cast<event_t>(0));
  device_assert_with_msg((((__ubuf__ int32_t*)buf_dyn_shmem)[19200] == 0), "moe_topk_gate_forward input contains nan or inf or kernel has internal error!\n  at \/workspace\/tilekernels-env-20261101\/src\/TileKernels-private\/tile_kernels\/moe\/moe_topk_gate_forward_asc.py:278 in moe_topk_gate_forward_kernel_asc\n");
  asc_sync_wait(PIPE_MTE3, PIPE_MTE2, static_cast<event_t>(0));
}

