#!/usr/bin/env bash
set -Eeo pipefail
r=/workspace/expert-profile-backfill-20261109-hidev
out="$r/official-post04-reference-20261111"
envdir=/workspace/tilekernels-env-20261101
repo="$envdir/src/TileKernels-private"
unset LD_LIBRARY_PATH PYTHONPATH LD_PRELOAD MEMORYCHART_ROOT MEMORYCHART_LOG
source "$envdir/activate.sh"
export PYTHONPATH="$repo" TILEKERNELS_ROOT="$repo" TILELANG_DEFAULT_TARGET=ascend ASCEND_RT_VISIBLE_DEVICES=0
export TILELANG_CACHE_DIR="$out/cache" PYTHONDONTWRITEBYTECODE=1 OMP_NUM_THREADS=8
[[ "$(git -C "$repo" rev-parse HEAD)" = bb866a442c59464902dc2e93916ceea82e7471d9 ]]
[[ -z "$(git -C "$repo" status --porcelain --untracked-files=no)" ]]
exec 9>/workspace/.puma-hidev-npu0.lock
flock -w 600 9
npu-smi info -t proc-mem -i 0 > "$out/device-before.txt"
grep -q 'No process in device' "$out/device-before.txt"
git -C "$repo" rev-parse HEAD > "$out/commit.txt"
src="$repo/research/ascend-profiling/reviews/20261107-replay-debug/post_compare.py"
sed "s|root=Path('/workspace/tilekernels-replay-watch-20261107')|root=Path('$out')|; s/if any(r\['mismatch'\] for v in totals.values() for r in v):/if any(r['mismatch'] for r in totals['npu']):/" "$src" > "$out/check.py"
python -B "$out/check.py"
