#!/usr/bin/env bash
set -Eeo pipefail
r=/workspace/expert-profile-backfill-20261109-hidev
out="$r/official-precision-reference-20261111"
envdir=/workspace/tilekernels-env-20261101
repo="$envdir/src/TileKernels-private"
unset LD_LIBRARY_PATH PYTHONPATH LD_PRELOAD MEMORYCHART_ROOT MEMORYCHART_LOG
source "$envdir/activate.sh"
export PYTHONPATH="$repo" TILEKERNELS_ROOT="$repo" TILELANG_DEFAULT_TARGET=ascend ASCEND_RT_VISIBLE_DEVICES=0
export TILELANG_CACHE_DIR="$out/cache" PYTHONDONTWRITEBYTECODE=1
[[ "$(git -C "$repo" rev-parse HEAD)" = bb866a442c59464902dc2e93916ceea82e7471d9 ]]
[[ -z "$(git -C "$repo" status --porcelain --untracked-files=no)" ]]
exec 9>/workspace/.puma-hidev-npu0.lock
flock -n 9
npu-smi info -t proc-mem -i 0 > "$out/device-before.txt"
grep -q 'No process in device' "$out/device-before.txt"
git -C "$repo" rev-parse HEAD > "$out/commit.txt"
python -B "$out/check.py" "$repo/research/ascend-profiling/reviews/20261107-finalize" "$r" "$out" normalize-03 normalize-16 normalize-20 mhc_pre_apply_mix_bwd-09
