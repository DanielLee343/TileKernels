"""Create exact disjoint byte intervals for a non-overlapping strided tensor."""
import itertools,math

def intervals(shape,strides,size,base):
    assert shape and len(shape)==len(strides) and size>0 and base>=0
    assert all(n>0 for n in shape) and all(s>=0 for s in strides)
    axes=sorted((s,n) for n,s in zip(shape,strides) if n>1)
    run=1;position=0
    while position<len(axes) and axes[position][0]==run:
        run*=axes[position][1];position+=1
    remaining=axes[position:];assert math.prod(n for _,n in remaining)<=1000000
    spans=[]
    for coord in itertools.product(*(range(n) for _,n in remaining)):
        lo=base+size*sum(c*s for c,(s,_) in zip(coord,remaining));spans.append((lo,lo+size*run))
    out=[]
    for lo,hi in sorted(spans):
        if out:assert out[-1][1]<=lo,'overlapping tensor layout'
        if out and out[-1][1]==lo:out[-1]=(out[-1][0],hi)
        else:out.append((lo,hi))
    assert sum(hi-lo for lo,hi in out)==math.prod(shape)*size
    return out
