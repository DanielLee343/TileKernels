"""Verify interval representation exactly matches strided tensor elements."""
import itertools,random
from strided_tensor_intervals import intervals

def brute(shape,strides,size,base):
 spans=[]
 for coord in itertools.product(*(range(n) for n in shape)):
  lo=base+size*sum(c*s for c,s in zip(coord,strides));spans.extend(range(lo,lo+size))
 assert len(set(spans))==len(spans),'overlapping tensor fixture'
 return set(spans)
for shape,strides in [([2,3],[3,1]),([2,3,2],[6,1,3]),([2,2],[4,1]),([1,5],[5,1]),([3],[2])]:
 for size in (1,2,4):
  got=intervals(shape,strides,size,1000);actual={x for lo,hi in got for x in range(lo,hi)};assert actual==brute(shape,strides,size,1000)
try:intervals([2,2],[1,1],2,1000)
except AssertionError:pass
else:raise AssertionError('overlapping layout was accepted')
rng=random.Random(103)
for _ in range(500):
 shape=[rng.randint(1,4) for _ in range(3)];axes=list(range(3));rng.shuffle(axes);strides=[0]*3;step=1
 for a in axes:strides[a]=step;step*=shape[a];step+=rng.randint(0,2)
 got=intervals(shape,strides,2,8000);assert {x for lo,hi in got for x in range(lo,hi)}==brute(shape,strides,2,8000)
print('PASS strided intervals match element-level addresses and reject overlaps')
