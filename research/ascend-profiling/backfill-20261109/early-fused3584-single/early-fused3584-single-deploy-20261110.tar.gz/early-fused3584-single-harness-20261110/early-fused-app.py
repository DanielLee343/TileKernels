"""Reproduce one old single-call castback, one record per replay process."""
import hashlib,json,os,sys,traceback
from pathlib import Path
import collect
root=Path(__file__).resolve().parent
out=Path(sys.argv[1]);pid=os.getpid();record=out/f'application-{pid}.json';state={'status':'running','pid':pid}
def save():record.write_text(json.dumps(state,indent=2)+'\n',encoding='utf8')
def tensor(t):
 return {'address':hex(t.data_ptr()),'device':str(t.device),'shape':list(t.shape),'stride':list(t.stride()),'dtype':str(t.dtype),'element_size':t.element_size(),'logical_bytes':t.numel()*t.element_size()}
try:
 import torch,torch_npu
 torch.set_num_threads(min(8,os.cpu_count() or 1));torch.npu.set_device(0)
 case=json.loads((root/'case.json').read_text());kernel,host,device,expected=collect.build(case,torch)
 outputs=tuple(torch.empty_like(x,device='npu:0') for x in expected)
 source=kernel.get_kernel_source();sf=out/f'generated-kernel-{pid}.cpp';sf.write_text(source)
 addresses={'inputs':[tensor(x) for x in device],'outputs':[tensor(x) for x in outputs]};af=out/f'tensor-addresses-{pid}.json';af.write_text(json.dumps(addresses,indent=2)+'\n')
 state.update(runtime_kernel=str(kernel.prim_func.attrs['global_symbol'])+'_kernel',source_sha256=hashlib.sha256(source.encode()).hexdigest(),inputs=[collect.describe(x,True) for x in host],device_inputs=[collect.describe(x) for x in device],outputs=[collect.describe(x) for x in outputs])
 def launch():kernel(*device,*outputs)
 collect.target_range(torch,launch)
 state['precision']=collect.compare(torch,outputs,expected,case['family']);assert all(x['passed'] for x in state['precision'])
 state['status']='passed';save()
except BaseException:
 state.update(status='failed',error=traceback.format_exc());save();raise
