#include <tl_templates/ascend/common.h>
#include <tl_templates/ascend/debug.h>
#include <tl_templates/ascend/philox_rng.h>
__simt_vf__ __launch_bounds__(512) inline void randn_kernel_asc_kernel_simt_vf_0(int64_t w, int64_t seed, __ubuf__ bfloat16_t* output_ub) {
  tl::AscendPhiloxState __asc_rng_state;
  tl::philox_init(&__asc_rng_state, (((w * (int64_t)56) + seed) + ((int64_t)((int32_t)block_idx))), ((((int32_t)block_idx) * 512) + ((int32_t)threadIdx.x)), 0);
  #pragma unroll 4
  for (int32_t serial = 0; serial < 4; ++serial) {
    bfloat16_t output_ub_local_cast[2];
    uint1 _;
      float2 v_ = tl::philox_rand_normal2(&__asc_rng_state);
      (reinterpret_cast<bfloat16x2_t*>(&_))[0] = __float22bfloat162_rn(((float2*)(&v_))[0]);
    *(uint1*)(output_ub_local_cast + 0) = _;
    *(__ubuf__ uint1*)(output_ub + ((serial * 1024) + (((int32_t)threadIdx.x) * 2))) = *(uint1*)(output_ub_local_cast + 0);
  }
}

extern "C" __global__ __vector__ void randn_kernel_asc_kernel(__gm__ bfloat16_t* output, int64_t n, int64_t seed) {
  asc_init();
  __ubuf__ bfloat16_t *output_ub = (__ubuf__ bfloat16_t *)0;
  asc_sync_notify(PIPE_MTE3, PIPE_V, static_cast<event_t>(0));
  for (int64_t w = (int64_t)0; w < ((n + (int64_t)229375) / (int64_t)229376); ++w) {
    if (((w * (int64_t)56) + ((int64_t)((int32_t)block_idx))) < ((n + (int64_t)4095) >> (int64_t)12)) {
      asc_sync_wait(PIPE_MTE3, PIPE_V, static_cast<event_t>(0));
      asc_vf_call<randn_kernel_asc_kernel_simt_vf_0>(cce::dim3(512), w, seed, output_ub);
      asc_sync_notify(PIPE_V, PIPE_MTE3, static_cast<event_t>(0));
      asc_sync_wait(PIPE_V, PIPE_MTE3, static_cast<event_t>(0));
      asc_copy_ub2gm_align((__gm__ uint8_t*)((&(output[((w * (int64_t)229376) + (((int64_t)((int32_t)block_idx)) * (int64_t)4096))]))), (__ubuf__ uint8_t*)((&(output_ub[0]))), 1, (min((int64_t)4096, max(((n - (((int64_t)((int32_t)block_idx)) * (int64_t)4096)) - (w * (int64_t)229376)), (int64_t)0)) * (int64_t)2), static_cast<asc_store_l2_cache_mode>(4), (min((int64_t)4096, max(((n - (((int64_t)((int32_t)block_idx)) * (int64_t)4096)) - (w * (int64_t)229376)), (int64_t)0)) * (int64_t)2), (min((int64_t)4096, max(((n - (((int64_t)((int32_t)block_idx)) * (int64_t)4096)) - (w * (int64_t)229376)), (int64_t)0)) * (int64_t)2));
      asc_sync_notify(PIPE_MTE3, PIPE_V, static_cast<event_t>(0));
    }
  }
  asc_sync_wait(PIPE_MTE3, PIPE_V, static_cast<event_t>(0));
}

